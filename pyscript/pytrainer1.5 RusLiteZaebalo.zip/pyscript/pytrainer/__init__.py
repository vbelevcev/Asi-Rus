"""Pytrainer for PyLoaderV 0.6."""
__version__ = "2.0.0-pyloaderv06"
