"""Pytrainer main callbacks for PyLoaderV 0.6."""

import gta

from pytrainer.Lib import (
    animation_functions,
    config,
    player_functions,
    weapon_functions,
    world_functions,
)
from pytrainer.Lib.menu_script import TrainerMenu

INTERVAL_MS = 0
__priority__ = 50

menu = None
_keys_down: set[int] = set()


def on_start():
    global menu
    try:
        config.load_ini()
        weapon_functions.init_weapon_data()
        TrainerMenu.reset()
        menu = TrainerMenu.get_instance()
        gta.notify("~g~Pytrainer loaded for PyLoaderV 0.6")
        gta.notify("~b~Press {} to open menu".format(config.MENU_KEY_NAME))
    except Exception as exc:
        gta.notify("~r~Pytrainer init error: {}".format(exc))
        gta.log("error", "Pytrainer init error: {!r}".format(exc))


def on_tick():
    try:
        player_functions.tick_update()
        weapon_functions.tick_update()
        world_functions.tick_update()
        if menu is not None:
            menu.tick()
    except Exception as exc:
        gta.log("error", "Pytrainer tick error: {!r}".format(exc))


def on_key_down(vk, down, shift, ctrl, alt):
    try:
        vk = int(vk)
        player_functions.handle_key_state(vk, down)
        if not down:
            _keys_down.discard(vk)
            return
        if vk in _keys_down:
            return
        _keys_down.add(vk)
        if menu is None:
            return
        if vk == config.MENU_KEY:
            menu.toggle()
            return
        if menu.is_visible():
            menu.handle_key(vk)
    except Exception as exc:
        gta.log("error", "Pytrainer key error: {!r}".format(exc))


def on_aborted():
    global menu
    try:
        try:
            animation_functions.stop_animation()
        except Exception:
            pass
        TrainerMenu.reset()
        player_functions.reset_runtime_state()
        weapon_functions.reset_runtime_state()
        world_functions.reset_runtime_state()
        _keys_down.clear()
        menu = None
        gta.notify("~y~Pytrainer unloaded.")
    except Exception:
        pass
