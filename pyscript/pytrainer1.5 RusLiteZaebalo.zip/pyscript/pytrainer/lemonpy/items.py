"""Native menu items ported from LemonUI."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List, Optional

from lemonpy.alignment import Alignment
from lemonpy.color_set import ColorSet
from lemonpy.scaled_text import ScaledText


ITEM_OFFSET_X = 6.0
ITEM_OFFSET_Y = 3.0


class NativeItem:
    """A row in a NativeMenu. Mirrors LemonUI's NativeItem layout."""

    def __init__(self, title: str, description: str = "", alt_title: str = "") -> None:
        self.title_text = ScaledText(title, scale=0.345)
        self.alt_title_text = ScaledText(alt_title, scale=0.345, alignment=Alignment.RIGHT)
        self.description = description or ""
        self.enabled = True
        self.colors = ColorSet()
        self.on_activated: List[Callable[[], None]] = []
        self._last_selected = False
        self._last_x = 0.0
        self._last_y = 0.0
        self._last_width = 0.0
        self._last_height = 0.0

    @property
    def title(self) -> str:
        return self.title_text.text

    @title.setter
    def title(self, value: str) -> None:
        self.title_text.text = str(value)

    @property
    def alt_title(self) -> str:
        return self.alt_title_text.text

    @alt_title.setter
    def alt_title(self, value: str) -> None:
        self.alt_title_text.text = str(value)

    def activated(self, callback: Callable[[], None]):
        self.on_activated.append(callback)
        return callback

    def recalculate(self, x: float, y: float, width: float, height: float, selected: bool) -> None:
        self._last_x = x
        self._last_y = y
        self._last_width = width
        self._last_height = height
        self._last_selected = bool(selected)
        self.title_text.set_position(x + ITEM_OFFSET_X, y + ITEM_OFFSET_Y)
        self.alt_title_text.set_position(x + width - ITEM_OFFSET_X, y + ITEM_OFFSET_Y)
        self._apply_colors()

    def _apply_colors(self) -> None:
        if not self.enabled:
            self.title_text.color = self.colors.title_disabled
            self.alt_title_text.color = self.colors.alt_title_disabled
        elif self._last_selected:
            self.title_text.color = self.colors.title_hovered
            self.alt_title_text.color = self.colors.alt_title_hovered
        else:
            self.title_text.color = self.colors.title_normal
            self.alt_title_text.color = self.colors.alt_title_normal

    def draw(self) -> None:
        self.title_text.draw()
        if self.alt_title_text.text:
            self.alt_title_text.draw()

    def activate(self, pool) -> None:
        if not self.enabled:
            from lemonpy.sound import DEFAULT_DISABLED
            DEFAULT_DISABLED.play_frontend()
            return
        for callback in list(self.on_activated):
            pool.enqueue(callback)

    def adjust(self, pool, delta: int) -> bool:
        return False


class NativeCheckboxItem(NativeItem):
    def __init__(self, title: str, description: str = "", checked: bool = False) -> None:
        super().__init__(title, description)
        self.checked = bool(checked)
        self.on_changed: List[Callable[[bool], None]] = []
        self._refresh_alt()

    def changed(self, callback: Callable[[bool], None]):
        self.on_changed.append(callback)
        return callback

    def _refresh_alt(self) -> None:
        self.alt_title = "[ON]" if self.checked else "[OFF]"

    def activate(self, pool) -> None:
        if not self.enabled:
            from lemonpy.sound import DEFAULT_DISABLED
            DEFAULT_DISABLED.play_frontend()
            return
        self.checked = not self.checked
        self._refresh_alt()
        for callback in list(self.on_changed):
            pool.enqueue(lambda cb=callback, value=self.checked: cb(value))


class NativeSliderItem(NativeItem):
    def __init__(self, title: str, description: str = "", minimum: int = 0,
                 maximum: int = 10, value: int = 0, step: int = 1) -> None:
        super().__init__(title, description)
        self.minimum = int(minimum)
        self.maximum = int(maximum)
        self.value = int(value)
        self.step = max(1, int(step))
        self.on_changed: List[Callable[[int], None]] = []
        self._refresh_alt()

    def changed(self, callback: Callable[[int], None]):
        self.on_changed.append(callback)
        return callback

    def _refresh_alt(self) -> None:
        self.alt_title = f"< {self.value} >"

    def adjust(self, pool, delta: int) -> bool:
        if not self.enabled:
            return False
        new_value = max(self.minimum, min(self.maximum, self.value + delta * self.step))
        if new_value == self.value:
            return False
        self.value = new_value
        self._refresh_alt()
        for callback in list(self.on_changed):
            pool.enqueue(lambda cb=callback, value=self.value: cb(value))
        return True


class NativeListItem(NativeItem):
    def __init__(self, title: str, description: str = "", values: Optional[list] = None,
                 selected_index: int = 0) -> None:
        super().__init__(title, description)
        self.values = list(values or [])
        self.selected_index = int(selected_index)
        self.on_changed: List[Callable[[object], None]] = []
        self._refresh_alt()

    def changed(self, callback: Callable[[object], None]):
        self.on_changed.append(callback)
        return callback

    @property
    def selected_item(self):
        if not self.values:
            return None
        return self.values[self.selected_index % len(self.values)]

    def _refresh_alt(self) -> None:
        item = self.selected_item
        if item is None:
            self.alt_title = ""
            return
        label = item[0] if isinstance(item, tuple) else str(item)
        self.alt_title = f"< {label} >"

    def adjust(self, pool, delta: int) -> bool:
        if not self.enabled or not self.values:
            return False
        self.selected_index = (self.selected_index + delta) % len(self.values)
        self._refresh_alt()
        for callback in list(self.on_changed):
            pool.enqueue(lambda cb=callback, item=self.selected_item: cb(item))
        return True

    def activate(self, pool) -> None:
        if not self.enabled:
            from lemonpy.sound import DEFAULT_DISABLED
            DEFAULT_DISABLED.play_frontend()
            return
        if self.selected_item is None:
            return
        for callback in list(self.on_changed):
            pool.enqueue(lambda cb=callback, item=self.selected_item: cb(item))


class NativeSubmenuItem(NativeItem):
    def __init__(self, submenu, title: str = "", description: str = "") -> None:
        super().__init__(title or submenu.subtitle or submenu.title, description)
        self.submenu = submenu
        self.alt_title = ">>>"

    def activate(self, pool) -> None:
        if not self.enabled or self.submenu is None:
            return
        pool.open(self.submenu, sound=None)
