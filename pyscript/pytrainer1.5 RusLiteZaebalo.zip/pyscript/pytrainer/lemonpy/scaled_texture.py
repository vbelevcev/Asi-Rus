"""1080p sprite that draws via DRAW_SPRITE.

Mirrors LemonUI's ScaledTexture: requests the texture dict on creation,
keeps it loaded across draws, and shifts the relative position to the
center because GTA's DRAW_SPRITE uses center-anchored positions.
"""

from __future__ import annotations

from gta.natives import graphics

from lemonpy.base_element import BaseElement, Color


class ScaledTexture(BaseElement):
    _loaded_dicts: set[str] = set()
    _requested_dicts: set[str] = set()

    def __init__(self, dictionary: str, texture: str,
                 x: float = 0.0, y: float = 0.0,
                 width: float = 0.0, height: float = 0.0,
                 color: Color | None = None) -> None:
        self.dictionary = str(dictionary)
        self.texture = str(texture)
        super().__init__(x, y, width, height, color)
        self.preload(self.dictionary)

    def recalculate(self) -> None:
        super().recalculate()
        self.relative_x += self.relative_width * 0.5
        self.relative_y += self.relative_height * 0.5

    @classmethod
    def preload(cls, dictionary: str) -> bool:
        """Request a texture dictionary once and cache the loaded state.

        Native texture dictionaries are global. Once a dictionary reports as
        loaded, avoid polling/requesting it every frame for every sprite; that
        keeps Lemonpy closer to LemonUI's long-lived ScaledTexture behavior and
        avoids tiny streaming hiccups in menus.
        """
        dictionary = str(dictionary)
        if dictionary in cls._loaded_dicts:
            return True
        try:
            if graphics.HAS_STREAMED_TEXTURE_DICT_LOADED(dictionary):
                cls._loaded_dicts.add(dictionary)
                return True
            if dictionary not in cls._requested_dicts:
                graphics.REQUEST_STREAMED_TEXTURE_DICT(dictionary, True)
                cls._requested_dicts.add(dictionary)
        except Exception:
            pass
        return False

    def _loaded(self) -> bool:
        return self.preload(self.dictionary)

    def draw(self) -> None:
        if self.literal_width <= 0.0 or self.literal_height <= 0.0:
            return
        if not self._loaded():
            return
        graphics.DRAW_SPRITE(
            self.dictionary, self.texture,
            self.relative_x, self.relative_y,
            self.relative_width, self.relative_height,
            self.heading,
            self.color.r, self.color.g, self.color.b, self.color.a,
            False, 0,
        )
