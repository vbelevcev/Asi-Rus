"""GTA V text fonts used by LemonUI."""

from enum import IntEnum


class Font(IntEnum):
    CHALET_LONDON = 0
    HOUSE_SCRIPT = 1
    MONOSPACE = 2
    CHALET_COMPRIME_COLOGNE = 4
    PRICEDOWN = 7
