"""1080p rectangle that draws via DRAW_RECT.

GTA's DRAW_RECT positions a rectangle by its CENTER, so we shift the
relative position by half the size after computing the relative values,
matching LemonUI's ScaledRectangle.Recalculate().
"""

from __future__ import annotations

from gta.natives import graphics

from lemonpy.base_element import BaseElement


class ScaledRectangle(BaseElement):
    def recalculate(self) -> None:
        super().recalculate()
        self.relative_x += self.relative_width * 0.5
        self.relative_y += self.relative_height * 0.5

    def draw(self) -> None:
        if self.literal_width <= 0.0 or self.literal_height <= 0.0:
            return
        graphics.DRAW_RECT(
            self.relative_x, self.relative_y,
            self.relative_width, self.relative_height,
            self.color.r, self.color.g, self.color.b, self.color.a,
            False,
        )
