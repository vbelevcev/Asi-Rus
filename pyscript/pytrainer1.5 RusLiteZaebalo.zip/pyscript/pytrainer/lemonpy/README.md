# Lemonpy 0.1

Lemonpy is a Python port of LemonUI for PyLoaderV 0.6.

It is a pure Python rewrite that uses the same Rockstar-style menu look as
LemonUI: bright `interaction_bgd` banner, black subtitle bar with the page
name and item counter, `commonmenu/gradient_bgd` menu body, `gradient_nav`
selection highlight, ChaletLondon body text, frontend menu sounds.

Original LemonUI project (.NET): https://github.com/LemonUIbyLemon/LemonUI

## Install

Copy the `lemonpy` folder into your GTA V `pyscript` folder so that PyLoaderV
can import it:

```text
pyscript/
  lemonpy/
  your_script.py
```

## Minimal Usage

```python
import gta
from lemonpy import (
    NativeCheckboxItem,
    NativeItem,
    NativeMenu,
    ObjectPool,
)

pool = ObjectPool()
menu = NativeMenu("LEMONPY", "MAIN MENU")
pool.add(menu)

hello = NativeItem("Say hello", "Show a notification")
hello.on_activated.append(lambda: gta.notify("Hello"))
menu.add(hello)

toggle = NativeCheckboxItem("Example toggle")
toggle.on_changed.append(lambda enabled: gta.notify(f"Toggle: {enabled}"))
menu.add(toggle)

_keys_down = set()


def on_tick():
    pool.process()


def on_key_down(vk, down, shift, ctrl, alt):
    vk = int(vk)
    if not down:
        _keys_down.discard(vk)
        return
    if vk in _keys_down:
        return
    _keys_down.add(vk)
    if vk == 0x76:  # F7
        pool.toggle(menu)
    elif pool.visible:
        pool.handle_key(vk)
```

## Public API (0.1)

Drawables:

- `Color`, `ScaledRectangle`, `ScaledTexture`, `ScaledText`
- `Alignment`, `Font`

Menu types:

- `ObjectPool` / `Pool`
- `NativeMenu`
- `NativeItem`
- `NativeCheckboxItem`
- `NativeSliderItem`
- `NativeListItem`
- `NativeSubmenuItem`

Other:

- `Sound`, `KeyboardInput`
- `text_input(prompt, callback)`, `number_input(prompt, callback)`
- `VK` keycode dictionary

## Not Yet In 0.1

- Mouse / cursor hover support and `RotateCamera`
- Scaleform components (`InstructionalButtons`, `BigMessage`, panels)
- Badges, `BadgeSet`
- Panels (`NativePanel`, `NativeColorPanel`, `NativeGridPanel`, `NativeStatsPanel`)
- Generic `NativeListItem<T>` reflection helpers
- Safe-zone aware layout
- Held-key auto-repeat for navigation
