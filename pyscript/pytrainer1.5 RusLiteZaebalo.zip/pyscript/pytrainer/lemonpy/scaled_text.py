"""1080p text drawer following LemonUI's ScaledText behavior."""

from __future__ import annotations

from gta.natives import hud

from lemonpy.alignment import Alignment
from lemonpy.base_element import Color, WHITESMOKE
from lemonpy.font import Font
from lemonpy.screen import to_x_relative, to_y_relative

CHUNK_SIZE = 90
_TEXT_ENTRY = b"CELL_EMAIL_BCON"


class ScaledText:
    def __init__(self, text: str = "", x: float = 0.0, y: float = 0.0,
                 scale: float = 0.345, font: Font = Font.CHALET_LONDON,
                 alignment: Alignment = Alignment.LEFT, color: Color | None = None,
                 outline: bool = False, shadow: bool = False,
                 word_wrap: float = 0.0) -> None:
        self.text = str(text)
        self.scale = float(scale)
        self.font = Font(int(font))
        self.alignment = Alignment(int(alignment))
        self.color = color if color is not None else Color(WHITESMOKE.r, WHITESMOKE.g, WHITESMOKE.b, WHITESMOKE.a)
        self.outline = bool(outline)
        self.shadow = bool(shadow)
        self.word_wrap = float(word_wrap)
        self.literal_x = float(x)
        self.literal_y = float(y)
        self.relative_x = 0.0
        self.relative_y = 0.0
        self.real_wrap = 0.0
        # Keep component byte buffers alive until END_TEXT_COMMAND_DISPLAY_TEXT.
        self._last_chunks: list[bytes] = []
        self.recalculate()

    def set_position(self, x: float, y: float) -> None:
        self.literal_x = float(x)
        self.literal_y = float(y)
        self.recalculate()

    def recalculate(self) -> None:
        self.relative_x = to_x_relative(self.literal_x)
        self.relative_y = to_y_relative(self.literal_y)
        self.real_wrap = to_x_relative(self.word_wrap) if self.word_wrap > 0 else 0.0

    def _chunks(self) -> list[bytes]:
        chunks: list[bytes] = []
        current = ""
        for ch in self.text:
            candidate = current + ch
            if len(candidate.encode("utf-8", errors="replace")) > CHUNK_SIZE:
                if current:
                    chunks.append(current.encode("utf-8", errors="replace"))
                current = ch
            else:
                current = candidate
        if current:
            chunks.append(current.encode("utf-8", errors="replace"))
        return chunks or [b""]

    def _apply_style(self) -> None:
        hud.SET_TEXT_FONT(int(self.font))
        hud.SET_TEXT_SCALE(1.0, self.scale)
        hud.SET_TEXT_COLOUR(self.color.r, self.color.g, self.color.b, self.color.a)
        try:
            hud.SET_TEXT_JUSTIFICATION(int(self.alignment))
        except Exception:
            pass
        if self.shadow:
            try:
                hud.SET_TEXT_DROP_SHADOW()
            except Exception:
                pass
        if self.outline:
            try:
                hud.SET_TEXT_OUTLINE()
            except Exception:
                pass
        if self.real_wrap > 0:
            try:
                if self.alignment == Alignment.CENTER:
                    hud.SET_TEXT_WRAP(self.relative_x - self.real_wrap * 0.5, self.relative_x + self.real_wrap * 0.5)
                elif self.alignment == Alignment.LEFT:
                    hud.SET_TEXT_WRAP(self.relative_x, self.relative_x + self.real_wrap)
                else:
                    hud.SET_TEXT_WRAP(self.relative_x - self.real_wrap, self.relative_x)
            except Exception:
                pass
        elif self.alignment == Alignment.RIGHT:
            try:
                hud.SET_TEXT_WRAP(0.0, self.relative_x)
            except Exception:
                pass

    def draw(self) -> None:
        if self.scale == 0 or not self.text:
            return
        self._last_chunks = self._chunks()
        # Use bytes so NativeInvoker passes a pointer to memory that stays alive
        # across BEGIN/ADD/END. Plain str is converted into a temporary std::string
        # inside each gta.invoke call, which can be invalid by END.
        hud.BEGIN_TEXT_COMMAND_DISPLAY_TEXT(_TEXT_ENTRY)
        for chunk in self._last_chunks:
            hud.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(chunk)
        self._apply_style()
        hud.END_TEXT_COMMAND_DISPLAY_TEXT(self.relative_x, self.relative_y, 0)
