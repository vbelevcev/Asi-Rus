"""Keyboard helpers for Lemonpy."""

from __future__ import annotations

from gta.natives import misc

VK = {
    "BACK": 0x08,
    "TAB": 0x09,
    "ENTER": 0x0D,
    "SHIFT": 0x10,
    "CTRL": 0x11,
    "ESCAPE": 0x1B,
    "SPACE": 0x20,
    "LEFT": 0x25,
    "UP": 0x26,
    "RIGHT": 0x27,
    "DOWN": 0x28,
    "INSERT": 0x2D,
    "A": 0x41,
    "D": 0x44,
    "S": 0x53,
    "W": 0x57,
}
for _i in range(1, 13):
    VK[f"F{_i}"] = 0x6F + _i


class KeyboardInput:
    """Small state machine around GTA's on-screen keyboard."""

    def __init__(self) -> None:
        self._callback = None

    @property
    def active(self) -> bool:
        return self._callback is not None

    def text(self, prompt: str, callback, default: str = "", max_len: int = 64) -> None:
        misc.DISPLAY_ONSCREEN_KEYBOARD(1, "FMMC_KEY_TIP8", "", default, "", "", "", max_len)
        self._callback = callback

    def number(self, prompt: str, callback, default: int = 0) -> None:
        def parse(value: str) -> None:
            try:
                callback(int(value.strip()))
            except (TypeError, ValueError):
                pass

        self.text(prompt, parse, str(default), 12)

    def poll(self, enqueue) -> None:
        if self._callback is None:
            return
        status = misc.UPDATE_ONSCREEN_KEYBOARD()
        if status == 0:
            return
        if status == 1:
            result = misc.GET_ONSCREEN_KEYBOARD_RESULT() or ""
            callback = self._callback
            enqueue(lambda r=result, cb=callback: cb(r))
        self._callback = None


_default_input = KeyboardInput()


def text_input(prompt: str, callback, default: str = "", max_len: int = 64) -> None:
    _default_input.text(prompt, callback, default, max_len)


def number_input(prompt: str, callback, default: int = 0) -> None:
    _default_input.number(prompt, callback, default)
