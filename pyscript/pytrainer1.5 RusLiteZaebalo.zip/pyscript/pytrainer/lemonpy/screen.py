"""Screen helpers ported from LemonUI's GameScreen.

LemonUI uses a 1080p literal coordinate system that it converts to GTA's
0-1 relative coordinates using the current aspect ratio.
"""

from __future__ import annotations

import gta

GET_ASPECT_RATIO = 0xF1307EF624A80D87
GET_SAFE_ZONE_SIZE = 0xBAF107B6BB2C97F0


_cached_aspect: float = 16.0 / 9.0


def aspect_ratio() -> float:
    return _cached_aspect


def refresh_aspect_ratio() -> None:
    """Refresh the cached aspect ratio. Call once per frame."""
    global _cached_aspect
    try:
        _cached_aspect = float(gta.invoke(GET_ASPECT_RATIO, False, return_type="float"))
    except Exception:
        pass


def safe_zone_size() -> float:
    try:
        return float(gta.invoke(GET_SAFE_ZONE_SIZE, return_type="float"))
    except Exception:
        return 1.0


def to_x_relative(value: float) -> float:
    return value / (1080.0 * _cached_aspect)


def to_y_relative(value: float) -> float:
    return value / 1080.0


def to_relative(x: float, y: float) -> tuple[float, float]:
    return to_x_relative(x), to_y_relative(y)
