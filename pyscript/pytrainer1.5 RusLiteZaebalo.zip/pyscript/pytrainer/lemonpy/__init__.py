"""Lemonpy 0.1 - LemonUI port for PyLoaderV 0.6.

Lemonpy reimplements LemonUI's NativeMenu surface in pure Python on top of
PyLoaderV's `gta.natives` API. It uses the same `commonmenu` sprite atlas
(`interaction_bgd`, `gradient_bgd`, `gradient_nav`) and the same 1080p
aspect-ratio-aware coordinate system as LemonUI for ScriptHookVDotNet 3.

Credit: LemonUI by Hannele Ruiz (MIT) - https://github.com/LemonUIbyLemon/LemonUI
"""

from lemonpy.alignment import Alignment
from lemonpy.base_element import Color
from lemonpy.color_set import ColorSet
from lemonpy.font import Font
from lemonpy.input import VK, KeyboardInput, number_input, text_input
from lemonpy.items import (
    NativeCheckboxItem,
    NativeItem,
    NativeListItem,
    NativeSliderItem,
    NativeSubmenuItem,
)
from lemonpy.native_menu import NativeMenu
from lemonpy.pool import ObjectPool, Pool
from lemonpy.scaled_rectangle import ScaledRectangle
from lemonpy.scaled_text import ScaledText
from lemonpy.scaled_texture import ScaledTexture
from lemonpy.sound import Sound

__all__ = [
    "Alignment",
    "Color",
    "ColorSet",
    "Font",
    "KeyboardInput",
    "NativeCheckboxItem",
    "NativeItem",
    "NativeListItem",
    "NativeMenu",
    "NativeSliderItem",
    "NativeSubmenuItem",
    "ObjectPool",
    "Pool",
    "ScaledRectangle",
    "ScaledText",
    "ScaledTexture",
    "Sound",
    "VK",
    "number_input",
    "text_input",
]

__version__ = "0.1.0"
