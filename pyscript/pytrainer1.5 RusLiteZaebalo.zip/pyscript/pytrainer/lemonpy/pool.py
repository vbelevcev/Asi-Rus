"""ObjectPool ported from LemonUI."""

from __future__ import annotations

from typing import Callable, List, Optional

import gta
from gta.natives import pad

from lemonpy.input import KeyboardInput, VK
from lemonpy.native_menu import NativeMenu
from lemonpy.screen import refresh_aspect_ratio
from lemonpy.scaled_texture import ScaledTexture
from lemonpy.sound import (
    DEFAULT_ACTIVATED,
    DEFAULT_BACK,
    DEFAULT_CLOSED,
    DEFAULT_LEFT_RIGHT,
    DEFAULT_OPENED,
    DEFAULT_UP_DOWN,
    Sound,
)

# Controls disabled while a menu is open.
#
# LemonUI builds this list as "all GTA controls except the controls it wants to
# read through IS_DISABLED_CONTROL_*" and then reads PhoneUp/Down/Left/Right
# (172-175) while those controls are disabled. Lemonpy currently receives raw
# VK keyboard events from PyLoaderV, so it must also disable the phone/frontend
# controls that GTA would normally trigger from arrow/enter/backspace keys.
DISABLED_CONTROLS = (
    # Weapon / player actions
    14, 15, 16, 17, 23, 24, 25, 27, 36, 37, 38, 44, 45, 47, 51, 52,
    71, 72, 75, 80, 85, 86, 140, 141, 142, 143, 156, 170, 171,
    # Cell phone controls. These are the ones that open/navigate the phone.
    172, 173, 174, 175, 176, 177, 178, 179, 180, 181,
    # Frontend controls mapped by GTA from arrows/enter/backspace.
    187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200,
    201, 202, 203, 204, 205, 206, 207, 208, 217,
    # Script pad controls.
    218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231,
    232, 233, 234, 235, 236,
    # Cursor / interaction / replay.
    237, 238, 239, 240, 241, 242, 243, 244, 257, 263, 264, 331,
)


class ObjectPool:
    """Holds the menus currently registered and drives input + drawing."""

    def __init__(self) -> None:
        self.menus: List[NativeMenu] = []
        self.current: Optional[NativeMenu] = None
        self._pending: List[Callable[[], None]] = []
        self._input = KeyboardInput()
        ScaledTexture.preload("commonmenu")

    def add(self, menu: NativeMenu) -> NativeMenu:
        if menu not in self.menus:
            self.menus.append(menu)
        if self.current is None:
            self.current = menu
        return menu

    @property
    def visible(self) -> bool:
        return self.current is not None and self.current.visible

    def open(self, menu: Optional[NativeMenu] = None,
             sound: Optional[Sound] = DEFAULT_OPENED) -> None:
        if menu is not None:
            self.current = menu
        if self.current is None and self.menus:
            self.current = self.menus[0]
        if self.current is None:
            return
        ScaledTexture.preload("commonmenu")
        for known in self.menus:
            known.visible = False
        self.current.visible = True
        self.current._clamp_first_item()
        self.current.run_opened()
        if sound is not None:
            sound.play_frontend()

    def close(self, sound: Optional[Sound] = DEFAULT_CLOSED) -> None:
        if self.current is not None:
            self.current.visible = False
        if sound is not None:
            sound.play_frontend()

    def toggle(self, menu: Optional[NativeMenu] = None) -> None:
        if self.visible:
            self.close()
        else:
            self.open(menu)

    def process(self) -> None:
        self._run_pending()
        if self.visible or self._input.active:
            self._input.poll(self.enqueue)
        if self.visible and self.current is not None:
            refresh_aspect_ratio()
            ScaledTexture.preload("commonmenu")
            self._disable_controls()
            self.current.draw()

    tick = process

    def handle_key(self, vk: int) -> bool:
        if self._input.active:
            return True
        if not self.visible or self.current is None:
            return False
        if vk in (VK["ESCAPE"], VK["BACK"]):
            self.back()
            return True
        if vk == VK["UP"]:
            self.move(-1)
            return True
        if vk == VK["DOWN"]:
            self.move(1)
            return True
        if vk == VK["LEFT"]:
            self.adjust(-1)
            return True
        if vk == VK["RIGHT"]:
            self.adjust(1)
            return True
        if vk == VK["ENTER"]:
            self.activate()
            return True
        return False

    def move(self, delta: int) -> None:
        if self.current is None:
            return
        if self.current.move_selection(delta):
            DEFAULT_UP_DOWN.play_frontend()

    def adjust(self, delta: int) -> None:
        if self.current is None:
            return
        item = self.current.selected_item()
        if item is None:
            return
        if item.adjust(self, delta):
            DEFAULT_LEFT_RIGHT.play_frontend()

    def activate(self) -> None:
        if self.current is None:
            return
        item = self.current.selected_item()
        if item is None:
            return
        if not item.enabled:
            from lemonpy.sound import DEFAULT_DISABLED
            DEFAULT_DISABLED.play_frontend()
            return
        item.activate(self)
        DEFAULT_ACTIVATED.play_frontend()

    def back(self) -> None:
        if self.current is not None and self.current.parent is not None:
            self.open(self.current.parent, sound=DEFAULT_BACK)
        else:
            self.close()

    def enqueue(self, callback: Callable[[], None]) -> None:
        self._pending.append(callback)

    def input_text(self, prompt: str, callback, default: str = "", max_len: int = 64) -> None:
        try:
            gta.notify(f"~b~{prompt}")
        except Exception:
            pass
        self._input.text(prompt, callback, default, max_len)

    def input_number(self, prompt: str, callback, default: int = 0) -> None:
        def parse(value: str) -> None:
            try:
                callback(int(value.strip()))
            except Exception:
                try:
                    gta.notify("~r~Invalid number")
                except Exception:
                    pass

        self.input_text(prompt, parse, str(default), 12)

    def _run_pending(self) -> None:
        if not self._pending:
            return
        actions, self._pending = self._pending, []
        for action in actions:
            try:
                action()
            except Exception as exc:
                try:
                    gta.notify(f"~r~Action failed: {exc}")
                    gta.log("error", f"Lemonpy action failed: {exc!r}")
                except Exception:
                    pass

    def _disable_controls(self) -> None:
        for control in DISABLED_CONTROLS:
            try:
                pad.DISABLE_CONTROL_ACTION(0, control, True)
            except Exception:
                pass


Pool = ObjectPool
