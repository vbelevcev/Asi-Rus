"""Base 2D element with 1080p literal coordinates.

Mirrors LemonUI's BaseElement / I2Dimensional contract.
"""

from __future__ import annotations

from dataclasses import dataclass

from lemonpy.screen import to_x_relative, to_y_relative


@dataclass
class Color:
    r: int = 255
    g: int = 255
    b: int = 255
    a: int = 255

    def as_tuple(self) -> tuple[int, int, int, int]:
        return self.r, self.g, self.b, self.a

    @classmethod
    def from_argb(cls, a: int, r: int, g: int, b: int) -> "Color":
        return cls(r=int(r), g=int(g), b=int(b), a=int(a))


WHITE = Color(255, 255, 255, 255)
WHITESMOKE = Color(245, 245, 245, 255)
BLACK = Color(0, 0, 0, 255)
DISABLED = Color(163, 159, 148, 255)


class BaseElement:
    """Base of every drawable element in Lemonpy."""

    def __init__(self, x: float = 0.0, y: float = 0.0,
                 width: float = 0.0, height: float = 0.0,
                 color: Color | None = None) -> None:
        self.literal_x = float(x)
        self.literal_y = float(y)
        self.literal_width = float(width)
        self.literal_height = float(height)
        self.color = color or Color()
        self.heading = 0.0
        self.relative_x = 0.0
        self.relative_y = 0.0
        self.relative_width = 0.0
        self.relative_height = 0.0
        self.recalculate()

    def set_position(self, x: float, y: float) -> None:
        self.literal_x = float(x)
        self.literal_y = float(y)
        self.recalculate()

    def set_size(self, width: float, height: float) -> None:
        self.literal_width = float(width)
        self.literal_height = float(height)
        self.recalculate()

    def recalculate(self) -> None:
        self.relative_x = to_x_relative(self.literal_x)
        self.relative_y = to_y_relative(self.literal_y)
        self.relative_width = to_x_relative(self.literal_width)
        self.relative_height = to_y_relative(self.literal_height)

    def draw(self) -> None:
        raise NotImplementedError
