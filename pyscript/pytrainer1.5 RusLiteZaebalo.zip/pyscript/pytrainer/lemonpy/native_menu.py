"""Rockstar-style NativeMenu ported from LemonUI to PyLoaderV 0.6."""

from __future__ import annotations

from typing import Callable, List, Optional

from lemonpy.alignment import Alignment
from lemonpy.base_element import BLACK, Color, WHITESMOKE
from lemonpy.font import Font
from lemonpy.items import NativeItem, NativeSubmenuItem
from lemonpy.scaled_rectangle import ScaledRectangle
from lemonpy.scaled_text import ScaledText
from lemonpy.scaled_texture import ScaledTexture

WIDTH = 433.0
NAME_HEIGHT = 38.0
ITEM_HEIGHT = 37.4
BANNER_HEIGHT = 108.0
HEIGHT_DIFF_DESC_IMG = 4.0
HEIGHT_DIFF_DESC_TXT = 3.0
ITEM_OFFSET_X = 6.0
NAME_TEXT_Y_OFFSET = 4.2

DEFAULT_MAX_ITEMS = 10


class NativeMenu:
    """A Rockstar-style menu drawn with the commonmenu sprite atlas."""

    def __init__(self, title: str = "", subtitle: str = "", description: str = "") -> None:
        self.title = str(title)
        self.subtitle = str(subtitle) if subtitle else str(title)
        self.description = str(description) if description else ""
        self.items: List[NativeItem] = []
        self.parent: Optional["NativeMenu"] = None
        self.selected_index: int = 0
        self.first_item: int = 0
        self.max_items: int = DEFAULT_MAX_ITEMS
        self.visible: bool = False
        self.offset_x: float = 0.0
        self.offset_y: float = 0.0
        self.on_opened: List[Callable[["NativeMenu"], None]] = []
        self.show_count: bool = True
        self.keep_subtitle_casing: bool = False

        self.banner: Optional[ScaledTexture] = ScaledTexture(
            "commonmenu", "interaction_bgd",
            width=WIDTH, height=BANNER_HEIGHT,
        )
        self.banner_text = ScaledText(
            self.title, scale=1.02, font=Font.HOUSE_SCRIPT,
            alignment=Alignment.CENTER,
        )
        self.name_image = ScaledRectangle(width=WIDTH, height=NAME_HEIGHT,
                                          color=Color(BLACK.r, BLACK.g, BLACK.b, BLACK.a))
        self.name_text = ScaledText(
            self._format_subtitle(self.subtitle), scale=0.345,
            font=Font.CHALET_LONDON,
            color=Color(WHITESMOKE.r, WHITESMOKE.g, WHITESMOKE.b, WHITESMOKE.a),
        )
        self.count_text = ScaledText(
            "", scale=0.345, font=Font.CHALET_LONDON,
            alignment=Alignment.RIGHT,
            color=Color(WHITESMOKE.r, WHITESMOKE.g, WHITESMOKE.b, WHITESMOKE.a),
        )
        self.background_image = ScaledTexture(
            "commonmenu", "gradient_bgd", width=WIDTH, height=0.0,
        )
        self.selected_rect = ScaledTexture(
            "commonmenu", "gradient_nav", width=WIDTH, height=ITEM_HEIGHT,
        )
        self.description_rect = ScaledTexture(
            "commonmenu", "gradient_bgd", width=WIDTH, height=0.0,
        )
        self.description_text = ScaledText(
            "", scale=0.351, font=Font.CHALET_LONDON,
            color=Color(WHITESMOKE.r, WHITESMOKE.g, WHITESMOKE.b, WHITESMOKE.a),
        )

    def _format_subtitle(self, value: str) -> str:
        if self.keep_subtitle_casing:
            return value
        return (value or "").upper()

    @property
    def banner_title(self) -> str:
        return self.title

    @banner_title.setter
    def banner_title(self, value: str) -> None:
        self.title = str(value)
        self.banner_text.text = str(value)

    def add(self, item: NativeItem) -> NativeItem:
        self.items.append(item)
        return item

    def add_submenu(self, submenu: "NativeMenu", title: str = "",
                    description: str = "") -> NativeSubmenuItem:
        submenu.parent = self
        item = NativeSubmenuItem(submenu, title or submenu.subtitle or submenu.title, description)
        self.add(item)
        return item

    def clear(self) -> None:
        self.items.clear()
        self.selected_index = 0
        self.first_item = 0

    def selected_item(self) -> Optional[NativeItem]:
        if not self.items:
            return None
        self.selected_index %= len(self.items)
        return self.items[self.selected_index]

    def opened(self, callback: Callable[["NativeMenu"], None]):
        self.on_opened.append(callback)
        return callback

    def run_opened(self) -> None:
        for callback in list(self.on_opened):
            callback(self)

    def move_selection(self, delta: int) -> bool:
        if not self.items:
            return False
        new_index = (self.selected_index + delta) % len(self.items)
        if new_index == self.selected_index:
            return False
        self.selected_index = new_index
        self._clamp_first_item()
        return True

    def _clamp_first_item(self) -> None:
        if self.max_items <= 0:
            self.first_item = 0
            return
        if self.selected_index < self.first_item:
            self.first_item = self.selected_index
        elif self.selected_index >= self.first_item + self.max_items:
            self.first_item = self.selected_index - self.max_items + 1
        max_first = max(0, len(self.items) - self.max_items)
        if self.first_item > max_first:
            self.first_item = max_first
        if self.first_item < 0:
            self.first_item = 0

    def draw(self) -> None:
        if not self.visible:
            return
        self.banner_text.text = self.title
        self.name_text.text = self._format_subtitle(self.subtitle)
        self._clamp_first_item()

        x = float(self.offset_x)
        y = float(self.offset_y)

        if self.banner is not None:
            self.banner.set_position(x, y)
            self.banner.set_size(WIDTH, BANNER_HEIGHT)
            self.banner.draw()
            self.banner_text.set_position(x + 209.0, y + 22.0)
            self.banner_text.draw()
            y += BANNER_HEIGHT

        self.name_image.set_position(x, y)
        self.name_image.set_size(WIDTH, NAME_HEIGHT)
        self.name_image.draw()
        self.name_text.set_position(x + ITEM_OFFSET_X, y + NAME_TEXT_Y_OFFSET)
        self.name_text.draw()

        if self.show_count and self.items:
            self.count_text.text = f"{self.selected_index + 1}/{len(self.items)}"
            self.count_text.set_position(x + WIDTH - ITEM_OFFSET_X, y + NAME_TEXT_Y_OFFSET)
            self.count_text.draw()
        y += NAME_HEIGHT

        visible_items = self.items[self.first_item:self.first_item + self.max_items]
        if visible_items:
            self.background_image.set_position(x, y)
            self.background_image.set_size(WIDTH, ITEM_HEIGHT * len(visible_items))
            self.background_image.draw()

            if 0 <= self.selected_index < len(self.items):
                sel_y = y + (self.selected_index - self.first_item) * ITEM_HEIGHT
                self.selected_rect.set_position(x, sel_y)
                self.selected_rect.set_size(WIDTH, ITEM_HEIGHT)
                self.selected_rect.draw()

            for idx, item in enumerate(visible_items):
                absolute = self.first_item + idx
                item_y = y + idx * ITEM_HEIGHT
                item.recalculate(x, item_y, WIDTH, ITEM_HEIGHT, absolute == self.selected_index)
                item.draw()

            y += ITEM_HEIGHT * len(visible_items)

        current = self.selected_item()
        description_text = current.description if current is not None and current.description else self.description
        if description_text:
            desc_y = y + HEIGHT_DIFF_DESC_IMG
            # Approximate line count: ~50 characters per line at scale 0.351 on width 433.
            approx_lines = max(1, (len(description_text) + 49) // 50)
            line_height = 18.0
            desc_height = max(NAME_HEIGHT, line_height * approx_lines + HEIGHT_DIFF_DESC_TXT * 2)
            self.description_rect.set_position(x, desc_y)
            self.description_rect.set_size(WIDTH, desc_height)
            self.description_rect.draw()
            self.description_text.word_wrap = WIDTH - ITEM_OFFSET_X * 2
            self.description_text.text = description_text
            self.description_text.set_position(x + ITEM_OFFSET_X, desc_y + HEIGHT_DIFF_DESC_TXT)
            self.description_text.draw()
