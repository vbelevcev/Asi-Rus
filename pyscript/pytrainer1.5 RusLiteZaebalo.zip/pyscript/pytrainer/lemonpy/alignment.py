"""Text alignment values matching GTA's SET_TEXT_JUSTIFICATION."""

from enum import IntEnum


class Alignment(IntEnum):
    CENTER = 0
    LEFT = 1
    RIGHT = 2
