"""Sound playback helpers ported from LemonUI's Sound class."""

from __future__ import annotations

from gta.natives import audio


class Sound:
    def __init__(self, set_name: str, file: str) -> None:
        self.set = str(set_name)
        self.file = str(file)

    def play_frontend(self) -> None:
        try:
            audio.PLAY_SOUND_FRONTEND(-1, self.file, self.set, False)
        except Exception:
            pass


DEFAULT_SOUNDSET = "HUD_FRONTEND_DEFAULT_SOUNDSET"
DEFAULT_OPENED = Sound(DEFAULT_SOUNDSET, "SELECT")
DEFAULT_CLOSED = Sound(DEFAULT_SOUNDSET, "BACK")
DEFAULT_ACTIVATED = Sound(DEFAULT_SOUNDSET, "SELECT")
DEFAULT_BACK = Sound(DEFAULT_SOUNDSET, "BACK")
DEFAULT_UP_DOWN = Sound(DEFAULT_SOUNDSET, "NAV_UP_DOWN")
DEFAULT_LEFT_RIGHT = Sound(DEFAULT_SOUNDSET, "NAV_LEFT_RIGHT")
DEFAULT_DISABLED = Sound(DEFAULT_SOUNDSET, "ERROR")
