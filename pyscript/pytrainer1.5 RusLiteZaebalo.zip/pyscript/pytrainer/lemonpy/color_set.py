"""LemonUI ColorSet defaults."""

from __future__ import annotations

from dataclasses import dataclass, field

from lemonpy.base_element import BLACK, Color, DISABLED, WHITESMOKE


def _smoke() -> Color:
    return Color(WHITESMOKE.r, WHITESMOKE.g, WHITESMOKE.b, WHITESMOKE.a)


def _black() -> Color:
    return Color(BLACK.r, BLACK.g, BLACK.b, BLACK.a)


def _disabled() -> Color:
    return Color(DISABLED.r, DISABLED.g, DISABLED.b, DISABLED.a)


@dataclass
class ColorSet:
    title_normal: Color = field(default_factory=_smoke)
    title_hovered: Color = field(default_factory=_black)
    title_disabled: Color = field(default_factory=_disabled)
    alt_title_normal: Color = field(default_factory=_smoke)
    alt_title_hovered: Color = field(default_factory=_black)
    alt_title_disabled: Color = field(default_factory=_disabled)
    arrows_normal: Color = field(default_factory=_smoke)
    arrows_hovered: Color = field(default_factory=_black)
    arrows_disabled: Color = field(default_factory=_disabled)
