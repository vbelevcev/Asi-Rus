from __future__ import annotations
from gta.natives import misc, weapon
from pytrainer.Lib.config import clean_save_name, ensure_save_dir, notify, show_status
from pytrainer.Lib.gta_compat import player_ped
WEAPON_NAMES=["WEAPON_KNIFE","WEAPON_NIGHTSTICK","WEAPON_HAMMER","WEAPON_BAT","WEAPON_CROWBAR","WEAPON_PISTOL","WEAPON_COMBATPISTOL","WEAPON_APPISTOL","WEAPON_PISTOL50","WEAPON_SNSPISTOL","WEAPON_HEAVYPISTOL","WEAPON_VINTAGEPISTOL","WEAPON_MICROSMG","WEAPON_SMG","WEAPON_ASSAULTSMG","WEAPON_COMBATPDW","WEAPON_ASSAULTRIFLE","WEAPON_CARBINERIFLE","WEAPON_ADVANCEDRIFLE","WEAPON_SPECIALCARBINE","WEAPON_BULLPUPRIFLE","WEAPON_PUMPSHOTGUN","WEAPON_SAWNOFFSHOTGUN","WEAPON_ASSAULTSHOTGUN","WEAPON_HEAVYSHOTGUN","WEAPON_SNIPERRIFLE","WEAPON_HEAVYSNIPER","WEAPON_GRENADELAUNCHER","WEAPON_RPG","WEAPON_MINIGUN","WEAPON_GRENADE","WEAPON_STICKYBOMB","WEAPON_MOLOTOV","WEAPON_FIREEXTINGUISHER","WEAPON_PETROLCAN","WEAPON_STUNGUN"]
WEAPON_LIST=[]
_UNARMED=0; _infinite_ammo=False
def init_weapon_data():
    global WEAPON_LIST,_UNARMED
    if not WEAPON_LIST:
        WEAPON_LIST=[(n.replace("WEAPON_","").replace("_"," ").title(), misc.GET_HASH_KEY(n)) for n in WEAPON_NAMES]
        _UNARMED=misc.GET_HASH_KEY("WEAPON_UNARMED")
def _ensure_weapon_data():
    if not WEAPON_LIST: init_weapon_data()
def _weapon_save_dir(): d=ensure_save_dir()/"weapons"; d.mkdir(exist_ok=True); return d
def reset_runtime_state():
    global _infinite_ammo; _infinite_ammo=False
def give_all_weapons():
    _ensure_weapon_data()
    h=player_ped()
    for _,wh in WEAPON_LIST:
        try: weapon.GIVE_WEAPON_TO_PED(h,wh,9999,False,False)
        except Exception: pass
    notify("~b~All weapons given.")
def remove_all_weapons(): weapon.REMOVE_ALL_PED_WEAPONS(player_ped(),True); notify("~b~All weapons removed.")
def select_weapon(weapon_hash):
    try: weapon.GIVE_WEAPON_TO_PED(player_ped(),int(weapon_hash),999,False,True); notify("~b~Weapon given.")
    except Exception: notify("~r~Failed to give weapon.")
def set_ammo(amount):
    _ensure_weapon_data()
    h=player_ped(); wh=weapon.GET_SELECTED_PED_WEAPON(h)
    if wh and wh!=_UNARMED: weapon.GIVE_WEAPON_TO_PED(h,wh,int(amount),False,True); weapon.SET_AMMO_IN_CLIP(h,wh,min(9999,int(amount))); notify("~b~Ammo set to {}.".format(int(amount)))
    else: notify("~r~No valid weapon equipped.")
def remove_current_weapon():
    _ensure_weapon_data()
    h=player_ped(); wh=weapon.GET_SELECTED_PED_WEAPON(h)
    if wh and wh!=_UNARMED: weapon.REMOVE_WEAPON_FROM_PED(h,wh); notify("~b~Current weapon removed.")
    else: notify("~r~No weapon to remove.")
def toggle_infinite_ammo(enabled):
    global _infinite_ammo; _infinite_ammo=bool(enabled); _apply_infinite_ammo(); show_status("Infinite Ammo:",_infinite_ammo)
def _apply_infinite_ammo():
    _ensure_weapon_data()
    h=player_ped(); wh=weapon.GET_SELECTED_PED_WEAPON(h)
    if wh and wh!=_UNARMED: weapon.SET_PED_INFINITE_AMMO(h,_infinite_ammo,wh)
def save_weapons(save_name):
    _ensure_weapon_data()
    name=clean_save_name(save_name)
    if not name: notify("~r~Save name cannot be empty."); return
    h=player_ped(); lines=[]
    for _,wh in WEAPON_LIST:
        try:
            if weapon.HAS_PED_GOT_WEAPON(h,wh,False): lines.append("{}|{}".format(wh,weapon.GET_AMMO_IN_PED_WEAPON(h,wh)))
        except Exception: pass
    if not lines: notify("~r~No weapons to save."); return
    (_weapon_save_dir()/(name+".txt")).write_text("\n".join(lines),encoding="utf-8"); notify("~g~Weapons saved: ~s~{}".format(name))
def load_weapons(save_name):
    name=clean_save_name(save_name); path=_weapon_save_dir()/(name+".txt")
    if not path.exists(): notify("~r~Save not found: {}".format(name)); return
    h=player_ped(); count=0
    for line in path.read_text(encoding="utf-8").splitlines():
        parts=line.strip().split("|")
        if len(parts)==2:
            try: weapon.GIVE_WEAPON_TO_PED(h,int(parts[0]),int(parts[1]),False,True); count+=1
            except Exception: pass
    notify("~g~Weapons loaded: ~s~{} ({} weapons)".format(name,count))
def delete_weapon_save(save_name):
    name=clean_save_name(save_name); path=_weapon_save_dir()/(name+".txt")
    if path.exists(): path.unlink(); notify("~y~Deleted weapon save: {}".format(name))
    else: notify("~r~Save not found.")
def list_weapon_saves(): return sorted(path.stem for path in _weapon_save_dir().glob("*.txt"))
def tick_update():
    if _infinite_ammo: _apply_infinite_ammo()
