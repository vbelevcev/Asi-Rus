from __future__ import annotations
import gta
from gta.natives import cam, entity, misc, ped, player, stats
from pytrainer.Lib import config
from pytrainer.Lib.config import VK, get_player_id, notify, show_status
from pytrainer.Lib.gta_compat import player_or_vehicle, player_ped, rotation_to_direction, right_from_forward, set_entity_pos, waypoint_coords
_infinite_stamina=_super_jump=_fast_run=_quick_swim=_never_wanted=_noclip=False
_keys=set(); RUN_MULTIPLIER=1.49; SWIM_MULTIPLIER=1.49
def _normalize_key(vk): return {160:VK["SHIFT"],161:VK["SHIFT"],162:VK["CTRL"],163:VK["CTRL"]}.get(int(vk),int(vk))
def handle_key_state(vk,down):
    key=_normalize_key(vk)
    (_keys.add(key) if down else _keys.discard(key))
def reset_runtime_state():
    global _infinite_stamina,_super_jump,_fast_run,_quick_swim,_never_wanted,_noclip
    _infinite_stamina=_super_jump=_fast_run=_quick_swim=_never_wanted=_noclip=False; _keys.clear(); p=get_player_id(); player.SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(p,1.0); player.SET_SWIM_MULTIPLIER_FOR_PLAYER(p,1.0); player.SET_MAX_WANTED_LEVEL(5); h=player_ped(); entity.SET_ENTITY_INVINCIBLE(h,False,False); entity.SET_ENTITY_VISIBLE(h,True,False); entity.SET_ENTITY_COLLISION(h,True,True); entity.FREEZE_ENTITY_POSITION(h,False)
def heal_player(): h=player_ped(); entity.SET_ENTITY_HEALTH(h,max(200,entity.GET_ENTITY_MAX_HEALTH(h)),0,0); ped.SET_PED_ARMOUR(h,100); notify("~g~Player healed.")
def clean_ped():
    h=player_ped(); ped.CLEAR_PED_BLOOD_DAMAGE(h); ped.RESET_PED_VISIBLE_DAMAGE(h); ped.CLEAR_PED_DECORATIONS(h)
    for zone in range(10):
        try: ped.CLEAR_PED_DAMAGE_DECAL_BY_ZONE(h,zone,"ALL")
        except Exception: pass
    notify("~b~Player cleaned.")
def clear_wanted_level(): set_player_wanted_level(0); notify("~b~Wanted level cleared.")
def set_player_wanted_level(level): level=max(0,min(5,int(level))); p=get_player_id(); player.SET_PLAYER_WANTED_LEVEL(p,level,False); player.SET_PLAYER_WANTED_LEVEL_NOW(p,False); notify("~b~Wanted Level: {}".format(level))
def set_player_cash(value):
    model=entity.GET_ENTITY_MODEL(player_ped()); lookup={misc.GET_HASH_KEY("player_zero"):"SP0_TOTAL_CASH",misc.GET_HASH_KEY("player_one"):"SP1_TOTAL_CASH",misc.GET_HASH_KEY("player_two"):"SP2_TOTAL_CASH"}; stat=lookup.get(model)
    if stat is None: notify("~r~Unknown character - cannot set cash."); return
    stats.STAT_SET_INT(misc.GET_HASH_KEY(stat),int(value),True); notify("~g~Money set to: ~s~${}".format(int(value)))
def teleport_to_waypoint():
    coords=waypoint_coords()
    if coords is None: notify("~r~No waypoint set."); return
    h=player_or_vehicle(); x,y,z=coords; set_entity_pos(h,(x,y,z+50.0)); gta.wait(300); set_entity_pos(h,(x,y,z+2.0)); entity.SET_ENTITY_VELOCITY(h,0.0,0.0,0.0); notify("~g~Teleported to waypoint.")
def teleport_to_coords(coords_str):
    try: xyz=tuple(float(p) for p in str(coords_str).replace(" ","").split(",")); assert len(xyz)==3; set_entity_pos(player_or_vehicle(),xyz); notify("~g~Teleported to {:.0f}, {:.0f}, {:.0f}".format(*xyz))
    except Exception: notify("~r~Invalid coordinates. Use: x,y,z")
def toggle_god_mode(enabled): entity.SET_ENTITY_INVINCIBLE(player_ped(),bool(enabled),False); show_status("God Mode:",bool(enabled))
def toggle_infinite_stamina(enabled):
    global _infinite_stamina; _infinite_stamina=bool(enabled); show_status("Infinite Stamina:",_infinite_stamina)
def toggle_never_wanted(enabled):
    global _never_wanted; _never_wanted=bool(enabled); player.SET_MAX_WANTED_LEVEL(0 if _never_wanted else 5); set_player_wanted_level(0) if _never_wanted else None; show_status("Never Wanted:",_never_wanted)
def toggle_super_jump(enabled):
    global _super_jump; _super_jump=bool(enabled); show_status("Super Jump:",_super_jump)
def toggle_fast_run(enabled):
    global _fast_run; _fast_run=bool(enabled); player.SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(get_player_id(),RUN_MULTIPLIER if _fast_run else 1.0); show_status("Fast Run:",_fast_run)
def toggle_quick_swim(enabled):
    global _quick_swim; _quick_swim=bool(enabled); player.SET_SWIM_MULTIPLIER_FOR_PLAYER(get_player_id(),SWIM_MULTIPLIER if _quick_swim else 1.0); show_status("Quick Swim:",_quick_swim)
def set_player_visibility(invisible): entity.SET_ENTITY_VISIBLE(player_ped(),not bool(invisible),False); show_status("Invisible:",bool(invisible))
def toggle_noclip(enabled):
    global _noclip; _noclip=bool(enabled); h=player_or_vehicle(); entity.SET_ENTITY_COLLISION(h,not _noclip,True); entity.FREEZE_ENTITY_POSITION(h,_noclip); show_status("Noclip:",_noclip)
def tick_update():
    p=get_player_id()
    if _infinite_stamina: player.RESET_PLAYER_STAMINA(p)
    if _super_jump: misc.SET_SUPER_JUMP_THIS_FRAME(p)
    if _never_wanted: player.SET_PLAYER_WANTED_LEVEL(p,0,False); player.SET_PLAYER_WANTED_LEVEL_NOW(p,False)
    if _fast_run: player.SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(p,RUN_MULTIPLIER)
    if _quick_swim: player.SET_SWIM_MULTIPLIER_FOR_PLAYER(p,SWIM_MULTIPLIER)
    if _noclip: _noclip_tick()
def _noclip_tick():
    h=player_or_vehicle(); entity.SET_ENTITY_COLLISION(h,False,True); entity.FREEZE_ENTITY_POSITION(h,True); entity.SET_ENTITY_VELOCITY(h,0.0,0.0,0.0); rot=cam.GET_GAMEPLAY_CAM_ROT(2); fwd=rotation_to_direction(rot); right=right_from_forward(fwd); speed=config.NOCLIP_SPEED_FAST if VK["SHIFT"] in _keys else config.NOCLIP_SPEED_NORMAL; dx=dy=dz=0.0
    if VK["W"] in _keys: dx+=fwd[0]*speed; dy+=fwd[1]*speed; dz+=fwd[2]*speed
    if VK["S"] in _keys: dx-=fwd[0]*speed; dy-=fwd[1]*speed; dz-=fwd[2]*speed
    if VK["D"] in _keys: dx+=right[0]*speed; dy+=right[1]*speed
    if VK["A"] in _keys: dx-=right[0]*speed; dy-=right[1]*speed
    if VK["SPACE"] in _keys: dz+=speed
    if VK["CTRL"] in _keys: dz-=speed
    if abs(dx)+abs(dy)+abs(dz)>0.001: pos=entity.GET_ENTITY_COORDS(h,True); set_entity_pos(h,(pos[0]+dx,pos[1]+dy,pos[2]+dz)); entity.SET_ENTITY_HEADING(h,float(rot[2]))
