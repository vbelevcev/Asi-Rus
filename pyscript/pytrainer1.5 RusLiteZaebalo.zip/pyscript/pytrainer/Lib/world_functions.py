from __future__ import annotations
from gta.natives import clock, misc
from pytrainer.Lib.config import notify, show_status
WEATHERS=[
 "Blizzard",
 "Christmas",
 "Clear",
 "Clearing",
 "Clouds",
 "ExtraSunny",
 "Foggy",
 "Halloween",
 #"HalloweenSnow",
 #"HalloweenRain",
 "Neutral",
 "Overcast",
 "Raining",
 "Smog",
 "Snowing",
 "Snowlight",
 "ThunderStorm"
]

_NATIVE={
  "Blizzard":"BLIZZARD",
  "Christmas":"XMAS",
  "Clear":"CLEAR",
  "Clearing":"CLEARING",
  "Clouds":"CLOUDS",
  "ExtraSunny":"EXTRASUNNY",
  "Foggy":"FOGGY",
  "Halloween":"HALLOWEEN",
  #"HalloweenSnow", "SNOW_HALLOWEEN",
  #"HalloweenRain", "RAIN_HALLOWEEN",
  "Neutral":"NEUTRAL",
  "Overcast":"OVERCAST",
  "Raining":"RAIN",
  "Smog":"SMOG",
  "Snowing":"SNOW",
  "Snowlight":"SNOWLIGHT",
  "ThunderStorm":"THUNDER"
}
_freeze_time=False; _low_gravity=False
def get_available_weathers(): return WEATHERS

def set_weather(name): misc.SET_WEATHER_TYPE_NOW_PERSIST(_NATIVE.get(str(name),str(name).upper())); notify("~b~Погодаr: ~g~{}".format(name))

def set_hour(hour): clock.SET_CLOCK_TIME(int(hour)%24,clock.GET_CLOCK_MINUTES(),clock.GET_CLOCK_SECONDS()); notify("~b~Час: {}".format(int(hour)%24))

def set_minutes(minutes): clock.SET_CLOCK_TIME(clock.GET_CLOCK_HOURS(),int(minutes)%60,clock.GET_CLOCK_SECONDS()); notify("~b~Минуты: {}".format(int(minutes)%60))

def set_seconds(seconds): clock.SET_CLOCK_TIME(clock.GET_CLOCK_HOURS(),clock.GET_CLOCK_MINUTES(),int(seconds)%60); notify("~b~Секунды: {}".format(int(seconds)%60))

def freeze_time(enabled):
    global _freeze_time; _freeze_time=bool(enabled); clock.PAUSE_CLOCK(_freeze_time); show_status("Заморозить время:",_freeze_time)
def set_low_gravity(enabled):
    global _low_gravity; _low_gravity=bool(enabled); misc.SET_GRAVITY_LEVEL(4 if _low_gravity else 0); show_status("Низкая гравитация:",_low_gravity)
def tick_update():
    if _freeze_time: clock.PAUSE_CLOCK(True)
    if _low_gravity: misc.SET_GRAVITY_LEVEL(4)
def reset_runtime_state():
    global _freeze_time,_low_gravity; _freeze_time=False; _low_gravity=False; clock.PAUSE_CLOCK(False); misc.SET_GRAVITY_LEVEL(0)
