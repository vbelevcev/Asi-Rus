"""Vehicle preview sprites for the PyLoaderV 0.6 / Lemonpy trainer."""

from __future__ import annotations

from gta.natives import graphics

_loaded_dicts: set[str] = set()
_requested_dicts: set[str] = set()

_PREVIEW_X = 0.34
_PREVIEW_Y = 0.40
_PREVIEW_W = 0.18
_PREVIEW_H = 0.12
_BG_PAD = 0.005


def _ensure_dict_loaded(tex_dict: str) -> bool:
    if not tex_dict:
        return False
    if tex_dict in _loaded_dicts:
        return True
    try:
        if graphics.HAS_STREAMED_TEXTURE_DICT_LOADED(tex_dict):
            _loaded_dicts.add(tex_dict)
            return True
        if tex_dict not in _requested_dicts:
            graphics.REQUEST_STREAMED_TEXTURE_DICT(tex_dict, True)
            _requested_dicts.add(tex_dict)
    except Exception:
        return False
    return False


def draw_vehicle_preview(tex_dict: str, tex_name: str) -> None:
    """Draw a vehicle preview sprite on screen. Call every tick while hovering."""
    if not tex_dict or not tex_name:
        return
    if not _ensure_dict_loaded(tex_dict):
        return

    graphics.DRAW_RECT(
        _PREVIEW_X,
        _PREVIEW_Y,
        _PREVIEW_W + _BG_PAD * 2,
        _PREVIEW_H + _BG_PAD * 2,
        0,
        0,
        0,
        180,
        False,
    )
    graphics.DRAW_SPRITE(
        tex_dict,
        tex_name,
        _PREVIEW_X,
        _PREVIEW_Y,
        _PREVIEW_W,
        _PREVIEW_H,
        0.0,
        255,
        255,
        255,
        255,
        False,
        0,
    )
