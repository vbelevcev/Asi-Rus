from __future__ import annotations
from gta import world
from gta.natives import entity, ped, vehicle
from gta.vehicle import Vehicle
from pytrainer.Lib import config
from pytrainer.Lib.config import NOT_IN_VEHICLE, notify, show_status
from pytrainer.Lib.gta_compat import current_vehicle, player_ped
from pytrainer.Lib.vehicle_data import VEHICLE_CATEGORIES
TOGGLE_MOD_SLOTS=frozenset([17,18,19,20,21,22])
def _current_vehicle(): h=current_vehicle(); return Vehicle(h) if h else None
def _require_vehicle():
    v=_current_vehicle(); notify(NOT_IN_VEHICLE) if v is None else None; return v
def spawn_vehicle(model_name):
    model_name=str(model_name).strip()
    if not model_name: return
    p=player_ped(); pos=entity.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(p,0.0,5.0,0.5); veh=world.create_vehicle(model_name,pos,entity.GET_ENTITY_HEADING(p))
    if veh is None: notify("~b~Invalid vehicle: ~r~{}".format(model_name)); return
    veh.place_on_ground(); ped.SET_PED_INTO_VEHICLE(p,veh.handle,-1); notify("~b~Spawned: ~g~{}".format(model_name))
def fix_vehicle():
    v=_require_vehicle();
    if v is None: return
    vehicle.SET_VEHICLE_FIXED(v.handle); vehicle.SET_VEHICLE_ENGINE_HEALTH(v.handle,1000.0); vehicle.SET_VEHICLE_BODY_HEALTH(v.handle,1000.0); vehicle.SET_VEHICLE_PETROL_TANK_HEALTH(v.handle,1000.0); vehicle.SET_VEHICLE_DIRT_LEVEL(v.handle,0.0); notify("~b~Vehicle repaired + cleaned.")
def clean_vehicle():
    v=_require_vehicle();
    if v: vehicle.SET_VEHICLE_DIRT_LEVEL(v.handle,0.0); notify("~b~Vehicle cleaned.")
def delete_current_vehicle():
    v=_require_vehicle();
    if v: v.delete(); notify("~b~Vehicle deleted.")
def toggle_god_mode(enabled):
    v=_require_vehicle();
    if v is None: return
    enabled=bool(enabled); entity.SET_ENTITY_INVINCIBLE(v.handle,enabled,False); vehicle.SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(v.handle,not enabled); vehicle.SET_VEHICLE_TYRES_CAN_BURST(v.handle,not enabled); vehicle.SET_VEHICLE_CAN_BREAK(v.handle,not enabled); vehicle.SET_VEHICLE_ENGINE_CAN_DEGRADE(v.handle,not enabled); vehicle.SET_DISABLE_VEHICLE_PETROL_TANK_DAMAGE(v.handle,enabled); vehicle.SET_DISABLE_VEHICLE_PETROL_TANK_FIRES(v.handle,enabled); show_status("Vehicle God Mode:",enabled)
def toggle_seatbelt(enabled):
    h=player_ped()
    if not ped.IS_PED_IN_ANY_VEHICLE(h,False): notify(NOT_IN_VEHICLE); return
    ped.SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(h,1 if enabled else 0); ped.SET_PED_CAN_RAGDOLL(h,not bool(enabled)); show_status("Seatbelt:",bool(enabled))
def get_vehicle_categories(): return [cat for cat,_ in VEHICLE_CATEGORIES]
def get_vehicles_in_category(category):
    for cat,vehicles in VEHICLE_CATEGORIES:
        if cat==category: return vehicles
    return []
def get_vehicle_preview(model_name):
    for _,vehicles in VEHICLE_CATEGORIES:
        for entry in vehicles:
            if entry[0]==model_name and len(entry)>=4: return (entry[2],entry[3])
    return ("","")
def max_tune_vehicle():
    v=_require_vehicle();
    if v is None: return
    h=v.handle; count=0; vehicle.SET_VEHICLE_MOD_KIT(h,0)
    for slot in TOGGLE_MOD_SLOTS: vehicle.TOGGLE_VEHICLE_MOD(h,slot,True); count+=1
    vehicle.SET_VEHICLE_WHEEL_TYPE(h,0)
    for slot in range(50):
        if slot in TOGGLE_MOD_SLOTS: continue
        try:
            num=vehicle.GET_NUM_VEHICLE_MODS(h,slot)
            if num and num>0: vehicle.SET_VEHICLE_MOD(h,slot,num-1,False); count+=1
        except Exception: pass
    for extra_id in range(15):
        try:
            if vehicle.DOES_EXTRA_EXIST(h,extra_id): vehicle.SET_VEHICLE_EXTRA(h,extra_id,False); count+=1
        except Exception: pass
    try:
        liv=vehicle.GET_VEHICLE_LIVERY_COUNT(h)
        if liv and liv>0: vehicle.SET_VEHICLE_LIVERY(h,liv-1)
    except Exception: pass
    vehicle.SET_VEHICLE_WINDOW_TINT(h,1); vehicle.SET_VEHICLE_TYRES_CAN_BURST(h,False)
    for side in range(4):
        try: vehicle.SET_VEHICLE_NEON_ENABLED(h,side,True)
        except Exception: pass
    try: vehicle.SET_VEHICLE_NEON_COLOUR(h,255,255,255); vehicle.SET_VEHICLE_NUMBER_PLATE_TEXT_INDEX(h,5)
    except Exception: pass
    notify("~g~Vehicle fully upgraded! ~w~{} mods applied".format(count))
def speed_boost():
    v=_require_vehicle();
    if v is None: return
    fwd=entity.GET_ENTITY_FORWARD_VECTOR(v.handle); cur=entity.GET_ENTITY_VELOCITY(v.handle); boost=float(config.BOOST_POWER); entity.SET_ENTITY_VELOCITY(v.handle,cur[0]+fwd[0]*boost,cur[1]+fwd[1]*boost,cur[2]+fwd[2]*boost); notify("~g~Boost!")
