from __future__ import annotations
import gta
from gta.natives import streaming, task
from pytrainer.Lib.animation_data import ANIMATIONS
from pytrainer.Lib.config import notify
from pytrainer.Lib.gta_compat import player_ped
def get_categories(): return [cat for cat,_ in ANIMATIONS]
def get_animations_in_category(category):
    for cat,anims in ANIMATIONS:
        if cat==category: return anims
    return []
def play_animation(anim_dict, anim_name):
    h=player_ped(); streaming.REQUEST_ANIM_DICT(anim_dict)
    for _ in range(10):
        if streaming.HAS_ANIM_DICT_LOADED(anim_dict): break
        gta.wait(50)
    else: notify("~r~Failed to load animation."); return
    task.TASK_PLAY_ANIM(h,anim_dict,anim_name,8.0,-8.0,-1,1,0.0,False,False,False); notify("~b~Playing: ~s~{}".format(anim_name))
def stop_animation(): task.CLEAR_PED_TASKS(player_ped()); notify("~b~Animation stopped.")
