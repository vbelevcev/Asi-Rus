from __future__ import annotations
import math
from gta.natives import entity, hud, misc, ped
from gta.player import current as current_player
def player_id(): return current_player().id
def player_ped(): return current_player().ped.handle
def current_vehicle():
    p = player_ped(); return ped.GET_VEHICLE_PED_IS_IN(p, False) if ped.IS_PED_IN_ANY_VEHICLE(p, False) else 0
def player_or_vehicle(): return current_vehicle() or player_ped()
def hash_key(name): return misc.GET_HASH_KEY(str(name))
def set_entity_pos(handle, xyz):
    x,y,z = float(xyz[0]), float(xyz[1]), float(xyz[2]); entity.SET_ENTITY_COORDS(handle, x,y,z, False, False, False, True)
def waypoint_coords():
    blip = hud.GET_FIRST_BLIP_INFO_ID(8); return hud.GET_BLIP_COORDS(blip) if blip and hud.DOES_BLIP_EXIST(blip) else None
def rotation_to_direction(rot):
    pitch = math.radians(float(rot[0])); yaw = math.radians(float(rot[2])); cp = math.cos(pitch); return (-math.sin(yaw)*cp, math.cos(yaw)*cp, math.sin(pitch))
def right_from_forward(fwd): return (float(fwd[1]), -float(fwd[0]), 0.0)
