from __future__ import annotations
import configparser
from pathlib import Path
import gta
from gta.player import current as current_player
PYTRAINER_DIR = Path(__file__).resolve().parents[1]
SAVE_DIR = PYTRAINER_DIR / "saves"
INI_PATH = PYTRAINER_DIR / "pytrainer.ini"
VK = {"BACK":8,"TAB":9,"ENTER":13,"SHIFT":16,"CTRL":17,"ESCAPE":27,"SPACE":32,"LEFT":37,"UP":38,"RIGHT":39,"DOWN":40,"A":65,"D":68,"S":83,"W":87,"F10":121}
for _i in range(1,13): VK["F{}".format(_i)] = 0x6F + _i
MENU_KEY_NAME = "F10"; MENU_KEY = VK[MENU_KEY_NAME]
NOCLIP_SPEED_NORMAL = 1.5; NOCLIP_SPEED_FAST = 5.0; BOOST_POWER = 25.0
NOT_IN_VEHICLE = "~b~Player is not in a ~r~Vehicle"
_DEFAULT_INI = """[Pytrainer]
MenuKey=F10
NoclipSpeed=1.5
NoclipSprintSpeed=5.0
BoostPower=25
"""
def _parse_key(value):
    raw = str(value).strip().upper(); aliases = {"RETURN":"ENTER","CONTROL":"CTRL","ESC":"ESCAPE","INSERT":"INSERT"}; raw = aliases.get(raw, raw)
    if raw == "INSERT": return raw, 45
    if raw in VK: return raw, VK[raw]
    if len(raw) == 1 and (48 <= ord(raw) <= 57 or 65 <= ord(raw) <= 90): return raw, ord(raw)
    return MENU_KEY_NAME, MENU_KEY
def _float_opt(section, key, default):
    try: return float(section.get(key, default))
    except Exception: return default
def load_ini():
    global MENU_KEY_NAME, MENU_KEY, NOCLIP_SPEED_NORMAL, NOCLIP_SPEED_FAST, BOOST_POWER
    ensure_save_dir()
    if not INI_PATH.exists(): INI_PATH.write_text(_DEFAULT_INI, encoding="utf-8")
    parser = configparser.ConfigParser(); parser.read(INI_PATH, encoding="utf-8")
    section = parser["Pytrainer"] if parser.has_section("Pytrainer") else {}
    MENU_KEY_NAME, MENU_KEY = _parse_key(section.get("MenuKey", MENU_KEY_NAME))
    NOCLIP_SPEED_NORMAL = _float_opt(section, "NoclipSpeed", NOCLIP_SPEED_NORMAL)
    NOCLIP_SPEED_FAST = _float_opt(section, "NoclipSprintSpeed", NOCLIP_SPEED_FAST)
    BOOST_POWER = _float_opt(section, "BoostPower", BOOST_POWER)
def ensure_save_dir():
    SAVE_DIR.mkdir(parents=True, exist_ok=True); (SAVE_DIR/"outfits").mkdir(exist_ok=True); (SAVE_DIR/"weapons").mkdir(exist_ok=True); return SAVE_DIR
def get_player(): return current_player().ped
def get_player_id(): return current_player().id
def notify(message): gta.notify(str(message))
def show_status(feature, is_enabled): notify("~b~{} {}".format(feature, "~g~Enabled" if is_enabled else "~r~Disabled"))
def clean_save_name(name): return "".join(ch for ch in str(name).strip() if ch.isalnum() or ch in " _-").strip()[:48]
