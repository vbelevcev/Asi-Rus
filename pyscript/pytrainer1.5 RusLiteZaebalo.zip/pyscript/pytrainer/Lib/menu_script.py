"""Pytrainer menus built with Lemonpy 0.1."""

from __future__ import annotations

from lemonpy import (
    NativeCheckboxItem,
    NativeItem,
    NativeListItem,
    NativeMenu,
    NativeSliderItem,
    ObjectPool,
)

from pytrainer.Lib import (
    animation_functions,
    outfit_functions,
    player_functions,
    vehicle_preview,
    vehicle_functions,
    weapon_functions,
    world_functions,
)


class TrainerMenu:
    _instance: "TrainerMenu | None" = None

    @classmethod
    def get_instance(cls) -> "TrainerMenu":
        if cls._instance is None:
            cls._instance = TrainerMenu()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        cls._instance = None

    def __init__(self) -> None:
        self.pool = ObjectPool()
        self.main = NativeMenu("Pytrainer 1.5", "Главное меню", "Python trainer для GTA V")
        self.main.banner_title = "Pytrainer 1.5 "
        self.pool.add(self.main)
        self._vehicle_preview_pages: dict[NativeMenu, list] = {}
        self._build_menus()

    def toggle(self) -> None:
        self.pool.toggle(self.main)

    def open_menu(self) -> None:
        self.pool.open(self.main)

    def close_menu(self) -> None:
        self.pool.close()

    def is_visible(self) -> bool:
        return self.pool.visible

    def handle_key(self, vk: int) -> bool:
        return self.pool.handle_key(vk)

    def tick(self) -> None:
        self.pool.process()
        self._draw_vehicle_preview()

    def _build_menus(self) -> None:
        player = self._menu("Игрок", "PLAYER OPTIONS")
        wanted = self._menu("Розыск", "WANTED OPTIONS")
        outfits = self._menu("Одежда", "OUTFIT OPTIONS")
        emotes = self._menu("Эмоции", "EMOTES")
        vehicle = self._menu("Транспорт", "VEHICLE OPTIONS")
        spawn = self._menu("Создать транспорт", "SPAWN VEHICLE")
        weapons = self._menu("Оружие", "WEAPON OPTIONS")
        world = self._menu("Мир", "WORLD OPTIONS")
        weather = self._menu("Погода", "WEATHER")
        time = self._menu("Время", "SET TIME")

        self.main.add_submenu(player, "Игрок", "Опции игрока")
        self.main.add_submenu(vehicle, "Транспорт", "Опции транспорта")
        self.main.add_submenu(weapons, "Оружие", "Опции оружия")
        self.main.add_submenu(world, "Мир", "Время, погода и гравитация")

        self._checkbox(player, "Бессмертие", "Бессмертие", player_functions.toggle_god_mode)
        self._checkbox(player, "Бесконечная выносливость", "Бесконечная выносливость", player_functions.toggle_infinite_stamina)
        self._checkbox(player, "Невидимость", "Невидимость", player_functions.set_player_visibility)
        self._checkbox(player, "Супер прыжок", "Прыгать высоко", player_functions.toggle_super_jump)
        self._checkbox(player, "Быстрый бег", "Бегать быстро", player_functions.toggle_fast_run)
        self._checkbox(player, "Быстрое плавание", "Плавать быстро", player_functions.toggle_quick_swim)
        self._checkbox(player, "Noclip", "Fly through walls (WASD + Shift) крашит", player_functions.toggle_noclip)
        self._action(player, "Телепорт к метке", "Телепорт к поставленной метке на карте", player_functions.teleport_to_waypoint)
        self._action(player, "Телепорт на координаты", "Введите координаты x,y,z",
                     lambda: self.pool.input_text("x,y,z", player_functions.teleport_to_coords))
        self._action(player, "Восполнить игрока", "Полное здоровье и броня", player_functions.heal_player)
        self._action(player, "Очистить игрока", "Очистить от крови/повреждений", player_functions.clean_ped)
        self._action(player, "Дать денег", "Enter a cash amount",
                     lambda: self.pool.input_number("Cash amount", player_functions.set_player_cash))
        player.add_submenu(wanted, "Розыск", "Система розыска")
        player.add_submenu(outfits, "Одежда", "Сохранить / Загрузить одежду")
        player.add_submenu(emotes, "Анимации", "Проигрывать анимации")

        self._slider(wanted, "Уровень розыска", "Установить розыск 0-5", 0, 5, 0,
                     player_functions.set_player_wanted_level)
        self._action(wanted, "Убрать розыск", "Убрать розыск", player_functions.clear_wanted_level)
        self._checkbox(wanted, "Отключить розыск", "Отключить систему розыска", player_functions.toggle_never_wanted)

outfits.add_submenu(self._dynamic_menu("Загрузить одежду", "LOAD OUTFIT",
  outfit_functions.list_outfits, outfit_functions.load_outfit),
 "Загрузить одежду", "Выбрать сохранённую одежду")
 
self._action(outfits, "Сохранить текущую одежду", "Сохранить текущую одежду",
 lambda: self.pool.input_text("Имя одежды", outfit_functions.save_outfit))
 self._action(outfits, "Удалить сохранённую одежду", "Удалить сохранённую одежду",
 lambda: self.pool.input_text("Outfit to delete", outfit_functions.delete_outfit))


        self._action(emotes, "Остановить анимацию", "Остановить текущую анимацию", animation_functions.stop_animation)
        for category in animation_functions.get_categories():
            page = self._menu(category, category.upper())
            for anim_dict, anim_name, display in animation_functions.get_animations_in_category(category):
                self._action(page, display, "", lambda d=anim_dict, n=anim_name: animation_functions.play_animation(d, n))
            emotes.add_submenu(page, category, "")

        vehicle.add_submenu(spawn, "Создать транспорт", "Browse vehicle categories")

        for category in vehicle_functions.get_vehicle_categories():
            page = self._menu(category, category.upper())
            vehicles = vehicle_functions.get_vehicles_in_category(category)
            self._vehicle_preview_pages[page] = vehicles
            for entry in vehicles:
                display = entry[1] if len(entry) > 1 else entry[0]
                self._action(page, display, "", lambda model=entry[0]: vehicle_functions.spawn_vehicle(model))
            spawn.add_submenu(page, category, "")

 self._checkbox(vehicle, "God Mode", "Vehicle invincibility", vehicle_functions.toggle_god_mode)
 self._checkbox(vehicle, "Seatbelt", "Prevent falling out", vehicle_functions.toggle_seatbelt)
 self._action(vehicle, "Max Tune", "Fully upgrade current vehicle", vehicle_functions.max_tune_vehicle)
        self._action(vehicle, "Speed Boost", "Launch vehicle forward", vehicle_functions.speed_boost)
        self._action(vehicle, "Fix Vehicle", "Repair + clean", vehicle_functions.fix_vehicle)
        self._action(vehicle, "Clean Vehicle", "Wash vehicle", vehicle_functions.clean_vehicle)
        self._action(vehicle, "Delete Vehicle", "Remove current vehicle", vehicle_functions.delete_current_vehicle)
        self._action(vehicle, "Custom Spawn", "Enter a model name",
                     lambda: self.pool.input_text("Vehicle model", vehicle_functions.spawn_vehicle))


        self._checkbox(weapons, "Бесконечные патроны", "Never run out", weapon_functions.toggle_infinite_ammo)
        weapon_item = NativeListItem("Выбрать оружие", "Pick & receive a weapon",
                                     values=weapon_functions.WEAPON_LIST)
        weapon_item.on_changed.append(lambda item: weapon_functions.select_weapon(item[1]))
        weapons.add(weapon_item)
        self._action(weapons, "Give Selected Weapon", "Give the weapon shown above", lambda: weapon_item.activate(self.pool))
        self._action(weapons, "Give All Weapons", "All weapons + 9999 ammo", weapon_functions.give_all_weapons)
        self._action(weapons, "Remove All Weapons", "Strip every weapon", weapon_functions.remove_all_weapons)
        self._action(weapons, "Remove Current Weapon", "Drop held weapon", weapon_functions.remove_current_weapon)
        self._action(weapons, "Set Ammo", "Enter ammo amount",
                     lambda: self.pool.input_number("Ammo", weapon_functions.set_ammo))
        self._action(weapons, "Save Current Weapons", "Save weapon inventory",
                     lambda: self.pool.input_text("Weapon save name", weapon_functions.save_weapons))
        self._action(weapons, "Delete Weapon Save", "Delete a saved loadout",
                     lambda: self.pool.input_text("Weapon save to delete", weapon_functions.delete_weapon_save))
        weapons.add_submenu(self._dynamic_menu("Загрузить сборку оружия", "LOAD WEAPONS",
                            weapon_functions.list_weapon_saves, weapon_functions.load_weapons),
                            "Загрузить сборку оружия", "Select a saved loadout")

        self._checkbox(world, "Заморозить время", "Stop the clock", world_functions.freeze_time)
        self._checkbox(world, "Низкая гравитация", "Moon-like gravity", world_functions.set_low_gravity)
        world.add_submenu(weather, "Погода", "Change weather")
        world.add_submenu(time, "Время", "Adjust game clock")
        for name in world_functions.get_available_weathers():
            self._action(weather, name, "", lambda weather_name=name: world_functions.set_weather(weather_name))
        self._slider(time, "Час", "Set hour (0-23)", 0, 23, 12, world_functions.set_hour)
        self._slider(time, "Минута", "Set minute (0-59)", 0, 59, 0, world_functions.set_minutes)
        self._slider(time, "Секунда", "Set second (0-59)", 0, 59, 0, world_functions.set_seconds)

    def _menu(self, title: str, subtitle: str) -> NativeMenu:
        menu = NativeMenu("PYTrainer", subtitle, title)
        menu.banner_title = "PYTRAINER"
        self.pool.add(menu)
        return menu

    def _dynamic_menu(self, title: str, subtitle: str, list_func, action_func) -> NativeMenu:
        menu = self._menu(title, subtitle)

        @menu.opened
        def refresh(page: NativeMenu) -> None:
            page.clear()
            names = list_func()
            if not names:
                page.add(NativeItem("Сохранений не найдено"))
                return
            for name in names:
                self._action(page, name, "", lambda save_name=name: action_func(save_name))

        return menu

    def _draw_vehicle_preview(self) -> None:
        if not self.pool.visible or self.pool.current is None:
            return
        vehicles = self._vehicle_preview_pages.get(self.pool.current)
        if not vehicles:
            return
        idx = self.pool.current.selected_index
        if idx < 0 or idx >= len(vehicles):
            return
        entry = vehicles[idx]
        if len(entry) < 4:
            return
        vehicle_preview.draw_vehicle_preview(entry[2], entry[3])

    @staticmethod
    def _action(menu: NativeMenu, title: str, description: str, callback) -> NativeItem:
        item = NativeItem(title, description)
        item.on_activated.append(callback)
        menu.add(item)
        return item

    @staticmethod
    def _checkbox(menu: NativeMenu, title: str, description: str, callback) -> NativeCheckboxItem:
        item = NativeCheckboxItem(title, description, checked=False)
        item.on_changed.append(callback)
        menu.add(item)
        return item

    @staticmethod
    def _slider(menu: NativeMenu, title: str, description: str, minimum: int, maximum: int,
                value: int, callback) -> NativeSliderItem:
        item = NativeSliderItem(title, description, minimum=minimum, maximum=maximum, value=value)
        item.on_changed.append(callback)
        menu.add(item)
        return item
