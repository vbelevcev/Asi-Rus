from __future__ import annotations
from gta.natives import ped
from pytrainer.Lib.config import clean_save_name, ensure_save_dir, notify
from pytrainer.Lib.gta_compat import player_ped
_NUM_COMPONENTS=12; _NUM_PROPS=9
def _outfit_save_dir(): d=ensure_save_dir()/"outfits"; d.mkdir(exist_ok=True); return d
def _get_components(h): return [(i,ped.GET_PED_DRAWABLE_VARIATION(h,i),ped.GET_PED_TEXTURE_VARIATION(h,i),ped.GET_PED_PALETTE_VARIATION(h,i)) for i in range(_NUM_COMPONENTS)]
def _get_props(h): return [(i,ped.GET_PED_PROP_INDEX(h,i,0),ped.GET_PED_PROP_TEXTURE_INDEX(h,i)) for i in range(_NUM_PROPS)]
def save_outfit(save_name):
    name=clean_save_name(save_name)
    if not name: notify("~r~Save name cannot be empty."); return
    try:
        h=player_ped(); lines=["C|{}|{}|{}|{}".format(*row) for row in _get_components(h)] + ["P|{}|{}|{}".format(*row) for row in _get_props(h)]
        (_outfit_save_dir()/(name+".txt")).write_text("\n".join(lines),encoding="utf-8"); notify("~g~Outfit saved: ~s~{}".format(name))
    except Exception as exc: notify("~r~Outfit save error: {}".format(exc))
def load_outfit(save_name):
    name=clean_save_name(save_name); path=_outfit_save_dir()/(name+".txt")
    if not path.exists(): notify("~r~Outfit not found: {}".format(name)); return
    try:
        h=player_ped()
        for line in path.read_text(encoding="utf-8").splitlines():
            parts=line.strip().split("|")
            if parts[0]=="C" and len(parts)==5: ped.SET_PED_COMPONENT_VARIATION(h,int(parts[1]),int(parts[2]),int(parts[3]),int(parts[4]))
            elif parts[0]=="P" and len(parts)==4:
                if int(parts[2])<0: ped.CLEAR_PED_PROP(h,int(parts[1]),0)
                else: ped.SET_PED_PROP_INDEX(h,int(parts[1]),int(parts[2]),int(parts[3]),True,0)
        notify("~g~Outfit loaded: ~s~{}".format(name))
    except Exception as exc: notify("~r~Outfit load error: {}".format(exc))
def delete_outfit(save_name):
    name=clean_save_name(save_name); path=_outfit_save_dir()/(name+".txt")
    if path.exists(): path.unlink(); notify("~y~Deleted outfit: {}".format(name))
    else: notify("~r~Outfit not found.")
def list_outfits(): return sorted(path.stem for path in _outfit_save_dir().glob("*.txt"))
