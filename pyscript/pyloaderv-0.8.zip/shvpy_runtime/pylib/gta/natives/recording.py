"""Auto-generated raw native bindings for namespace RECORDING.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib


def STOP_REPLAY_RECORDING() -> None:
    _iv(0x071A5197D6AFC8B3)

def REPLAY_CANCEL_EVENT() -> None:
    _iv(0x13B350B8AD0EEE10)

def IS_REPLAY_RECORDING() -> bool:
    return _ib(0x1897CA71995A90B4)

def REPLAY_CHECK_FOR_EVENT_THIS_FRAME(missionNameLabel: str, p1: int) -> None:
    _iv(0x208784099002BC30, missionNameLabel, p1)

def REPLAY_RECORD_BACK_FOR_TIME(p0: float, p1: float, p2: int) -> None:
    _iv(0x293220DA1B46CEBC, p0, p1, p2)

def IS_REPLAY_RECORD_SPACE_AVAILABLE(p0: bool) -> bool:
    return _ib(0x33D47E85B476ABCD, p0)

def IS_REPLAY_AVAILABLE() -> bool:
    return _ib(0x4282E08174868BE3)

def REPLAY_START_EVENT(p0: int) -> None:
    _iv(0x48621C9FCA3EBD28, p0)

def SAVE_REPLAY_RECORDING() -> bool:
    return _ib(0x644546EC5287471B)

def RECORD_GREATEST_MOMENT(p0: int, p1: int, p2: int) -> None:
    _iv(0x66972397E0757E7A, p0, p1, p2)

def REPLAY_STOP_EVENT() -> None:
    _iv(0x81CBAE94390F9F89)

def CANCEL_REPLAY_RECORDING() -> None:
    _iv(0x88BB3507ED41A240)

def REPLAY_DISABLE_CAMERA_MOVEMENT_THIS_FRAME() -> None:
    _iv(0xAF66DCEE6609B148)

def START_REPLAY_RECORDING(mode: int) -> None:
    _iv(0xC3AC2FFF9612AC81, mode)

def IS_REPLAY_INITIALIZED() -> bool:
    return _ib(0xDF4B952F7D381B95)

def REPLAY_PREVENT_RECORDING_THIS_FRAME() -> None:
    _iv(0xEB2D525B57F42B40)

def REPLAY_RESET_EVENT_INFO() -> None:
    _iv(0xF854439EFBB3B583)
