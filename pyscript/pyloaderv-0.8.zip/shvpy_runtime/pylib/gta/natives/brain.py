"""Auto-generated raw native bindings for namespace BRAIN.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib


def REACTIVATE_ALL_WORLD_BRAINS_THAT_ARE_WAITING_TILL_OUT_OF_RANGE() -> None:
    _iv(0x0B40ED49D7D6FF84)

def REGISTER_OBJECT_SCRIPT_BRAIN(scriptName: str, modelHash: int, p2: int, activationRange: float, p4: int, p5: int) -> None:
    _iv(0x0BE84C318BA6EC22, scriptName, modelHash, p2, activationRange, p4, p5)

def DISABLE_SCRIPT_BRAIN_SET(brainSet: int) -> None:
    _iv(0x14D8518E9760F08F, brainSet)

def REGISTER_WORLD_POINT_SCRIPT_BRAIN(scriptName: str, activationRange: float, p2: int) -> None:
    _iv(0x3CDC7136613284BD, scriptName, activationRange, p2)

def REACTIVATE_ALL_OBJECT_BRAINS_THAT_ARE_WAITING_TILL_OUT_OF_RANGE() -> None:
    _iv(0x4D953DF78EBF8158)

def ADD_SCRIPT_TO_RANDOM_PED(name: str, model: int, p2: float, p3: float) -> None:
    _iv(0x4EE5367468A65CCC, name, model, p2, p3)

def ENABLE_SCRIPT_BRAIN_SET(brainSet: int) -> None:
    _iv(0x67AA4D73F0CFA86B, brainSet)

def REACTIVATE_NAMED_WORLD_BRAINS_WAITING_TILL_OUT_OF_RANGE(scriptName: str) -> None:
    _iv(0x6D6840CEE8845831, scriptName)

def REACTIVATE_NAMED_OBJECT_BRAINS_WAITING_TILL_OUT_OF_RANGE(scriptName: str) -> None:
    _iv(0x6E91B04E08773030, scriptName)

def IS_WORLD_POINT_WITHIN_BRAIN_ACTIVATION_RANGE() -> bool:
    return _ib(0xC5042CC6F5E3D450)

def IS_OBJECT_WITHIN_BRAIN_ACTIVATION_RANGE(object: int) -> bool:
    return _ib(0xCCBA154209823057, object)
