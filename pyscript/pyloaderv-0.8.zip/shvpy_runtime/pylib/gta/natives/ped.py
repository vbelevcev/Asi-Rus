"""Auto-generated raw native bindings for namespace PED.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_str as _is, _invoke_vector3 as _ivec


def RESET_FACIAL_IDLE_ANIM(ped: int) -> None:
    _iv(0x007FDE5A7897E426, ped)

def IS_PED_USING_ACTION_MODE(ped: int) -> bool:
    return _ib(0x00E73468D085F745, ped)

def GET_PED_MAKEUP_TINT_COLOR(makeupColorIndex: int, outR: int, outG: int, outB: int) -> None:
    _iv(0x013E5CFC38CD5387, makeupColorIndex, outR, outG, outB)

def SET_PED_MIN_MOVE_BLEND_RATIO(ped: int, value: float) -> None:
    _iv(0x01A898D26E2333DD, ped, value)

def SET_PED_RAGDOLL_FORCE_FALL(ped: int) -> None:
    _iv(0x01F6594B923B9251, ped)

def IS_PED_ON_FOOT(ped: int) -> bool:
    return _ib(0x01FEE67DB37F59B2, ped)

def SET_PED_AS_ENEMY(ped: int, toggle: bool) -> None:
    _iv(0x02A0C9720B854BFA, ped, toggle)

def SET_PED_DUCKING(ped: int, toggle: bool) -> None:
    _iv(0x030983CA930B692D, ped, toggle)

def GET_CAN_PED_BE_GRABBED_BY_SCRIPT(ped: int, p1: bool, p2: bool, p3: bool, p4: bool, p5: bool, p6: bool, p7: bool, p8: int) -> bool:
    return _ib(0x03EA03AF85A85CB7, ped, p1, p2, p3, p4, p5, p6, p7, p8)

def GET_PED_TEXTURE_VARIATION(ped: int, componentId: int) -> int:
    return _ii(0x04A355E041E004E6, ped, componentId)

def IS_PED_LIPSTICK_TINT_FOR_BARBER(colorID: int) -> bool:
    return _ib(0x0525A2C2562F3CD4, colorID)

def IS_TARGET_PED_IN_PERCEPTION_AREA(ped: int, targetPed: int, p2: float, p3: float, p4: float, p5: float) -> bool:
    return _ib(0x06087579E7AA85A9, ped, targetPed, p2, p3, p4, p5)

def SET_ALLOW_LOCKON_TO_PED_IF_FRIENDLY(ped: int, toggle: bool) -> None:
    _iv(0x061CB768363D6424, ped, toggle)

def SET_PED_TARGET_LOSS_RESPONSE(ped: int, responseType: int) -> None:
    _iv(0x0703B9079823DA4A, ped, responseType)

def IS_ANY_PED_NEAR_POINT(x: float, y: float, z: float, radius: float) -> bool:
    return _ib(0x083961498679DC9F, x, y, z, radius)

def SET_PED_MOVE_RATE_OVERRIDE(ped: int, value: float) -> None:
    _iv(0x085BF80FA50A39D1, ped, value)

def CLEAR_PED_PROP(ped: int, propId: int, p2: int) -> None:
    _iv(0x0943E5B8E078E76E, ped, propId, p2)

def IS_PED_BLUSH_FACEPAINT_TINT_FOR_BARBER(colorId: int) -> bool:
    return _ib(0x09E7ECA981D9B210, colorId)

def SET_PED_MOTION_BLUR(ped: int, toggle: bool) -> None:
    _iv(0x0A986918B102B448, ped, toggle)

def SET_PED_MOVE_RATE_IN_WATER_OVERRIDE(ped: int, p1: float) -> None:
    _iv(0x0B3E35AC043707D9, ped, p1)

def IS_PED_IN_ANY_POLICE_VEHICLE(ped: int) -> bool:
    return _ib(0x0BD04E29640C9C12, ped)

def SET_PED_GROUP_MEMBER_PASSENGER_INDEX(ped: int, index: int) -> None:
    _iv(0x0BDDB8D9EC6BCF3C, ped, index)

def CLEAR_PED_DECORATIONS(ped: int) -> None:
    _iv(0x0E5173C163976E38, ped)

def SET_PED_CAN_PLAY_AMBIENT_BASE_ANIMS(ped: int, toggle: bool) -> None:
    _iv(0x0EB0585D15254740, ped, toggle)

def SET_PED_TREATED_AS_FRIENDLY(p0: int, p1: int, p2: int) -> None:
    _iv(0x0F62619393661D6E, p0, p1, p2)

def _SET_PED_SURVIVES_BEING_OUT_OF_WATER(ped: int, toggle: bool) -> bool:
    return _ib(0x100CD221F572F6E1, ped, toggle)

def SET_CREATE_RANDOM_COPS(toggle: bool) -> None:
    _iv(0x102E68B2024D536D, toggle)

def SET_PED_ENVEFF_CPV_ADD(ped: int, p1: float) -> None:
    _iv(0x110F526AB784111F, ped, p1)

def SET_PED_TO_INFORM_RESPECTED_FRIENDS(ped: int, radius: float, maxFriends: int) -> None:
    _iv(0x112942C6E708F70B, ped, radius, maxFriends)

def IS_PED_VAULTING(ped: int) -> bool:
    return _ib(0x117C70D1F5730B5E, ped)

def WAS_PED_SKELETON_UPDATED(ped: int) -> bool:
    return _ib(0x11B499C1E0FF8559, ped)

def REQUEST_RAGDOLL_BOUNDS_UPDATE(p0: int, p1: int) -> None:
    _iv(0x1216E0BFA72CC703, p0, p1)

def IS_PED_A_PLAYER(ped: int) -> bool:
    return _ib(0x12534C348C6CB68B, ped)

def CLEAR_PED_PARACHUTE_PACK_VARIATION(ped: int) -> None:
    _iv(0x1280804F7CFD2D6C, ped)

def CAN_PED_RAGDOLL(ped: int) -> bool:
    return _ib(0x128F79EDCECE4FD5, ped)

def SET_FORCE_FOOTSTEP_UPDATE(ped: int, toggle: bool) -> None:
    _iv(0x129466ED55140F8D, ped, toggle)

def SET_PED_BLEND_FROM_PARENTS(ped: int, p1: int, p2: int, p3: float, p4: float) -> None:
    _iv(0x137BBD05230DB22D, ped, p1, p2, p3, p4)

def REMOVE_ACTION_MODE_ASSET(asset: str) -> None:
    _iv(0x13E940F88470FA51, asset)

def IS_PED_TAKING_OFF_HELMET(ped: int) -> bool:
    return _ib(0x14590DDBEDB1EC85, ped)

def GET_PED_EMISSIVE_SCALE(ped: int) -> float:
    return _if(0x1461B28A06717D68, ped)

def CLONE_PED_TO_TARGET_ALT(ped: int, targetPed: int, p2: bool) -> None:
    _iv(0x148B08C2D2ACB884, ped, targetPed, p2)

def SET_SCENARIO_PEDS_TO_BE_RETURNED_BY_NEXT_COMMAND(value: bool) -> None:
    _iv(0x14F19A8782C8071E, value)

def SET_PED_STEERS_AROUND_OBJECTS(ped: int, toggle: bool) -> None:
    _iv(0x1509C089ADC208BF, ped, toggle)

def FORCE_PED_TO_OPEN_PARACHUTE(ped: int) -> None:
    _iv(0x16E42E800B472221, ped)

def IS_COP_PED_IN_AREA_3D(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> bool:
    return _ib(0x16EC4839969F9F5E, x1, y1, z1, x2, y2, z2)

def GET_PED_CAUSE_OF_DEATH(ped: int) -> int:
    return _ii(0x16FFE42AB2D2DC59, ped)

def GET_PED_BONE_COORDS(ped: int, boneId: int, offsetX: float, offsetY: float, offsetZ: float) -> 'gta.Vector3':
    return _ivec(0x17C07FC640E86B4E, ped, boneId, offsetX, offsetY, offsetZ)

def GET_MELEE_TARGET_FOR_PED(ped: int) -> int:
    return _ii(0x18A3E9EE1297FD39, ped)

def SET_PED_CONFIG_FLAG(ped: int, flagId: int, value: bool) -> None:
    _iv(0x1913FE4CBF41C463, ped, flagId, value)

def SET_LADDER_CLIMB_INPUT_STATE(ped: int, p1: int) -> None:
    _iv(0x1A330D297AAC6BC1, ped, p1)

def SET_AI_WEAPON_DAMAGE_MODIFIER(value: float) -> None:
    _iv(0x1B1E2A40A65B8521, value)

def ADD_SCENARIO_BLOCKING_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, p6: bool, p7: bool, p8: bool, p9: bool, p10: int) -> int:
    return _ii(0x1B5C85C612E5256E, x1, y1, z1, x2, y2, z2, p6, p7, p8, p9, p10)

def IS_PED_USING_SCENARIO(ped: int, scenario: str) -> bool:
    return _ib(0x1BF094736DD62C2E, ped, scenario)

def IS_PED_HANGING_ON_TO_VEHICLE(ped: int) -> bool:
    return _ib(0x1C86D8AEF8254B78, ped)

def SET_PED_CAN_SMASH_GLASS(ped: int, p1: bool, p2: bool) -> None:
    _iv(0x1CCE141467FF42A2, ped, p1, p2)

def SET_GROUP_FORMATION_SPACING(groupId: int, x: float, y: float, z: float) -> None:
    _iv(0x1D9D45004C28C916, groupId, x, y, z)

def GET_FM_MALE_SHOP_PED_APPAREL_ITEM_INDEX(p0: int) -> int:
    return _ii(0x1E77FA7A62EE6C4C, p0)

def GET_PED_TIME_OF_DEATH(ped: int) -> int:
    return _ii(0x1E98817B311AE98A, ped)

def SET_PED_STEERS_AROUND_DEAD_BODIES(ped: int, toggle: bool) -> None:
    _iv(0x2016C603D6B8987C, ped, toggle)

def RESET_PED_STRAFE_CLIPSET(ped: int) -> None:
    _iv(0x20510814175EA477, ped)

def GET_PED_RAGDOLL_BONE_INDEX(ped: int, bone: int) -> int:
    return _ii(0x2057EF813397A772, ped, bone)

def FORCE_PED_AI_AND_ANIMATION_UPDATE(ped: int, p1: bool, p2: bool) -> None:
    _iv(0x2208438012482A1A, ped, p1, p2)

def RESET_PED_IN_VEHICLE_CONTEXT(ped: int) -> None:
    _iv(0x22EF8FF8778030EB, ped)

def GET_PED_NEARBY_PEDS(ped: int, sizeAndPeds: int, ignore: int) -> int:
    return _ii(0x23F8F5FC7E8C4A6B, ped, sizeAndPeds, ignore)

def IS_PED_RELOADING(ped: int) -> bool:
    return _ib(0x24B100C68C645951, ped)

def TRIGGER_PED_SCENARIO_PANICEXITTOFLEE(p0: int, p1: int, p2: int, p3: int) -> bool:
    return _ib(0x25361A96E0F7E419, p0, p1, p2, p3)

def IS_SYNCHRONIZED_SCENE_RUNNING(sceneId: int) -> bool:
    return _ib(0x25D39B935A038A26, sceneId)

def SET_PED_WEAPON_MOVEMENT_CLIPSET(ped: int, clipSet: str) -> None:
    _iv(0x2622E35B77D3ACA2, ped, clipSet)

def SET_PED_COMPONENT_VARIATION(ped: int, componentId: int, drawableId: int, textureId: int, paletteId: int) -> None:
    _iv(0x262B14F48D29DE80, ped, componentId, drawableId, textureId, paletteId)

def SET_RAGDOLL_BLOCKING_FLAGS(ped: int, blockingFlag: int) -> None:
    _iv(0x26695EC767728D84, ped, blockingFlag)

def IS_PED_OPENING_DOOR(ped: int) -> bool:
    return _ib(0x26AF0E8E30BD2A2C, ped)

def SET_PED_HELMET_PROP_INDEX(ped: int, propIndex: int, p2: bool) -> None:
    _iv(0x26D83693ED99291C, ped, propIndex, p2)

def ATTACH_SYNCHRONIZED_SCENE_TO_ENTITY(sceneID: int, entity: int, boneIndex: int) -> None:
    _iv(0x272E4723B56A3B96, sceneID, entity, boneIndex)

def SET_CORPSE_RAGDOLL_FRICTION(ped: int, p1: float) -> None:
    _iv(0x2735233A786B1BEF, ped, p1)

def GET_PED_HEAD_BLEND_DATA(ped: int, headBlendData: int) -> bool:
    return _ib(0x2746BD9D88C5C5D0, ped, headBlendData)

def GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(ped: int, componentId: int) -> int:
    return _ii(0x27561561732A7842, ped, componentId)

def SET_PED_SWEAT(ped: int, sweat: float) -> None:
    _iv(0x27B0405F59637D1F, ped, sweat)

def SPAWNPOINTS_GET_SEARCH_RESULT(randomInt: int, x: int, y: int, z: int) -> None:
    _iv(0x280C7E3AC7F56E90, randomInt, x, y, z)

def SET_SCENARIO_PEDS_SPAWN_IN_SPHERE_AREA(x: float, y: float, z: float, range: float, p4: int) -> None:
    _iv(0x28157D43CF600981, x, y, z, range, p4)

def SET_PED_STEER_BIAS(ped: int, value: float) -> None:
    _iv(0x288DF530C92DAD6F, ped, value)

def REQUEST_ACTION_MODE_ASSET(asset: str) -> None:
    _iv(0x290E2780BB7AA598, asset)

def IS_PED_IN_ANY_HELI(ped: int) -> bool:
    return _ib(0x298B91AE825E5705, ped)

def SET_PED_STRAFE_CLIPSET(ped: int, clipSet: str) -> None:
    _iv(0x29A28F3F8CF6D854, ped, clipSet)

def REQUEST_STEALTH_MODE_ASSET(asset: str) -> None:
    _iv(0x2A0A62FCDEE16D4F, asset)

def SET_PED_DIES_IN_VEHICLE(ped: int, toggle: bool) -> None:
    _iv(0x2A30922C90C9B42C, ped, toggle)

def SET_PED_AS_GROUP_LEADER(ped: int, groupId: int) -> None:
    _iv(0x2A7819605465FBCE, ped, groupId)

def IS_PED_RUNNING_MOBILE_PHONE_TASK(ped: int) -> bool:
    return _ib(0x2AFE52F782F25775, ped)

def SET_PED_PRELOAD_PROP_DATA(ped: int, componentId: int, drawableId: int, TextureId: int) -> int:
    return _ii(0x2B16A3BFF1FBCE49, ped, componentId, drawableId, TextureId)

def SET_PED_AO_BLOB_RENDERING(ped: int, toggle: bool) -> None:
    _iv(0x2B5AA717A181FB4C, ped, toggle)

def MARK_PED_DECORATIONS_AS_CLONED_FROM_LOCAL_PLAYER(ped: int, p1: bool) -> None:
    _iv(0x2B694AFCF64E6994, ped, p1)

def REQUEST_PED_VEHICLE_VISIBILITY_TRACKING(ped: int, p1: bool) -> None:
    _iv(0x2BC338A7B21F4608, ped, p1)

def EXPLODE_PED_HEAD(ped: int, weaponHash: int) -> None:
    _iv(0x2D05CED3A38D0F3A, ped, weaponHash)

def SET_PED_VISUAL_FIELD_MIN_ANGLE(ped: int, value: float) -> None:
    _iv(0x2DB492222FB21E26, ped, value)

def SPAWNPOINTS_START_SEARCH(p0: float, p1: float, p2: float, p3: float, p4: float, interiorFlags: int, scale: float, duration: int) -> None:
    _iv(0x2DF9038C90AD5264, p0, p1, p2, p3, p4, interiorFlags, scale, duration)

def CAN_PED_SHUFFLE_TO_OR_FROM_EXTRA_SEAT(ped: int, p1: int) -> bool:
    return _ib(0x2DFC81C9B9608549, ped, p1)

def CLEAR_PED_NON_CREATION_AREA() -> None:
    _iv(0x2E05208086BA0651)

def IS_PED_IN_ANY_BOAT(ped: int) -> bool:
    return _ib(0x2E0E1C2B4F6CB339, ped)

def SET_PED_CAN_TELEPORT_TO_GROUP_LEADER(pedHandle: int, groupHandle: int, toggle: bool) -> None:
    _iv(0x2E2F4240B3F24647, pedHandle, groupHandle, toggle)

def SET_COP_PERCEPTION_OVERRIDES(seeingRange: float, seeingRangePeripheral: float, hearingRange: float, visualFieldMinAzimuthAngle: float, visualFieldMaxAzimuthAngle: float, fieldOfGazeMaxAngle: float, p6: float) -> None:
    _iv(0x2F074C904D85129E, seeingRange, seeingRangePeripheral, hearingRange, visualFieldMinAzimuthAngle, visualFieldMaxAzimuthAngle, fieldOfGazeMaxAngle, p6)

def REGISTER_TARGET(ped: int, target: int) -> None:
    _iv(0x2F25D9AEFA34FBA2, ped, target)

def SET_TREAT_AS_AMBIENT_PED_FOR_DRIVER_LOCKON(ped: int, p1: bool) -> None:
    _iv(0x2F3C3D9F50681DE4, ped, p1)

def REMOVE_SCENARIO_BLOCKING_AREA(p0: int, p1: bool) -> None:
    _iv(0x31D16B74C6E29D66, p0, p1)

def GET_PED_TARGET_FROM_COMBAT_PED(ped: int, p1: int) -> int:
    return _ii(0x32C27A11307B01CC, ped, p1)

def APPLY_PED_BLOOD_BY_ZONE(ped: int, p1: int, p2: float, p3: float, p4: str) -> None:
    _iv(0x3311E47B91EDCBBC, ped, p1, p2, p3, p4)

def IS_PED_DEAD_OR_DYING(ped: int, p1: bool) -> bool:
    return _ib(0x3317DEDB88C95038, ped, p1)

def SET_PED_TO_LOAD_COVER(ped: int, toggle: bool) -> None:
    _iv(0x332B562EEDA62399, ped, toggle)

def SET_PED_PARACHUTE_TINT_INDEX(ped: int, tintIndex: int) -> None:
    _iv(0x333FC8DB079B7186, ped, tintIndex)

def COUNT_PEDS_IN_COMBAT_WITH_TARGET_WITHIN_RADIUS(ped: int, x: float, y: float, z: float, radius: float) -> int:
    return _ii(0x336B3D200AB007CB, ped, x, y, z, radius)

def SET_PED_IS_IGNORED_BY_AUTO_OPEN_DOORS(ped: int, p1: bool) -> None:
    _iv(0x33A60D8BDD6E508C, ped, p1)

def SET_PED_HEARING_RANGE(ped: int, value: float) -> None:
    _iv(0x33A8F7F7D5F7F33C, ped, value)

def IS_PED_SHOOTING(ped: int) -> bool:
    return _ib(0x34616828CD07F1A1, ped)

def SET_PED_CAPSULE(ped: int, value: float) -> None:
    _iv(0x364DF566EC833DE2, ped, value)

def GET_TIME_PED_DAMAGED_BY_WEAPON(ped: int, weaponHash: int) -> int:
    return _ii(0x36B77BB84687C318, ped, weaponHash)

def SET_PED_SCUBA_GEAR_VARIATION(ped: int) -> None:
    _iv(0x36C6984C3ED0C911, ped)

def IS_PED_SWITCHING_WEAPON(Ped: int) -> bool:
    return _ib(0x3795688A307E1EB6, Ped)

def GET_PED_ACCURACY(ped: int) -> int:
    return _ii(0x37F4AD56ECBC0CD6, ped)

def SET_SYNCHRONIZED_SCENE_HOLD_LAST_FRAME(sceneID: int, toggle: bool) -> None:
    _iv(0x394B9CD12435C981, sceneID, toggle)

def APPLY_PED_DAMAGE_DECAL(ped: int, damageZone: int, xOffset: float, yOffset: float, heading: float, scale: float, alpha: float, variation: int, fadeIn: bool, decalName: str) -> None:
    _iv(0x397C38AA7B4A5F83, ped, damageZone, xOffset, yOffset, heading, scale, alpha, variation, fadeIn, decalName)

def IS_PED_AIMING_FROM_COVER(ped: int) -> bool:
    return _ib(0x3998B1276A3300E5, ped)

def SET_PED_PRELOAD_VARIATION_DATA(ped: int, slot: int, drawableId: int, textureId: int) -> int:
    return _ii(0x39D55A620FCB6A3A, ped, slot, drawableId, textureId)

def RESET_PED_VISIBLE_DAMAGE(ped: int) -> None:
    _iv(0x3AC1F7B898F30C05, ped)

def SET_PED_VISUAL_FIELD_CENTER_ANGLE(ped: int, angle: float) -> None:
    _iv(0x3B6405E8AB34A907, ped, angle)

def SET_PED_ALLOW_VEHICLES_OVERRIDE(ped: int, toggle: bool) -> None:
    _iv(0x3C028C636A414ED9, ped, toggle)

def GET_PED_DEFENSIVE_AREA_POSITION(ped: int, p1: bool) -> 'gta.Vector3':
    return _ivec(0x3C06B8786DD94CD1, ped, p1)

def SET_PED_COMBAT_RANGE(ped: int, combatRange: int) -> None:
    _iv(0x3C606747B23E497B, ped, combatRange)

def SPAWNPOINTS_IS_SEARCH_ACTIVE() -> bool:
    return _ib(0x3C67506996001F5E)

def SET_PED_NEVER_LEAVES_GROUP(ped: int, toggle: bool) -> None:
    _iv(0x3DBFC55D5C9BB447, ped, toggle)

def IS_PED_LIPSTICK_TINT_FOR_CREATOR(colorId: int) -> bool:
    return _ib(0x3E802F11FBE27674, colorId)

def CAN_CREATE_RANDOM_PED(p0: bool) -> bool:
    return _ib(0x3E8349C08E4B82E4, p0)

def SET_PED_WILL_ONLY_ATTACK_WANTED_PLAYER(p0: int, p1: int) -> None:
    _iv(0x3E9679C1DFCF422C, p0, p1)

def GET_PED_BONE_INDEX(ped: int, boneId: int) -> int:
    return _ii(0x3F428D08BE5AAE31, ped, boneId)

def GET_PED_MONEY(ped: int) -> int:
    return _ii(0x3F69145BBA87BAE7, ped)

def SET_PED_HELMET_VISOR_PROP_INDICES(ped: int, p1: bool, p2: int, p3: int) -> None:
    _iv(0x3F7325574E41B44D, ped, p1, p2, p3)

def SET_GROUP_SEPARATION_RANGE(groupHandle: int, separationRange: float) -> None:
    _iv(0x4102C7858CFEE4E4, groupHandle, separationRange)

def IS_PED_LANDING(p0: int) -> bool:
    return _ib(0x412F1364FA066CFB, p0)

def SET_PED_DEFENSIVE_AREA_DIRECTION(ped: int, p1: float, p2: float, p3: float, p4: bool) -> None:
    _iv(0x413C6C763A4AFFAD, ped, p1, p2, p3, p4)

def IS_PED_EVASIVE_DIVING(ped: int, evadingEntity: int) -> bool:
    return _ib(0x414641C26E105898, ped, evadingEntity)

def CREATE_NM_MESSAGE(startImmediately: bool, messageId: int) -> None:
    _iv(0x418EF2A1BCE56685, startImmediately, messageId)

def SET_PED_SHOULD_IGNORE_SCENARIO_EXIT_COLLISION_CHECKS(ped: int, p1: bool) -> None:
    _iv(0x425AECF167663F48, ped, p1)

def GET_PED_RELATIONSHIP_GROUP_DEFAULT_HASH(ped: int) -> int:
    return _ii(0x42FDD0F017B1E38E, ped)

def SET_PED_CAN_BE_TARGETED_WITHOUT_LOS(ped: int, toggle: bool) -> None:
    _iv(0x4328652AE5769C71, ped, toggle)

def SET_PED_MAX_MOVE_BLEND_RATIO(ped: int, value: float) -> None:
    _iv(0x433083750C5E064A, ped, value)

def IS_PED_JUMPING_OUT_OF_VEHICLE(ped: int) -> bool:
    return _ib(0x433DDFFE2044B636, ped)

def SET_PED_MAX_TIME_IN_WATER(ped: int, value: float) -> None:
    _iv(0x43C851690662113D, ped, value)

def SET_CREATE_RANDOM_COPS_ON_SCENARIOS(toggle: bool) -> None:
    _iv(0x444CB7D7DBE6973D, toggle)

def REGISTER_PEDHEADSHOT(ped: int) -> int:
    return _ii(0x4462658788425076, ped)

def SET_PED_WETNESS_HEIGHT(ped: int, height: float) -> None:
    _iv(0x44CB6447D2571AA0, ped, height)

def IS_PED_TRYING_TO_ENTER_A_LOCKED_VEHICLE(ped: int) -> bool:
    return _ib(0x44D28D5DDFE5F68C, ped)

def GET_PED_HELMET_STORED_HAT_PROP_INDEX(ped: int) -> int:
    return _ii(0x451294E859ECC018, ped)

def IS_PED_DOING_A_BEAST_JUMP(p0: int) -> bool:
    return _ib(0x451D05012CCEC234, p0)

def KNOCK_PED_OFF_VEHICLE(ped: int) -> None:
    _iv(0x45BBCBA77C29A841, ped)

def SET_PED_DEFAULT_COMPONENT_VARIATION(ped: int) -> None:
    _iv(0x45EEE61580806D63, ped)

def IS_PED_ON_MOUNT(ped: int) -> bool:
    return _ib(0x460BC76A0E10655E, ped)

def FINALIZE_HEAD_BLEND(ped: int) -> None:
    _iv(0x4668D80430D6C299, ped)

def PED_HAS_SEXINESS_FLAG_SET(ped: int, sexinessFlag: int) -> bool:
    return _ib(0x46B05BCAE43856B0, ped, sexinessFlag)

def APPLY_PED_DAMAGE_PACK(ped: int, damagePack: str, damage: float, mult: float) -> None:
    _iv(0x46DF918788CB093F, ped, damagePack, damage, mult)

def RESET_AI_MELEE_WEAPON_DAMAGE_MODIFIER() -> None:
    _iv(0x46E56A7CD1D63C3F)

def SET_PED_STEERS_AROUND_PEDS(ped: int, toggle: bool) -> None:
    _iv(0x46F2193B3AD1D891, ped, toggle)

def GET_PED_MAX_HEALTH(ped: int) -> int:
    return _ii(0x4700A416E8324EF3, ped)

def INSTANTLY_FILL_PED_POPULATION() -> None:
    _iv(0x4759CC730F947C81)

def IS_PED_RAGDOLL(ped: int) -> bool:
    return _ib(0x47E4E977581C5B55, ped)

def GET_PED_HAIR_TINT_COLOR(hairColorIndex: int, outR: int, outG: int, outB: int) -> None:
    _iv(0x4852FC386E2E1BB5, hairColorIndex, outR, outG, outB)

def IS_PED_IN_COMBAT(ped: int, target: int) -> bool:
    return _ib(0x4859F1FC66A6278E, ped, target)

def SET_PED_HEAD_OVERLAY(ped: int, overlayID: int, index: int, opacity: float) -> None:
    _iv(0x48F44967FA05CC1E, ped, overlayID, index, opacity)

def SET_PED_HEAD_OVERLAY_TINT(ped: int, overlayID: int, colorType: int, colorID: int, secondColorID: int) -> None:
    _iv(0x497BF74A7B9CB952, ped, overlayID, colorType, colorID, secondColorID)

def SET_PED_ALLOW_MINOR_REACTIONS_AS_MISSION_PED(ped: int, toggle: bool) -> None:
    _iv(0x49E50BDB8BA4DAB2, ped, toggle)

def IS_PED_JACKING(ped: int) -> bool:
    return _ib(0x4AE4FF911DFB61DA, ped)

def CLEAR_PED_DRIVE_BY_CLIPSET_OVERRIDE(ped: int) -> None:
    _iv(0x4AFE3690D7E0B5AC, ped)

def GET_ANIM_INITIAL_OFFSET_ROTATION(animDict: str, animName: str, x: float, y: float, z: float, xRot: float, yRot: float, zRot: float, p8: float, p9: int) -> 'gta.Vector3':
    return _ivec(0x4B805E6046EE9E47, animDict, animName, x, y, z, xRot, yRot, zRot, p8, p9)

def IS_PED_TRACKED(ped: int) -> bool:
    return _ib(0x4C5E1F087CD10BB7, ped)

def SET_PED_HAIR_TINT(ped: int, colorID: int, highlightColorID: int) -> None:
    _iv(0x4CFFC65454C93A49, ped, colorID, highlightColorID)

def SET_PED_COMBAT_MOVEMENT(ped: int, combatMovement: int) -> None:
    _iv(0x4D9CA1009AFBD057, ped, combatMovement)

def IS_PED_IN_MELEE_COMBAT(ped: int) -> bool:
    return _ib(0x4E209B2C1EAD5159, ped)

def SET_PED_EMISSIVE_SCALE(ped: int, intensity: float) -> None:
    _iv(0x4E90D746056E273D, ped, intensity)

def SET_PED_DEFENSIVE_AREA_ATTACHED_TO_PED(ped: int, attachPed: int, p2: float, p3: float, p4: float, p5: float, p6: float, p7: float, p8: float, p9: bool, p10: bool) -> None:
    _iv(0x4EF47FE21698A8B6, ped, attachPed, p2, p3, p4, p5, p6, p7, p8, p9, p10)

def SET_PED_BOUNDS_ORIENTATION(ped: int, p1: float, p2: float, x: float, y: float, z: float) -> None:
    _iv(0x4F5F651ACCC9C4CF, ped, p1, p2, x, y, z)

def IS_PED_BEING_STUNNED(ped: int, p1: int) -> bool:
    return _ib(0x4FBACCE3B4138EE8, ped, p1)

def SET_SCRIPTED_CONVERSION_COORD_THIS_FRAME(x: float, y: float, z: float) -> None:
    _iv(0x5086C7843552CF85, x, y, z)

def SET_HEAD_BLEND_EYE_COLOR(ped: int, index: int) -> None:
    _iv(0x50B56988B170AFDF, ped, index)

def GET_TRACKED_PED_PIXELCOUNT(ped: int) -> int:
    return _ii(0x511F1A683387C7E2, ped)

def GET_PED_AS_GROUP_MEMBER(groupID: int, memberNumber: int) -> int:
    return _ii(0x51455483CF23ED97, groupID, memberNumber)

def CAN_KNOCK_PED_OFF_VEHICLE(ped: int) -> bool:
    return _ib(0x51AC07A44D4F5B8A, ped)

def CLEAR_PED_DAMAGE_DECAL_BY_ZONE(ped: int, p1: int, p2: str) -> None:
    _iv(0x523C79AEEFCC4A2A, ped, p1, p2)

def SET_PED_HIGHLY_PERCEPTIVE(ped: int, toggle: bool) -> None:
    _iv(0x52D59AB61DDC05DD, ped, toggle)

def GET_COMBAT_FLOAT(ped: int, p1: int) -> float:
    return _if(0x52DFF8A10508090A, ped, p1)

def SET_PED_IN_VEHICLE_CONTEXT(ped: int, context: int) -> None:
    _iv(0x530071295899A8C6, ped, context)

def IS_PED_STOPPED(ped: int) -> bool:
    return _ib(0x530944F6F4B8A214, ped)

def IS_PED_CLIMBING(ped: int) -> bool:
    return _ib(0x53E8CB4F48BFE623, ped)

def COUNT_PEDS_IN_COMBAT_WITH_TARGET(ped: int) -> int:
    return _ii(0x5407B7288D0478B7, ped)

def GET_JACK_TARGET(ped: int) -> int:
    return _ii(0x5486A79D9FBD342D, ped)

def GIVE_PED_HELMET(ped: int, cannotRemove: bool, helmetFlag: int, textureIndex: int) -> None:
    _iv(0x54C7C4A94367717E, ped, cannotRemove, helmetFlag, textureIndex)

def IS_PED_DIVING(ped: int) -> bool:
    return _ib(0x5527B8246FEF9B11, ped)

def SET_PED_HELMET(ped: int, canWearHelmet: bool) -> None:
    _iv(0x560A43136EB58105, ped, canWearHelmet)

def SET_RELATIONSHIP_GROUP_AFFECTS_WANTED_LEVEL(group: int, p1: bool) -> None:
    _iv(0x5615E0C5EB2BC6E2, group, p1)

def ADD_PED_DECORATION_FROM_HASHES_IN_CORONA(ped: int, collection: int, overlay: int) -> None:
    _iv(0x5619BFA07CFD7833, ped, collection, overlay)

def SET_FACIAL_CLIPSET(ped: int, animDict: str) -> None:
    _iv(0x5687C7F05B39E401, ped, animDict)

def SET_PED_DIES_IN_WATER(ped: int, toggle: bool) -> None:
    _iv(0x56CEF0AC79073BDE, ped, toggle)

def CLEAR_PED_BLOOD_DAMAGE_BY_ZONE(ped: int, p1: int) -> None:
    _iv(0x56E3B78C5408D9F4, ped, p1)

def SET_PED_INCREASED_AVOIDANCE_RADIUS(ped: int) -> None:
    _iv(0x570389D1C3DE3C6B, ped)

def SET_PED_BLOCKS_PATHING_WHEN_DEAD(ped: int, toggle: bool) -> None:
    _iv(0x576594E8D64375E2, ped, toggle)

def IS_PED_USING_ANY_SCENARIO(ped: int) -> bool:
    return _ib(0x57AB4A3080F85143, ped)

def IS_PED_IN_GROUP(ped: int) -> bool:
    return _ib(0x5891CAC5D4ACFF74, ped)

def SET_SCRIPTED_ANIM_SEAT_OFFSET(ped: int, p1: float) -> None:
    _iv(0x5917BBA32D06C230, ped, p1)

def IS_PED_HURT(ped: int) -> bool:
    return _ib(0x5983BB449D7FDB12, ped)

def SUPPRESS_AMBIENT_PED_AGGRESSIVE_CLEANUP_THIS_FRAME() -> None:
    _iv(0x5A7F62FDA59759BD)

def RELEASE_PED_PRELOAD_VARIATION_DATA(ped: int) -> None:
    _iv(0x5AAB586FFEC0FD96, ped)

def SET_PED_SHOULD_IGNORE_SCENARIO_NAV_CHECKS(p0: int, p1: bool) -> None:
    _iv(0x5B6010B3CBC29095, p0, p1)

def ADD_ARMOUR_TO_PED(ped: int, amount: int) -> None:
    _iv(0x5BA652A0CD14DF2F, ped, amount)

def SET_PED_DIES_WHEN_INJURED(ped: int, toggle: bool) -> None:
    _iv(0x5BA7919BED300023, ped, toggle)

def GET_PED_AS_GROUP_LEADER(groupID: int) -> int:
    return _ii(0x5CCE68DBD5FE93EC, groupID)

def IS_PED_HEADTRACKING_PED(ped1: int, ped2: int) -> bool:
    return _ib(0x5CD3CB88A7F8850D, ped1, ped2)

def RELEASE_PEDHEADSHOT_IMG_UPLOAD(id: int) -> None:
    _iv(0x5D517B27CF6ECD04, id)

def CLEAR_RELATIONSHIP_BETWEEN_GROUPS(relationship: int, group1: int, group2: int) -> None:
    _iv(0x5E29243FB56FC6D4, relationship, group1, group2)

def CAN_CREATE_RANDOM_COPS() -> bool:
    return _ib(0x5EE2CAFF7F17770D)

def GET_PED_HEAD_BLEND_NUM_HEADS(type: int) -> int:
    return _ii(0x5EF37013A6539C9D, type)

def ADD_PED_DECORATION_FROM_HASHES(ped: int, collection: int, overlay: int) -> None:
    _iv(0x5F5D1665E352A839, ped, collection, overlay)

def GET_NUMBER_OF_PED_PROP_DRAWABLE_VARIATIONS(ped: int, propId: int) -> int:
    return _ii(0x5FAF9754E789FB47, ped, propId)

def IS_PED_IN_ANY_PLANE(ped: int) -> bool:
    return _ib(0x5FFF4CFC74D8FB80, ped)

def DISABLE_PED_HEATSCALE_OVERRIDE(ped: int) -> None:
    _iv(0x600048C60D5C2C51, ped)

def IS_PED_BLUSH_TINT_FOR_BARBER(colorID: int) -> bool:
    return _ib(0x604E810189EE3A59, colorID)

def GET_VEHICLE_PED_IS_USING(ped: int) -> int:
    return _ii(0x6094AD011A2EA87D, ped)

def IS_PED_IN_COVER(ped: int, exceptUseWeapon: bool) -> bool:
    return _ib(0x60DFD0691A170B88, ped, exceptUseWeapon)

def SET_PED_SHOOT_RATE(ped: int, shootRate: int) -> None:
    _iv(0x614DA022990752DC, ped, shootRate)

def WAS_PED_KNOCKED_OUT(ped: int) -> bool:
    return _ib(0x61767F73EACEED21, ped)

def IS_SYNCHRONIZED_SCENE_LOOPED(sceneID: int) -> bool:
    return _ib(0x62522002E0C391BA, sceneID)

def IS_PED_RESPONDING_TO_EVENT(ped: int, event: int) -> bool:
    return _ib(0x625B774D75C87068, ped, event)

def HIDE_PED_BLOOD_DAMAGE_BY_ZONE(ped: int, p1: int, p2: bool) -> None:
    _iv(0x62AB793144DE75DC, ped, p1, p2)

def CREATE_SYNCHRONIZED_SCENE_AT_MAP_OBJECT(x: float, y: float, z: float, radius: float, object: int) -> int:
    return _ii(0x62EC273D00187DCA, x, y, z, radius, object)

def SET_PED_CAN_PLAY_AMBIENT_ANIMS(ped: int, toggle: bool) -> None:
    _iv(0x6373D1349925A70E, ped, toggle)

def CLEAR_COVER_POINT_FOR_PED(ped: int) -> None:
    _iv(0x637822DC2AFEEBF8, ped)

def SET_PED_CAN_BE_TARGETED_WHEN_INJURED(ped: int, toggle: bool) -> None:
    _iv(0x638C03B0F9878F57, ped, toggle)

def RESET_GROUP_FORMATION_DEFAULT_SPACING(groupHandle: int) -> None:
    _iv(0x63DAB4CCB3273205, groupHandle)

def SET_PED_CAN_BE_TARGETTED(ped: int, toggle: bool) -> None:
    _iv(0x63F58F7C80513AAD, ped, toggle)

def HAS_PED_HEAD_BLEND_FINISHED(ped: int) -> bool:
    return _ib(0x654CD0A825161131, ped)

def GET_PED_DIES_IN_WATER(ped: int) -> bool:
    return _ib(0x65671A4FB8218930, ped)

def CLEAR_PED_ENV_DIRT(ped: int) -> None:
    _iv(0x6585D955A68452A5, ped)

def SET_AI_MELEE_WEAPON_DAMAGE_MODIFIER(modifier: float) -> None:
    _iv(0x66460DEDDD417254, modifier)

def SET_PED_CAN_TORSO_VEHICLE_IK(ped: int, p1: bool) -> None:
    _iv(0x6647C5F6F5792496, ped, p1)

def HAS_PED_PRELOAD_VARIATION_DATA_FINISHED(ped: int) -> bool:
    return _ib(0x66680A92700F43DF, ped)

def CLONE_PED_ALT(ped: int, isNetwork: bool, bScriptHostPed: bool, copyHeadBlendFlag: bool, p4: bool) -> int:
    return _ii(0x668FD40BCBA5DE48, ped, isNetwork, bScriptHostPed, copyHeadBlendFlag, p4)

def SET_PED_CAN_BE_TARGETTED_BY_PLAYER(ped: int, player: int, toggle: bool) -> None:
    _iv(0x66B57B72E0836A76, ped, player, toggle)

def IS_PED_ON_VEHICLE(ped: int) -> bool:
    return _ib(0x67722AEB798E5FAB, ped)

def GET_PED_DRAWABLE_VARIATION(ped: int, componentId: int) -> int:
    return _ii(0x67F3780DD425D4FC, ped, componentId)

def IS_ANY_HOSTILE_PED_NEAR_POINT(ped: int, x: float, y: float, z: float, radius: float) -> bool:
    return _ib(0x68772DB2B2526F9F, ped, x, y, z, radius)

def CLEAR_PED_STORED_HAT_PROP(ped: int) -> None:
    _iv(0x687C0B594907D2E8, ped)

def GET_PED_HEAD_BLEND_FIRST_INDEX(type: int) -> int:
    return _ii(0x68D353AB88B97E0C, type)

def APPLY_DAMAGE_TO_PED(ped: int, damageAmount: int, p2: bool, p3: int, weaponType: int) -> None:
    _iv(0x697157CED63F18D4, ped, damageAmount, p2, p3, weaponType)

def IS_PED_IN_HIGH_COVER(ped: int) -> bool:
    return _ib(0x6A03BF943D767C93, ped)

def GET_PLAYER_PED_IS_FOLLOWING(ped: int) -> int:
    return _ii(0x6A3975DEA89F9A17, ped)

def SET_SYNCHRONIZED_SCENE_ORIGIN(sceneID: int, x: float, y: float, z: float, roll: float, pitch: float, yaw: float, p7: bool) -> None:
    _iv(0x6ACF6B7225801CD7, sceneID, x, y, z, roll, pitch, yaw, p7)

def SET_AMBIENT_PEDS_DROP_MONEY(p0: bool) -> None:
    _iv(0x6B0E6172C9A4D902, p0)

def SET_PED_CAN_EVASIVE_DIVE(ped: int, toggle: bool) -> None:
    _iv(0x6B7A646C242A7059, ped, toggle)

def SET_PED_MAX_TIME_UNDERWATER(ped: int, value: float) -> None:
    _iv(0x6BA428C528D9E522, ped, value)

def SET_PED_CAN_ARM_IK(ped: int, toggle: bool) -> None:
    _iv(0x6C3B4D6D13B4C841, ped, toggle)

def SET_PED_ALTERNATE_WALK_ANIM(ped: int, animDict: str, animName: str, p3: float, p4: bool) -> None:
    _iv(0x6C60394CB4F75E9A, ped, animDict, animName, p3, p4)

def CAN_PED_SEE_HATED_PED(ped1: int, ped2: int) -> bool:
    return _ib(0x6CD5A433374D4CFB, ped1, ped2)

def DETACH_SYNCHRONIZED_SCENE(sceneID: int) -> None:
    _iv(0x6D38F1F04CBB37EA, sceneID)

def IS_PED_MALE(ped: int) -> bool:
    return _ib(0x6D9F5FAA7488BA46, ped)

def IS_PED_IN_ANY_TAXI(ped: int) -> bool:
    return _ib(0x6E575D6A898AB852, ped)

def IS_SCRIPTED_SCENARIO_PED_USING_CONDITIONAL_ANIM(ped: int, animDict: str, anim: str) -> bool:
    return _ib(0x6EC47A344923E1ED, ped, animDict, anim)

def GET_SEAT_PED_IS_TRYING_TO_ENTER(ped: int) -> int:
    return _ii(0x6F4C85ACD641BCD2, ped)

def IS_PED_IN_ANY_TRAIN(ped: int) -> bool:
    return _ib(0x6F972C1AB75A1ED0, ped)

def KNOCK_OFF_PED_PROP(ped: int, p1: bool, p2: bool, p3: bool, p4: bool) -> None:
    _iv(0x6FD7816A36615F48, ped, p1, p2, p3, p4)

def SET_PED_VISUAL_FIELD_MAX_ANGLE(ped: int, value: float) -> None:
    _iv(0x70793BDCA1E854D4, ped, value)

def IS_PEDHEADSHOT_READY(id: int) -> bool:
    return _ib(0x7085228842B13A67, id)

def SET_PED_FLEE_ATTRIBUTES(ped: int, attributeFlags: int, enable: bool) -> None:
    _iv(0x70A2D1137C8ED7C9, ped, attributeFlags, enable)

def SET_DISABLE_HIGH_FALL_DEATH(ped: int, toggle: bool) -> None:
    _iv(0x711794453CFD692B, ped, toggle)

def SET_PED_MICRO_MORPH(ped: int, index: int, scale: float) -> None:
    _iv(0x71A5C1DBA060049E, ped, index, scale)

def RESURRECT_PED(ped: int) -> None:
    _iv(0x71BC8E838B9C6035, ped)

def GET_PED_DECORATIONS_STATE(ped: int) -> int:
    return _ii(0x71EAB450D86954A1, ped)

def UPDATE_PED_HEAD_BLEND_DATA(ped: int, shapeMix: float, skinMix: float, thirdMix: float) -> None:
    _iv(0x723538F61C647C5A, ped, shapeMix, skinMix, thirdMix)

def CLEAR_FACIAL_IDLE_ANIM_OVERRIDE(ped: int) -> None:
    _iv(0x726256CC1EEB182F, ped)

def DISABLE_PED_INJURED_ON_GROUND_BEHAVIOUR(ped: int) -> None:
    _iv(0x733C87D4CE22BEA2, ped)

def SET_SYNCHRONIZED_SCENE_PHASE(sceneID: int, phase: float) -> None:
    _iv(0x734292F4F0ABF6D0, sceneID, phase)

def HAVE_ALL_STREAMING_REQUESTS_COMPLETED(ped: int) -> bool:
    return _ib(0x7350823473013C02, ped)

def SET_PED_CAN_LEG_IK(ped: int, toggle: bool) -> None:
    _iv(0x73518ECE2485412B, ped, toggle)

def REMOVE_PED_DEFENSIVE_AREA(ped: int, toggle: bool) -> None:
    _iv(0x74D4E028107450A9, ped, toggle)

def REQUEST_PED_USE_SMALL_BBOX_VISIBILITY_TRACKING(ped: int, p1: bool) -> None:
    _iv(0x75BA1CB3B7D40CAF, ped, p1)

def GET_HEAD_BLEND_EYE_COLOR(ped: int) -> int:
    return _ii(0x76BBA2CEE66D47E9, ped)

def SET_MOVEMENT_MODE_OVERRIDE(ped: int, name: str) -> None:
    _iv(0x781DE8FA214E87D2, ped, name)

def HAS_PED_PRELOAD_PROP_DATA_FINISHED(ped: int) -> bool:
    return _ib(0x784002A632822099, ped)

def SET_PED_CLOTH_PIN_FRAMES(p0: int, p1: int) -> None:
    _iv(0x78C4E9961DB3EB5B, p0, p1)

def SET_PED_VISUAL_FIELD_MAX_ELEVATION_ANGLE(ped: int, angle: float) -> None:
    _iv(0x78D0B67629D75856, ped, angle)

def IS_PED_IN_MODEL(ped: int, modelHash: int) -> bool:
    return _ib(0x796D90EFB19AA332, ped, modelHash)

def GET_PED_PARACHUTE_STATE(ped: int) -> int:
    return _ii(0x79CFD9827CC979B6, ped)

def SET_PED_VISUAL_FIELD_MIN_ELEVATION_ANGLE(ped: int, angle: float) -> None:
    _iv(0x7A276EB2C224D70F, ped, angle)

def SET_SCENARIO_PED_DENSITY_MULTIPLIER_THIS_FRAME(p0: float, p1: float) -> None:
    _iv(0x7A556143A1C03898, p0, p1)

def SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(ped: int, state: int) -> None:
    _iv(0x7A6535691B477C48, ped, state)

def SET_PED_ACCURACY(ped: int, accuracy: int) -> None:
    _iv(0x7AEFB85C1D49DEB6, ped, accuracy)

def GET_PED_STEALTH_MOVEMENT(ped: int) -> bool:
    return _ib(0x7C2AC9CA66575FBF, ped)

def DOES_GROUP_EXIST(groupId: int) -> bool:
    return _ib(0x7C6B0C22F9F40BBE, groupId)

def REQUEST_PED_VISIBILITY_TRACKING(ped: int) -> None:
    _iv(0x7D7A2E43E74E2EB8, ped)

def GET_PED_RELATIONSHIP_GROUP_HASH(ped: int) -> int:
    return _ii(0x7DBDD04862D95F04, ped)

def IS_PED_IN_PARACHUTE_FREE_FALL(ped: int) -> bool:
    return _ib(0x7DCE8BDA0F1C1200, ped)

def CREATE_PED_INSIDE_VEHICLE(vehicle: int, pedType: int, modelHash: int, seat: int, isNetwork: bool, bScriptHostPed: bool) -> int:
    return _ii(0x7DD959874C1FD534, vehicle, pedType, modelHash, seat, isNetwork, bScriptHostPed)

def IS_PED_SHOOTING_IN_AREA(ped: int, x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, p7: bool, p8: bool) -> bool:
    return _ib(0x7E9DFE24AC1E58EF, ped, x1, y1, z1, x2, y2, z2, p7, p8)

def GET_PED_CONFIG_FLAG(ped: int, flagId: int, p2: bool) -> bool:
    return _ib(0x7EE53118C892B513, ped, flagId, p2)

def WAS_PED_KILLED_BY_TAKEDOWN(ped: int) -> bool:
    return _ib(0x7F08E26039C7347C, ped)

def IS_SYNCHRONIZED_SCENE_HOLD_LAST_FRAME(sceneID: int) -> bool:
    return _ib(0x7F2F4F13AC5257EF, sceneID)

def SET_PED_GENERATES_DEAD_BODY_EVENTS(ped: int, toggle: bool) -> None:
    _iv(0x7FB17BA2E7DECA5B, ped, toggle)

def CLEAR_PED_FALL_UPPER_BODY_CLIPSET_OVERRIDE(ped: int) -> None:
    _iv(0x80054D7FCC70EEC6, ped)

def IS_PED_HEADTRACKING_ENTITY(ped: int, entity: int) -> bool:
    return _ib(0x813A0A7C9D2E831F, ped, entity)

def GET_VEHICLE_PED_IS_TRYING_TO_ENTER(ped: int) -> int:
    return _ii(0x814FA8BE5449445D, ped)

def APPLY_PED_BLOOD_DAMAGE_BY_ZONE(ped: int, p1: int, p2: float, p3: float, p4: int) -> None:
    _iv(0x816F6981C60BF53B, ped, p1, p2, p3, p4)

def IS_PED_SHADER_READY(ped: int) -> bool:
    return _ib(0x81AA517FBBA05D39, ped)

def SET_PED_CAN_PLAY_IN_CAR_IDLES(ped: int, toggle: bool) -> None:
    _iv(0x820E9892A77E97CD, ped, toggle)

def IS_PED_SITTING_IN_ANY_VEHICLE(ped: int) -> bool:
    return _ib(0x826AA586EDB9FEF8, ped)

def SET_PED_CLOTH_PACKAGE_INDEX(p0: int, p1: int) -> None:
    _iv(0x82A3D6D9CC2CB8E3, p0, p1)

def SET_PED_PHONE_PALETTE_IDX(p0: int, p1: int) -> None:
    _iv(0x83A169EABCDB10A2, p0, p1)

def APPLY_PED_BLOOD(ped: int, boneIndex: int, xRot: float, yRot: float, zRot: float, woundType: str) -> None:
    _iv(0x83F7E01C7B769A26, ped, boneIndex, xRot, yRot, zRot, woundType)

def SET_PED_PREFERRED_COVER_SET(ped: int, itemSet: int) -> None:
    _iv(0x8421EB4DA7E391B9, ped, itemSet)

def IS_PED_IN_COVER_FACING_LEFT(ped: int) -> bool:
    return _ib(0x845333B3150583AB, ped)

def IS_PED_INJURED(ped: int) -> bool:
    return _ib(0x84A2DD9AC37C35C1, ped)

def HAS_PED_RECEIVED_EVENT(ped: int, eventId: int) -> bool:
    return _ib(0x8507BCB710FA6DC0, ped, eventId)

def IS_PED_BEING_STEALTH_KILLED(ped: int) -> bool:
    return _ib(0x863B23EFDE9C5DF2, ped)

def SET_PED_COORDS_NO_GANG(ped: int, posX: float, posY: float, posZ: float) -> None:
    _iv(0x87052FE446E07247, ped, posX, posY, posZ)

def GET_RANDOM_PED_AT_COORD(x: float, y: float, z: float, xRadius: float, yRadius: float, zRadius: float, pedType: int) -> int:
    return _ii(0x876046A8E3A4B71C, x, y, z, xRadius, yRadius, zRadius, pedType)

def HAS_PEDHEADSHOT_IMG_UPLOAD_FAILED() -> bool:
    return _ib(0x876928DDDFCCC9CD)

def SET_AMBIENT_LAW_PED_ACCURACY_MODIFIER(multiplier: float) -> None:
    _iv(0x87DDEB611B329A9C, multiplier)

def GET_MP_LIGHT_ENABLED(ped: int) -> bool:
    return _ib(0x88274C11CF0D866D, ped)

def CLEAR_PED_ALTERNATE_WALK_ANIM(ped: int, p1: float) -> None:
    _iv(0x8844BBFCE30AA9E9, ped, p1)

def SET_PED_STEALTH_MOVEMENT(ped: int, p1: bool, action: str) -> None:
    _iv(0x88CBB5CEB96B7BD2, ped, p1, action)

def GET_PED_PROP_INDEX(ped: int, componentId: int, p2: int) -> int:
    return _ii(0x898CC20EA75BACD8, ped, componentId, p2)

def DOES_SCENARIO_BLOCKING_AREA_EXISTS(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> bool:
    return _ib(0x8A24B067D175A7BD, x1, y1, z1, x2, y2, z2)

def SET_CREATE_RANDOM_COPS_NOT_ON_SCENARIOS(toggle: bool) -> None:
    _iv(0x8A4986851C4EF6E7, toggle)

def GET_PED_PARACHUTE_LANDING_TYPE(ped: int) -> int:
    return _ii(0x8B9F1FC6AE8166C0, ped)

def CREATE_SYNCHRONIZED_SCENE(x: float, y: float, z: float, roll: float, pitch: float, yaw: float, p6: int) -> int:
    return _ii(0x8C18E0F9080ADD73, x, y, z, roll, pitch, yaw, p6)

def CREATE_PARACHUTE_BAG_OBJECT(ped: int, p1: bool, p2: bool) -> int:
    return _ii(0x8C4F3BF23B6237DB, ped, p1, p2)

def REVIVE_INJURED_PED(ped: int) -> None:
    _iv(0x8D8ACD8388CD99CE, ped)

def GET_GROUP_SIZE(groupID: int, p1: int, sizeInMembers: int) -> None:
    _iv(0x8DE69FE35CA09A45, groupID, p1, sizeInMembers)

def REMOVE_GROUP(groupId: int) -> None:
    _iv(0x8EB2F69076AF7053, groupId)

def CLEAR_PED_LAST_DAMAGE_BONE(ped: int) -> None:
    _iv(0x8EF6B7AC68E2F01B, ped)

def GET_NUMBER_OF_PED_TEXTURE_VARIATIONS(ped: int, componentId: int, drawableId: int) -> int:
    return _ii(0x8F7156A3142A6BAD, ped, componentId, drawableId)

def CLEAR_PED_BLOOD_DAMAGE(ped: int) -> None:
    _iv(0x8FE22675A5A45817, ped)

def CREATE_GROUP(unused: int) -> int:
    return _ii(0x90370EBE0FEE1A3D, unused)

def SET_PED_ALTERNATE_MOVEMENT_ANIM(ped: int, stance: int, animDictionary: str, animationName: str, p4: float, p5: bool) -> None:
    _iv(0x90A43CC281FFAB46, ped, stance, animDictionary, animationName, p4, p5)

def IS_PED_IN_FLYING_VEHICLE(ped: int) -> bool:
    return _ib(0x9134873537FA419C, ped)

def IS_TRACKED_PED_VISIBLE(ped: int) -> bool:
    return _ib(0x91C8E617F64188AC, ped)

def REMOVE_STEALTH_MODE_ASSET(asset: str) -> None:
    _iv(0x9219857D21F0E842, asset)

def REGISTER_HATED_TARGETS_AROUND_PED(ped: int, radius: float) -> None:
    _iv(0x9222F300BF8354FE, ped, radius)

def SET_PED_PROP_INDEX(ped: int, componentId: int, drawableId: int, TextureId: int, attach: bool, p5: int) -> None:
    _iv(0x93376B65A266EB5F, ped, componentId, drawableId, TextureId, attach, p5)

def GET_PED_SOURCE_OF_DEATH(ped: int) -> int:
    return _ii(0x93C8B64DEB84728C, ped)

def SET_PED_HEAD_BLEND_DATA(ped: int, shapeFirstID: int, shapeSecondID: int, shapeThirdID: int, skinFirstID: int, skinSecondID: int, skinThirdID: int, shapeMix: float, skinMix: float, thirdMix: float, isParent: bool) -> None:
    _iv(0x9414E18B9434C2FE, ped, shapeFirstID, shapeSecondID, shapeThirdID, skinFirstID, skinSecondID, skinThirdID, shapeMix, skinMix, thirdMix, isParent)

def IS_PED_ON_ANY_BIKE(ped: int) -> bool:
    return _ib(0x94495889E22C6479, ped)

def GET_PED_ARMOUR(ped: int) -> int:
    return _ii(0x9483AF821605B1D8, ped)

def SET_PED_PLAYS_HEAD_ON_HORN_ANIM_WHEN_DIES_IN_VEHICLE(ped: int, toggle: bool) -> None:
    _iv(0x94D94BF1A75AED3D, ped, toggle)

def SET_PED_VEHICLE_FORCED_SEAT_USAGE(ped: int, vehicle: int, seatIndex: int, flags: int, p4: int) -> None:
    _iv(0x952F06BEECD775CC, ped, vehicle, seatIndex, flags, p4)

def REGISTER_PEDHEADSHOT_TRANSPARENT(ped: int) -> int:
    return _ii(0x953563CE563143AF, ped)

def SET_PED_DENSITY_MULTIPLIER_THIS_FRAME(multiplier: float) -> None:
    _iv(0x95E3D6257B166CF2, multiplier)

def DELETE_PED(ped: int) -> None:
    _iv(0x9614299DCB53E54B, ped)

def SET_PED_SHOOTS_AT_COORD(ped: int, x: float, y: float, z: float, toggle: bool) -> None:
    _iv(0x96A05E4FB321B1BA, ped, x, y, z, toggle)

def UNREGISTER_PEDHEADSHOT(id: int) -> None:
    _iv(0x96B1361D9B24C2FF, id)

def SET_PED_KEEP_TASK(ped: int, toggle: bool) -> None:
    _iv(0x971D38760FBC02EF, ped, toggle)

def SET_PED_ENABLE_WEAPON_BLOCKING(ped: int, toggle: bool) -> None:
    _iv(0x97A790315D3831FD, ped, toggle)

def RESET_PED_WEAPON_MOVEMENT_CLIPSET(ped: int) -> None:
    _iv(0x97B0DB5B4AA74E77, ped)

def SET_PED_NAME_DEBUG(ped: int, name: str) -> None:
    _iv(0x98EFA132A4117BE1, ped, name)

def SET_BLOCKING_OF_NON_TEMPORARY_EVENTS_FOR_AMBIENT_PEDS_THIS_FRAME(p0: bool) -> None:
    _iv(0x9911F4A24485F653, p0)

def IS_PED_IN_ANY_VEHICLE(ped: int, atGetIn: bool) -> bool:
    return _ib(0x997ABD671D25CA0B, ped, atGetIn)

def IS_PED_BEING_JACKED(ped: int) -> bool:
    return _ib(0x9A497FE2DF198913, ped)

def TOGGLE_SCENARIO_PED_COWER_IN_PLACE(ped: int, toggle: bool) -> None:
    _iv(0x9A77DFD295E29B09, ped, toggle)

def GET_VEHICLE_PED_IS_IN(ped: int, includeEntering: bool) -> int:
    return _ii(0x9A9112A0FE9A4713, ped, includeEntering)

def SET_PED_FIRING_PATTERN(ped: int, patternHash: int) -> None:
    _iv(0x9AC577F5A12AD8A9, ped, patternHash)

def SET_PED_COORDS_KEEP_VEHICLE(ped: int, posX: float, posY: float, posZ: float) -> None:
    _iv(0x9AFEFF481A85AB2E, ped, posX, posY, posZ)

def GET_PEDS_JACKER(ped: int) -> int:
    return _ii(0x9B128DC36C1E04CF, ped)

def CREATE_RANDOM_PED_AS_DRIVER(vehicle: int, returnHandle: bool) -> int:
    return _ii(0x9B62392B474F44A0, vehicle, returnHandle)

def IS_PED_GROUP_MEMBER(ped: int, groupId: int) -> bool:
    return _ib(0x9BB01E3834671191, ped, groupId)

def GET_PED_ENVEFF_SCALE(ped: int) -> float:
    return _if(0x9C14D30395A51A3C, ped)

def CAN_PED_SHUFFLE_TO_OR_FROM_TURRET_SEAT(ped: int, p1: int) -> bool:
    return _ib(0x9C6A6C19B6C0C496, ped, p1)

def CLEAR_PED_WETNESS(ped: int) -> None:
    _iv(0x9C720776DAA43E7E, ped)

def SET_PED_VISUAL_FIELD_PERIPHERAL_RANGE(ped: int, range: float) -> None:
    _iv(0x9C74B0BC831B753A, ped, range)

def SET_PED_SPHERE_DEFENSIVE_AREA(ped: int, x: float, y: float, z: float, radius: float, p5: bool, p6: bool) -> None:
    _iv(0x9D3151A373974804, ped, x, y, z, radius, p5, p6)

def GET_PED_HELMET_STORED_HAT_TEX_INDEX(ped: int) -> int:
    return _ii(0x9D728C1E12BF5518, ped)

def SET_PED_MOTION_IN_COVER_CLIPSET_OVERRIDE(ped: int, p1: str) -> None:
    _iv(0x9DBA107B4937F809, ped, p1)

def IS_PED_SWIMMING(ped: int) -> bool:
    return _ib(0x9DE327631295B4C2, ped)

def GET_MP_OUTFIT_DATA_FROM_METADATA(p0: int, p1: int) -> bool:
    return _ib(0x9E30E91FB03A2CAF, p0, p1)

def GET_RELATIONSHIP_BETWEEN_GROUPS(group1: int, group2: int) -> int:
    return _ii(0x9E6B70061662AE5C, group1, group2)

def SET_PED_MOVE_ANIMS_BLEND_OUT(ped: int) -> None:
    _iv(0x9E8C908F41584ECD, ped)

def SET_PED_AS_GROUP_MEMBER(ped: int, groupId: int) -> None:
    _iv(0x9F3480FE65DB31B5, ped, groupId)

def IS_PED_GOING_INTO_COVER(ped: int) -> bool:
    return _ib(0x9F65DBC537E59AD5, ped)

def SET_PED_COMBAT_ATTRIBUTES(ped: int, attributeId: int, enabled: bool) -> None:
    _iv(0x9F7794730795E019, ped, attributeId, enabled)

def SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(ped: int, toggle: bool) -> None:
    _iv(0x9F8AA94D6D97DBF4, ped, toggle)

def RESET_PED_RAGDOLL_TIMER(ped: int) -> None:
    _iv(0x9FA4664CF62E47E8, ped)

def GET_PED_DECORATION_ZONE_FROM_HASHES(collection: int, overlay: int) -> int:
    return _ii(0x9FD452BFBE7A7A8B, collection, overlay)

def SET_PED_GRAVITY(ped: int, toggle: bool) -> None:
    _iv(0x9FF447B6B6AD960A, ped, toggle)

def IS_PEDHEADSHOT_VALID(id: int) -> bool:
    return _ib(0xA0A9668F158129A2, id)

def IS_ANY_PED_SHOOTING_IN_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, p6: bool, p7: bool) -> bool:
    return _ib(0xA0D3D71EA1086C55, x1, y1, z1, x2, y2, z2, p6, p7)

def DISABLE_HEAD_BLEND_PALETTE_COLOR(ped: int) -> None:
    _iv(0xA21C118553BBDF02, ped)

def _HAS_PED_CLEAR_LOS_TO_ENTITY(ped: int, entity: int, x: float, y: float, z: float, p5: int, p6: bool, p7: bool) -> bool:
    return _ib(0xA32ABFEB2A03B306, ped, entity, x, y, z, p5, p6, p7)

def SET_PED_SHOULD_PLAY_NORMAL_SCENARIO_EXIT(ped: int) -> None:
    _iv(0xA3A9299C4F2ADB98, ped)

def IS_PED_IN_VEHICLE(ped: int, vehicle: int, atGetIn: bool) -> bool:
    return _ib(0xA3EE4A07279BB9DB, ped, vehicle, atGetIn)

def IS_MOBILE_PHONE_TO_PED_EAR(ped: int) -> bool:
    return _ib(0xA3F3564A5B3646C0, ped)

def SET_PED_NO_TIME_DELAY_BEFORE_SHOT(p0: int) -> None:
    _iv(0xA52D5247A4227E14, p0)

def SET_PED_COWER_HASH(ped: int, p1: str) -> None:
    _iv(0xA549131166868ED3, ped, p1)

def SPAWNPOINTS_IS_SEARCH_COMPLETE() -> bool:
    return _ib(0xA586FBEB32A53DBB)

def GET_PED_HEAD_OVERLAY(ped: int, overlayID: int) -> int:
    return _ii(0xA60EF3B6461A4D43, ped, overlayID)

def SPAWNPOINTS_GET_NUM_SEARCH_RESULTS() -> int:
    return _ii(0xA635C11B8C44AFC2)

def SET_PED_CLOTH_PRONE(p0: int, p1: bool) -> None:
    _iv(0xA660FAF550EB37E5, p0, p1)

def GET_NUMBER_OF_PED_PROP_TEXTURE_VARIATIONS(ped: int, propId: int, drawableId: int) -> int:
    return _ii(0xA6E7F1CEB523E171, ped, propId, drawableId)

def SET_DRIVER_AGGRESSIVENESS(driver: int, aggressiveness: float) -> None:
    _iv(0xA731F608CA104E3C, driver, aggressiveness)

def REMOVE_PED_HELMET(ped: int, instantly: bool) -> None:
    _iv(0xA7B2458D0AD6DED8, ped, instantly)

def IS_PED_SITTING_IN_VEHICLE(ped: int, vehicle: int) -> bool:
    return _ib(0xA808AA1D79230FC2, ped, vehicle)

def SET_PED_IS_AVOIDED_BY_OTHERS(p0: int, p1: bool) -> None:
    _iv(0xA9B61A329BFDCBEA, p0, p1)

def SET_PED_MONEY(ped: int, amount: int) -> None:
    _iv(0xA9C8960E8684C1B5, ped, amount)

def SET_PED_DESIRED_HEADING(ped: int, heading: float) -> None:
    _iv(0xAA5A7ECE2AA8FE70, ped, heading)

def RESET_PED_MOVEMENT_CLIPSET(ped: int, p1: float) -> None:
    _iv(0xAA74EC0CB0AAEA2C, ped, p1)

def GET_DEFAULT_SECONDARY_TINT_FOR_BARBER(colorID: int) -> int:
    return _ii(0xAAA6A3698A69E048, colorID)

def SET_PED_PINNED_DOWN(ped: int, pinned: bool, i: int) -> bool:
    return _ib(0xAAD6D1ACF08F4612, ped, pinned, i)

def SET_PED_WETNESS(ped: int, wetLevel: float) -> None:
    _iv(0xAC0BB4D87777CAE2, ped, wetLevel)

def REMOVE_PED_ELEGANTLY(ped: int) -> None:
    _iv(0xAC6D445B994DF95E, ped)

def TELL_GROUP_PEDS_IN_AREA_TO_ATTACK(ped: int, p1: int, p2: float, hash: int, p4: int, p5: int) -> None:
    _iv(0xAD27D957598E49E9, ped, p1, p2, hash, p4, p5)

def SET_PED_RELATIONSHIP_GROUP_DEFAULT_HASH(ped: int, hash: int) -> None:
    _iv(0xADB3F206518799E8, ped, hash)

def SET_PED_TO_RAGDOLL(ped: int, time1: int, time2: int, ragdollType: int, p4: bool, p5: bool, p6: bool) -> bool:
    return _ib(0xAE99FB955581844A, ped, time1, time2, ragdollType, p4, p5, p6)

def SET_PED_MOVEMENT_CLIPSET(ped: int, clipSet: str, transitionSpeed: float) -> None:
    _iv(0xAF8A94EDE7712BEF, ped, clipSet, transitionSpeed)

def GET_PED_RESET_FLAG(ped: int, flagId: int) -> bool:
    return _ib(0xAF9E59B1B1FBF2A0, ped, flagId)

def SET_PED_UPPER_BODY_DAMAGE_ONLY(ped: int, toggle: bool) -> None:
    _iv(0xAFC976FD0580C7B3, ped, toggle)

def DROP_AMBIENT_PROP(ped: int) -> None:
    _iv(0xAFF4710E2A0A6C12, ped)

def SET_PED_CAN_RAGDOLL(ped: int, toggle: bool) -> None:
    _iv(0xB128377056A54E2A, ped, toggle)

def GIVE_PED_NM_MESSAGE(ped: int) -> None:
    _iv(0xB158DFCCC56E5C5B, ped)

def SET_DRIVER_ABILITY(driver: int, ability: float) -> None:
    _iv(0xB195FFA8042FC5C3, driver, ability)

def SET_PED_CAN_BE_KNOCKED_OFF_BIKE(p0: int, p1: int) -> None:
    _iv(0xB282749D5E028163, p0, p1)

def SPAWNPOINTS_START_SEARCH_IN_ANGLED_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, width: float, interiorFlags: int, scale: float, duration: int) -> None:
    _iv(0xB2AFF10216DEFA2F, x1, y1, z1, x2, y2, z2, width, interiorFlags, scale, duration)

def IS_PED_DOING_DRIVEBY(ped: int) -> bool:
    return _ib(0xB2C086CC1BF8F2BF, ped)

def SET_PED_HEALTH_PENDING_LAST_DAMAGE_EVENT_OVERRIDE_FLAG(toggle: bool) -> None:
    _iv(0xB3352E018D6F89DF, toggle)

def SET_CAN_ATTACK_FRIENDLY(ped: int, toggle: bool, p2: bool) -> None:
    _iv(0xB3B1CB349FF9C75D, ped, toggle, p2)

def STOP_ANY_PED_MODEL_BEING_SUPPRESSED() -> None:
    _iv(0xB47BD05FA66B40CF)

def CREATE_RANDOM_PED(posX: float, posY: float, posZ: float) -> int:
    return _ii(0xB4AC7D0CF06BFE8F, posX, posY, posZ)

def CLEAR_PED_SCUBA_GEAR_VARIATION(ped: int) -> None:
    _iv(0xB50EB4CCB29704AC, ped)

def SET_PED_WETNESS_ENABLED_THIS_FRAME(ped: int) -> None:
    _iv(0xB5485E4907B53019, ped)

def REMOVE_RELATIONSHIP_GROUP(groupHash: int) -> None:
    _iv(0xB6BA2444AB393DA2, groupHash)

def SET_SYNCHRONIZED_SCENE_RATE(sceneID: int, rate: float) -> None:
    _iv(0xB6C49F8A5E295A5D, sceneID, rate)

def SPAWNPOINTS_GET_SEARCH_RESULT_FLAGS(p0: int, p1: int) -> None:
    _iv(0xB782F8238512BAD5, p0, p1)

def IS_PED_SHELTERED(ped: int) -> bool:
    return _ib(0xB8B52E498014F5B0, ped)

def CAN_CREATE_RANDOM_DRIVER() -> bool:
    return _ib(0xB8EB95E5B4E56978)

def IS_PED_HELMET_VISOR_UP(ped: int) -> bool:
    return _ib(0xB9496CE47546DB2C, ped)

def IS_PED_HUMAN(ped: int) -> bool:
    return _ib(0xB980061DA992779D, ped)

def IS_PED_DEFENSIVE_AREA_ACTIVE(ped: int, p1: bool) -> bool:
    return _ib(0xBA63D9FE45412247, ped, p1)

def GET_POS_FROM_FIRED_EVENT(ped: int, eventType: int, outData: int) -> bool:
    return _ib(0xBA656A3BB01BDEA3, ped, eventType, outData)

def REGISTER_PEDHEADSHOT_HIRES(ped: int) -> int:
    return _ii(0xBA8805A1108A2515, ped)

def SET_PED_CAN_PLAY_GESTURE_ANIMS(ped: int, toggle: bool) -> None:
    _iv(0xBAF20C5432058024, ped, toggle)

def SET_PED_AS_COP(ped: int, toggle: bool) -> None:
    _iv(0xBB03C38DD3FB7FFD, ped, toggle)

def IS_PED_GETTING_INTO_A_VEHICLE(ped: int) -> bool:
    return _ib(0xBB062B2B5722478E, ped)

def RESET_PED_LAST_VEHICLE(ped: int) -> None:
    _iv(0xBB8DE8CF6A8DD8BB, ped)

def IS_PED_FLEEING(ped: int) -> bool:
    return _ib(0xBBCCE00B381F8482, ped)

def SET_PED_GET_OUT_UPSIDE_DOWN_VEHICLE(ped: int, toggle: bool) -> None:
    _iv(0xBC0ED94165A48BC2, ped, toggle)

def GET_ANIM_INITIAL_OFFSET_POSITION(animDict: str, animName: str, x: float, y: float, z: float, xRot: float, yRot: float, zRot: float, p8: float, p9: int) -> 'gta.Vector3':
    return _ivec(0xBE22B26DD764C040, animDict, animName, x, y, z, xRot, yRot, zRot, p8, p9)

def SET_PED_CAN_BE_TARGETTED_BY_TEAM(ped: int, team: int, toggle: bool) -> None:
    _iv(0xBF1CA77833E58F2C, ped, team, toggle)

def SET_RELATIONSHIP_BETWEEN_GROUPS(relationship: int, group1: int, group2: int) -> None:
    _iv(0xBF25EB89375A37AD, relationship, group1, group2)

def SET_PED_ENVEFF_SCALE(ped: int, value: float) -> None:
    _iv(0xBF29516833893561, ped, value)

def IS_PED_SWIMMING_UNDER_WATER(ped: int) -> bool:
    return _ib(0xC024869A53992F34, ped)

def SET_PED_HELMET_FLAG(ped: int, helmetFlag: int) -> None:
    _iv(0xC0E78D5C2CE3EB25, ped, helmetFlag)

def SET_PED_CAN_HEAD_IK(ped: int, toggle: bool) -> None:
    _iv(0xC11C18092C5530DC, ped, toggle)

def STOP_PED_WEAPON_FIRING_WHEN_DROPPED(ped: int) -> None:
    _iv(0xC158D28142A34608, ped)

def SET_PED_CAN_BE_DRAGGED_OUT(ped: int, toggle: bool) -> None:
    _iv(0xC1670E958EEE24E5, ped, toggle)

def SET_PED_RESET_FLAG(ped: int, flagId: int, doReset: bool) -> None:
    _iv(0xC1E8A365BF3B29F2, ped, flagId, doReset)

def SET_PED_HEATSCALE_OVERRIDE(ped: int, heatScale: float) -> None:
    _iv(0xC1F6EBF9A3D55538, ped, heatScale)

def TRIGGER_IDLE_ANIMATION_ON_PED(ped: int) -> None:
    _iv(0xC2EE020F5FB4DB53, ped)

def IS_PED_GESTURING(p0: int) -> bool:
    return _ib(0xC30BDAEE47256C13, p0)

def SET_IK_TARGET(ped: int, ikIndex: int, entityLookAt: int, boneLookAt: int, offsetX: float, offsetY: float, offsetZ: float, p7: int, blendInDuration: int, blendOutDuration: int) -> None:
    _iv(0xC32779C16FCEECD9, ped, ikIndex, entityLookAt, boneLookAt, offsetX, offsetY, offsetZ, p7, blendInDuration, blendOutDuration)

def GET_CLOSEST_PED(x: float, y: float, z: float, radius: float, p4: bool, p5: bool, outPed: int, p7: bool, p8: bool, pedType: int) -> bool:
    return _ib(0xC33AB876A77F8164, x, y, z, radius, p4, p5, outPed, p7, p8, pedType)

def SET_PED_LEG_IK_MODE(ped: int, mode: int) -> None:
    _iv(0xC396F5B86FF9FEBD, ped, mode)

def SET_PED_RANDOM_PROPS(ped: int) -> None:
    _iv(0xC44AA05345C992C6, ped)

def SET_PED_CAN_PEEK_IN_COVER(ped: int, toggle: bool) -> None:
    _iv(0xC514825C507E3736, ped, toggle)

def SET_ENABLE_BOUND_ANKLES(ped: int, toggle: bool) -> None:
    _iv(0xC52E0F855C58FC2E, ped, toggle)

def GET_TINT_INDEX_FOR_LAST_GEN_HAIR_TEXTURE(modelHash: int, drawableId: int, textureId: int) -> int:
    return _ii(0xC56FBF2F228E1DAC, modelHash, drawableId, textureId)

def IS_PED_PLANTING_BOMB(ped: int) -> bool:
    return _ib(0xC70B5FAE151982D8, ped)

def _SET_BLOCK_AMBIENT_PEDS_FROM_DROPPING_WEAPONS_THIS_FRAME() -> None:
    _iv(0xC73EFFC5E043A8BA)

def SET_PED_COMBAT_ABILITY(ped: int, abilityLevel: int) -> None:
    _iv(0xC7622C0D36B2FDA8, ped, abilityLevel)

def CLEAR_PED_MOTION_IN_COVER_CLIPSET_OVERRIDE(ped: int) -> None:
    _iv(0xC79196DCB36F6121, ped)

def SET_PED_CAN_BE_SHOT_IN_VEHICLE(ped: int, toggle: bool) -> None:
    _iv(0xC7EF1BA83230BA07, ped, toggle)

def SET_PED_ANGLED_DEFENSIVE_AREA(ped: int, p1: float, p2: float, p3: float, p4: float, p5: float, p6: float, p7: float, p8: bool, p9: bool) -> None:
    _iv(0xC7F76DF27A5045A1, ped, p1, p2, p3, p4, p5, p6, p7, p8, p9)

def SET_PED_RELATIONSHIP_GROUP_HASH(ped: int, hash: int) -> None:
    _iv(0xC80A74AC829DDD92, ped, hash)

def SET_PED_RANDOM_COMPONENT_VARIATION(ped: int, p1: int) -> None:
    _iv(0xC8A9481A01E63C28, ped, p1)

def IS_PED_MODEL(ped: int, modelHash: int) -> bool:
    return _ib(0xC9D55B1A358A5BF7, ped, modelHash)

def SET_PED_CAN_COWER_IN_COVER(ped: int, toggle: bool) -> None:
    _iv(0xCB7553CDCEF4A735, ped, toggle)

def SET_FORCE_STEP_TYPE(ped: int, p1: bool, type: int, p3: int) -> None:
    _iv(0xCB968B53FC7F916D, ped, p1, type, p3)

def DOES_RELATIONSHIP_GROUP_EXIST(groupHash: int) -> bool:
    return _ib(0xCC6E3B6BB69501F1, groupHash)

def SET_HEAD_BLEND_PALETTE_COLOR(ped: int, r: int, g: int, b: int, id: int) -> None:
    _iv(0xCC9682B8951C5229, ped, r, g, b, id)

def REQUEST_PED_RESTRICTED_VEHICLE_VISIBILITY_TRACKING(ped: int, p1: bool) -> None:
    _iv(0xCD018C591F94CB43, ped, p1)

def SET_PED_PRIMARY_LOOKAT(ped: int, lookAt: int) -> None:
    _iv(0xCD17B554996A8D9E, ped, lookAt)

def GET_DEAD_PED_PICKUP_COORDS(ped: int, p1: float, p2: float) -> 'gta.Vector3':
    return _ivec(0xCD5003B097200F36, ped, p1, p2)

def CLEAR_ALL_PED_PROPS(ped: int, p1: int) -> None:
    _iv(0xCD8A7537A9B52F06, ped, p1)

def TAKE_OWNERSHIP_OF_SYNCHRONIZED_SCENE(scene: int) -> None:
    _iv(0xCD9CC7E200A52A6F, scene)

def SET_GROUP_FORMATION(groupId: int, formationType: int) -> None:
    _iv(0xCE2F5FC3AF7E8C1E, groupId, formationType)

def SET_PED_ARMOUR(ped: int, amount: int) -> None:
    _iv(0xCEA04D83135264CC, ped, amount)

def SET_PED_SHOULD_PROBE_FOR_SCENARIO_EXITS_IN_ONE_FRAME(p0: int, p1: bool) -> None:
    _iv(0xCEDA60A74219D064, p0, p1)

def IS_PED_JUMPING(ped: int) -> bool:
    return _ib(0xCEDABC5900A0BF97, ped)

def GET_PED_HEAD_OVERLAY_NUM(overlayID: int) -> int:
    return _ii(0xCF1CE768BB43480E, overlayID)

def GET_PED_NEARBY_VEHICLES(ped: int, sizeAndVehs: int) -> int:
    return _ii(0xCFF869CBFA210D82, ped, sizeAndVehs)

def IS_PED_DUCKING(ped: int) -> bool:
    return _ib(0xD125AE748725C6BC, ped)

def IS_PED_RUNNING_MELEE_TASK(ped: int) -> bool:
    return _ib(0xD1871251F3B5ACD7, ped)

def GET_NUM_PED_MAKEUP_TINTS() -> int:
    return _ii(0xD1F7CA1535D22818)

def SET_ENABLE_PED_ENVEFF_SCALE(ped: int, toggle: bool) -> None:
    _iv(0xD2C5AA0C0E8D0F1E, ped, toggle)

def FORCE_ZERO_MASS_IN_COLLISIONS(ped: int) -> None:
    _iv(0xD33DAA36272177C4, ped)

def REMOVE_SCENARIO_BLOCKING_AREAS() -> None:
    _iv(0xD37401D78A929A49)

def CREATE_PED(pedType: int, modelHash: int, x: float, y: float, z: float, heading: float, isNetwork: bool, bScriptHostPed: bool) -> int:
    return _ii(0xD49F9B0955C367DE, pedType, modelHash, x, y, z, heading, isNetwork, bScriptHostPed)

def SET_PED_ENVEFF_COLOR_MODULATOR(ped: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xD69411AA0CEBF9E9, ped, p1, p2, p3)

def IS_PED_PRONE(ped: int) -> bool:
    return _ib(0xD6A86331A537A7B9, ped)

def IS_PED_FACING_PED(ped: int, otherPed: int, angle: float) -> bool:
    return _ib(0xD71649DB0A545AA3, ped, otherPed, angle)

def SET_PED_DIES_IN_SINKING_VEHICLE(ped: int, toggle: bool) -> None:
    _iv(0xD718A22995E2B4BC, ped, toggle)

def GET_PED_LAST_DAMAGE_BONE(ped: int, outBone: int) -> bool:
    return _ib(0xD75960F6BD9EA49C, ped, outBone)

def SET_PED_USING_ACTION_MODE(ped: int, p1: bool, p2: int, action: str) -> None:
    _iv(0xD75ACCF5E0FB5367, ped, p1, p2, action)

def SET_PED_TO_RAGDOLL_WITH_FALL(ped: int, time: int, p2: int, ragdollType: int, x: float, y: float, z: float, velocity: float, p8: float, p9: float, p10: float, p11: float, p12: float, p13: float) -> bool:
    return _ib(0xD76632D99E4966C8, ped, time, p2, ragdollType, x, y, z, velocity, p8, p9, p10, p11, p12, p13)

def GET_SYNCHRONIZED_SCENE_RATE(sceneID: int) -> float:
    return _if(0xD80932D577274D40, sceneID)

def IS_PED_FATALLY_INJURED(ped: int) -> bool:
    return _ib(0xD839450756ED5A80, ped)

def CLEAR_RAGDOLL_BLOCKING_FLAGS(ped: int, blockingFlag: int) -> None:
    _iv(0xD86D101FCFD00A4B, ped, blockingFlag)

def SET_POP_CONTROL_SPHERE_THIS_FRAME(x: float, y: float, z: float, min: float, max: float) -> None:
    _iv(0xD8C3BE3EE94CAF2D, x, y, z, min, max)

def CLEAR_PED_ALTERNATE_MOVEMENT_ANIM(ped: int, stance: int, p2: float) -> None:
    _iv(0xD8D19675ED5FBDCE, ped, stance, p2)

def SET_SYNCHRONIZED_SCENE_LOOPED(sceneID: int, toggle: bool) -> None:
    _iv(0xD9A897A4C6C2974F, sceneID, toggle)

def SET_PED_ALLOWED_TO_DUCK(ped: int, toggle: bool) -> None:
    _iv(0xDA1F1B7BE1A8766F, ped, toggle)

def GET_PEDHEADSHOT_TXD_STRING(id: int) -> str:
    return _is(0xDB4EACD4AD0A5D6B, id)

def SET_PED_ALERTNESS(ped: int, value: int) -> None:
    _iv(0xDBA71115ED9941A6, ped, value)

def SET_PED_LOD_MULTIPLIER(ped: int, multiplier: float) -> None:
    _iv(0xDC2C5C242AAC342B, ped, multiplier)

def IS_PED_PERFORMING_MELEE_ACTION(ped: int) -> bool:
    return _ib(0xDCCA191DF9980FD7, ped)

def SET_PED_GESTURE_GROUP(ped: int, animGroupGesture: str) -> None:
    _iv(0xDDF803377F94AAA8, ped, animGroupGesture)

def GET_PED_COMBAT_MOVEMENT(ped: int) -> int:
    return _ii(0xDEA92412FCAEB3F5, ped)

def SET_DRIVER_RACING_MODIFIER(driver: int, modifier: float) -> None:
    _iv(0xDED5AF5A0EA4B297, driver, modifier)

def SET_ENABLE_HANDCUFFS(ped: int, toggle: bool) -> None:
    _iv(0xDF1AF8B5D56542FA, ped, toggle)

def SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(ped: int, toggle: bool) -> None:
    _iv(0xDF993EE5E90ABA25, ped, toggle)

def SET_DISABLE_PED_MAP_COLLISION(ped: int) -> None:
    _iv(0xDFE68C4B787E1BFB, ped)

def IS_CONVERSATION_PED_DEAD(ped: int) -> bool:
    return _ib(0xE0A0AEC214B1FABA, ped)

def GET_PED_EXTRACTED_DISPLACEMENT(ped: int, worldSpace: bool) -> 'gta.Vector3':
    return _ivec(0xE0AF41401ADF87E3, ped, worldSpace)

def IS_PED_HAIR_TINT_FOR_BARBER(colorID: int) -> bool:
    return _ib(0xE0D36E5D9E99CC21, colorID)

def GET_PED_PROP_TEXTURE_INDEX(ped: int, componentId: int) -> int:
    return _ii(0xE131A28626F81AB2, ped, componentId)

def SET_PED_MODEL_IS_SUPPRESSED(modelHash: int, toggle: bool) -> None:
    _iv(0xE163A4BCE4DE6F11, modelHash, toggle)

def PLAY_FACIAL_ANIM(ped: int, animName: str, animDict: str) -> None:
    _iv(0xE1E65CA8AC9C00ED, ped, animName, animDict)

def CLEAR_PED_DECORATIONS_LEAVE_SCARS(ped: int) -> None:
    _iv(0xE3B27E70CEAB9F0C, ped)

def IS_PED_RUNNING_RAGDOLL_TASK(ped: int) -> bool:
    return _ib(0xE3B6097CC25AA69E, ped)

def GET_PED_PALETTE_VARIATION(ped: int, componentId: int) -> int:
    return _ii(0xE3DD5F2A84B42281, ped, componentId)

def BLOCK_PED_FROM_GENERATING_DEAD_BODY_EVENTS_WHEN_DEAD(ped: int, toggle: bool) -> None:
    _iv(0xE43A13C9E4CCCBCF, ped, toggle)

def SET_PED_DEFENSIVE_SPHERE_ATTACHED_TO_VEHICLE(ped: int, target: int, xOffset: float, yOffset: float, zOffset: float, radius: float, p6: bool) -> None:
    _iv(0xE4723DB6E736CCFF, ped, target, xOffset, yOffset, zOffset, radius, p6)

def GET_SYNCHRONIZED_SCENE_PHASE(sceneID: int) -> float:
    return _if(0xE4A310B1D7FA73CC, sceneID)

def HAS_ACTION_MODE_ASSET_LOADED(asset: str) -> bool:
    return _ib(0xE4B5F4BF2CB24E65, asset)

def GET_NUM_PED_HAIR_TINTS() -> int:
    return _ii(0xE5C0CF872C2AD150)

def CLEAR_ALL_PED_VEHICLE_FORCED_SEAT_USAGE(ped: int) -> None:
    _iv(0xE6CA85E7259CE16B, ped)

def GET_MOUNT(ped: int) -> int:
    return _ii(0xE7E11B8DCBED1058, ped)

def IS_PED_COMPONENT_VARIATION_VALID(ped: int, componentId: int, drawableId: int, textureId: int) -> bool:
    return _ib(0xE825F6B6CEA7671D, ped, componentId, drawableId, textureId)

def SET_PED_CAN_LOSE_PROPS_ON_DAMAGE(ped: int, toggle: bool, p2: int) -> None:
    _iv(0xE861D0B05C7662B8, ped, toggle, p2)

def SET_PED_RESERVE_PARACHUTE_TINT_INDEX(ped: int, p1: int) -> None:
    _iv(0xE88DA0751C22A2AD, ped, p1)

def HAS_PEDHEADSHOT_IMG_UPLOAD_SUCCEEDED() -> bool:
    return _ib(0xE8A169E666CBC541)

def SET_PED_ENABLE_CREW_EMBLEM(ped: int, toggle: bool) -> None:
    _iv(0xE906EC930F5FE7C8, ped, toggle)

def CLONE_PED_TO_TARGET(ped: int, targetPed: int) -> None:
    _iv(0xE952D6431689AD9A, ped, targetPed)

def HAS_STEALTH_MODE_ASSET_LOADED(asset: str) -> bool:
    return _ib(0xE977FC5B08AF3441, asset)

def RESET_AI_WEAPON_DAMAGE_MODIFIER() -> None:
    _iv(0xEA16670E7BA4743C)

def GET_DEFAULT_SECONDARY_TINT_FOR_CREATOR(colorId: int) -> int:
    return _ii(0xEA9960D07DADCF10, colorId)

def CAN_CREATE_RANDOM_BIKE_RIDER() -> bool:
    return _ib(0xEACEEDA81751915C)

def CAN_PED_IN_COMBAT_SEE_TARGET(ped: int, target: int) -> bool:
    return _ib(0xEAD42DE3610D0721, ped, target)

def GET_PED_PARACHUTE_TINT_INDEX(ped: int, outTintIndex: int) -> None:
    _iv(0xEAF5F7E5AE7C6C9D, ped, outTintIndex)

def SET_PED_STEERS_AROUND_VEHICLES(ped: int, toggle: bool) -> None:
    _iv(0xEB6FB9D48DDE23EC, ped, toggle)

def GET_RELATIONSHIP_BETWEEN_PEDS(ped1: int, ped2: int) -> int:
    return _ii(0xEBA5AD3A0EAF7121, ped1, ped2)

def IS_PEDHEADSHOT_IMG_UPLOAD_AVAILABLE() -> bool:
    return _ib(0xEBB376779A760AA8)

def IS_PED_PERFORMING_A_COUNTER_ATTACK(ped: int) -> bool:
    return _ib(0xEBD0EDBA5BE957CF, ped)

def SET_PED_SUFFERS_CRITICAL_HITS(ped: int, toggle: bool) -> None:
    _iv(0xEBD76F2359F190AC, ped, toggle)

def SET_PED_CAN_USE_AUTO_CONVERSATION_LOOKAT(ped: int, toggle: bool) -> None:
    _iv(0xEC4686EC06434678, ped, toggle)

def SET_PED_INJURED_ON_GROUND_BEHAVIOUR(ped: int, p1: float) -> None:
    _iv(0xEC4B4B3B9908052A, ped, p1)

def IS_PED_ON_SPECIFIC_VEHICLE(ped: int, vehicle: int) -> bool:
    return _ib(0xEC5F66E459AF3BB2, ped, vehicle)

def SET_PED_SHOULD_PLAY_DIRECTED_NORMAL_SCENARIO_EXIT(p0: int, p1: int, p2: int, p3: int) -> bool:
    return _ib(0xEC6935EBE0847B90, p0, p1, p2, p3)

def SET_PED_DRIVE_BY_CLIPSET_OVERRIDE(ped: int, clipset: str) -> None:
    _iv(0xED34AB6C5CB36520, ped, clipset)

def FORCE_INSTANT_LEG_IK_SETUP(ped: int) -> None:
    _iv(0xED3C76ADFA6D07C4, ped)

def IS_PED_HAIR_TINT_FOR_CREATOR(colorId: int) -> bool:
    return _ib(0xED6D8E27A43B8CDE, colorId)

def REMOVE_PED_FROM_GROUP(ped: int) -> None:
    _iv(0xED74007FFB146BC2, ped)

def SET_PED_CAN_SWITCH_WEAPON(ped: int, toggle: bool) -> None:
    _iv(0xED7F7EFE9FABF340, ped, toggle)

def SET_PED_STAY_IN_VEHICLE_WHEN_JACKED(ped: int, toggle: bool) -> None:
    _iv(0xEDF4079F9D54C9A1, ped, toggle)

def SET_PED_NON_CREATION_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> None:
    _iv(0xEE01041D559983EA, x1, y1, z1, x2, y2, z2)

def ENABLE_MP_LIGHT(ped: int, toggle: bool) -> None:
    _iv(0xEE2476B9EE4A094F, ped, toggle)

def SET_PED_DIES_INSTANTLY_IN_WATER(ped: int, toggle: bool) -> None:
    _iv(0xEEB64139BA29A7CF, ped, toggle)

def SET_PED_SHOULD_PLAY_FLEE_SCENARIO_EXIT(ped: int, p1: int, p2: int, p3: int) -> bool:
    return _ib(0xEEED8FAFEC331A70, ped, p1, p2, p3)

def APPLY_PED_BLOOD_SPECIFIC(ped: int, p1: int, p2: float, p3: float, p4: float, p5: float, p6: int, p7: float, p8: str) -> None:
    _iv(0xEF0D582CBF2D9B0F, ped, p1, p2, p3, p4, p5, p6, p7, p8)

def CLONE_PED(ped: int, isNetwork: bool, bScriptHostPed: bool, copyHeadBlendFlag: bool) -> int:
    return _ii(0xEF29A16337FACADB, ped, isNetwork, bScriptHostPed, copyHeadBlendFlag)

def GET_PED_VISUAL_FIELD_CENTER_ANGLE(ped: int) -> float:
    return _if(0xEF2C71A32CAD5FBD, ped)

def GET_FM_FEMALE_SHOP_PED_APPAREL_ITEM_INDEX(p0: int) -> int:
    return _ii(0xF033419D1B81FAE8, p0)

def SET_PED_RAGDOLL_ON_COLLISION(ped: int, toggle: bool) -> None:
    _iv(0xF0A4F1BBF4FA7497, ped, toggle)

def REQUEST_PEDHEADSHOT_IMG_UPLOAD(id: int) -> bool:
    return _ib(0xF0DAEF2F545BEE25, id)

def SET_PED_ID_RANGE(ped: int, value: float) -> None:
    _iv(0xF107E836A70DCE05, ped, value)

def SET_PED_HELMET_TEXTURE_INDEX(ped: int, textureIndex: int) -> None:
    _iv(0xF1550C4BD22582E2, ped, textureIndex)

def GET_PED_GROUP_INDEX(ped: int) -> int:
    return _ii(0xF162E133B4E7A675, ped)

def SET_PED_SHOULD_PLAY_IMMEDIATE_SCENARIO_EXIT(ped: int) -> None:
    _iv(0xF1C03A5352243A30, ped)

def IS_CURRENT_HEAD_PROP_A_HELMET(p0: int) -> bool:
    return _ib(0xF2385935BFFD4D92, p0)

def FORCE_PED_MOTION_STATE(ped: int, motionStateHash: int, p2: bool, p3: int, p4: bool) -> bool:
    return _ib(0xF28965D04F570DCA, ped, motionStateHash, p2, p3, p4)

def SET_PED_SEEING_RANGE(ped: int, value: float) -> None:
    _iv(0xF29CF591C4BF6CEE, ped, value)

def SET_PED_CAN_TORSO_IK(ped: int, toggle: bool) -> None:
    _iv(0xF2B7106D37947CE0, ped, toggle)

def SET_PED_ALLOW_HURT_COMBAT_FOR_ALL_MISSION_PEDS(toggle: bool) -> None:
    _iv(0xF2BEBCDFAFDAA19E, toggle)

def IS_PED_WEARING_HELMET(ped: int) -> bool:
    return _ib(0xF33BDFE19B309B19, ped)

def ADD_RELATIONSHIP_GROUP(name: str, groupHash: int) -> bool:
    return _ib(0xF372BC22FCB88606, name, groupHash)

def IS_PED_BLUSH_TINT_FOR_CREATOR(colorId: int) -> bool:
    return _ib(0xF41B5D290C99A3D6, colorId)

def SPAWNPOINTS_IS_SEARCH_FAILED() -> bool:
    return _ib(0xF445DE8DA80A1792)

def SET_PED_CAN_TORSO_REACT_IK(ped: int, p1: bool) -> None:
    _iv(0xF5846EDB26A98A24, ped, p1)

def SET_PED_MAX_HEALTH(ped: int, value: int) -> None:
    _iv(0xF5F6378C4F3419D3, ped, value)

def GET_PED_CURRENT_MOVE_BLEND_RATIO(ped: int, speedX: int, speedY: int) -> bool:
    return _ib(0xF60165E1D2C5370B, ped, speedX, speedY)

def GET_PED_ALERTNESS(ped: int) -> int:
    return _ii(0xF6AA118530443FD2, ped)

def SET_PED_INTO_VEHICLE(ped: int, vehicle: int, seatIndex: int) -> None:
    _iv(0xF75B0D629E1C063D, ped, vehicle, seatIndex)

def RELEASE_PED_PRELOAD_PROP_DATA(ped: int) -> None:
    _iv(0xF79F9DEF0AADE61A, ped)

def SET_PED_CAN_PLAY_VISEME_ANIMS(ped: int, toggle: bool, p2: bool) -> None:
    _iv(0xF833DDBA3B104D43, ped, toggle, p2)

def GET_VEHICLE_PED_IS_ENTERING(ped: int) -> int:
    return _ii(0xF92691AED837A5FC, ped)

def WAS_PED_KILLED_BY_STEALTH(ped: int) -> bool:
    return _ib(0xF9800AA1A771B000, ped)

def SET_ENABLE_SCUBA(ped: int, toggle: bool) -> None:
    _iv(0xF99F62004024D506, ped, toggle)

def SPECIAL_FUNCTION_DO_NOT_USE(ped: int, p1: bool) -> None:
    _iv(0xF9ACF4A08098EA25, ped, p1)

def SET_PED_DEFENSIVE_SPHERE_ATTACHED_TO_PED(ped: int, target: int, xOffset: float, yOffset: float, zOffset: float, radius: float, p6: bool) -> None:
    _iv(0xF9B8F91AAD3B953E, ped, target, xOffset, yOffset, zOffset, radius, p6)

def GET_PED_COMBAT_RANGE(ped: int) -> int:
    return _ii(0xF9D9F7F2DB8E2FA0, ped)

def SET_PED_MIN_GROUND_TIME_FOR_STUNGUN(ped: int, ms: int) -> None:
    _iv(0xFA0675AB151073FA, ped, ms)

def SET_ALLOW_STUNT_JUMP_CAMERA(ped: int, toggle: bool) -> None:
    _iv(0xFAB944D4D481ACCB, ped, toggle)

def IS_PED_FALLING(ped: int) -> bool:
    return _ib(0xFB92A102F1C4DFA3, ped)

def IS_PED_IN_ANY_SUB(ped: int) -> bool:
    return _ib(0xFBFC01CCFB35D99E, ped)

def IS_PED_HEADING_TOWARDS_POSITION(ped: int, x: float, y: float, z: float, p4: float) -> bool:
    return _ib(0xFCF37A457CB96DC0, ped, x, y, z, p4)

def SET_USE_CAMERA_HEADING_FOR_DESIRED_DIRECTION_LOCK_ON_TEST(ped: int, toggle: bool) -> None:
    _iv(0xFD325494792302D7, ped, toggle)

def IS_PED_PERFORMING_STEALTH_KILL(ped: int) -> bool:
    return _ib(0xFD4CCDBCC59941B7, ped)

def REMOVE_PED_PREFERRED_COVER_SET(ped: int) -> None:
    _iv(0xFDDB234CF74073D9, ped)

def SET_PED_PANIC_EXIT_SCENARIO(p0: int, p1: int, p2: int, p3: int) -> bool:
    return _ib(0xFE07FF6495D52E2A, p0, p1, p2, p3)

def IS_USING_PED_SCUBA_GEAR_VARIATION(p0: int) -> bool:
    return _ib(0xFEC9A3B1820F3331, p0)

def SPAWNPOINTS_CANCEL_SEARCH() -> None:
    _iv(0xFEE4A5459472A9F8)

def GET_PED_TYPE(ped: int) -> int:
    return _ii(0xFF059E1E4C01E63C, ped)

def FORCE_ALL_HEADING_VALUES_TO_ALIGN(ped: int) -> None:
    _iv(0xFF287323B0E2C69A, ped)

def SET_COMBAT_FLOAT(ped: int, combatType: int, p2: float) -> None:
    _iv(0xFF41B4B141ED981C, ped, combatType, p2)

def SET_HEALTH_SNACKS_CARRIED_BY_ALL_NEW_PEDS(p0: float, p1: int) -> None:
    _iv(0xFF4803BC019852D9, p0, p1)

def SET_FACIAL_IDLE_ANIM_OVERRIDE(ped: int, animName: str, animDict: str) -> None:
    _iv(0xFFC24B988B938B38, ped, animName, animDict)
