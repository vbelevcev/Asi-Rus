"""Auto-generated raw native bindings for namespace WATER.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if


def GET_DEEP_OCEAN_SCALER() -> float:
    return _if(0x2B2A2CC86778B619)

def TEST_VERTICAL_PROBE_AGAINST_ALL_WATER(x: float, y: float, z: float, flags: int, waterHeight: int) -> int:
    return _ii(0x2B3451FA1E3142E2, x, y, z, flags, waterHeight)

def SET_CALMED_WAVE_HEIGHT_SCALER(height: float) -> None:
    _iv(0x547237AA71AB44DE, height)

def RESET_DEEP_OCEAN_SCALER() -> None:
    _iv(0x5E5E99285AE812DB)

def TEST_PROBE_AGAINST_ALL_WATER(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, flags: int, waterHeight: int) -> int:
    return _ii(0x8974647ED222EA5F, x1, y1, z1, x2, y2, z2, flags, waterHeight)

def GET_WATER_HEIGHT_NO_WAVES(x: float, y: float, z: float, height: int) -> bool:
    return _ib(0x8EE6B53CE13A9794, x, y, z, height)

def REMOVE_EXTRA_CALMING_QUAD(calmingQuad: int) -> None:
    _iv(0xB1252E3E59A82AAF, calmingQuad)

def SET_DEEP_OCEAN_SCALER(intensity: float) -> None:
    _iv(0xB96B00E976BE977F, intensity)

def MODIFY_WATER(x: float, y: float, radius: float, height: float) -> None:
    _iv(0xC443FD757C3BA637, x, y, radius, height)

def GET_WATER_HEIGHT(x: float, y: float, z: float, height: int) -> bool:
    return _ib(0xF6829842C06AE524, x, y, z, height)

def ADD_EXTRA_CALMING_QUAD(xLow: float, yLow: float, xHigh: float, yHigh: float, height: float) -> int:
    return _ii(0xFDBF4CDBC07E1706, xLow, yLow, xHigh, yHigh, height)

def TEST_PROBE_AGAINST_WATER(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, result: int) -> bool:
    return _ib(0xFFA5D878809819DB, x1, y1, z1, x2, y2, z2, result)
