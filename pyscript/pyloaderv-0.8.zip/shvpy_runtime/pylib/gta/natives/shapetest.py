"""Auto-generated raw native bindings for namespace SHAPETEST.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_int as _ii


def START_SHAPE_TEST_BOUNDING_BOX(entity: int, flags1: int, flags2: int) -> int:
    return _ii(0x052837721A854EC7, entity, flags1, flags2)

def START_SHAPE_TEST_CAPSULE(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, radius: float, flags: int, entity: int, p9: int) -> int:
    return _ii(0x28579D1B8F8AAC80, x1, y1, z1, x2, y2, z2, radius, flags, entity, p9)

def RELEASE_SCRIPT_GUID_FROM_ENTITY(entityHit: int) -> None:
    _iv(0x2B3334BCA57CD799, entityHit)

def START_SHAPE_TEST_BOUND(entity: int, flags1: int, flags2: int) -> int:
    return _ii(0x37181417CE7C8900, entity, flags1, flags2)

def START_EXPENSIVE_SYNCHRONOUS_SHAPE_TEST_LOS_PROBE(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, flags: int, entity: int, p8: int) -> int:
    return _ii(0x377906D8A31E5586, x1, y1, z1, x2, y2, z2, flags, entity, p8)

def GET_SHAPE_TEST_RESULT(shapeTestHandle: int, hit: int, endCoords: int, surfaceNormal: int, entityHit: int) -> int:
    return _ii(0x3D87450E15D98694, shapeTestHandle, hit, endCoords, surfaceNormal, entityHit)

def GET_SHAPE_TEST_RESULT_INCLUDING_MATERIAL(shapeTestHandle: int, hit: int, endCoords: int, surfaceNormal: int, materialHash: int, entityHit: int) -> int:
    return _ii(0x65287525D951F6BE, shapeTestHandle, hit, endCoords, surfaceNormal, materialHash, entityHit)

def START_SHAPE_TEST_LOS_PROBE(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, flags: int, entity: int, p8: int) -> int:
    return _ii(0x7EE9F5D83DD4F90E, x1, y1, z1, x2, y2, z2, flags, entity, p8)

def START_SHAPE_TEST_SWEPT_SPHERE(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, radius: float, flags: int, entity: int, p9: int) -> int:
    return _ii(0xE6AC6C45FBE83004, x1, y1, z1, x2, y2, z2, radius, flags, entity, p9)

def START_SHAPE_TEST_BOX(x: float, y: float, z: float, dimX: float, dimY: float, dimZ: float, rotX: float, rotY: float, rotZ: float, p9: int, flags: int, entity: int, p12: int) -> int:
    return _ii(0xFE466162C4401D18, x, y, z, dimX, dimY, dimZ, rotX, rotY, rotZ, p9, flags, entity, p12)

def START_SHAPE_TEST_MOUSE_CURSOR_LOS_PROBE(pVec1: int, pVec2: int, flag: int, entity: int, flag2: int) -> int:
    return _ii(0xFF6BE494C7987F34, pVec1, pVec2, flag, entity, flag2)
