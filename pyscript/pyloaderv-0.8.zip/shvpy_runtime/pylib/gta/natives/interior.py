"""Auto-generated raw native bindings for namespace INTERIOR.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_vector3 as _ivec


def GET_INTERIOR_AT_COORDS_WITH_TYPE(x: float, y: float, z: float, interiorType: str) -> int:
    return _ii(0x05B7A89BD78797FC, x, y, z, interiorType)

def GET_INTERIOR_FROM_ENTITY(entity: int) -> int:
    return _ii(0x2107BA504071A6BB, entity)

def CLEAR_ROOM_FOR_GAME_VIEWPORT() -> None:
    _iv(0x23B59D8912F94246)

def GET_INTERIOR_LOCATION_AND_NAMEHASH(interior: int, position: int, nameHash: int) -> None:
    _iv(0x252BDC06B73FA6EA, interior, position, nameHash)

def UNPIN_INTERIOR(interior: int) -> None:
    _iv(0x261CCE7EED010641, interior)

def IS_VALID_INTERIOR(interior: int) -> bool:
    return _ib(0x26B0E73D7EAAF4D3, interior)

def PIN_INTERIOR_IN_MEMORY(interior: int) -> None:
    _iv(0x2CA429C029CCF247, interior)

def IS_INTERIOR_ENTITY_SET_ACTIVE(interior: int, entitySetName: str) -> bool:
    return _ib(0x35F7DD45E8C0A16D, interior, entitySetName)

def FORCE_ACTIVATING_TRACKING_ON_ENTITY(p0: int, p1: int) -> None:
    _iv(0x38C1CB1CB119A016, p0, p1)

def GET_KEY_FOR_ENTITY_IN_ROOM(entity: int) -> int:
    return _ii(0x399685DB942336BC, entity)

def ADD_PICKUP_TO_INTERIOR_ROOM_BY_NAME(pickup: int, roomName: str) -> None:
    _iv(0x3F6167F351168730, pickup, roomName)

def SET_ROOM_FOR_GAME_VIEWPORT_BY_KEY(roomHashKey: int) -> None:
    _iv(0x405DC2AEF6AF95B9, roomHashKey)

def REFRESH_INTERIOR(interior: int) -> None:
    _iv(0x41F37C3427C75AE0, interior)

def DEACTIVATE_INTERIOR_ENTITY_SET(interior: int, entitySetName: str) -> None:
    _iv(0x420BD37289EEE162, interior, entitySetName)

def GET_ROOM_KEY_FROM_ENTITY(entity: int) -> int:
    return _ii(0x47C2A06D4F5F424B, entity)

def ACTIVATE_INTERIOR_GROUPS_USING_CAMERA() -> None:
    _iv(0x483ACA1176CA93F1)

def SET_INTERIOR_IN_USE(interior: int) -> bool:
    return _ib(0x4C2330E61D3DEB56, interior)

def ENABLE_SHADOW_CULL_MODEL_THIS_FRAME(mapObjectHash: int) -> None:
    _iv(0x50C375537449F369, mapObjectHash)

def FORCE_ROOM_FOR_ENTITY(entity: int, interior: int, roomHashKey: int) -> None:
    _iv(0x52923C4710DD9907, entity, interior, roomHashKey)

def ACTIVATE_INTERIOR_ENTITY_SET(interior: int, entitySetName: str) -> None:
    _iv(0x55E86AF2712B36A1, interior, entitySetName)

def DISABLE_INTERIOR(interior: int, toggle: bool) -> None:
    _iv(0x6170941419D7D8EC, interior, toggle)

def IS_INTERIOR_READY(interior: int) -> bool:
    return _ib(0x6726BDCCC1932F0E, interior)

def SET_IS_EXTERIOR_ONLY(entity: int, toggle: bool) -> None:
    _iv(0x7241CCB7D020DB69, entity, toggle)

def ENABLE_STADIUM_PROBES_THIS_FRAME(toggle: bool) -> None:
    _iv(0x7ECDF98587E92DEC, toggle)

def RETAIN_ENTITY_IN_INTERIOR(entity: int, interior: int) -> None:
    _iv(0x82EBB79E258FA2B7, entity, interior)

def CLEAR_INTERIOR_STATE_OF_ENTITY(entity: int) -> None:
    _iv(0x85D5422B2039A70D, entity)

def FORCE_ROOM_FOR_GAME_VIEWPORT(interiorID: int, roomHashKey: int) -> None:
    _iv(0x920D853F3E17F1DA, interiorID, roomHashKey)

def IS_INTERIOR_CAPPED(interior: int) -> bool:
    return _ib(0x92BAC8ACF88CEC26, interior)

def GET_OFFSET_FROM_INTERIOR_IN_WORLD_COORDS(interior: int, x: float, y: float, z: float) -> 'gta.Vector3':
    return _ivec(0x9E3B3E6D66F6E22F, interior, x, y, z)

def DISABLE_METRO_SYSTEM(toggle: bool) -> None:
    _iv(0x9E6542F0CE8E70A3, toggle)

def GET_ROOM_KEY_FOR_GAME_VIEWPORT() -> int:
    return _ii(0xA6575914D2A0B450)

def ENABLE_EXTERIOR_CULL_MODEL_THIS_FRAME(mapObjectHash: int) -> None:
    _iv(0xA97F257D0151A6AB, mapObjectHash)

def SET_ROOM_FOR_GAME_VIEWPORT_BY_NAME(roomName: str) -> None:
    _iv(0xAF348AFCB575A441, roomName)

def GET_INTERIOR_AT_COORDS(x: float, y: float, z: float) -> int:
    return _ii(0xB0F7F8663821D9C3, x, y, z)

def CLEAR_ROOM_FOR_ENTITY(entity: int) -> None:
    _iv(0xB365FC0C4E27FFA7, entity)

def IS_INTERIOR_DISABLED(interior: int) -> bool:
    return _ib(0xBC5115A5A939DD15, interior)

def IS_INTERIOR_SCENE() -> bool:
    return _ib(0xBC72B5D7A1CBD54D)

def SET_INTERIOR_ENTITY_SET_TINT_INDEX(interior: int, entitySetName: str, color: int) -> None:
    _iv(0xC1F1920BAF281317, interior, entitySetName, color)

def CAP_INTERIOR(interior: int, toggle: bool) -> None:
    _iv(0xD9175F941610DB54, interior, toggle)

def GET_INTERIOR_GROUP_ID(interior: int) -> int:
    return _ii(0xE4A84ABF135EF91A, interior)

def GET_INTERIOR_FROM_PRIMARY_VIEW() -> int:
    return _ii(0xE7D267EC6CA966C3)

def GET_INTERIOR_FROM_COLLISION(x: float, y: float, z: float) -> int:
    return _ii(0xEC4CF9FCB29A4424, x, y, z)

def IS_COLLISION_MARKED_OUTSIDE(x: float, y: float, z: float) -> bool:
    return _ib(0xEEA5AC2EDA7C33E8, x, y, z)

def GET_INTERIOR_AT_COORDS_WITH_TYPEHASH(x: float, y: float, z: float, typeHash: int) -> int:
    return _ii(0xF0F77ADB9F67E79D, x, y, z, typeHash)

def GET_INTERIOR_HEADING(interior: int) -> float:
    return _if(0xF49B58631D9E22D9, interior)
