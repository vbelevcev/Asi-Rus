"""Auto-generated raw native bindings for namespace ITEMSET.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii


def REMOVE_FROM_ITEMSET(item: int, itemset: int) -> None:
    _iv(0x25E68244B0177686, item, itemset)

def IS_IN_ITEMSET(item: int, itemset: int) -> bool:
    return _ib(0x2D0FC594D1E9C107, item, itemset)

def CREATE_ITEMSET(p0: bool) -> int:
    return _ii(0x35AD299F50D91B24, p0)

def CLEAN_ITEMSET(itemset: int) -> None:
    _iv(0x41BC0D722FC04221, itemset)

def GET_INDEXED_ITEM_IN_ITEMSET(index: int, itemset: int) -> int:
    return _ii(0x7A197E2521EE2BAB, index, itemset)

def IS_ITEMSET_VALID(itemset: int) -> bool:
    return _ib(0xB1B1EA596344DFAB, itemset)

def GET_ITEMSET_SIZE(itemset: int) -> int:
    return _ii(0xD9127E83ABF7C631, itemset)

def DESTROY_ITEMSET(itemset: int) -> None:
    _iv(0xDE18220B1C183EDA, itemset)

def ADD_TO_ITEMSET(item: int, itemset: int) -> bool:
    return _ib(0xE3945201F14637DD, item, itemset)
