"""Auto-generated raw native bindings for namespace DECORATOR.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if


def DECOR_REMOVE(entity: int, propertyName: str) -> bool:
    return _ib(0x00EE9F297C738720, entity, propertyName)

def DECOR_EXIST_ON(entity: int, propertyName: str) -> bool:
    return _ib(0x05661B80A8C9165F, entity, propertyName)

def DECOR_SET_INT(entity: int, propertyName: str, value: int) -> bool:
    return _ib(0x0CE3AA5E1CA19E10, entity, propertyName, value)

def DECOR_SET_FLOAT(entity: int, propertyName: str, value: float) -> bool:
    return _ib(0x211AB1DD8D0F363A, entity, propertyName, value)

def DECOR_IS_REGISTERED_AS_TYPE(propertyName: str, type: int) -> bool:
    return _ib(0x4F14F9F870D6FBC8, propertyName, type)

def DECOR_GET_FLOAT(entity: int, propertyName: str) -> float:
    return _if(0x6524A2F114706F43, entity, propertyName)

def DECOR_SET_BOOL(entity: int, propertyName: str, value: bool) -> bool:
    return _ib(0x6B1E8E2ED1335B71, entity, propertyName, value)

def DECOR_SET_TIME(entity: int, propertyName: str, timestamp: int) -> bool:
    return _ib(0x95AED7B8E39ECAA4, entity, propertyName, timestamp)

def DECOR_REGISTER(propertyName: str, type: int) -> None:
    _iv(0x9FD90732F56403CE, propertyName, type)

def DECOR_GET_INT(entity: int, propertyName: str) -> int:
    return _ii(0xA06C969B02A97298, entity, propertyName)

def DECOR_REGISTER_LOCK() -> None:
    _iv(0xA9D14EEA259F9248)

def DECOR_GET_BOOL(entity: int, propertyName: str) -> bool:
    return _ib(0xDACE671663F2F5DB, entity, propertyName)
