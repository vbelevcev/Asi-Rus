"""Auto-generated raw native bindings for namespace DLC.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii


def ON_ENTER_MP() -> None:
    _iv(0x0888C3502DBBEEF5)

def GET_IS_LOADING_SCREEN_ACTIVE() -> bool:
    return _ib(0x10D0A8F259E93EC9)

def ARE_ANY_CCS_PENDING() -> bool:
    return _ib(0x241FCA5B1AA14F75)

def HAS_CLOUD_REQUESTS_FINISHED(p0: int, unused: int) -> bool:
    return _ib(0x46E2B844905BC5F0, p0, unused)

def IS_DLC_PRESENT(dlcHash: int) -> bool:
    return _ib(0x812595A0644CE1DE, dlcHash)

def GET_EVER_HAD_BAD_PACK_ORDER() -> bool:
    return _ib(0x8D30F648014A92B5)

def GET_EXTRACONTENT_CLOUD_RESULT() -> int:
    return _ii(0x9489659372A81585)

def DLC_CHECK_COMPAT_PACK_CONFIGURATION() -> bool:
    return _ib(0xA213B11DFF526300)

def GET_IS_INITIAL_LOADING_SCREEN_ACTIVE() -> bool:
    return _ib(0xC4637A6D03C24CC3)

def ON_ENTER_SP() -> None:
    _iv(0xD7C10C4A637992C9)

def DLC_CHECK_CLOUD_DATA_CORRECT() -> bool:
    return _ib(0xF2E07819EF1A5289)
