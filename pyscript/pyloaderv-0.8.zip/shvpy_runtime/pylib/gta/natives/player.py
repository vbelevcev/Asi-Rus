"""Auto-generated raw native bindings for namespace PLAYER.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_str as _is, _invoke_vector3 as _ivec


def RESET_LAW_RESPONSE_DELAY_OVERRIDE() -> None:
    _iv(0x0032A6DBA562C518)

def SET_PLAYER_MODEL(player: int, model: int) -> None:
    _iv(0x00A1CADD00108836, player, model)

def SET_WANTED_LEVEL_MULTIPLIER(multiplier: float) -> None:
    _iv(0x020E5F00CDA207BA, multiplier)

def SET_PLAYER_TEAM(player: int, team: int) -> None:
    _iv(0x0299FA38396A4940, player, team)

def IS_PLAYER_TELEPORT_ACTIVE() -> bool:
    return _ib(0x02B15662D7F8886F)

def CHANGE_PLAYER_PED(player: int, ped: int, p2: bool, resetDamage: bool) -> None:
    _iv(0x048189FAC643DEEE, player, ped, p2, resetDamage)

def SET_ALL_RANDOM_PEDS_FLEE(player: int, toggle: bool) -> None:
    _iv(0x056E0FE8534C2949, player, toggle)

def IS_SPECIAL_ABILITY_METER_FULL(player: int, p1: int) -> bool:
    return _ib(0x05A1FE504B7F2587, player, p1)

def SET_PLAYER_RESERVE_PARACHUTE_MODEL_OVERRIDE(player: int, model: int) -> None:
    _iv(0x0764486AEDE748DB, player, model)

def GET_WANTED_LEVEL_RADIUS(player: int) -> float:
    return _if(0x085DEB493BE80812, player)

def ARE_PLAYER_STARS_GREYED_OUT(player: int) -> bool:
    return _ib(0x0A6EB355EE14A2DB, player)

def GET_PLAYER_WANTED_CENTRE_POSITION(player: int) -> 'gta.Vector3':
    return _ivec(0x0C92BA89F1AF26F8, player)

def GET_PLAYER_GROUP(player: int) -> int:
    return _ii(0x0D127585F77030AF, player)

def CLEAR_PLAYER_PARACHUTE_VARIATION_OVERRIDE(player: int) -> None:
    _iv(0x0F4CC924CF8C7B21, player)

def SET_PLAYER_FORCED_AIM(player: int, toggle: bool) -> None:
    _iv(0x0FEE4F80AC44A726, player, toggle)

def CLEAR_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(player: int) -> None:
    _iv(0x10C54E4389C12B42, player)

def SET_PLAYER_PHONE_PALETTE_IDX(player: int, idx: int) -> None:
    _iv(0x11D5F725F0E780E0, player, idx)

def GET_PLAYER_TARGET_ENTITY(player: int, entity: int) -> bool:
    return _ib(0x13EDE1A5DBF797C9, player, entity)

def SET_PLAYER_CLOTH_LOCK_COUNTER(value: int) -> None:
    _iv(0x14D913B777DFF5DA, value)

def SPECIAL_ABILITY_DEACTIVATE_MP(player: int, p1: int) -> None:
    _iv(0x17F7471EACA78290, player, p1)

def ENABLE_SPECIAL_ABILITY(player: int, toggle: bool, p2: int) -> None:
    _iv(0x181EC197DAEFE121, player, toggle, p2)

def GET_PLAYER_SPRINT_TIME_REMAINING(player: int) -> float:
    return _if(0x1885BC9B108B4C99, player)

def RESET_PLAYER_INPUT_GAIT(player: int) -> None:
    _iv(0x19531C47A2ABD691, player)

def GET_ACHIEVEMENT_PROGRESS(achievementId: int) -> int:
    return _ii(0x1C186837D0619335, achievementId)

def SPECIAL_ABILITY_DEPLETE_METER(player: int, p1: bool, p2: int) -> None:
    _iv(0x1D506DBBBC51E64B, player, p1, p2)

def PLAYER_DETACH_VIRTUAL_BOUND() -> None:
    _iv(0x1DD5897E2FA6E7C9)

def SET_PLAYER_MAY_NOT_ENTER_ANY_VEHICLE(player: int) -> None:
    _iv(0x1DE37BBF9E9CC14A, player)

def GET_NUMBER_OF_PLAYERS_IN_TEAM(team: int) -> int:
    return _ii(0x1FC200409F10E6F1, team)

def HAS_PLAYER_DAMAGED_AT_LEAST_ONE_PED(player: int) -> bool:
    return _ib(0x20CE80B0C2BF4ACC, player)

def SET_PLAYER_VEHICLE_WEAPON_TO_NON_HOMING(p0: int) -> None:
    _iv(0x237440E46D918649, p0)

def SET_APPLY_WAYPOINT_OF_PLAYER(player: int, hudColor: int) -> None:
    _iv(0x2382AB11450AE7BA, player, hudColor)

def IS_PLAYER_WANTED_LEVEL_GREATER(player: int, wantedLevel: int) -> bool:
    return _ib(0x238DB2A2C23EE9EF, player, wantedLevel)

def SET_PLAYER_INVINCIBLE(player: int, toggle: bool) -> None:
    _iv(0x239528EACDC3E7DE, player, toggle)

def CLEAR_PLAYER_RESERVE_PARACHUTE_MODEL_OVERRIDE(player: int) -> None:
    _iv(0x290D248E25815AE8, player)

def GET_ENTITY_PLAYER_IS_FREE_AIMING_AT(player: int, entity: int) -> bool:
    return _ib(0x2975C866E6713290, player, entity)

def SET_PLAYER_LOCKON_RANGE_OVERRIDE(player: int, range: float) -> None:
    _iv(0x29961D490E5814FD, player, range)

def RESET_PLAYER_ARREST_STATE(player: int) -> None:
    _iv(0x2D03E13C460760D6, player)

def SET_PLAYER_WEAPON_DEFENSE_MODIFIER(player: int, modifier: float) -> None:
    _iv(0x2D83BC011CA14A3C, player, modifier)

def IS_PLAYER_FREE_AIMING(player: int) -> bool:
    return _ib(0x2E397FD2ECD37C87, player)

def SPECIAL_ABILITY_CHARGE_SMALL(player: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0x2E7B9B683481687D, player, p1, p2, p3)

def SET_DISABLE_AMBIENT_MELEE_MOVE(player: int, toggle: bool) -> None:
    _iv(0x2E8AABFA40A84F8C, player, toggle)

def GET_PLAYER_CURRENT_STEALTH_NOISE(player: int) -> float:
    return _if(0x2F395D61F3A1F877, player)

def ALLOW_EVASION_HUD_IF_DISABLING_HIDDEN_EVASION_THIS_FRAME(player: int, p1: int) -> None:
    _iv(0x2F41A3BAE005E5FA, player, p1)

def SET_PLAYER_SPECTATED_VEHICLE_RADIO_OVERRIDE(p0: bool) -> None:
    _iv(0x2F7CEB6520288061, p0)

def SET_PLAYER_WEAPON_TAKEDOWN_DEFENSE_MODIFIER(player: int, p1: float) -> None:
    _iv(0x31E90B8873A4CD3B, player, p1)

def SET_POLICE_IGNORE_PLAYER(player: int, toggle: bool) -> None:
    _iv(0x32C62AA929C2DA6A, player, toggle)

def SET_PLAYER_WANTED_LEVEL_NO_DROP(player: int, wantedLevel: int, p2: bool) -> None:
    _iv(0x340E61DE7F471565, player, wantedLevel, p2)

def SUPPRESS_WITNESSES_CALLING_POLICE_THIS_FRAME(player: int) -> None:
    _iv(0x36F1B38855F2A8DF, player)

def GET_PLAYER_TEAM(player: int) -> int:
    return _ii(0x37039302F4E0A008, player)

def SPECIAL_ABILITY_RESET(player: int, p1: int) -> None:
    _iv(0x375F0E738F861A94, player, p1)

def GET_PLAYER_RESERVE_PARACHUTE_MODEL_OVERRIDE(player: int) -> int:
    return _ii(0x37FAAA68DCA9D08D, player)

def IS_PLAYER_BEING_ARRESTED(player: int, atArresting: bool) -> bool:
    return _ib(0x388A47C51ABDAC8E, player, atArresting)

def IS_PLAYER_BATTLE_AWARE(player: int) -> bool:
    return _ib(0x38D28DA81E4E9BF9, player)

def SET_PLAYER_WANTED_LEVEL(player: int, wantedLevel: int, disableNoMission: bool) -> None:
    _iv(0x39FF19C64EF7DA5B, player, wantedLevel, disableNoMission)

def IS_PLAYER_FREE_AIMING_AT_ENTITY(player: int, entity: int) -> bool:
    return _ib(0x3C06B5C839B38F7B, player, entity)

def GIVE_PLAYER_RAGDOLL_CONTROL(player: int, toggle: bool) -> None:
    _iv(0x3C49C870E66F0A28, player, toggle)

def SPECIAL_ABILITY_FILL_METER(player: int, p1: bool, p2: int) -> None:
    _iv(0x3DACA8DDC6FD4980, player, p1, p2)

def IS_SPECIAL_ABILITY_ACTIVE(player: int, p1: int) -> bool:
    return _ib(0x3E5F7FC85D854E15, player, p1)

def GET_PLAYER_SPRINT_STAMINA_REMAINING(player: int) -> float:
    return _if(0x3F9F16F8E65A7ED7, player)

def GET_NUMBER_OF_PLAYERS() -> int:
    return _ii(0x407C7F91DDB46C16)

def INT_TO_PLAYERINDEX(value: int) -> int:
    return _ii(0x41BD2A6B006AF756, value)

def IS_PLAYER_DEAD(player: int) -> bool:
    return _ib(0x424D4687FA1E5652, player)

def SET_POLICE_RADAR_BLIPS(toggle: bool) -> None:
    _iv(0x43286D561B72B8BF, toggle)

def GET_PLAYER_PED(player: int) -> int:
    return _ii(0x43A66C31C68491C0, player)

def GET_MAX_WANTED_LEVEL() -> int:
    return _ii(0x462E0DB9B137DC5F)

def SUPPRESS_LOSING_WANTED_LEVEL_IF_HIDDEN_THIS_FRAME(player: int) -> None:
    _iv(0x4669B3ED80F24B4E, player)

def SET_ALL_RANDOM_PEDS_FLEE_THIS_FRAME(player: int) -> None:
    _iv(0x471D2FF42A94B4F2, player)

def SIMULATE_PLAYER_INPUT_GAIT(player: int, amount: float, gaitType: int, speed: float, p4: bool, p5: bool, p6: int) -> None:
    _iv(0x477D5D63E63ECA5D, player, amount, gaitType, speed, p4, p5, p6)

def SET_WANTED_LEVEL_HIDDEN_ESCAPE_TIME(player: int, wantedLevel: int, lossTime: int) -> None:
    _iv(0x49B856B1360C47C7, player, wantedLevel, lossTime)

def IS_PLAYER_CONTROL_ON(player: int) -> bool:
    return _ib(0x49C32D60007AFA47, player)

def SET_PLAYER_MELEE_WEAPON_DAMAGE_MODIFIER(player: int, modifier: float, p2: bool) -> None:
    _iv(0x4A3DC7ECCC321032, player, modifier, p2)

def CLEAR_PLAYER_HAS_DAMAGED_AT_LEAST_ONE_NON_ANIMAL_PED(player: int) -> None:
    _iv(0x4AACB96203D11A31, player)

def SET_PLAYER_VEHICLE_DEFENSE_MODIFIER(player: int, modifier: float) -> None:
    _iv(0x4C60E6EFDAFF2462, player, modifier)

def FORCE_CLEANUP_FOR_ALL_THREADS_WITH_THIS_NAME(name: str, cleanupFlags: int) -> None:
    _iv(0x4C68DDDDF0097317, name, cleanupFlags)

def SET_PLAYER_STEALTH_PERCEPTION_MODIFIER(player: int, value: float) -> None:
    _iv(0x4E9021C1FCDD507A, player, value)

def IS_PLAYER_RIDING_TRAIN(player: int) -> bool:
    return _ib(0x4EC12697209F2196, player)

def PLAYER_ID() -> int:
    return _ii(0x4F8644AF03D0E0D6)

def EXTEND_WORLD_BOUNDARY_FOR_PLAYER(x: float, y: float, z: float) -> None:
    _iv(0x5006D96C995A5827, x, y, z)

def GET_TIME_SINCE_LAST_ARREST() -> int:
    return _ii(0x5063F92F07C2A316)

def GET_PLAYER_PED_SCRIPT_INDEX(player: int) -> int:
    return _ii(0x50FAC3A3E030A6E1, player)

def SET_PLAYER_WANTED_CENTRE_POSITION(player: int, position: int, p2: bool, p3: bool) -> None:
    _iv(0x520E541A97A13354, player, position, p2, p3)

def DISABLE_CAMERA_VIEW_MODE_CYCLE(player: int) -> None:
    _iv(0x5501B7A5CDB79D37, player)

def SET_PLAYER_CAN_DAMAGE_PLAYER(player1: int, player2: int, toggle: bool) -> None:
    _iv(0x55FCC0C390620314, player1, player2, toggle)

def GET_PLAYER_FAKE_WANTED_LEVEL(player: int) -> int:
    return _ii(0x56105E599CAB0EFA, player)

def SET_PLAYER_TARGET_LEVEL(targetLevel: int) -> None:
    _iv(0x5702B917B99DB1CD, targetLevel)

def SET_IGNORE_LOW_PRIORITY_SHOCKING_EVENTS(player: int, toggle: bool) -> None:
    _iv(0x596976B02B6B5700, player, toggle)

def SET_PLAYER_LOCKON(player: int, toggle: bool) -> None:
    _iv(0x5C8B2F450EE4328E, player, toggle)

def GET_TIME_SINCE_PLAYER_HIT_VEHICLE(player: int) -> int:
    return _ii(0x5D35ECF3A81A0EE0, player)

def IS_SYSTEM_UI_BEING_DISPLAYED() -> bool:
    return _ib(0x5D511E3867C87139)

def SET_PLAYER_HEALTH_RECHARGE_MULTIPLIER(player: int, regenRate: float) -> None:
    _iv(0x5DB660B38DD98A31, player, regenRate)

def SET_PLAYER_BLUETOOTH_STATE(player: int, state: bool) -> None:
    _iv(0x5DC40A8869C22141, player, state)

def GET_PLAYER_HAS_RESERVE_PARACHUTE(player: int) -> bool:
    return _ib(0x5DDFE2FF727F3CA3, player)

def DISABLE_PLAYER_FIRING(player: int, toggle: bool) -> None:
    _iv(0x5E6CC07646BBEAB8, player, toggle)

def IS_PLAYER_PLAYING(player: int) -> bool:
    return _ib(0x5E9564D8246B909A, player)

def GET_IS_PLAYER_DRIVING_ON_HIGHWAY(player: int) -> bool:
    return _ib(0x5FC472C501CCADB3, player)

def IS_PLAYER_BLUETOOTH_ENABLE(player: int) -> bool:
    return _ib(0x65FAEE425DE637B0, player)

def IS_REMOTE_PLAYER_IN_NON_CLONED_VEHICLE(player: int) -> bool:
    return _ib(0x690A61A6D13583F6, player)

def SPECIAL_ABILITY_LOCK(playerModel: int, p1: int) -> None:
    _iv(0x6A09D0D590A47D13, playerModel, p1)

def SET_PLAYER_INVINCIBLE_BUT_HAS_REACTIONS(player: int, toggle: bool) -> None:
    _iv(0x6BC97F4F4BB3C04B, player, toggle)

def GET_PLAYER_NAME(player: int) -> str:
    return _is(0x6D0DE6A7B5DA71F8, player)

def SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(player: int, multiplier: float) -> None:
    _iv(0x6DB47AA77FD94E09, player, multiplier)

def IS_PLAYER_VEHICLE_WEAPON_TOGGLED_TO_NON_HOMING(p0: int) -> bool:
    return _ib(0x6E4361FF3E8CD7CA, p0)

def SET_PLAYER_CAN_DO_DRIVE_BY(player: int, toggle: bool) -> None:
    _iv(0x6E8834B52EC20C77, player, toggle)

def GET_PLAYER_PARACHUTE_PACK_TINT_INDEX(player: int, tintIndex: int) -> None:
    _iv(0x6E9C742F340CE5A2, player, tintIndex)

def SET_SCRIPT_FIRE_POSITION(coordX: float, coordY: float, coordZ: float) -> None:
    _iv(0x70A382ADEC069DD3, coordX, coordY, coordZ)

def REMOVE_SCRIPT_FIRE_POSITION() -> None:
    _iv(0x7148E0F43D11F0D9)

def IS_PLAYER_LOGGING_IN_NP() -> bool:
    return _ib(0x74556E1420867ECA)

def SET_PLAYER_CLOTH_PIN_FRAMES(player: int, p1: int) -> None:
    _iv(0x749FADDF97DFE930, player, p1)

def GET_PLAYER_PARACHUTE_TINT_INDEX(player: int, tintIndex: int) -> None:
    _iv(0x75D3F7A1B0D9B145, player, tintIndex)

def SET_PLAYER_FORCED_ZOOM(player: int, toggle: bool) -> None:
    _iv(0x75E7D505F2B15902, player, toggle)

def SET_PLAYER_FORCE_SKIP_AIM_INTRO(player: int, toggle: bool) -> None:
    _iv(0x7651BC64AE59E128, player, toggle)

def SET_PLAYER_MAX_ARMOUR(player: int, value: int) -> None:
    _iv(0x77DFCCF5948B8C71, player, value)

def IS_PLAYER_TARGETTING_ANYTHING(player: int) -> bool:
    return _ib(0x78CFE51896B6B8A4, player)

def IS_PLAYER_TARGETTING_ENTITY(player: int, entity: int) -> bool:
    return _ib(0x7912F7FC4F6264B6, player, entity)

def SET_PLAYER_PREVIOUS_VARIATION_DATA(player: int, p1: int, p2: int, p3: int, p4: int, p5: int) -> None:
    _iv(0x7BAE68775557AE0B, player, p1, p2, p3, p4, p5)

def GET_ARE_CAMERA_CONTROLS_DISABLED() -> bool:
    return _ib(0x7C814D2FB49F40C0)

def SET_PLAYER_HAS_RESERVE_PARACHUTE(player: int) -> None:
    _iv(0x7DDAB28D31FAC363, player)

def IS_WANTED_AND_HAS_BEEN_SEEN_BY_COPS(player: int) -> bool:
    return _ib(0x7E07C78925D5FD96, player)

def SET_PLAYER_MAY_ONLY_ENTER_THIS_VEHICLE(player: int, vehicle: int) -> None:
    _iv(0x8026FF78F208978A, player, vehicle)

def SET_PLAYER_PARACHUTE_SMOKE_TRAIL_COLOR(player: int, r: int, g: int, b: int) -> None:
    _iv(0x8217FD371A4625CF, player, r, g, b)

def SPECIAL_ABILITY_ACTIVATE(player: int, p1: int) -> None:
    _iv(0x821FDC827D6F4090, player, p1)

def RESET_WANTED_LEVEL_HIDDEN_ESCAPE_TIME(player: int) -> None:
    _iv(0x823EC8E82BA45986, player)

def ASSISTED_MOVEMENT_FLUSH_ROUTE() -> None:
    _iv(0x8621390F0CDCFE1F)

def HAS_ACHIEVEMENT_BEEN_PASSED(achievementId: int) -> bool:
    return _ib(0x867365E111A3B6EB, achievementId)

def CLEAR_PLAYER_PARACHUTE_MODEL_OVERRIDE(player: int) -> None:
    _iv(0x8753997EB5F6EE3F, player)

def GET_PLAYER_TARGETING_MODE() -> int:
    return _ii(0x875BDD898B99C8CE)

def IS_PLAYER_SCRIPT_CONTROL_ON(player: int) -> bool:
    return _ib(0x8A876A65283DD7D7, player)

def GET_PLAYER_HEALTH_RECHARGE_MAX_PERCENT(player: int) -> float:
    return _if(0x8BC515BAE4AAF8FF, player)

def SET_PLAYER_CONTROL(player: int, bHasControl: bool, flags: int) -> None:
    _iv(0x8D32347D6D4C40A2, player, bHasControl, flags)

def SET_PLAYER_MAX_EXPLOSIVE_DAMAGE(player: int, p1: float) -> None:
    _iv(0x8D768602ADEF2245, player, p1)

def SET_EVERYONE_IGNORE_PLAYER(player: int, toggle: bool) -> None:
    _iv(0x8EEDA153AD141BA4, player, toggle)

def IS_PLAYER_READY_FOR_CUTSCENE(player: int) -> bool:
    return _ib(0x908CBECC2CAA3690, player)

def ADD_PLAYER_TARGETABLE_ENTITY(player: int, entity: int) -> None:
    _iv(0x9097EB6D4BB9A12A, player, entity)

def GET_PLAYER_MAX_ARMOUR(player: int) -> int:
    return _ii(0x92659B4CE1863CB3, player)

def SET_PLAYER_PARACHUTE_PACK_TINT_INDEX(player: int, tintIndex: int) -> None:
    _iv(0x93B0FB27C9A04060, player, tintIndex)

def DISPLAY_SYSTEM_SIGNIN_UI(p0: bool) -> None:
    _iv(0x94DD7888C10A979E, p0)

def IS_PLAYER_CLIMBING(player: int) -> bool:
    return _ib(0x95E8F73DC65EFB9C, player)

def SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(player: int, model: int) -> None:
    _iv(0x977DB4641F6FC3DB, player, model)

def GET_CAUSE_OF_MOST_RECENT_FORCE_CLEANUP() -> int:
    return _ii(0x9A41CF4674A12272)

def SUPPRESS_CRIME_THIS_FRAME(player: int, crimeType: int) -> None:
    _iv(0x9A987297ED8BD838, player, crimeType)

def SET_WANTED_LEVEL_DIFFICULTY(player: int, difficulty: float) -> None:
    _iv(0x9B0BB33B04405E7A, player, difficulty)

def SPECIAL_ABILITY_DEACTIVATE_FAST(player: int, p1: int) -> None:
    _iv(0x9CB5CE07A3968D5A, player, p1)

def INT_TO_PARTICIPANTINDEX(value: int) -> int:
    return _ii(0x9EC6603812C24710, value)

def INCREASE_PLAYER_JUMP_SUPPRESSION_RANGE(player: int) -> None:
    _iv(0x9EDD76E87D5D51BA, player)

def REMOVE_PLAYER_TARGETABLE_ENTITY(player: int, entity: int) -> None:
    _iv(0x9F260BFB59ADBCA3, player, entity)

def SET_AUTO_GIVE_PARACHUTE_WHEN_ENTER_PLANE(player: int, toggle: bool) -> None:
    _iv(0x9F343285A00B4BB6, player, toggle)

def SET_PLAYER_CLOTH_PACKAGE_INDEX(index: int) -> None:
    _iv(0x9F7BBA2EA6372500, index)

def SET_PLAYER_SPRINT(player: int, toggle: bool) -> None:
    _iv(0xA01B8075D8B92DF4, player, toggle)

def SPECIAL_ABILITY_CHARGE_NORMALIZED(player: int, normalizedValue: float, p2: bool, p3: int) -> None:
    _iv(0xA0696A65F009EE18, player, normalizedValue, p2, p3)

def SET_PLAYER_UNDERWATER_BREATH_PERCENT_REMAINING(player: int, time: float) -> float:
    return _if(0xA0D3E4F7AAFB7E78, player, time)

def GET_PLAYER_UNDERWATER_TIME_REMAINING(player: int) -> float:
    return _if(0xA1FCF8E6AF40B731, player)

def RESTORE_PLAYER_STAMINA(player: int, p1: float) -> None:
    _iv(0xA352C1B864CAFD33, player, p1)

def SET_PLAYER_PARACHUTE_TINT_INDEX(player: int, tintIndex: int) -> None:
    _iv(0xA3D0E54541D9A5E5, player, tintIndex)

def SET_SPECIAL_ABILITY_MULTIPLIER(multiplier: float) -> None:
    _iv(0xA49C426ED0CA4AB7, multiplier)

def SET_PLAYER_VEHICLE_DAMAGE_MODIFIER(player: int, modifier: float) -> None:
    _iv(0xA50E117CDDF82F0C, player, modifier)

def GET_PLAYER_INDEX() -> int:
    return _ii(0xA5EDC40EF369B48D)

def RESET_PLAYER_STAMINA(player: int) -> None:
    _iv(0xA6F312FCCE9C1DFE, player)

def GET_WANTED_LEVEL_TIME_TO_ESCAPE() -> int:
    return _ii(0xA72200F51875FEA4)

def SET_SWIM_MULTIPLIER_FOR_PLAYER(player: int, multiplier: float) -> None:
    _iv(0xA91C6F0FF7D16A13, player, multiplier)

def SET_MAX_WANTED_LEVEL(maxWantedLevel: int) -> None:
    _iv(0xAA5F02DB48D704B9, maxWantedLevel)

def START_PLAYER_TELEPORT(player: int, x: float, y: float, z: float, heading: float, p5: bool, findCollisionLand: bool, p7: bool) -> None:
    _iv(0xAD15F075A4DA0FDE, player, x, y, z, heading, p5, findCollisionLand, p7)

def FORCE_START_HIDDEN_EVASION(player: int) -> None:
    _iv(0xAD73CE5A09E42D12, player)

def SET_PLAYER_MELEE_WEAPON_DEFENSE_MODIFIER(player: int, modifier: float) -> None:
    _iv(0xAE540335B4ABC4E2, player, modifier)

def ASSISTED_MOVEMENT_CLOSE_ROUTE() -> None:
    _iv(0xAEBF081FFC0A0E5E)

def SET_PLAYER_RESERVE_PARACHUTE_TINT_INDEX(player: int, index: int) -> None:
    _iv(0xAF04C87F5DC1DF38, player, index)

def ARE_PLAYER_FLASHING_STARS_ABOUT_TO_DROP(player: int) -> bool:
    return _ib(0xAFAF86043E5874E9, player)

def SET_PLAYER_TARGETING_MODE(targetMode: int) -> None:
    _iv(0xB1906895227793F3, targetMode)

def IS_SPECIAL_ABILITY_ENABLED(player: int, p1: int) -> bool:
    return _ib(0xB1D200FE26AEF3CB, player, p1)

def SET_SPECIAL_ABILITY_MP(player: int, p1: int, p2: int) -> None:
    _iv(0xB214D570EAD7F81A, player, p1, p2)

def SET_PLAYER_SNEAKING_NOISE_MULTIPLIER(player: int, multiplier: float) -> None:
    _iv(0xB2C1A29588A9F47C, player, multiplier)

def CLEAR_PLAYER_WANTED_LEVEL(player: int) -> None:
    _iv(0xB302540597885499, player)

def SET_LAW_RESPONSE_DELAY_OVERRIDE(p0: float) -> None:
    _iv(0xB45EFF719D8427A6, p0)

def GET_PLAYERS_LAST_VEHICLE() -> int:
    return _ii(0xB6997A7EB3F5C8C0)

def GET_PLAYER_INVINCIBLE(player: int) -> bool:
    return _ib(0xB721981B2B939E07, player)

def SPECIAL_ABILITY_CHARGE_ABSOLUTE(player: int, p1: int, p2: bool, p3: int) -> None:
    _iv(0xB7B0870EB531D08D, player, p1, p2, p3)

def DISABLE_PLAYER_THROW_GRENADE_WHILE_USING_GUN() -> None:
    _iv(0xB885852C39CC265D)

def GET_IS_USING_FPS_THIRD_PERSON_COVER() -> bool:
    return _ib(0xB9CF1F793A9F1BF1)

def RESET_WANTED_LEVEL_DIFFICULTY(player: int) -> None:
    _iv(0xB9D0DD990DC141DD, player)

def GET_PLAYER_RECEIVED_BATTLE_EVENT_RECENTLY(player: int, p1: int, p2: bool) -> bool:
    return _ib(0xBC0753C9CA14B506, player, p1, p2)

def FORCE_CLEANUP(cleanupFlags: int) -> None:
    _iv(0xBC8983F38F78ED51, cleanupFlags)

def UPDATE_WANTED_POSITION_THIS_FRAME(player: int) -> None:
    _iv(0xBC9490CA15AEA8FB, player)

def DISABLE_PLAYER_HEALTH_RECHARGE(player: int) -> None:
    _iv(0xBCB06442F7E52666, player)

def SET_PLAYER_WEAPON_MINIGUN_DEFENSE_MODIFIER(player: int, modifier: float) -> None:
    _iv(0xBCFDE9EDE4CF27DC, player, modifier)

def GIVE_ACHIEVEMENT_TO_PLAYER(achievementId: int) -> bool:
    return _ib(0xBEC7076D64130195, achievementId)

def START_FIRING_AMNESTY(duration: int) -> None:
    _iv(0xBF9BD71691857E48, duration)

def DISABLE_PLAYER_VEHICLE_REWARDS(player: int) -> None:
    _iv(0xC142BE3BB9CE125F, player)

def GET_PLAYER_PARACHUTE_MODEL_OVERRIDE(player: int) -> int:
    return _ii(0xC219887CA3E65C41, player)

def SET_ACHIEVEMENT_PROGRESS(achievementId: int, progress: int) -> bool:
    return _ib(0xC2AFFFDABBDC2C5C, achievementId, progress)

def SET_ALL_NEUTRAL_RANDOM_PEDS_FLEE_THIS_FRAME(player: int) -> None:
    _iv(0xC3376F42B1FACCC6, player)

def SET_PLAYER_HEALTH_RECHARGE_MAX_PERCENT(player: int, limit: float) -> None:
    _iv(0xC388A0F065F5BC34, player, limit)

def STOP_PLAYER_TELEPORT() -> None:
    _iv(0xC449EDED9D73009C)

def SET_PLAYER_SIMULATE_AIMING(player: int, toggle: bool) -> None:
    _iv(0xC54C95DA968EC5B5, player, toggle)

def IS_SPECIAL_ABILITY_UNLOCKED(playerModel: int) -> bool:
    return _ib(0xC6017F6A6CDFA694, playerModel)

def GET_TIME_SINCE_LAST_DEATH() -> int:
    return _ii(0xC7034807558DDFCA)

def HAS_FORCE_CLEANUP_OCCURRED(cleanupFlags: int) -> bool:
    return _ib(0xC968670BFACE42D9, cleanupFlags)

def SPECIAL_ABILITY_CHARGE_ON_MISSION_FAILED(player: int, p1: int) -> None:
    _iv(0xC9A763D8FE87436A, player, p1)

def SET_AIR_DRAG_MULTIPLIER_FOR_PLAYERS_VEHICLE(player: int, multiplier: float) -> None:
    _iv(0xCA7DC8329F0A1E9E, player, multiplier)

def SET_PLAYER_CAN_COLLECT_DROPPED_MONEY(player: int, p1: bool) -> None:
    _iv(0xCAC57395B151135F, player, p1)

def GET_IS_USING_HOOD_CAMERA() -> bool:
    return _ib(0xCB645E85E97EA48B)

def SET_PLAYER_WEAPON_DAMAGE_MODIFIER(player: int, modifier: float) -> None:
    _iv(0xCE07B9F7817AADA3, player, modifier)

def SET_AUTO_GIVE_SCUBA_GEAR_WHEN_EXIT_VEHICLE(player: int, toggle: bool) -> None:
    _iv(0xD2B315B6689D537D, player, toggle)

def SET_PLAYER_CAN_USE_COVER(player: int, toggle: bool) -> None:
    _iv(0xD465A8599DFF6814, player, toggle)

def GET_TIME_SINCE_PLAYER_DROVE_ON_PAVEMENT(player: int) -> int:
    return _ii(0xD559D2BE9E37853B, player)

def HAS_PLAYER_LEFT_THE_WORLD(player: int) -> bool:
    return _ib(0xD55DDFB47991A294, player)

def GET_PLAYER_RESERVE_PARACHUTE_TINT_INDEX(player: int, index: int) -> None:
    _iv(0xD5A016BC3C09CF40, player, index)

def SET_PLAYER_CAN_BE_HASSLED_BY_GANGS(player: int, toggle: bool) -> None:
    _iv(0xD5E460AD7020A246, player, toggle)

def SPECIAL_ABILITY_DEACTIVATE(player: int, p1: int) -> None:
    _iv(0xD6A953C6D1492057, player, p1)

def HAS_PLAYER_BEEN_SPOTTED_IN_STOLEN_VEHICLE(player: int) -> bool:
    return _ib(0xD705740BB0A1CF4C, player)

def PLAYER_PED_ID() -> int:
    return _ii(0xD80958FC74E988A6)

def SET_PLAYER_EXPLOSIVE_DAMAGE_MODIFIER(player: int, p1: int) -> None:
    _iv(0xD821056B9ACF8052, player, p1)

def SET_PLAYER_PARACHUTE_VARIATION_OVERRIDE(player: int, p1: int, p2: int, p3: int, p4: bool) -> None:
    _iv(0xD9284A8C0D48352C, player, p1, p2, p3, p4)

def RESET_WORLD_BOUNDARY_FOR_PLAYER() -> None:
    _iv(0xDA1DF03D5A315F4E)

def SET_DISPATCH_COPS_FOR_PLAYER(player: int, toggle: bool) -> None:
    _iv(0xDB172424876553F4, player, toggle)

def GET_TIME_SINCE_PLAYER_DROVE_AGAINST_TRAFFIC(player: int) -> int:
    return _ii(0xDB89591E290D9182, player)

def SET_PLAYER_NOISE_MULTIPLIER(player: int, multiplier: float) -> None:
    _iv(0xDB89EF50FF25FCE9, player, multiplier)

def REPORT_POLICE_SPOTTED_PLAYER(player: int) -> None:
    _iv(0xDC64D2C53493ED12, player)

def SET_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(player: int, model: int) -> None:
    _iv(0xDC80A4C2F18A2B64, player, model)

def GET_PLAYER_DEBUG_INVINCIBLE(player: int) -> bool:
    return _ib(0xDCC07526B8EC45AF, player)

def IS_PLAYER_FREE_FOR_AMBIENT_TASK(player: int) -> bool:
    return _ib(0xDCCFD3F106C36AB4, player)

def GET_IS_MOPPING_AREA_FREE_IN_FRONT_OF_PLAYER(player: int, p1: float) -> bool:
    return _ib(0xDD2620B7B9D16FF1, player, p1)

def SET_ALL_NEUTRAL_RANDOM_PEDS_FLEE(player: int, toggle: bool) -> None:
    _iv(0xDE45D1A1EF45EE61, player, toggle)

def CAN_PLAYER_START_MISSION(player: int) -> bool:
    return _ib(0xDE7465A27D403C06, player)

def SET_PLAYER_WANTED_LEVEL_NOW(player: int, p1: bool) -> None:
    _iv(0xE0A7D1E497FFCD6F, player, p1)

def UPDATE_PLAYER_TELEPORT(player: int) -> bool:
    return _ib(0xE23D5873C2394C61, player)

def GET_PLAYER_WANTED_LEVEL(player: int) -> int:
    return _ii(0xE28E54788CE8F12D, player)

def GET_TIME_SINCE_PLAYER_HIT_PED(player: int) -> int:
    return _ii(0xE36A25322DC35F42, player)

def HAS_PLAYER_DAMAGED_AT_LEAST_ONE_NON_ANIMAL_PED(player: int) -> bool:
    return _ib(0xE4B90F367BD81752, player)

def GET_PLAYER_RGB_COLOUR(player: int, r: int, g: int, b: int) -> None:
    _iv(0xE902EF951DCE178F, player, r, g, b)

def REPORT_CRIME(player: int, crimeType: int, wantedLvlThresh: int) -> None:
    _iv(0xE9B09589827545E7, player, crimeType, wantedLvlThresh)

def SPECIAL_ABILITY_CHARGE_CONTINUOUS(player: int, p1: int, p2: int) -> None:
    _iv(0xED481732DFF7E997, player, p1, p2)

def PLAYER_ATTACH_VIRTUAL_BOUND(p0: float, p1: float, p2: float, p3: float, p4: float, p5: float, p6: float, p7: float) -> None:
    _iv(0xED51733DC73AED51, p0, p1, p2, p3, p4, p5, p6, p7)

def SET_PLAYER_HOMING_DISABLED_FOR_ALL_VEHICLE_WEAPONS(p0: int, p1: int) -> None:
    _iv(0xEE4EBDD2593BA844, p0, p1)

def NETWORK_PLAYER_ID_TO_INT() -> int:
    return _ii(0xEE68096F9F37341E)

def GET_PLAYER_PARACHUTE_SMOKE_TRAIL_COLOR(player: int, r: int, g: int, b: int) -> None:
    _iv(0xEF56DBABD3CD4887, player, r, g, b)

def SET_PLAYER_FALL_DISTANCE_TO_TRIGGER_RAGDOLL_OVERRIDE(player: int, p1: float) -> None:
    _iv(0xEFD79FA81DFBA9CB, player, p1)

def CLEAR_PLAYER_HAS_DAMAGED_AT_LEAST_ONE_PED(player: int) -> None:
    _iv(0xF0B67A4DE6AB5F98, player)

def GET_IS_PLAYER_DRIVING_WRECKLESS(player: int, p1: int) -> bool:
    return _ib(0xF10B44FD479D69F3, player, p1)

def SPECIAL_ABILITY_CHARGE_MEDIUM(player: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0xF113E3AA9BC54613, player, p1, p2, p3)

def SPECIAL_ABILITY_UNLOCK(playerModel: int, p1: int) -> None:
    _iv(0xF145F3BE2EFA9A3B, playerModel, p1)

def IS_PLAYER_ONLINE() -> bool:
    return _ib(0xF25D331DC2627BBC)

def CAN_PED_HEAR_PLAYER(player: int, ped: int) -> bool:
    return _ib(0xF297383AA91DCA29, player, ped)

def REMOVE_PLAYER_HELMET(player: int, p2: bool) -> None:
    _iv(0xF3AC26D3CC576528, player, p2)

def SET_PLAYER_CAN_LEAVE_PARACHUTE_SMOKE_TRAIL(player: int, enabled: bool) -> None:
    _iv(0xF401B182DBA8AF53, player, enabled)

def SPECIAL_ABILITY_CHARGE_LARGE(player: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0xF733F45FA4497D93, player, p1, p2, p3)

def FORCE_CLEANUP_FOR_THREAD_WITH_THIS_ID(id: int, cleanupFlags: int) -> None:
    _iv(0xF745B37630DF176B, id, cleanupFlags)

def IS_PLAYER_PRESSING_HORN(player: int) -> bool:
    return _ib(0xFA1E2BF8B10598F9, player)

def SET_LAW_PEDS_CAN_ATTACK_NON_WANTED_PLAYER_THIS_FRAME(player: int) -> None:
    _iv(0xFAC75988A7D078D3, player)

def GET_WANTED_LEVEL_THRESHOLD(wantedLevel: int) -> int:
    return _ii(0xFDD179EAF45B556C, wantedLevel)

def SET_PLAYER_LEAVE_PED_BEHIND(player: int, toggle: bool) -> None:
    _iv(0xFF300C7649724A0B, player, toggle)

def UPDATE_SPECIAL_ABILITY_FROM_STAT(player: int, p1: int) -> None:
    _iv(0xFFEE8FA29AB9A18E, player, p1)
