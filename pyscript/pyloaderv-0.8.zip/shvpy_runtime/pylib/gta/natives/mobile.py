"""Auto-generated raw native bindings for namespace MOBILE.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib


def CELL_CAM_ACTIVATE_SELFIE_MODE(toggle: bool) -> None:
    _iv(0x015C49A93E3E086E, toggle)

def CELL_CAM_SET_SELFIE_MODE_ROLL_OFFSET(roll: float) -> None:
    _iv(0x15E69E2802C24B8D, roll)

def CELL_CAM_SET_SELFIE_MODE_SIDE_OFFSET_SCALING(p0: float) -> None:
    _iv(0x1B0B4AEED5B9B41C, p0)

def GET_MOBILE_PHONE_ROTATION(rotation: int, p1: int) -> None:
    _iv(0x1CEFB61F193070AE, rotation, p1)

def CELL_CAM_SET_SELFIE_MODE_VERT_PAN_OFFSET(vertPan: float) -> None:
    _iv(0x3117D84EFA60F77B, vertPan)

def SET_MOBILE_PHONE_DOF_STATE(toggle: bool) -> None:
    _iv(0x375A706A5C2FD084, toggle)

def DESTROY_MOBILE_PHONE() -> None:
    _iv(0x3BC861DF703E5097)

def CELL_CAM_IS_CHAR_VISIBLE_NO_FACE_CHECK(entity: int) -> bool:
    return _ib(0x439E9BC95B7E7FBE, entity)

def CELL_HORIZONTAL_MODE_TOGGLE(toggle: bool) -> None:
    _iv(0x44E44169EF70138E, toggle)

def CELL_CAM_SET_SELFIE_MODE_HEAD_PITCH_OFFSET(pitch: float) -> None:
    _iv(0x466DA42C89865553, pitch)

def CELL_CAM_SET_SELFIE_MODE_HORZ_PAN_OFFSET(horizontalPan: float) -> None:
    _iv(0x53F4892D18EC90A4, horizontalPan)

def GET_MOBILE_PHONE_POSITION(position: int) -> None:
    _iv(0x584FDFDA48805B86, position)

def SET_MOBILE_PHONE_POSITION(posX: float, posY: float, posZ: float) -> None:
    _iv(0x693A5C6D6734085B, posX, posY, posZ)

def CELL_SET_INPUT(direction: int) -> None:
    _iv(0x95C9E72F3D7DEC9B, direction)

def CELL_CAM_ACTIVATE_SHALLOW_DOF_MODE(toggle: bool) -> None:
    _iv(0xA2CCBE62CD4C91A4, toggle)

def CREATE_MOBILE_PHONE(phoneType: int) -> None:
    _iv(0xA4E8E696C532FBC7, phoneType)

def CELL_CAM_SET_SELFIE_MODE_DISTANCE_SCALING(distanceScaling: float) -> None:
    _iv(0xAC2890471901861C, distanceScaling)

def GET_MOBILE_PHONE_RENDER_ID(renderId: int) -> None:
    _iv(0xB4A53E05F68B6FA1, renderId)

def SET_MOBILE_PHONE_ROTATION(rotX: float, rotY: float, rotZ: float, p3: int) -> None:
    _iv(0xBB779C0CA917E865, rotX, rotY, rotZ, p3)

def CAN_PHONE_BE_SEEN_ON_SCREEN() -> bool:
    return _ib(0xC4E2813898C97A4B)

def SET_MOBILE_PHONE_SCALE(scale: float) -> None:
    _iv(0xCBDD322A73D6D932, scale)

def CELL_CAM_SET_SELFIE_MODE_HEAD_YAW_OFFSET(yaw: float) -> None:
    _iv(0xD6ADE981781FCA09, yaw)

def CELL_CAM_SET_SELFIE_MODE_HEAD_ROLL_OFFSET(roll: float) -> None:
    _iv(0xF1E22DC13F5EEBAD, roll)

def SCRIPT_IS_MOVING_MOBILE_PHONE_OFFSCREEN(toggle: bool) -> None:
    _iv(0xF511F759238A5122, toggle)

def CELL_CAM_ACTIVATE(p0: bool, p1: bool) -> None:
    _iv(0xFDE8F069C542D126, p0, p1)
