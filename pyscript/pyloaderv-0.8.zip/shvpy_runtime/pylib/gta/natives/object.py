"""Auto-generated raw native bindings for namespace OBJECT.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_vector3 as _ivec


def PLAY_OBJECT_AUTO_START_ANIM(p0: int) -> None:
    _iv(0x006E4B040ED37EC3, p0)

def IS_PLAYER_ENTIRELY_INSIDE_GARAGE(garageHash: int, player: int, p2: float, p3: int) -> bool:
    return _ib(0x024A60DEB0EA69F0, garageHash, player, p2, p3)

def IS_OBJECT_A_PORTABLE_PICKUP(object: int) -> bool:
    return _ib(0x0378C08504160D0D, object)

def DOOR_SYSTEM_SET_AUTOMATIC_RATE(doorHash: int, rate: float, requestDoor: bool, forceUpdate: bool) -> None:
    _iv(0x03C27E13B42A0E82, doorHash, rate, requestDoor, forceUpdate)

def CREATE_MONEY_PICKUPS(x: float, y: float, z: float, value: int, amount: int, model: int) -> None:
    _iv(0x0589B5E791CE9B2B, x, y, z, value, amount, model)

def SET_PICKUP_GLOW_OFFSET(pickup: int, p1: float) -> None:
    _iv(0x0596843B34B95CE5, pickup, p1)

def _SET_PICKUP_GLOW_DISABLED(pickup: int, toggle: bool) -> None:
    _iv(0x08BD8BA5BDE2C2FA, pickup, toggle)

def GET_WEAPON_TYPE_FROM_PICKUP_TYPE(pickupHash: int) -> int:
    return _ii(0x08F96CA6C551AD51, pickupHash)

def SET_MAX_NUM_PORTABLE_PICKUPS_CARRIED_BY_PLAYER(modelHash: int, number: int) -> None:
    _iv(0x0BF3B3BD47D79C08, modelHash, number)

def IS_PICKUP_WEAPON_OBJECT_VALID(object: int) -> bool:
    return _ib(0x11D1E53A726891FE, object)

def CREATE_NON_NETWORKED_PORTABLE_PICKUP(pickupHash: int, x: float, y: float, z: float, placeOnGround: bool, modelHash: int) -> int:
    return _ii(0x125494B98A21AAF7, pickupHash, x, y, z, placeOnGround, modelHash)

def DOOR_SYSTEM_GET_DOOR_STATE(doorHash: int) -> int:
    return _ii(0x160AA1B32F6139B8, doorHash)

def GET_OFFSET_FROM_COORD_AND_HEADING_IN_WORLD_COORDS(xPos: float, yPos: float, zPos: float, heading: float, xOffset: float, yOffset: float, zOffset: float) -> 'gta.Vector3':
    return _ivec(0x163E252DE035A133, xPos, yPos, zPos, heading, xOffset, yOffset, zOffset)

def GET_COORDS_AND_ROTATION_OF_CLOSEST_OBJECT_OF_TYPE(x: float, y: float, z: float, radius: float, modelHash: int, outPosition: int, outRotation: int, rotationOrder: int) -> bool:
    return _ib(0x163F8B586BC95F2A, x, y, z, radius, modelHash, outPosition, outRotation, rotationOrder)

def IS_PLAYER_PARTIALLY_INSIDE_GARAGE(garageHash: int, player: int, p2: int) -> bool:
    return _ib(0x1761DC5D8471CBAA, garageHash, player, p2)

def CLEAR_OBJECTS_INSIDE_GARAGE(garageHash: int, vehicles: bool, peds: bool, objects: bool, isNetwork: bool) -> None:
    _iv(0x190428512B240692, garageHash, vehicles, peds, objects, isNetwork)

def SET_WEAPON_IMPACTS_APPLY_GREATER_FORCE(object: int, p1: bool) -> None:
    _iv(0x1A6CBB06E2D0D79D, object, p1)

def SET_PICKUP_UNCOLLECTABLE(pickup: int, toggle: bool) -> None:
    _iv(0x1C1B69FAE509BA97, pickup, toggle)

def SET_IS_OBJECT_ARTICULATED(object: int, toggle: bool) -> None:
    _iv(0x1C57C94A6446492A, object, toggle)

def BLOCK_PLAYERS_FOR_AMBIENT_PICKUP(p0: int, p1: int) -> None:
    _iv(0x1E3F1B1B891A2AAA, p0, p1)

def GET_PICKUP_COORDS(pickup: int) -> 'gta.Vector3':
    return _ivec(0x225B8B35C88029B3, pickup)

def GET_HAS_OBJECT_BEEN_COMPLETELY_DESTROYED(p0: int) -> bool:
    return _ib(0x2542269291C6AC84, p0)

def GET_RAYFIRE_MAP_OBJECT_ANIM_PHASE(object: int) -> float:
    return _if(0x260EE4FDBDF4DB01, object)

def SET_PICKUP_OBJECT_GLOW_WHEN_UNCOLLECTABLE(pickup: int, toggle: bool) -> None:
    _iv(0x27F248C3FEBFAAD3, pickup, toggle)

def REMOVE_ALL_PICKUPS_OF_TYPE(pickupHash: int) -> None:
    _iv(0x27F9D613092159CF, pickupHash)

def IS_POINT_IN_ANGLED_AREA(xPos: float, yPos: float, zPos: float, x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, width: float, debug: bool, includeZ: bool) -> bool:
    return _ib(0x2A70BAE8883E4C81, xPos, yPos, zPos, x1, y1, z1, x2, y2, z2, width, debug, includeZ)

def CREATE_PORTABLE_PICKUP(pickupHash: int, x: float, y: float, z: float, placeOnGround: bool, modelHash: int) -> int:
    return _ii(0x2EAF1FDB2FB55698, pickupHash, x, y, z, placeOnGround, modelHash)

def SLIDE_OBJECT(object: int, toX: float, toY: float, toZ: float, speedX: float, speedY: float, speedZ: float, collision: bool) -> bool:
    return _ib(0x2FDFF4107B8C1147, object, toX, toY, toZ, speedX, speedY, speedZ, collision)

def SET_PROP_TINT_INDEX(p0: int, p1: int) -> None:
    _iv(0x31574B1B41268673, p0, p1)

def SET_PICKUP_GENERATION_RANGE_MULTIPLIER(multiplier: float) -> None:
    _iv(0x318516E02DE3ECE2, multiplier)

def SET_ONLY_ALLOW_AMMO_COLLECTION_WHEN_LOW(p0: bool) -> None:
    _iv(0x31F924B53EADDF65, p0)

def REMOVE_PICKUP(pickup: int) -> None:
    _iv(0x3288D8ACAECD2AB2, pickup)

def RENDER_FAKE_PICKUP_GLOW(x: float, y: float, z: float, colorIndex: int) -> None:
    _iv(0x3430676B11CDF21D, x, y, z, colorIndex)

def IS_OBJECT_ENTIRELY_INSIDE_GARAGE(garageHash: int, entity: int, p2: float, p3: int) -> bool:
    return _ib(0x372EF6699146A1E4, garageHash, entity, p2, p3)

def FORCE_PICKUP_ROTATE_FACE_UP() -> None:
    _iv(0x394CD08E31313C28)

def IS_ANY_OBJECT_NEAR_POINT(x: float, y: float, z: float, range: float, p4: bool) -> bool:
    return _ib(0x397DC58FF00298D1, x, y, z, range, p4)

def SET_PICKUP_OBJECT_ARROW_MARKER(pickup: int, toggle: bool) -> None:
    _iv(0x39A5FB7EAF150840, pickup, toggle)

def SET_OBJECT_IS_VISIBLE_IN_MIRRORS(object: int, toggle: bool) -> None:
    _iv(0x3B2FD68DB5F8331C, object, toggle)

def GET_IS_ARTICULATED_JOINT_AT_MAX_ANGLE(p0: int, p1: int) -> bool:
    return _ib(0x3BD770D281982DB5, p0, p1)

def SET_PICKUP_HIDDEN_WHEN_UNCOLLECTABLE(pickup: int, toggle: bool) -> None:
    _iv(0x3ED2B83AB2E82799, pickup, toggle)

def SET_ACTIVATE_OBJECT_PHYSICS_AS_SOON_AS_IT_IS_UNFROZEN(object: int, toggle: bool) -> None:
    _iv(0x406137F8EF90EAF5, object, toggle)

def GET_IS_ARTICULATED_JOINT_AT_MIN_ANGLE(object: int, p1: int) -> bool:
    return _ib(0x43C677F1E1158005, object, p1)

def HAS_CLOSEST_OBJECT_OF_TYPE_BEEN_COMPLETELY_DESTROYED(x: float, y: float, z: float, radius: float, modelHash: int, p5: bool) -> bool:
    return _ib(0x46494A2475701343, x, y, z, radius, modelHash, p5)

def REMOVE_DOOR_FROM_SYSTEM(doorHash: int, p1: int) -> None:
    _iv(0x464D8E1427156FE4, doorHash, p1)

def SET_PORTABLE_PICKUP_PERSIST(pickup: int, toggle: bool) -> None:
    _iv(0x46F3ADD1E2D5BAF2, pickup, toggle)

def REMOVE_OBJECT_HIGH_DETAIL_MODEL(object: int) -> None:
    _iv(0x4A39DB43E47CF3AA, object)

def DOOR_SYSTEM_GET_DOOR_PENDING_STATE(doorHash: int) -> int:
    return _ii(0x4BC2854478F3A749, doorHash)

def FORCE_ACTIVATE_PHYSICS_ON_UNFIXED_PICKUP(pickup: int, toggle: bool) -> None:
    _iv(0x4C134B4DF76025D0, pickup, toggle)

def SET_OBJECT_ALLOW_LOW_LOD_BUOYANCY(object: int, toggle: bool) -> None:
    _iv(0x4D89D607CB3DD1D2, object, toggle)

def GET_PICKUP_OBJECT(pickup: int) -> int:
    return _ii(0x5099BC55630B25AE, pickup)

def CREATE_OBJECT(modelHash: int, x: float, y: float, z: float, isNetwork: bool, bScriptHostObj: bool, dynamic: bool) -> int:
    return _ii(0x509D5878EB39E842, modelHash, x, y, z, isNetwork, bScriptHostObj, dynamic)

def DOES_RAYFIRE_MAP_OBJECT_EXIST(object: int) -> bool:
    return _ib(0x52AF537A0C5B8AAD, object)

def DELETE_OBJECT(object: int) -> None:
    _iv(0x539E0AE3E6634B9F, object)

def SET_TEAM_PICKUP_OBJECT(object: int, p1: int, p2: bool) -> None:
    _iv(0x53E0DF1A2A3CF0CA, object, p1, p2)

def DOOR_SYSTEM_FIND_EXISTING_DOOR(x: float, y: float, z: float, modelHash: int, outDoorHash: int) -> bool:
    return _ib(0x589F80B325CC82C5, x, y, z, modelHash, outDoorHash)

def PLACE_OBJECT_ON_GROUND_PROPERLY(object: int) -> bool:
    return _ib(0x58A850EAEE20FAA3, object)

def SET_STATE_OF_RAYFIRE_MAP_OBJECT(object: int, state: int) -> None:
    _iv(0x5C29F698D404C5E1, object, state)

def FORCE_PORTABLE_PICKUP_LAST_ACCESSIBLE_POSITION_SETTING(object: int) -> None:
    _iv(0x5CE2E45A5CE2E45A, object)

def CONVERT_OLD_PICKUP_TYPE_TO_NEW(pickupHash: int) -> int:
    return _ii(0x5EAAD83F8CFB4575, pickupHash)

def SET_PROP_LIGHT_COLOR(object: int, p1: bool, r: int, g: int, b: int) -> bool:
    return _ib(0x5F048334B4A4E774, object, p1, r, g, b)

def SET_PLAYER_PERMITTED_TO_COLLECT_PICKUPS_OF_TYPE(player: int, pickupHash: int, toggle: bool) -> None:
    _iv(0x616093EC6B139DD9, player, pickupHash, toggle)

def SET_OBJECT_GLOW_IN_SAME_TEAM(pickup: int) -> None:
    _iv(0x62454A641B41F3C5, pickup)

def SET_PROJECTILES_SHOULD_EXPLODE_ON_CONTACT(entity: int, p1: int) -> None:
    _iv(0x63ECF581BC70E363, entity, p1)

def ALLOW_PORTABLE_PICKUP_TO_MIGRATE_TO_NON_PARTICIPANTS(pickup: int, toggle: bool) -> None:
    _iv(0x641F272B52E2F0F8, pickup, toggle)

def DOOR_SYSTEM_GET_OPEN_RATIO(doorHash: int) -> float:
    return _if(0x65499865FCA6E5EC, doorHash)

def DISABLE_TIDYING_UP_IN_GARAGE(id: int, toggle: bool) -> None:
    _iv(0x659F9D71F52843F8, id, toggle)

def CLOSE_SAFEHOUSE_GARAGES() -> None:
    _iv(0x66A49D021870FE88)

def CREATE_AMBIENT_PICKUP(pickupHash: int, posX: float, posY: float, posZ: float, flags: int, value: int, modelHash: int, p7: bool, p8: bool) -> int:
    return _ii(0x673966A0C0FD7171, pickupHash, posX, posY, posZ, flags, value, modelHash, p7, p8)

def IS_ANY_ENTITY_ENTIRELY_INSIDE_GARAGE(garageHash: int, p1: bool, p2: bool, p3: bool, p4: int) -> bool:
    return _ib(0x673ED815D6E323B7, garageHash, p1, p2, p3, p4)

def DOOR_SYSTEM_SET_DOOR_STATE(doorHash: int, state: int, requestDoor: bool, forceUpdate: bool) -> None:
    _iv(0x6BAB9442830C7F53, doorHash, state, requestDoor, forceUpdate)

def GET_SAFE_PICKUP_COORDS(x: float, y: float, z: float, p3: float, p4: float) -> 'gta.Vector3':
    return _ivec(0x6E16BC2503FF1FF0, x, y, z, p3, p4)

def ADD_DOOR_TO_SYSTEM(doorHash: int, modelHash: int, x: float, y: float, z: float, p5: bool, scriptDoor: bool, isLocal: bool, p8: int) -> None:
    _iv(0x6F8838D03D1DC226, doorHash, modelHash, x, y, z, p5, scriptDoor, isLocal, p8)

def CLOSE_ALL_BARRIERS_FOR_RACE() -> None:
    _iv(0x701FDA1E82076BA4)

def SET_OBJECT_IS_A_PRESSURE_PLATE(object: int, toggle: bool) -> None:
    _iv(0x734E1714D077DA9A, object, toggle)

def FORCE_PICKUP_REGENERATE(p0: int) -> None:
    _iv(0x758A5C1B3B1E1990, p0)

def HAS_CLOSEST_OBJECT_OF_TYPE_BEEN_BROKEN(p0: float, p1: float, p2: float, p3: float, modelHash: int, p5: int) -> bool:
    return _ib(0x761B0E69AC4D007E, p0, p1, p2, p3, modelHash, p5)

def CLEAR_PICKUP_REWARD_TYPE_SUPPRESSION(rewardType: int) -> None:
    _iv(0x762DB2D380B48D04, rewardType)

def SET_OBJECT_FORCE_VEHICLES_TO_AVOID(object: int, toggle: bool) -> None:
    _iv(0x77F33F2CCF64B3AA, object, toggle)

def SET_PICKUP_REGENERATION_TIME(pickup: int, duration: int) -> None:
    _iv(0x78015C9B4B3ECC9D, pickup, duration)

def SET_PICKUP_OBJECT_COLLECTABLE_IN_VEHICLE(pickup: int) -> None:
    _iv(0x7813E8B8C4AE4799, pickup)

def SET_LOCAL_PLAYER_CAN_COLLECT_PORTABLE_PICKUPS(toggle: bool) -> None:
    _iv(0x78857FC65CADB909, toggle)

def HAS_PICKUP_BEEN_COLLECTED(pickup: int) -> bool:
    return _ib(0x80EC48E6679313F9, pickup)

def SET_CUSTOM_PICKUP_WEAPON_HASH(pickupHash: int, pickup: int) -> None:
    _iv(0x826D1EE4D1CAFC78, pickupHash, pickup)

def ALLOW_PICKUP_ARROW_MARKER_WHEN_UNCOLLECTABLE(pickup: int, toggle: bool) -> None:
    _iv(0x834344A414C7C85D, pickup, toggle)

def DOOR_SYSTEM_GET_IS_SPRING_REMOVED(doorHash: int) -> bool:
    return _ib(0x8562FD8AB1E94D39, doorHash)

def SET_PICKUP_TRANSPARENT_WHEN_UNCOLLECTABLE(pickup: int, toggle: bool) -> None:
    _iv(0x858EC9FD25DE04AA, pickup, toggle)

def ARE_ENTITIES_ENTIRELY_INSIDE_GARAGE(garageHash: int, p1: bool, p2: bool, p3: bool, p4: int) -> bool:
    return _ib(0x85B6C850546FDDE2, garageHash, p1, p2, p3, p4)

def HIDE_PORTABLE_PICKUP_WHEN_DETACHED(pickupObject: int, toggle: bool) -> None:
    _iv(0x867458251D47CCB2, pickupObject, toggle)

def SET_PICKUP_OBJECT_TRANSPARENT_WHEN_UNCOLLECTABLE(pickup: int, toggle: bool) -> None:
    _iv(0x8881C98A31117998, pickup, toggle)

def SET_LOCAL_PLAYER_PERMITTED_TO_COLLECT_PICKUPS_WITH_MODEL(modelHash: int, toggle: bool) -> None:
    _iv(0x88EAEC617CD26926, modelHash, toggle)

def CREATE_PICKUP_ROTATE(pickupHash: int, posX: float, posY: float, posZ: float, rotX: float, rotY: float, rotZ: float, flag: int, amount: int, p9: int, p10: bool, modelHash: int) -> int:
    return _ii(0x891804727E0A98B7, pickupHash, posX, posY, posZ, rotX, rotY, rotZ, flag, amount, p9, p10, modelHash)

def GET_STATE_OF_RAYFIRE_MAP_OBJECT(object: int) -> int:
    return _ii(0x899BA936634A322E, object)

def SET_OBJECT_TARGETTABLE(object: int, targettable: bool, p2: int) -> None:
    _iv(0x8A7391690F5AFD81, object, targettable, p2)

def HAS_OBJECT_BEEN_BROKEN(object: int, p1: int) -> bool:
    return _ib(0x8ABFB70C49CC43E2, object, p1)

def IS_OBJECT_VISIBLE(object: int) -> bool:
    return _ib(0x8B32ACE6326A7546, object)

def IS_OBJECT_NEAR_POINT(objectHash: int, x: float, y: float, z: float, range: float) -> bool:
    return _ib(0x8C90FE4B381BA60A, objectHash, x, y, z, range)

def SET_DISABLE_COLLISIONS_BETWEEN_CARS_AND_CAR_PARACHUTE(p0: int) -> None:
    _iv(0x8CAAB2BD3EA58BD4, p0)

def SET_PICKUP_OBJECT_ALPHA_WHEN_TRANSPARENT(p0: int) -> None:
    _iv(0x8CFF648FBD7330F1, p0)

def ATTACH_PORTABLE_PICKUP_TO_PED(pickupObject: int, ped: int) -> None:
    _iv(0x8DC39368BDD57755, pickupObject, ped)

def SUPPRESS_PICKUP_SOUND_FOR_PICKUP(p0: int, p1: int) -> None:
    _iv(0x8DCA505A5C196F05, p0, p1)

def IS_GARAGE_EMPTY(garageHash: int, p1: bool, p2: int) -> bool:
    return _ib(0x90E47239EA1980B8, garageHash, p1, p2)

def SET_DRIVE_ARTICULATED_JOINT(object: int, toggle: bool, p2: int) -> None:
    _iv(0x911024442F4898F0, object, toggle, p2)

def PREVENT_COLLECTION_OF_PORTABLE_PICKUP(object: int, p1: bool, p2: bool) -> None:
    _iv(0x92AEFB5F6E294023, object, p1, p2)

def SET_OBJECT_SPEED_BOOST_AMOUNT(object: int, p1: int) -> None:
    _iv(0x96EE0EBA0163DF80, object, p1)

def SET_OBJECT_TINT_INDEX(object: int, textureVariation: int) -> None:
    _iv(0x971DA0055324D033, object, textureVariation)

def CREATE_OBJECT_NO_OFFSET(modelHash: int, x: float, y: float, z: float, isNetwork: bool, bScriptHostObj: bool, dynamic: bool, p7: int) -> int:
    return _ii(0x9A294B2138ABB884, modelHash, x, y, z, isNetwork, bScriptHostObj, dynamic, p7)

def SET_LOCKED_UNSTREAMED_IN_DOOR_OF_TYPE(modelHash: int, x: float, y: float, z: float, locked: bool, xRotMult: float, yRotMult: float, zRotMult: float) -> None:
    _iv(0x9B12F9A24FABEDB0, modelHash, x, y, z, locked, xRotMult, yRotMult, zRotMult)

def DOOR_SYSTEM_SET_AUTOMATIC_DISTANCE(doorHash: int, distance: float, requestDoor: bool, forceUpdate: bool) -> None:
    _iv(0x9BA001CB45CBF627, doorHash, distance, requestDoor, forceUpdate)

def CREATE_NON_NETWORKED_AMBIENT_PICKUP(pickupHash: int, posX: float, posY: float, posZ: float, flags: int, value: int, modelHash: int, p7: bool, p8: bool) -> int:
    return _ii(0x9C93764223E29C50, pickupHash, posX, posY, posZ, flags, value, modelHash, p7, p8)

def SET_PICKUP_OBJECT_GLOW_OFFSET(pickup: int, p1: float, p2: bool) -> None:
    _iv(0xA08FE5E49BDC39DD, pickup, p1, p2)

def CLEAR_ALL_PICKUP_REWARD_TYPE_SUPPRESSION() -> None:
    _iv(0xA2C1F5E92AFE49ED)

def DOOR_SYSTEM_SET_DOOR_OPEN_FOR_RACES(doorHash: int, p1: bool) -> None:
    _iv(0xA85A21582451E951, doorHash, p1)

def ALLOW_PICKUP_BY_NONE_PARTICIPANT(pickup: int, toggle: bool) -> None:
    _iv(0xAA059C615DE9DD03, pickup, toggle)

def ALLOW_DAMAGE_EVENTS_FOR_NON_NETWORKED_OBJECTS(value: bool) -> None:
    _iv(0xABDABF4E1EDECBFA, value)

def ONLY_CLEAN_UP_OBJECT_WHEN_OUT_OF_RANGE(object: int) -> None:
    _iv(0xADBE4809F19F927A, object)

def IS_PROP_LIGHT_OVERRIDEN(object: int) -> bool:
    return _ib(0xADF084FB8F075D06, object)

def DOES_PICKUP_EXIST(pickup: int) -> bool:
    return _ib(0xAFC1CA75AD4074D1, pickup)

def ROTATE_OBJECT(object: int, p1: float, p2: float, p3: bool) -> bool:
    return _ib(0xAFE24E4D29249E4A, object, p1, p2, p3)

def SET_DRIVE_ARTICULATED_JOINT_WITH_INFLICTOR(object: int, toggle: bool, p2: int, ped: int) -> None:
    _iv(0xB20834A7DD3D8896, object, toggle, p2, ped)

def TRACK_OBJECT_VISIBILITY(object: int) -> None:
    _iv(0xB252BC036B525623, object)

def SET_ENTITY_FLAG_RENDER_SMALL_SHADOW(object: int, toggle: bool) -> None:
    _iv(0xB2D0BDE54F0E8E5A, object, toggle)

def _SET_OBJECT_TARGETTABLE_BY_PLAYER(object: int, setFlag34: bool, setFlag35: bool) -> None:
    _iv(0xB39F03368DB0CAA2, object, setFlag34, setFlag35)

def GET_PICKUP_GENERATION_RANGE_MULTIPLIER() -> float:
    return _if(0xB3ECA65C7317F174)

def GET_RAYFIRE_MAP_OBJECT(x: float, y: float, z: float, radius: float, name: str) -> int:
    return _ii(0xB48FCED898292E52, x, y, z, radius, name)

def SET_IS_OBJECT_BALL(object: int, toggle: bool) -> None:
    _iv(0xB5B7742424BD4445, object, toggle)

def DOOR_SYSTEM_SET_OPEN_RATIO(doorHash: int, ajar: float, requestDoor: bool, forceUpdate: bool) -> None:
    _iv(0xB6E6FBA95C7324AC, doorHash, ajar, requestDoor, forceUpdate)

def GET_OBJECT_FRAGMENT_DAMAGE_HEALTH(p0: int, p1: bool) -> float:
    return _if(0xB6FBFD079B8D0596, p0, p1)

def CLEAR_EXTENDED_PICKUP_PROBE_AREAS() -> None:
    _iv(0xB7C6D80FB371659A)

def SET_CUTSCENES_WEAPON_FLASHLIGHT_ON_THIS_FRAME(object: int, toggle: bool) -> None:
    _iv(0xBCE595371A5FBAAF, object, toggle)

def DOES_OBJECT_OF_TYPE_EXIST_AT_COORDS(x: float, y: float, z: float, radius: float, hash: int, p5: bool) -> bool:
    return _ib(0xBFA48E2FF417213F, x, y, z, radius, hash, p5)

def SET_PICKUP_TRACK_DAMAGE_EVENTS(pickup: int, toggle: bool) -> None:
    _iv(0xBFFE53AE7E67FCDC, pickup, toggle)

def IS_DOOR_REGISTERED_WITH_SYSTEM(doorHash: int) -> bool:
    return _ib(0xC153C43EA202C8C1, doorHash)

def DOOR_SYSTEM_SET_SPRING_REMOVED(doorHash: int, removed: bool, requestDoor: bool, forceUpdate: bool) -> None:
    _iv(0xC485E07E4F0B7958, doorHash, removed, requestDoor, forceUpdate)

def IS_DOOR_CLOSED(doorHash: int) -> bool:
    return _ib(0xC531EE8A1145A149, doorHash)

def SET_OBJECT_IS_SPECIAL_GOLFBALL(object: int, toggle: bool) -> None:
    _iv(0xC6033D32241F6FB5, object, toggle)

def OPEN_ALL_BARRIERS_FOR_RACE(p0: bool) -> None:
    _iv(0xC7F29CA00F46350E, p0)

def DETACH_PORTABLE_PICKUP_FROM_PED(pickupObject: int) -> None:
    _iv(0xCF463D1E9A0AECB1, pickupObject)

def SET_ENTITY_FLAG_SUPPRESS_SHADOW(entity: int, toggle: bool) -> None:
    _iv(0xD05A3241B9A86F19, entity, toggle)

def ADD_EXTENDED_PICKUP_PROBE_AREA(x: float, y: float, z: float, radius: float) -> None:
    _iv(0xD4A7A435B3710D05, x, y, z, radius)

def GET_PICKUP_TYPE_FROM_WEAPON_HASH(weaponHash: int) -> int:
    return _ii(0xD6429A016084F1A5, weaponHash)

def PLACE_OBJECT_ON_GROUND_OR_OBJECT_PROPERLY(object: int) -> bool:
    return _ib(0xD76EEEF746057FD6, object)

def DOOR_SYSTEM_SET_HOLD_OPEN(doorHash: int, toggle: bool) -> None:
    _iv(0xD9B71952F78A2640, doorHash, toggle)

def DOES_PICKUP_OBJECT_EXIST(pickupObject: int) -> bool:
    return _ib(0xD9EFB6DBF7DAAEA3, pickupObject)

def CLEAR_GARAGE(garageHash: int, isNetwork: bool) -> None:
    _iv(0xDA05194260CDCDF9, garageHash, isNetwork)

def GET_DEFAULT_AMMO_FOR_WEAPON_PICKUP(pickupHash: int) -> int:
    return _ii(0xDB41D07A45A6D4B7, pickupHash)

def SET_OBJECT_SPEED_BOOST_DURATION(object: int, duration: float) -> None:
    _iv(0xDF6CA0330F2E737B, object, duration)

def DOOR_SYSTEM_GET_IS_PHYSICS_LOADED(p0: int) -> bool:
    return _ib(0xDF97CDD4FC08FD34, p0)

def DAMAGE_OBJECT_FRAGMENT_CHILD(p0: int, p1: int, p2: int) -> None:
    _iv(0xE05F6AEEFEB0BB02, p0, p1, p2)

def GET_CLOSEST_OBJECT_OF_TYPE(x: float, y: float, z: float, radius: float, modelHash: int, isMission: bool, p6: bool, p7: bool) -> int:
    return _ii(0xE143FA2249364369, x, y, z, radius, modelHash, isMission, p6, p7)

def BREAK_OBJECT_FRAGMENT_CHILD(p0: int, p1: int, p2: bool) -> None:
    _iv(0xE7E4C198B0185900, p0, p1, p2)

def GET_OBJECT_TINT_INDEX(object: int) -> int:
    return _ii(0xE84EB93729C5F36A, object)

def DOOR_SYSTEM_GET_AUTOMATIC_DISTANCE(doorHash: int) -> float:
    return _if(0xE851471AEFC3374F, doorHash)

def SET_OBJECT_TAKES_DAMAGE_FROM_COLLIDING_WITH_BUILDINGS(p0: int, p1: bool) -> None:
    _iv(0xEB6F1A9B5510A5D2, p0, p1)

def GET_STATE_OF_CLOSEST_DOOR_OF_TYPE(type: int, x: float, y: float, z: float, locked: int, heading: int) -> None:
    _iv(0xEDC1A5B84AEF33FF, type, x, y, z, locked, heading)

def IS_OBJECT_PARTIALLY_INSIDE_GARAGE(garageHash: int, entity: int, p2: int) -> bool:
    return _ib(0xF0EED5A6BC7B237A, garageHash, entity, p2)

def SET_TINT_INDEX_CLOSEST_BUILDING_OF_TYPE(x: float, y: float, z: float, radius: float, modelHash: int, textureVariation: int) -> bool:
    return _ib(0xF12E33034D887F66, x, y, z, radius, modelHash, textureVariation)

def ENABLE_SAVING_IN_GARAGE(garageHash: int, toggle: bool) -> None:
    _iv(0xF2E1A7133DD356A6, garageHash, toggle)

def SET_FORCE_OBJECT_THIS_FRAME(x: float, y: float, z: float, p3: float) -> None:
    _iv(0xF538081986E49E9D, x, y, z, p3)

def SET_OBJECT_PHYSICS_PARAMS(object: int, weight: float, p2: float, p3: float, p4: float, p5: float, gravity: float, p7: float, p8: float, p9: float, p10: float, buoyancy: float) -> None:
    _iv(0xF6DF6E90DE7DF90F, object, weight, p2, p3, p4, p5, gravity, p7, p8, p9, p10, buoyancy)

def SET_STATE_OF_CLOSEST_DOOR_OF_TYPE(type: int, x: float, y: float, z: float, locked: bool, heading: float, p6: bool) -> None:
    _iv(0xF82D8F1926A02C3D, type, x, y, z, locked, heading, p6)

def SUPPRESS_PICKUP_REWARD_TYPE(rewardType: int, suppress: bool) -> None:
    _iv(0xF92099527DB8E2A7, rewardType, suppress)

def FIX_OBJECT_FRAGMENT(object: int) -> None:
    _iv(0xF9C1681347C8BD15, object)

def DOES_PICKUP_OF_TYPE_EXIST_IN_AREA(pickupHash: int, x: float, y: float, z: float, radius: float) -> bool:
    return _ib(0xF9C36251F6E48E33, pickupHash, x, y, z, radius)

def CREATE_PICKUP(pickupHash: int, posX: float, posY: float, posZ: float, p4: int, value: int, p6: bool, modelHash: int) -> int:
    return _ii(0xFBA08C503DD5FA58, pickupHash, posX, posY, posZ, p4, value, p6, modelHash)

def IS_OBJECT_A_PICKUP(object: int) -> bool:
    return _ib(0xFC481C641EBBD27D, object)

def ALLOW_ALL_PLAYERS_TO_COLLECT_PICKUPS_OF_TYPE(pickupHash: int) -> None:
    _iv(0xFDC07C58E8AAB715, pickupHash)
