"""Auto-generated raw native bindings for namespace CUTSCENE.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_vector3 as _ivec


def SET_CUTSCENE_ORIGIN_AND_ORIENTATION(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, p6: int) -> None:
    _iv(0x011883F41211432A, x1, y1, z1, x2, y2, z2, p6)

def SET_CUTSCENE_PED_PROP_VARIATION(cutsceneEntName: str, componentId: int, drawableId: int, textureId: int, modelHash: int) -> None:
    _iv(0x0546524ADE2E9723, cutsceneEntName, componentId, drawableId, textureId, modelHash)

def REQUEST_CUT_FILE(cutsceneName: str) -> None:
    _iv(0x06A3524161C502BA, cutsceneName)

def SET_CUTSCENE_MULTIHEAD_FADE_MANUAL(p0: bool) -> None:
    _iv(0x06EE9048FD080382, p0)

def GET_ENTITY_INDEX_OF_CUTSCENE_ENTITY(cutsceneEntName: str, modelHash: int) -> int:
    return _ii(0x0A2E9FDB9A8C62F6, cutsceneEntName, modelHash)

def GET_CUT_FILE_CONCAT_COUNT(cutsceneName: str) -> int:
    return _ii(0x0ABC54DE641DC0FC, cutsceneName)

def START_CUTSCENE(flags: int) -> None:
    _iv(0x186D5CB5E7B0FF7B, flags)

def START_CUTSCENE_AT_COORDS(x: float, y: float, z: float, flags: int) -> None:
    _iv(0x1C9ADDA3244A1FBF, x, y, z, flags)

def GET_CUT_FILE_OFFSET(cutsceneName: str, index: int) -> 'gta.Vector3':
    return _ivec(0x1FA904B60E492336, cutsceneName, index)

def SET_CUTSCENE_MULTIHEAD_FADE(p0: bool, p1: bool, p2: bool, p3: bool) -> None:
    _iv(0x20746F7B1032A3C7, p0, p1, p2, p3)

def SET_CAN_DISPLAY_MINIMAP_DURING_CUTSCENE_THIS_UPDATE() -> None:
    _iv(0x2131046957F31B04)

def HAS_THIS_CUTSCENE_LOADED(cutsceneName: str) -> bool:
    return _ib(0x228D3D94F8A11C3C, cutsceneName)

def SET_CUTSCENE_PED_COMPONENT_VARIATION_FROM_PED(cutsceneEntName: str, ped: int, modelHash: int) -> None:
    _iv(0x2A56C06EBEF2B0D9, cutsceneEntName, ped, modelHash)

def NETWORK_SET_MOCAP_CUTSCENE_CAN_BE_SKIPPED(toggle: bool) -> None:
    _iv(0x2F137B508DE238F2, toggle)

def WAS_CUTSCENE_SKIPPED() -> bool:
    return _ib(0x40C8656EDAEDD569)

def SET_CUTSCENE_CAN_BE_SKIPPED(p0: bool) -> None:
    _iv(0x41FAA8FB2ECE8720, p0)

def REMOVE_CUTSCENE() -> None:
    _iv(0x440AF51A3462B86F)

def GET_CUTSCENE_SECTION_PLAYING() -> int:
    return _ii(0x49010A6A396553D8)

def DOES_CUTSCENE_ENTITY_EXIST(cutsceneEntName: str, modelHash: int) -> bool:
    return _ib(0x499EF20C5DB25C59, cutsceneEntName, modelHash)

def SET_CUTSCENE_ENTITY_STREAMING_FLAGS(cutsceneEntName: str, p1: int, p2: int) -> None:
    _iv(0x4C61C75BEE8184C2, cutsceneEntName, p1, p2)

def CAN_SET_EXIT_STATE_FOR_REGISTERED_ENTITY(cutsceneEntName: str, modelHash: int) -> bool:
    return _ib(0x4C6A6451C79E4662, cutsceneEntName, modelHash)

def IS_CUTSCENE_AUTHORIZED(cutsceneName: str) -> bool:
    return _ib(0x4CEBC1ED31E8925E, cutsceneName)

def DOES_CUTSCENE_HANDLE_EXIST(cutsceneHandle: int) -> int:
    return _ii(0x4FCD976DA686580C, cutsceneHandle)

def GET_CUTSCENE_CONCAT_SECTION_PLAYING() -> int:
    return _ii(0x583DF8E3D4AFBD98)

def GET_CUTSCENE_PLAY_DURATION() -> int:
    return _ii(0x5D583F71C901F2A3)

def CAN_USE_MOBILE_PHONE_DURING_CUTSCENE() -> bool:
    return _ib(0x5EDEF0CF8C1DAB3C)

def CAN_SET_ENTER_STATE_FOR_REGISTERED_ENTITY(cutsceneEntName: str, modelHash: int) -> bool:
    return _ib(0x645D0B458D8E17B5, cutsceneEntName, modelHash)

def HAS_CUTSCENE_CUT_THIS_FRAME() -> bool:
    return _ib(0x708BDD8CD795B043)

def GET_CUTSCENE_PLAY_TIME() -> int:
    return _ii(0x710286BC5EF4D6E1)

def IS_CUTSCENE_PLAYBACK_FLAG_SET(flag: int) -> bool:
    return _ib(0x71B74D2AE19338D0, flag)

def REQUEST_CUTSCENE(cutsceneName: str, flags: int) -> None:
    _iv(0x7A86743F475D9E09, cutsceneName, flags)

def HAS_CUTSCENE_FINISHED() -> bool:
    return _ib(0x7C0A893088881D57)

def SET_VEHICLE_MODEL_PLAYER_WILL_EXIT_SCENE(modelHash: int) -> None:
    _iv(0x7F96F23FA9B73327, modelHash)

def SET_CUTSCENE_FADE_VALUES(p0: bool, p1: bool, p2: bool, p3: bool) -> None:
    _iv(0x8093F23ABACCC7D4, p0, p1, p2, p3)

def SET_SCRIPT_CAN_START_CUTSCENE(threadId: int) -> None:
    _iv(0x8D9DF6ECA8768583, threadId)

def GET_CUTSCENE_END_TIME() -> int:
    return _ii(0x971D7B15BCDBEF99)

def SET_CUTSCENE_TRIGGER_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> None:
    _iv(0x9896CE4721BE84BA, x1, y1, z1, x2, y2, z2)

def IS_CUTSCENE_ACTIVE() -> bool:
    return _ib(0x991251AFC3981F84)

def IS_MULTIHEAD_FADE_UP() -> bool:
    return _ib(0xA0FE76168A189DDB)

def HAS_CUT_FILE_LOADED(cutsceneName: str) -> bool:
    return _ib(0xA1C996C2A744262E, cutsceneName)

def CAN_SET_EXIT_STATE_FOR_CAMERA(p0: bool) -> bool:
    return _ib(0xB2CBCD0930DFB420, p0)

def CAN_REQUEST_ASSETS_FOR_CUTSCENE_ENTITY() -> bool:
    return _ib(0xB56BBBCC2955D9CB)

def SET_CUTSCENE_ORIGIN(x: float, y: float, z: float, p3: float, p4: int) -> None:
    _iv(0xB812B3FD1C01CF27, x, y, z, p3, p4)

def SET_CUTSCENE_PED_COMPONENT_VARIATION(cutsceneEntName: str, componentId: int, drawableId: int, textureId: int, modelHash: int) -> None:
    _iv(0xBA01E7B6DEEFBBC9, cutsceneEntName, componentId, drawableId, textureId, modelHash)

def GET_ENTITY_INDEX_OF_REGISTERED_ENTITY(cutsceneEntName: str, modelHash: int) -> int:
    return _ii(0xC0741A26499654CD, cutsceneEntName, modelHash)

def REQUEST_CUTSCENE_WITH_PLAYBACK_LIST(cutsceneName: str, playbackFlags: int, flags: int) -> None:
    _iv(0xC23DE0E91C30B58C, cutsceneName, playbackFlags, flags)

def HAS_CUTSCENE_LOADED() -> bool:
    return _ib(0xC59F528E9AB9F339)

def SET_PAD_CAN_SHAKE_DURING_CUTSCENE(toggle: bool) -> None:
    _iv(0xC61B86C9F61EB404, toggle)

def STOP_CUTSCENE(p0: bool) -> None:
    _iv(0xC7272775B4DC786E, p0)

def REMOVE_CUT_FILE(cutsceneName: str) -> None:
    _iv(0xD00D76A7DFC9D852, cutsceneName)

def STOP_CUTSCENE_IMMEDIATELY() -> None:
    _iv(0xD220BDD222AC4A1E)

def IS_CUTSCENE_PLAYING() -> bool:
    return _ib(0xD3C2E180A40F031E)

def SET_CAR_GENERATORS_CAN_UPDATE_DURING_CUTSCENE(p0: bool) -> None:
    _iv(0xE36A98D8AB3D3C66, p0)

def REGISTER_ENTITY_FOR_CUTSCENE(cutscenePed: int, cutsceneEntName: str, p2: int, modelHash: int, p4: int) -> None:
    _iv(0xE40C1C56DF95C2E8, cutscenePed, cutsceneEntName, p2, modelHash, p4)

def GET_CUTSCENE_TIME() -> int:
    return _ii(0xE625BEABBAFFDAB9)

def GET_CUTSCENE_TOTAL_DURATION() -> int:
    return _ii(0xEE53B14A19E480D4)
