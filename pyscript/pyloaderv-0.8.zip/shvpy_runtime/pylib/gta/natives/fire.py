"""Auto-generated raw native bindings for namespace FIRE.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii


def STOP_FIRE_IN_RANGE(x: float, y: float, z: float, radius: float) -> None:
    _iv(0x056A8A219B8E829F, x, y, z, radius)

def GET_OWNER_OF_EXPLOSION_IN_ANGLED_AREA(explosionType: int, x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, radius: float) -> int:
    return _ii(0x14BA4BA137AF6CEC, explosionType, x1, y1, z1, x2, y2, z2, radius)

def ADD_OWNED_EXPLOSION(ped: int, x: float, y: float, z: float, explosionType: int, damageScale: float, isAudible: bool, isInvisible: bool, cameraShake: float) -> None:
    _iv(0x172AA1B624FA1013, ped, x, y, z, explosionType, damageScale, isAudible, isInvisible, cameraShake)

def IS_ENTITY_ON_FIRE(entity: int) -> bool:
    return _ib(0x28D3FED7190D3A0B, entity)

def IS_EXPLOSION_IN_AREA(explosionType: int, x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> bool:
    return _ib(0x2E2EBA0EE7CED0E0, explosionType, x1, y1, z1, x2, y2, z2)

def GET_CLOSEST_FIRE_POS(outPosition: int, x: float, y: float, z: float) -> bool:
    return _ib(0x352A9F6BCF90081F, outPosition, x, y, z)

def ADD_EXPLOSION_WITH_USER_VFX(x: float, y: float, z: float, explosionType: int, explosionFx: int, damageScale: float, isAudible: bool, isInvisible: bool, cameraShake: float) -> None:
    _iv(0x36DD3FE58B5E5212, x, y, z, explosionType, explosionFx, damageScale, isAudible, isInvisible, cameraShake)

def GET_NUMBER_OF_FIRES_IN_RANGE(x: float, y: float, z: float, radius: float) -> int:
    return _ii(0x50CAD495A460B305, x, y, z, radius)

def _NETWORK_EXPECT_EXPLOSION_EVENTS_FOR_PLAYER(expect: bool, player: int) -> None:
    _iv(0x5241DB47A8B8AD54, expect, player)

def IS_EXPLOSION_ACTIVE_IN_AREA(explosionType: int, x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> bool:
    return _ib(0x6070104B699B2EF4, explosionType, x1, y1, z1, x2, y2, z2)

def START_SCRIPT_FIRE(X: float, Y: float, Z: float, maxChildren: int, isGasFire: bool) -> int:
    return _ii(0x6B83617E04503888, X, Y, Z, maxChildren, isGasFire)

def STOP_ENTITY_FIRE(entity: int) -> None:
    _iv(0x7F0DD2EBBB651AFF, entity)

def REMOVE_SCRIPT_FIRE(fireHandle: int) -> None:
    _iv(0x7FF548385680673F, fireHandle)

def SET_FLAMMABILITY_MULTIPLIER(p0: float) -> None:
    _iv(0x8F390AC4155099BA, p0)

def IS_EXPLOSION_IN_ANGLED_AREA(explosionType: int, x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, width: float) -> bool:
    return _ib(0xA079A6C51525DC4B, explosionType, x1, y1, z1, x2, y2, z2, width)

def IS_EXPLOSION_IN_SPHERE(explosionType: int, x: float, y: float, z: float, radius: float) -> bool:
    return _ib(0xAB0F816885B0E483, explosionType, x, y, z, radius)

def GET_OWNER_OF_EXPLOSION_IN_SPHERE(explosionType: int, x: float, y: float, z: float, radius: float) -> int:
    return _ii(0xB3CD51E3DB86F176, explosionType, x, y, z, radius)

def ADD_EXPLOSION(x: float, y: float, z: float, explosionType: int, damageScale: float, isAudible: bool, isInvisible: bool, cameraShake: float, noDamage: bool) -> None:
    _iv(0xE3AD2BDBAEE269AC, x, y, z, explosionType, damageScale, isAudible, isInvisible, cameraShake, noDamage)

def START_ENTITY_FIRE(entity: int) -> int:
    return _ii(0xF6A9D9708F6F23DF, entity)
