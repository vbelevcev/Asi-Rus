"""Auto-generated raw native bindings for namespace CLOCK.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_int as _ii


def GET_CLOCK_MINUTES() -> int:
    return _ii(0x13D2B8ADD79640F2)

def GET_CLOCK_HOURS() -> int:
    return _ii(0x25223CA6B4D20B7F)

def GET_MILLISECONDS_PER_GAME_MINUTE() -> int:
    return _ii(0x2F8B4D1C595B11DB)

def GET_CLOCK_DAY_OF_MONTH() -> int:
    return _ii(0x3D10BC92A4DB1D35)

def PAUSE_CLOCK(toggle: bool) -> None:
    _iv(0x4055E40BD2DBEC1D, toggle)

def SET_CLOCK_TIME(hour: int, minute: int, second: int) -> None:
    _iv(0x47C3B5848C3E45D8, hour, minute, second)

def GET_CLOCK_SECONDS() -> int:
    return _ii(0x494E97C2EF27C470)

def GET_LOCAL_TIME(year: int, month: int, day: int, hour: int, minute: int, second: int) -> None:
    _iv(0x50C7A99057A69748, year, month, day, hour, minute, second)

def GET_UTC_TIME(year: int, month: int, day: int, hour: int, minute: int, second: int) -> None:
    _iv(0x8117E09A19EEF4D3, year, month, day, hour, minute, second)

def GET_CLOCK_YEAR() -> int:
    return _ii(0x961777E64BDAF717)

def SET_CLOCK_DATE(day: int, month: int, year: int) -> None:
    _iv(0xB096419DF0D06CE7, day, month, year)

def GET_CLOCK_MONTH() -> int:
    return _ii(0xBBC72712E80257A1)

def ADVANCE_CLOCK_TIME_TO(hour: int, minute: int, second: int) -> None:
    _iv(0xC8CA9670B9D83B3B, hour, minute, second)

def ADD_TO_CLOCK_TIME(hours: int, minutes: int, seconds: int) -> None:
    _iv(0xD716F30D8C8980E2, hours, minutes, seconds)

def GET_CLOCK_DAY_OF_WEEK() -> int:
    return _ii(0xD972E4BD7AEB235F)

def GET_POSIX_TIME(year: int, month: int, day: int, hour: int, minute: int, second: int) -> None:
    _iv(0xDA488F299A5B164E, year, month, day, hour, minute, second)
