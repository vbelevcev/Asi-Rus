"""Auto-generated raw native bindings for namespace BUILTIN.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_int as _ii, _invoke_float as _if


def TIMESTEP() -> float:
    return _if(0x0000000050597EE2)

def SIN(value: float) -> float:
    return _if(0x0BADBFA3B172435F, value)

def CEIL(value: float) -> int:
    return _ii(0x11E019C8F43ACC8A, value)

def VDIST(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> float:
    return _if(0x2A488C176D52CCA5, x1, y1, z1, x2, y2, z2)

def SET_THIS_THREAD_PRIORITY(priority: int) -> None:
    _iv(0x42B65DEEF2EDF2A1, priority)

def WAIT(ms: int) -> None:
    _iv(0x4EDE34FBADD967A6, ms)

def SETTIMERB(value: int) -> None:
    _iv(0x5AE11BC36633DE4E, value)

def VMAG(x: float, y: float, z: float) -> float:
    return _if(0x652D2EEEF1D3E62C, x, y, z)

def SQRT(value: float) -> float:
    return _if(0x71D93B57D07F9804, value)

def TIMERA() -> int:
    return _ii(0x83666F9FB8FEBD4B)

def SHIFT_RIGHT(value: int, bitShift: int) -> int:
    return _ii(0x97EF1E5BCE9DC075, value, bitShift)

def VMAG2(x: float, y: float, z: float) -> float:
    return _if(0xA8CEACB4F35AE058, x, y, z)

def VDIST2(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> float:
    return _if(0xB7A628320EFF8E47, x1, y1, z1, x2, y2, z2)

def START_NEW_SCRIPT_WITH_ARGS(scriptName: str, args: int, argCount: int, stackSize: int) -> int:
    return _ii(0xB8BA7F44DF1575E1, scriptName, args, argCount, stackSize)

def TO_FLOAT(value: int) -> float:
    return _if(0xBBDA792448DB5A89, value)

def SETTIMERA(value: int) -> None:
    _iv(0xC1B1E9A034A63A62, value)

def START_NEW_SCRIPT_WITH_NAME_HASH_AND_ARGS(scriptHash: int, args: int, argCount: int, stackSize: int) -> int:
    return _ii(0xC4BB298BD441BE78, scriptHash, args, argCount, stackSize)

def TIMERB() -> int:
    return _ii(0xC9D9444186B5A374)

def COS(value: float) -> float:
    return _if(0xD0FFB162F40A139C, value)

def POW(base: float, exponent: float) -> float:
    return _if(0xE3621CC40F31FE2E, base, exponent)

def START_NEW_SCRIPT(scriptName: str, stackSize: int) -> int:
    return _ii(0xE81651AD79516E48, scriptName, stackSize)

def LOG10(value: float) -> float:
    return _if(0xE816E655DE37FE20, value)

def START_NEW_SCRIPT_WITH_NAME_HASH(scriptHash: int, stackSize: int) -> int:
    return _ii(0xEB1C67C3A5333A92, scriptHash, stackSize)

def SHIFT_LEFT(value: int, bitShift: int) -> int:
    return _ii(0xEDD95A39E5544DE8, value, bitShift)

def ROUND(value: float) -> int:
    return _ii(0xF2DB717A73826179, value)

def FLOOR(value: float) -> int:
    return _ii(0xF34EE736CF047844, value)
