"""Auto-generated raw native bindings for namespace APP.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_str as _is


def APP_GET_FLOAT(property: str) -> float:
    return _if(0x1514FB24C02C2322, property)

def APP_SET_FLOAT(property: str, value: float) -> None:
    _iv(0x25D7687C68E0DAA4, property, value)

def APP_SET_BLOCK(blockName: str) -> None:
    _iv(0x262AB456A3D21F93, blockName)

def APP_SET_STRING(property: str, value: str) -> None:
    _iv(0x3FF2FCEC4B7721B4, property, value)

def APP_DELETE_APP_DATA(appName: str) -> bool:
    return _ib(0x44151AEA95C8A003, appName)

def APP_CLEAR_BLOCK() -> None:
    _iv(0x5FE1DF3342DB7DBA)

def APP_SET_INT(property: str, value: int) -> None:
    _iv(0x607E8E3D3E4F9611, property, value)

def APP_HAS_LINKED_SOCIAL_CLUB_ACCOUNT() -> bool:
    return _ib(0x71EEE69745088DA0)

def APP_GET_STRING(property: str) -> str:
    return _is(0x749B023950D2311C, property)

def APP_DATA_VALID() -> bool:
    return _ib(0x846AA8E7D55EE5B6)

def APP_SAVE_DATA() -> None:
    _iv(0x95C5D356CDA6E85F)

def APP_GET_DELETED_FILE_STATUS() -> int:
    return _ii(0xC9853A2BE3DED1A6)

def APP_HAS_SYNCED_DATA(appName: str) -> bool:
    return _ib(0xCA52279A7271517F, appName)

def APP_SET_APP(appName: str) -> None:
    _iv(0xCFD0406ADAF90D2B, appName)

def APP_GET_INT(property: str) -> int:
    return _ii(0xD3A58A12C77D9D4B, property)

def APP_CLOSE_APP() -> None:
    _iv(0xE41C65E07A5F05FC)

def APP_CLOSE_BLOCK() -> None:
    _iv(0xE8E3FCF72EAC0EF8)
