"""Auto-generated raw native bindings for namespace LOBBY.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib


def LOBBY_AUTO_MULTIPLAYER_EVENT() -> bool:
    return _ib(0x8AA464D4E0F6ACCD)

def LOBBY_SET_AUTO_MULTIPLAYER(toggle: bool) -> None:
    _iv(0xB0C56BD3D808D863, toggle)

def LOBBY_AUTO_MULTIPLAYER_RANDOM_JOB() -> bool:
    return _ib(0xC6DC823253FBB366)

def LOBBY_SET_AUTO_MP_RANDOM_JOB(toggle: bool) -> None:
    _iv(0xC7E7181C09F33B69, toggle)

def LOBBY_AUTO_MULTIPLAYER_FREEMODE() -> bool:
    return _ib(0xEF7D17BC6C85264C)

def LOBBY_AUTO_MULTIPLAYER_MENU() -> bool:
    return _ib(0xF2CA003F167E21D2)

def SHUTDOWN_SESSION_CLEARS_AUTO_MULTIPLAYER(toggle: bool) -> None:
    _iv(0xFA1E0E893D915215, toggle)

def LOBBY_SET_AUTO_MULTIPLAYER_EVENT(toggle: bool) -> None:
    _iv(0xFC309E94546FCDB5, toggle)
