"""Auto-generated raw native bindings for namespace SECURITY.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv


def UNREGISTER_SCRIPT_VARIABLE(variable: int) -> None:
    _iv(0x340A36A700E99699, variable)

def REGISTER_SCRIPT_VARIABLE(variable: int) -> None:
    _iv(0x40EB1EFD921822BC, variable)

def FORCE_CHECK_SCRIPT_VARIABLES() -> None:
    _iv(0x8E580AB902917360)
