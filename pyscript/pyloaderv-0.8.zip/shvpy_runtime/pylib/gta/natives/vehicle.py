"""Auto-generated raw native bindings for namespace VEHICLE.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_str as _is, _invoke_vector3 as _ivec


def REMOVE_VEHICLE_HIGH_DETAIL_MODEL(vehicle: int) -> None:
    _iv(0x00689CDE5F7C6787, vehicle)

def IS_VEHICLE_MOD_GEN9_EXCLUSIVE(vehicle: int, modType: int, modIndex: int) -> bool:
    return _ib(0x00834EAC4A96E010, vehicle, modType, modIndex)

def GET_VEHICLE_CLASS_ESTIMATED_MAX_SPEED(vehicleClass: int) -> float:
    return _if(0x00C09F246ABEDD82, vehicleClass)

def SET_TYRE_WEAR_RATE(vehicle: int, wheelIndex: int, multiplier: float) -> None:
    _iv(0x01894E2EDE923CA2, vehicle, wheelIndex, multiplier)

def SET_ARRIVE_DISTANCE_OVERRIDE_FOR_VEHICLE_PERSUIT_ATTACK(vehicle: int, p1: float) -> None:
    _iv(0x0205F5365292D2EB, vehicle, p1)

def SET_VEHICLE_HAS_BEEN_DRIVEN_FLAG(vehicle: int, toggle: bool) -> None:
    _iv(0x02398B627547189C, vehicle, toggle)

def VEHICLE_SET_OVERRIDE_EXTENABLE_SIDE_RATIO(p0: int, p1: int) -> int:
    return _ii(0x0419B167EE128F33, p0, p1)

def GET_LAST_SHUNT_VEHICLE(vehicle: int) -> int:
    return _ii(0x04F2FA6E234162F7, vehicle)

def GET_IS_VEHICLE_DISABLED_BY_EMP(vehicle: int) -> bool:
    return _ib(0x0506ED94363AD905, vehicle)

def GET_RANDOM_VEHICLE_MODEL_IN_MEMORY(p0: bool, modelHash: int, successIndicator: int) -> None:
    _iv(0x055BF0AC0C34F4FD, p0, modelHash, successIndicator)

def SET_VEHICLE_TURRET_TARGET(vehicle: int, p1: bool, x: float, y: float, z: float, p5: bool) -> None:
    _iv(0x0581730AB9380412, vehicle, p1, x, y, z, p5)

def SET_SHOULD_LERP_FROM_AI_TO_FULL_RECORDING(vehicle: int, p1: bool) -> None:
    _iv(0x063AE2B2CC273588, vehicle, p1)

def SET_VEHICLE_INACTIVE_DURING_PLAYBACK(vehicle: int, toggle: bool) -> None:
    _iv(0x06582AFF74894C75, vehicle, toggle)

def SET_VEHICLE_CAN_EJECT_PASSENGERS_IF_LOCKED(p0: int, p1: int) -> None:
    _iv(0x065D03A9D6B2C6B5, p0, p1)

def SET_VEHICLE_DROPS_MONEY_WHEN_BLOWN_UP(vehicle: int, toggle: bool) -> None:
    _iv(0x068F64F2470F9656, vehicle, toggle)

def HAS_PRELOAD_MODS_FINISHED(vehicle: int) -> bool:
    return _ib(0x06F43E5175EB6D96, vehicle)

def SET_VEHICLE_IS_RACING(vehicle: int, toggle: bool) -> None:
    _iv(0x07116E24E9D1929D, vehicle, toggle)

def GET_TRAIN_CARRIAGE(train: int, trailerNumber: int) -> int:
    return _ii(0x08AAFD0814722BC3, train, trailerNumber)

def GET_SUBMARINE_NUMBER_OF_AIR_LEAKS(submarine: int) -> int:
    return _ii(0x093D6DDCA5B8FBAE, submarine)

def SET_VEHICLE_RUDDER_BROKEN(vehicle: int, toggle: bool) -> None:
    _iv(0x09606148B6C71DEF, vehicle, toggle)

def SET_HELI_COMBAT_OFFSET(vehicle: int, x: float, y: float, z: float) -> None:
    _iv(0x0A3F820A9A9A9AC5, vehicle, x, y, z)

def CLEAR_VEHICLE_GENERATOR_AREA_OF_INTEREST() -> None:
    _iv(0x0A436B8643716D14)

def SET_BOAT_DISABLE_AVOIDANCE(vehicle: int, p1: bool) -> None:
    _iv(0x0A6A279F3AA4FD70, vehicle, p1)

def SET_VEHICLE_INFLUENCES_WANTED_LEVEL(p0: int, p1: bool) -> None:
    _iv(0x0AD9E8F87FF7C16F, p0, p1)

def GET_HYDRAULIC_SUSPENSION_RAISE_FACTOR(vehicle: int, wheelId: int) -> float:
    return _if(0x0BB5CBDDD0F25AE3, vehicle, wheelId)

def SET_PLANE_SECTION_DAMAGE_SCALE(vehicle: int, p1: int, p2: int) -> None:
    _iv(0x0BBB9A7A8FFE931B, vehicle, p1, p2)

def VEHICLE_START_PARACHUTING(vehicle: int, active: bool) -> None:
    _iv(0x0BFFB028B3DD0A97, vehicle, active)

def _SET_DEPLOY_MISSILE_BAYS(vehicle: int, deploy: bool) -> None:
    _iv(0x0C02468829E4AA65, vehicle, deploy)

def SET_VEHICLE_CAN_DEFORM_WHEELS(vehicle: int, toggle: bool) -> None:
    _iv(0x0CDDA42F9E360CA6, vehicle, toggle)

def SET_CARGOBOB_PICKUP_ROPE_TYPE(p0: int, p1: int) -> None:
    _iv(0x0D5F65A8F4EBDAB5, p0, p1)

def DETACH_VEHICLE_FROM_CARGOBOB(vehicle: int, cargobob: int) -> None:
    _iv(0x0E21D3DF1051399D, vehicle, cargobob)

def GET_TOTAL_DURATION_OF_VEHICLE_RECORDING(recording: int, script: str) -> float:
    return _if(0x0E48D1C262390950, recording, script)

def GET_VEHICLE_WINDOW_TINT(vehicle: int) -> int:
    return _ii(0x0EE21293DAD47C95, vehicle)

def ALLOW_BOAT_BOOM_TO_ANIMATE(vehicle: int, toggle: bool) -> None:
    _iv(0x0F3B4D4E43177236, vehicle, toggle)

def STOP_ALL_GARAGE_ACTIVITY() -> None:
    _iv(0x0F87E938BDF29D66)

def SET_VEHICLE_MODEL_IS_SUPPRESSED(model: int, suppressed: bool) -> None:
    _iv(0x0FC2D89AC25A5814, model, suppressed)

def GET_TOTAL_DURATION_OF_VEHICLE_RECORDING_ID(id: int) -> float:
    return _if(0x102D125411A7B6E6, id)

def REMOVE_ROAD_NODE_SPEED_ZONE(speedzone: int) -> bool:
    return _ib(0x1033371FC8E842A7, speedzone)

def SET_VEHICLE_HANDLING_OVERRIDE(vehicle: int, hash: int) -> None:
    _iv(0x10655FAB9915623D, vehicle, hash)

def SET_SHORT_SLOWDOWN_FOR_LANDING(vehicle: int) -> None:
    _iv(0x107A473D7A6647A9, vehicle)

def SET_DONT_PROCESS_VEHICLE_GLASS(vehicle: int, toggle: bool) -> None:
    _iv(0x1087BC8EC540DAEB, vehicle, toggle)

def SET_VEHICLE_TURRET_SPEED_THIS_FRAME(vehicle: int, speed: float) -> None:
    _iv(0x1093408B4B9D1146, vehicle, speed)

def SET_VEHICLE_FIXED(vehicle: int) -> None:
    _iv(0x115722B1B9C14C1C, vehicle)

def ARE_ALL_VEHICLE_WINDOWS_INTACT(vehicle: int) -> bool:
    return _ib(0x11D862A3E977A9EF, vehicle)

def SET_CAN_USE_HYDRAULICS(vehicle: int, toggle: bool) -> None:
    _iv(0x1201E8A3290A3B98, vehicle, toggle)

def DOES_EXTRA_EXIST(vehicle: int, extraId: int) -> bool:
    return _ib(0x1262D55792428154, vehicle, extraId)

def IS_VEHICLE_IN_BURNOUT(vehicle: int) -> bool:
    return _ib(0x1297A88E081430EB, vehicle)

def SET_WHEELIE_ENABLED(vehicle: int, enabled: bool) -> None:
    _iv(0x1312DDD8385AEE4E, vehicle, enabled)

def _GET_VEHICLE_DRIVETRAIN_TYPE(vehicleModel: int) -> int:
    return _ii(0x1423725069EE1D14, vehicleModel)

def SET_DISABLE_VEHICLE_EXPLOSIONS_DAMAGE(toggle: bool) -> None:
    _iv(0x143921E45EC44D62, toggle)

def IS_VEHICLE_ATTACHED_TO_TOW_TRUCK(towTruck: int, vehicle: int) -> bool:
    return _ib(0x146DF9EC4C4B9FD4, towTruck, vehicle)

def SET_VEHICLE_SEARCHLIGHT(heli: int, toggle: bool, canBeUsedByAI: bool) -> None:
    _iv(0x14E85C5EE7A4D542, heli, toggle, canBeUsedByAI)

def SET_TRAIN_CRUISE_SPEED(train: int, speed: float) -> None:
    _iv(0x16469284DB8C62B5, train, speed)

def ATTACH_VEHICLE_ON_TO_TRAILER(vehicle: int, trailer: int, offsetX: float, offsetY: float, offsetZ: float, coordsX: float, coordsY: float, coordsZ: float, rotationX: float, rotationY: float, rotationZ: float, disableCollisions: float) -> None:
    _iv(0x16B5E274BDE402F8, vehicle, trailer, offsetX, offsetY, offsetZ, coordsX, coordsY, coordsZ, rotationX, rotationY, rotationZ, disableCollisions)

def _SET_MINIMUM_TIME_BETWEEN_GEAR_SHIFTS(vehicle: int, time: int) -> None:
    _iv(0x16CFBC5E7EB32861, vehicle, time)

def DOES_CARGOBOB_HAVE_PICK_UP_ROPE(cargobob: int) -> bool:
    return _ib(0x1821D91AD4B56108, cargobob)

def SET_VEHICLE_CUSTOM_PATH_NODE_STREAMING_RADIUS(vehicle: int, p1: float) -> None:
    _iv(0x182F266C2D9E2BEB, vehicle, p1)

def SET_VEHICLE_FRICTION_OVERRIDE(vehicle: int, friction: float) -> None:
    _iv(0x1837AF7C627009BA, vehicle, friction)

def SET_VEHICLE_CAN_LEAK_PETROL(vehicle: int, toggle: bool) -> None:
    _iv(0x192547247864DFDD, vehicle, toggle)

def _SET_VEHICLE_USE_HORN_BUTTON_FOR_NITROUS(toggle: bool) -> None:
    _iv(0x1980F68872CC2C3D, toggle)

def FULLY_CHARGE_NITROUS(vehicle: int) -> None:
    _iv(0x1A2BCC8C636F9226, vehicle)

def SET_CONVERTIBLE_ROOF_LATCH_STATE(vehicle: int, state: bool) -> None:
    _iv(0x1A78AD3D8240536F, vehicle, state)

def SET_VEHICLE_HAS_UNBREAKABLE_LIGHTS(vehicle: int, toggle: bool) -> None:
    _iv(0x1AA8A837D2169D94, vehicle, toggle)

def _SET_REMAINING_NITROUS_DURATION(vehicle: int, duration: float) -> None:
    _iv(0x1AD0F63A94E10EFF, vehicle, duration)

def SET_OPEN_REAR_DOORS_ON_EXPLOSION(vehicle: int, toggle: bool) -> None:
    _iv(0x1B212B26DD3C04DF, vehicle, toggle)

def VEHICLE_SET_ENABLE_RAMP_CAR_SIDE_IMPULSE(p0: int, p1: int) -> None:
    _iv(0x1BBAC99C0BC53656, p0, p1)

def HAS_VEHICLE_ASSET_LOADED(vehicleAsset: int) -> bool:
    return _ib(0x1BBE0523B8DB9A21, vehicleAsset)

def IS_PLAYBACK_GOING_ON_FOR_VEHICLE(vehicle: int) -> bool:
    return _ib(0x1C8A4C2C19E68EEC, vehicle)

def GET_VEHICLE_TRAILER_VEHICLE(vehicle: int, trailer: int) -> bool:
    return _ib(0x1CDD6BADC297830D, vehicle, trailer)

def SET_VEHICLE_STAYS_FROZEN_WHEN_CLEANED_UP(vehicle: int, toggle: bool) -> None:
    _iv(0x1CF38D529D7441D9, vehicle, toggle)

def SET_VEHICLE_USE_ALTERNATE_HANDLING(vehicle: int, toggle: bool) -> None:
    _iv(0x1D97D1E3A70A649F, vehicle, toggle)

def GET_IS_WHEELS_RETRACTED(vehicle: int) -> bool:
    return _ib(0x1DA0DA9CB3F0C8BF, vehicle)

def SET_VEHICLE_ALLOW_HOMING_MISSLE_LOCKON_SYNCED(vehicle: int, canBeLockedOn: bool, p2: bool) -> None:
    _iv(0x1DDA078D12879EEE, vehicle, canBeLockedOn, p2)

def IS_VEHICLE_HIGH_DETAIL(vehicle: int) -> bool:
    return _ib(0x1F25887F3C104278, vehicle)

def SET_VEHICLE_MOD_KIT(vehicle: int, modKit: int) -> None:
    _iv(0x1F2AA07F00B3217A, vehicle, modKit)

def FORCE_PLAYBACK_RECORDED_VEHICLE_UPDATE(vehicle: int, p1: bool) -> None:
    _iv(0x1F2E4E06DEA8992B, vehicle, p1)

def SET_CARGOBOB_EXCLUDE_FROM_PICKUP_ENTITY(p0: int, p1: int) -> None:
    _iv(0x1F34B0626C594380, p0, p1)

def SET_VEHICLE_ACT_AS_IF_HIGH_SPEED_FOR_FRAG_SMASHING(vehicle: int, p1: bool) -> None:
    _iv(0x1F9FB66F3A3842D2, vehicle, p1)

def _GET_IS_VEHICLE_ELECTRIC(vehicleModel: int) -> bool:
    return _ib(0x1FCB07FE230B6639, vehicleModel)

def SET_VEHICLE_HEADLIGHT_SHADOWS(vehicle: int, p1: int) -> None:
    _iv(0x1FD09E7390A74D54, vehicle, p1)

def SET_VEHICLE_EXTRA_COLOURS(vehicle: int, pearlescentColor: int, wheelColor: int) -> None:
    _iv(0x2036F561ADD12E33, vehicle, pearlescentColor, wheelColor)

def SET_VEHICLE_DOORS_LOCKED_FOR_ALL_TEAMS(vehicle: int, toggle: bool) -> None:
    _iv(0x203B527D1B77904C, vehicle, toggle)

def GET_ROTATION_OF_VEHICLE_RECORDING_AT_TIME(recording: int, time: float, script: str) -> 'gta.Vector3':
    return _ivec(0x2058206FBE79A8AD, recording, time, script)

def SET_VEHICLE_CAN_ENGINE_MISSFIRE(vehicle: int, toggle: bool) -> None:
    _iv(0x206BC5DC9D1AC70A, vehicle, toggle)

def SET_VEHICLE_ACTIVE_FOR_PED_NAVIGATION(vehicle: int, toggle: bool) -> None:
    _iv(0x21115BCD6E44656A, vehicle, toggle)

def SET_DISABLE_WEAPON_BLADE_FORCES(toggle: bool) -> None:
    _iv(0x211E95CE9903940C, toggle)

def GET_VEHICLE_RECORDING_ID(recording: int, script: str) -> int:
    return _ii(0x21543C612379DB3C, recording, script)

def GET_PED_USING_VEHICLE_DOOR(vehicle: int, doord: int) -> int:
    return _ii(0x218297BF0CFD853B, vehicle, doord)

def SET_TRAIN_TRACK_SPAWN_FREQUENCY(trackIndex: int, frequency: int) -> None:
    _iv(0x21973BBF8D17EDFA, trackIndex, frequency)

def RESET_VEHICLE_WHEELS(vehicle: int, toggle: bool) -> None:
    _iv(0x21D2E5662C1F6FED, vehicle, toggle)

def DELETE_SCRIPT_VEHICLE_GENERATOR(vehicleGenerator: int) -> None:
    _iv(0x22102C9ABFCF125D, vehicleGenerator)

def SET_VEHICLE_REDUCE_GRIP(vehicle: int, toggle: bool) -> None:
    _iv(0x222FF6A823D122E2, vehicle, toggle)

def IS_VEHICLE_SEAT_FREE(vehicle: int, seatIndex: int, isTaskRunning: bool) -> bool:
    return _ib(0x22AC59A870E6A669, vehicle, seatIndex, isTaskRunning)

def ALLOW_TRAIN_TO_BE_REMOVED_BY_POPULATION(p0: int) -> None:
    _iv(0x2310A8F9421EBF43, p0)

def SET_VEHICLE_RESPECTS_LOCKS_WHEN_HAS_DRIVER(vehicle: int, p1: bool) -> None:
    _iv(0x2311DD7159F00582, vehicle, p1)

def DISABLE_PLANE_AILERON(vehicle: int, p1: bool, p2: bool) -> None:
    _iv(0x23428FC53C60919C, vehicle, p1, p2)

def SET_VEHICLE_DENSITY_MULTIPLIER_THIS_FRAME(multiplier: float) -> None:
    _iv(0x245A6883D966D537, multiplier)

def _GET_VEHICLE_MAX_DRIVE_GEAR_COUNT(vehicle: int) -> int:
    return _ii(0x24910C3D66BA770D, vehicle)

def APPLY_EMP_EFFECT(vehicle: int) -> None:
    _iv(0x249249D74F813EB2, vehicle)

def SET_VEHICLE_ENGINE_ON(vehicle: int, value: bool, instantly: bool, disableAutoStart: bool) -> None:
    _iv(0x2497C4717C8B881E, vehicle, value, instantly, disableAutoStart)

def GET_VEHICLE_NUMBER_OF_PASSENGERS(vehicle: int, includeDriver: bool, includeDeadOccupants: bool) -> int:
    return _ii(0x24CB2137731FFE89, vehicle, includeDriver, includeDeadOccupants)

def CAN_ANCHOR_BOAT_HERE_IGNORE_PLAYERS(vehicle: int) -> bool:
    return _ib(0x24F4121D07579880, vehicle)

def SET_DISABLE_PRETEND_OCCUPANTS(vehicle: int, toggle: bool) -> None:
    _iv(0x25367DE49D64CF16, vehicle, toggle)

def GET_VEHICLE_DOOR_LOCK_STATUS(vehicle: int) -> int:
    return _ii(0x25BC98A59C2EA962, vehicle)

def DOES_VEHICLE_HAVE_WEAPONS(vehicle: int) -> bool:
    return _ib(0x25ECB9F8017D98E0, vehicle)

def BRING_VEHICLE_TO_HALT(vehicle: int, distance: float, duration: int, p3: bool) -> None:
    _iv(0x260BE8F09E326A20, vehicle, distance, duration, p3)

def SET_FAR_DRAW_VEHICLES(toggle: bool) -> None:
    _iv(0x26324F33423F3CC3, toggle)

def CAN_ANCHOR_BOAT_HERE(vehicle: int) -> bool:
    return _ib(0x26C10ECBDA5D043B, vehicle)

def SET_DISABLE_BMX_EXTRA_TRICK_FORCES(p0: int) -> None:
    _iv(0x26D99D5A82FD18E8, p0)

def SET_DISABLE_EXPLODE_FROM_BODY_DAMAGE_ON_COLLISION(vehicle: int, disable: bool) -> None:
    _iv(0x26E13D440E7F6064, vehicle, disable)

def SET_VEHICLE_GENERATES_ENGINE_SHOCKING_EVENTS(vehicle: int, toggle: bool) -> None:
    _iv(0x279D50DE5652D935, vehicle, toggle)

def IS_VEHICLE_BUMPER_BOUNCING(vehicle: int, frontBumper: bool) -> bool:
    return _ib(0x27B926779DEB502D, vehicle, frontBumper)

def _SET_ALLOW_COLLISION_WHEN_IN_VEHICLE(vehicle: int, toggle: bool) -> None:
    _iv(0x27D27223E8EF22ED, vehicle, toggle)

def SET_HYDRAULICS_CONTROL(vehicle: int, toggle: bool) -> None:
    _iv(0x28B18377EB6E25F6, vehicle, toggle)

def VEHICLE_SET_RAMP_AND_RAMMING_CARS_TAKE_DAMAGE(vehicle: int, toggle: bool) -> None:
    _iv(0x28D034A93FE31BF5, vehicle, toggle)

def GET_VEHICLE_LAYOUT_HASH(vehicle: int) -> int:
    return _ii(0x28D37D4F71AC5C58, vehicle)

def IS_ANY_PED_RAPPELLING_FROM_HELI(vehicle: int) -> bool:
    return _ib(0x291E373D483E7EE7, vehicle)

def GET_VEHICLE_CLASS(vehicle: int) -> int:
    return _ii(0x29439776AAA00A62, vehicle)

def IS_VEHICLE_STOPPED_AT_TRAFFIC_LIGHTS(vehicle: int) -> bool:
    return _ib(0x2959F696AE390A99, vehicle)

def SET_INCREASE_WHEEL_CRUSH_DAMAGE(vehicle: int, toggle: bool) -> None:
    _iv(0x2970EAA18FD5E42F, vehicle, toggle)

def ATTACH_VEHICLE_TO_TOW_TRUCK(towTruck: int, vehicle: int, rear: bool, hookOffsetX: float, hookOffsetY: float, hookOffsetZ: float) -> None:
    _iv(0x29A16F8D621C4508, towTruck, vehicle, rear, hookOffsetX, hookOffsetY, hookOffsetZ)

def SET_VEHICLE_WHEELS_CAN_BREAK(vehicle: int, enabled: bool) -> None:
    _iv(0x29B18B4FD460CA8F, vehicle, enabled)

def START_PLAYBACK_RECORDED_VEHICLE_USING_AI(vehicle: int, recording: int, script: str, speed: float, drivingStyle: int) -> None:
    _iv(0x29DE5FA52D00428C, vehicle, recording, script, speed, drivingStyle)

def TOGGLE_VEHICLE_MOD(vehicle: int, modType: int, toggle: bool) -> None:
    _iv(0x2A1F4F37F95BAD08, vehicle, modType, toggle)

def TRANSFORM_TO_CAR(vehicle: int, noAnimation: bool) -> None:
    _iv(0x2A69FFD1B42BFF9E, vehicle, noAnimation)

def SET_PLANE_ENGINE_HEALTH(vehicle: int, health: float) -> None:
    _iv(0x2A86A0475B6A1434, vehicle, health)

def SET_TRAILER_INVERSE_MASS_SCALE(vehicle: int, p1: float) -> None:
    _iv(0x2A8F319B392E7B3F, vehicle, p1)

def SET_VEHICLE_NEON_ENABLED(vehicle: int, index: int, toggle: bool) -> None:
    _iv(0x2AA720E4287BF269, vehicle, index, toggle)

def GET_VEHICLE_MODEL_NUMBER_OF_SEATS(modelHash: int) -> int:
    return _ii(0x2AD93716F184EDA4, modelHash)

def SET_GARBAGE_TRUCKS(toggle: bool) -> None:
    _iv(0x2AFD795EEAC8D30D, toggle)

def SET_VEHICLE_HAS_BEEN_OWNED_BY_PLAYER(vehicle: int, owned: bool) -> None:
    _iv(0x2B5F9D2AF1F1722D, vehicle, owned)

def SET_VEHICLE_DISABLE_TOWING(vehicle: int, toggle: bool) -> None:
    _iv(0x2B6747FAA9DB9D6B, vehicle, toggle)

def GET_VEHICLE_LIVERY(vehicle: int) -> int:
    return _ii(0x2BB9230590DA5E8A, vehicle)

def CAN_CARGOBOB_PICK_UP_ENTITY(p0: int, p1: int) -> bool:
    return _ib(0x2C1D8B3B19E517CC, p0, p1)

def SET_VEHICLE_WILL_TELL_OTHERS_TO_HURRY(vehicle: int, p1: bool) -> None:
    _iv(0x2C4A1590ABF43E8B, vehicle, p1)

def GET_VEHICLE_NUM_OF_BROKEN_LOOSEN_PARTS(vehicle: int) -> int:
    return _ii(0x2C8CBFE1EA5FC631, vehicle)

def ADD_ROAD_NODE_SPEED_ZONE(x: float, y: float, z: float, radius: float, speed: float, p5: bool) -> int:
    return _ii(0x2CE544C68FB812A0, x, y, z, radius, speed, p5)

def ARE_ANY_VEHICLE_SEATS_FREE(vehicle: int) -> bool:
    return _ib(0x2D34FC3BC4ADB780, vehicle)

def SET_DISABLE_HOVER_MODE_FLIGHT(vehicle: int, toggle: bool) -> None:
    _iv(0x2D55FE374D5FDB91, vehicle, toggle)

def GET_POSITION_IN_RECORDING(vehicle: int) -> float:
    return _if(0x2DACD605FC681475, vehicle)

def SET_VEHICLE_TIMED_EXPLOSION(vehicle: int, ped: int, toggle: bool) -> None:
    _iv(0x2E0A74E1002380B1, vehicle, ped, toggle)

def GET_DRIFT_TYRES_SET(vehicle: int) -> bool:
    return _ib(0x2F5A72430E78C8D3, vehicle)

def GET_VEHICLE_CLASS_MAX_ACCELERATION(vehicleClass: int) -> float:
    return _if(0x2F83E7E45D9EA7AE, vehicleClass)

def SET_DOOR_ALLOWED_TO_BE_BROKEN_OFF(vehicle: int, doorId: int, isBreakable: bool) -> None:
    _iv(0x2FA133A4A9D37ED8, vehicle, doorId, isBreakable)

def SET_TRAILER_ATTACHMENT_ENABLED(p0: int, p1: int) -> None:
    _iv(0x2FA2494B47FDD009, p0, p1)

def ADD_VEHICLE_STUCK_CHECK_WITH_WARP(p0: int, p1: float, p2: int, p3: bool, p4: bool, p5: bool, p6: int) -> None:
    _iv(0x2FA9923062DD396C, p0, p1, p2, p3, p4, p5, p6)

def SET_VEHICLE_CAN_BE_USED_BY_FLEEING_PEDS(vehicle: int, toggle: bool) -> None:
    _iv(0x300504B23BD3B711, vehicle, toggle)

def HAS_VEHICLE_RECORDING_BEEN_LOADED(recording: int, script: str) -> bool:
    return _ib(0x300D614A4C785FC4, recording, script)

def CAN_SHUFFLE_SEAT(vehicle: int, seatIndex: int) -> bool:
    return _ib(0x30785D90C956BF35, vehicle, seatIndex)

def SET_VEHICLE_FLIGHT_NOZZLE_POSITION(vehicle: int, angleRatio: float) -> None:
    _iv(0x30D779DE7C4F6DD3, vehicle, angleRatio)

def SET_RENDER_TRAIN_AS_DERAILED(train: int, toggle: bool) -> None:
    _iv(0x317B11A312DF5534, train, toggle)

def SET_VEHICLE_IS_CONSIDERED_BY_PLAYER(vehicle: int, toggle: bool) -> None:
    _iv(0x31B927BBC44156CD, vehicle, toggle)

def DISABLE_VEHICLE_TURRET_MOVEMENT_THIS_FRAME(vehicle: int) -> None:
    _iv(0x32CAEDF24A583345, vehicle)

def FORCE_SUBMARINE_SURFACE_MODE(vehicle: int, toggle: bool) -> None:
    _iv(0x33506883545AC0DF, vehicle, toggle)

def _SET_TRANSMISSION_REDUCED_GEAR_RATIO(vehicle: int, toggle: bool) -> None:
    _iv(0x337EF33DA3DDB990, vehicle, toggle)

def SET_VEHICLE_COLOUR_COMBINATION(vehicle: int, colorCombination: int) -> None:
    _iv(0x33E8CD3322E2FE31, vehicle, colorCombination)

def GET_NUM_MOD_KITS(vehicle: int) -> int:
    return _ii(0x33F2E3FE70EAAE1D, vehicle)

def SET_ALLOW_VEHICLE_EXPLODES_ON_CONTACT(vehicle: int, toggle: bool) -> None:
    _iv(0x3441CAD2F2231923, vehicle, toggle)

def SET_ALL_VEHICLE_GENERATORS_ACTIVE() -> None:
    _iv(0x34AD89078831A4BC)

def SET_VEHICLE_LIGHTS(vehicle: int, state: int) -> None:
    _iv(0x34E710FF01247C5A, vehicle, state)

def CLOSE_BOMB_BAY_DOORS(vehicle: int) -> None:
    _iv(0x3556041742A0DC74, vehicle)

def SET_VEHICLE_OCCUPANTS_TAKE_EXPLOSIVE_DAMAGE(vehicle: int, toggle: bool) -> None:
    _iv(0x35BB21DE06784373, vehicle, toggle)

def SET_AMBIENT_VEHICLE_NEON_ENABLED(p0: bool) -> None:
    _iv(0x35E0654F4BAD7971, p0)

def GET_VEHICLE_CURRENT_TIME_IN_SLIP_STREAM(vehicle: int) -> float:
    return _if(0x36492C2F0D134C56, vehicle)

def SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(vehicle: int, r: int, g: int, b: int) -> None:
    _iv(0x36CED73BFED89754, vehicle, r, g, b)

def GET_HAS_ROCKET_BOOST(vehicle: int) -> bool:
    return _ib(0x36D782F68B309BDA, vehicle)

def SET_VEHICLE_COMBAT_MODE(toggle: bool) -> None:
    _iv(0x36DE109527A2C0C4, toggle)

def STABILISE_ENTITY_ATTACHED_TO_HELI(vehicle: int, entity: int, p2: float) -> None:
    _iv(0x374706271354CB18, vehicle, entity, p2)

def SET_VEHICLE_CAN_BE_TARGETTED(vehicle: int, state: bool) -> None:
    _iv(0x3750146A28097A82, vehicle, state)

def FIND_HANDLER_VEHICLE_CONTAINER_IS_ATTACHED_TO(entity: int) -> int:
    return _ii(0x375E7FC44F21C8AB, entity)

def SET_DISABLE_VEHICLE_PETROL_TANK_DAMAGE(vehicle: int, toggle: bool) -> None:
    _iv(0x37C8252A7C92D017, vehicle, toggle)

def SET_FORKLIFT_FORK_HEIGHT(vehicle: int, height: float) -> None:
    _iv(0x37EBBF3117BD6A25, vehicle, height)

def GET_RANDOM_VEHICLE_IN_SPHERE(x: float, y: float, z: float, radius: float, modelHash: int, flags: int) -> int:
    return _ii(0x386F6CE5BAF6091C, x, y, z, radius, modelHash, flags)

def SET_TYRE_WEAR_RATE_SCALE(vehicle: int, wheelIndex: int, multiplier: float) -> None:
    _iv(0x392183BB9EA57697, vehicle, wheelIndex, multiplier)

def IS_THIS_MODEL_A_QUADBIKE(model: int) -> bool:
    return _ib(0x39DAC362EE65FA28, model)

def SET_REDUCED_SUSPENSION_FORCE(vehicle: int, enable: bool) -> None:
    _iv(0x3A375167F5782A65, vehicle, enable)

def GET_OUTRIGGERS_DEPLOYED(vehicle: int) -> bool:
    return _ib(0x3A9128352EAC9E85, vehicle)

def SET_VEHICLE_ENVEFF_SCALE(vehicle: int, fade: float) -> None:
    _iv(0x3AFDC536C3D01674, vehicle, fade)

def SET_VEHICLE_DOOR_AUTO_LOCK(vehicle: int, doorId: int, toggle: bool) -> None:
    _iv(0x3B458DDB57038F08, vehicle, doorId, toggle)

def GET_NUMBER_OF_VEHICLE_COLOURS(vehicle: int) -> int:
    return _ii(0x3B963160CD65D41E, vehicle)

def GET_VEHICLE_EXTRA_COLOURS(vehicle: int, pearlescentColor: int, wheelColor: int) -> None:
    _iv(0x3BC4245933A166F7, vehicle, pearlescentColor, wheelColor)

def ATTACH_VEHICLE_TO_TRAILER(vehicle: int, trailer: int, radius: float) -> None:
    _iv(0x3C7D42D58F770B54, vehicle, trailer, radius)

def IS_ROCKET_BOOST_ACTIVE(vehicle: int) -> bool:
    return _ib(0x3D34E80EED4AE3BE, vehicle)

def IS_VEHICLE_PARACHUTE_DEPLOYED(vehicle: int) -> bool:
    return _ib(0x3DE51E9C80B116CF, vehicle)

def GET_VEHICLE_XENON_LIGHT_COLOR_INDEX(vehicle: int) -> int:
    return _ii(0x3DFF319A831E0CDB, vehicle)

def GET_SUBMARINE_IS_UNDER_DESIGN_DEPTH(submarine: int) -> bool:
    return _ib(0x3E71D0B300B7AA79, submarine)

def SET_VEHICLE_STRONG(vehicle: int, toggle: bool) -> None:
    _iv(0x3E8C8727991A8A0B, vehicle, toggle)

def IS_VEHICLE_DOOR_FULLY_OPEN(vehicle: int, doorId: int) -> bool:
    return _ib(0x3E933CFF7B111C22, vehicle, doorId)

def SET_HELI_TAIL_BOOM_CAN_BREAK_OFF(vehicle: int, toggle: bool) -> bool:
    return _ib(0x3EC8BF18AA453FE9, vehicle, toggle)

def _GET_VEHICLE_MAX_EXHAUST_BONE_COUNT() -> int:
    return _ii(0x3EE18B00CD86C54F)

def START_PLAYBACK_RECORDED_VEHICLE(vehicle: int, recording: int, script: str, p3: bool) -> None:
    _iv(0x3F878F92B3A7A071, vehicle, recording, script, p3)

def SET_HELI_MAIN_ROTOR_HEALTH(vehicle: int, health: float) -> None:
    _iv(0x4056EA1105F5ABD7, vehicle, health)

def SET_VEHICLE_HOMING_LOCKEDONTO_STATE(p0: int, p1: int) -> None:
    _iv(0x407DC5E97DB1A4D3, p0, p1)

def SET_VEHICLE_AI_CAN_USE_EXCLUSIVE_SEATS(vehicle: int, toggle: bool) -> None:
    _iv(0x41062318F23ED854, vehicle, toggle)

def ATTACH_VEHICLE_TO_CARGOBOB(cargobob: int, vehicle: int, p2: int, x: float, y: float, z: float) -> None:
    _iv(0x4127F1D84E347769, cargobob, vehicle, p2, x, y, z)

def SET_VEHICLE_USE_BOOST_BUTTON_FOR_WHEEL_RETRACT(toggle: bool) -> None:
    _iv(0x41290B40FA63E6DA, toggle)

def IS_PLANE_LANDING_GEAR_INTACT(plane: int) -> bool:
    return _ib(0x4198AB0022B15F87, plane)

def SET_TRANSFORM_TO_SUBMARINE_USES_ALTERNATE_INPUT(vehicle: int, toggle: bool) -> None:
    _iv(0x41B9FB92EDED32A6, vehicle, toggle)

def IS_VEHICLE_MODEL(vehicle: int, model: int) -> bool:
    return _ib(0x423E8DE37D934D89, vehicle, model)

def SET_FORMATION_LEADER(vehicle: int, x: float, y: float, z: float, p4: float) -> None:
    _iv(0x428AD3E26C8D9EB0, vehicle, x, y, z, p4)

def SET_VEHICLE_CAN_SAVE_IN_GARAGE(vehicle: int, toggle: bool) -> None:
    _iv(0x428BACCDF5E26EAD, vehicle, toggle)

def GET_VEHICLE_NUM_OF_BROKEN_OFF_PARTS(vehicle: int) -> int:
    return _ii(0x42A4BEB35D372407, vehicle)

def SET_VEHICLE_STEER_BIAS(vehicle: int, value: float) -> None:
    _iv(0x42A8EC77D5150CBE, vehicle, value)

def GET_CURRENT_PLAYBACK_FOR_VEHICLE(vehicle: int) -> int:
    return _ii(0x42BC05C27A946054, vehicle)

def SET_GROUND_EFFECT_REDUCES_DRAG(toggle: bool) -> None:
    _iv(0x430A7631A84C9BE7, toggle)

def IS_VEHICLE_ALARM_ACTIVATED(vehicle: int) -> bool:
    return _ib(0x4319E335B71FFF34, vehicle)

def SET_SPECIAL_FLIGHT_MODE_TARGET_RATIO(vehicle: int, targetRatio: float) -> None:
    _iv(0x438B3D7CA026FE91, vehicle, targetRatio)

def SET_VEHICLE_MOD_COLOR_1(vehicle: int, paintType: int, color: int, pearlescentColor: int) -> None:
    _iv(0x43FEB945EE7F85B8, vehicle, paintType, color, pearlescentColor)

def CLEAR_VEHICLE_PETROLTANK_FIRE_CULPRIT(vehicle: int) -> None:
    _iv(0x4419966C9936071A, vehicle)

def RELEASE_PRELOAD_MODS(vehicle: int) -> None:
    _iv(0x445D79F995508307, vehicle)

def SET_VEHICLE_WEAPON_RESTRICTED_AMMO(vehicle: int, weaponIndex: int, capacity: int) -> None:
    _iv(0x44CD1F493DB2A0A6, vehicle, weaponIndex, capacity)

def GET_VEHICLE_MOD_IDENTIFIER_HASH(vehicle: int, modType: int, modIndex: int) -> int:
    return _ii(0x4593CF82AA179706, vehicle, modType, modIndex)

def SET_VEHICLE_WEAPON_DAMAGE_SCALE(vehicle: int, multiplier: float) -> bool:
    return _ib(0x45A561A9421AB6AD, vehicle, multiplier)

def IS_THIS_MODEL_A_BOAT(model: int) -> bool:
    return _ib(0x45A9187928F4B9E3, model)

def SET_VEHICLE_ENGINE_HEALTH(vehicle: int, health: float) -> None:
    _iv(0x45F6D8EEF34ABEF1, vehicle, health)

def SET_DISABLE_VEHICLE_PETROL_TANK_FIRES(vehicle: int, toggle: bool) -> None:
    _iv(0x465BF26AB9684352, vehicle, toggle)

def _SET_NITROUS_IS_VISIBLE(vehicle: int, enabled: bool) -> None:
    _iv(0x465EEA70AF251045, vehicle, enabled)

def IS_VEHICLE_BUMPER_BROKEN_OFF(vehicle: int, frontBumper: bool) -> bool:
    return _ib(0x468056A6BB6F3846, vehicle, frontBumper)

def REMOVE_VEHICLES_FROM_GENERATORS_IN_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, p6: int) -> None:
    _iv(0x46A1E1A299EC4BBA, x1, y1, z1, x2, y2, z2, p6)

def IS_VEHICLE_WINDOW_INTACT(vehicle: int, windowIndex: int) -> bool:
    return _ib(0x46E571A0E20D01F1, vehicle, windowIndex)

def SET_VEHICLE_WHEEL_TYPE(vehicle: int, WheelType: int) -> None:
    _iv(0x487EB21CC7295BA1, vehicle, WheelType)

def INSTANTLY_FILL_VEHICLE_POPULATION() -> None:
    _iv(0x48ADC8A773564670)

def _SET_ATTACHED_VEHICLE_TO_TOW_TRUCK_ARM(towTruck: int, vehicle: int) -> None:
    _iv(0x48BD57D0DD17786A, towTruck, vehicle)

def IS_VEHICLE_PRODUCING_SLIP_STREAM(vehicle: int) -> bool:
    return _ib(0x48C633E94A8142A7, vehicle)

def IS_NITROUS_ACTIVE(vehicle: int) -> bool:
    return _ib(0x491E822B2C464FE4, vehicle)

def GET_VEHICLE_MOD_COLOR_2_NAME(vehicle: int) -> str:
    return _is(0x4967A516ED23A5A1, vehicle)

def SET_VEHICLE_ON_GROUND_PROPERLY(vehicle: int, p1: float) -> bool:
    return _ib(0x49733E92263139D1, vehicle, p1)

def SET_TRANSFORM_RATE_FOR_ANIMATION(vehicle: int, transformRate: float) -> None:
    _iv(0x498218259FB7C72D, vehicle, transformRate)

def SET_DISABLE_WANTED_CONES_RESPONSE(vehicle: int, toggle: bool) -> None:
    _iv(0x4AD280EB48B2D8E6, vehicle, toggle)

def IS_VEHICLE_STOLEN(vehicle: int) -> bool:
    return _ib(0x4AF9BD80EEBEB453, vehicle)

def GET_VEHICLE_CLASS_MAX_BRAKING(vehicleClass: int) -> float:
    return _if(0x4BF54C16EC8FEC03, vehicleClass)

def IS_VEHICLE_DRIVEABLE(vehicle: int, isOnFireCheck: bool) -> bool:
    return _ib(0x4C241E39B23DF959, vehicle, isOnFireCheck)

def GET_NUMBER_OF_VEHICLE_NUMBER_PLATES() -> int:
    return _ii(0x4C4D6B2644F458CB)

def SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(vehicle: int, state: bool) -> None:
    _iv(0x4C7028F78FFD3681, vehicle, state)

def SET_PLANE_PROPELLER_HEALTH(plane: int, health: float) -> bool:
    return _ib(0x4C815EB175086F84, plane, health)

def IS_VEHICLE_SIREN_ON(vehicle: int) -> bool:
    return _ib(0x4C9BF537BE2634B2, vehicle)

def VEHICLE_SET_PARACHUTE_MODEL_OVERRIDE(vehicle: int, modelHash: int) -> None:
    _iv(0x4D610C6B56031351, vehicle, modelHash)

def SET_FORCE_VEHICLE_ENGINE_DAMAGE_BY_BULLET(p0: int, p1: bool) -> None:
    _iv(0x4D9D109F63FEE1D4, p0, p1)

def SET_VEHICLE_DAMAGE_SCALE(vehicle: int, p1: float) -> bool:
    return _ib(0x4E20D2A627011E8E, vehicle, p1)

def DOES_VEHICLE_ALLOW_RAPPEL(vehicle: int) -> bool:
    return _ib(0x4E417C547182C84D, vehicle)

def SET_POLICE_FOCUS_WILL_TRACK_VEHICLE(vehicle: int, toggle: bool) -> None:
    _iv(0x4E74E62E0A97E901, vehicle, toggle)

def GET_VEHICLE_DEFORMATION_AT_POS(vehicle: int, offsetX: float, offsetY: float, offsetZ: float) -> 'gta.Vector3':
    return _ivec(0x4EC6CFBC7B2E9536, vehicle, offsetX, offsetY, offsetZ)

def SET_VEHICLE_COLOURS(vehicle: int, colorPrimary: int, colorSecondary: int) -> None:
    _iv(0x4F1D4BE3A7F24601, vehicle, colorPrimary, colorSecondary)

def GET_VEHICLE_CLASS_MAX_AGILITY(vehicleClass: int) -> float:
    return _if(0x4F930AD022D6DE3B, vehicleClass)

def DISABLE_INDIVIDUAL_PLANE_PROPELLER(vehicle: int, propeller: int) -> None:
    _iv(0x500873A45724C863, vehicle, propeller)

def GET_VEHICLE_HAS_KERS(vehicle: int) -> bool:
    return _ib(0x50634E348C8D44EF, vehicle)

def SET_VEHICLE_DOORS_LOCKED_FOR_PLAYER(vehicle: int, player: int, toggle: bool) -> None:
    _iv(0x517AAF684BB50CD1, vehicle, player, toggle)

def SET_VEHICLE_CAN_LEAK_OIL(vehicle: int, toggle: bool) -> None:
    _iv(0x51BB2D88D31A914B, vehicle, toggle)

def NETWORK_ENABLE_EMPTY_CROWDING_VEHICLES_REMOVAL(toggle: bool) -> None:
    _iv(0x51DB102F4A3BA5E0, toggle)

def GET_MOD_SLOT_NAME(vehicle: int, modType: int) -> str:
    return _is(0x51F0FEB9F6AE98C0, vehicle, modType)

def GET_CAN_VEHICLE_BE_PLACED_HERE(vehicle: int, x: float, y: float, z: float, rotX: float, rotY: float, rotZ: float, p7: int, p8: int) -> bool:
    return _ib(0x51F30DB60626A20E, vehicle, x, y, z, rotX, rotY, rotZ, p7, p8)

def SET_CAN_RESPRAY_VEHICLE(vehicle: int, state: bool) -> None:
    _iv(0x52BBA29D5EC69356, vehicle, state)

def IS_VEHICLE_A_CONVERTIBLE(vehicle: int, p1: bool) -> bool:
    return _ib(0x52F357A30698BCCE, vehicle, p1)

def SET_WHEELS_RETRACTED_INSTANTLY(vehicle: int) -> None:
    _iv(0x5335BE58C083E74E, vehicle)

def GET_VEHICLE_MODEL_ACCELERATION_MAX_MODS(modelHash: int) -> float:
    return _if(0x53409B5163D5B846, modelHash)

def IS_EXTRA_BROKEN_OFF(vehicle: int, extraId: int) -> bool:
    return _ib(0x534E36D4DB9ECC5D, vehicle, extraId)

def GET_FAKE_SUSPENSION_LOWERING_AMOUNT(vehicle: int) -> float:
    return _if(0x53952FD2BAA19F17, vehicle)

def GET_VEHICLE_MODEL_MAX_TRACTION(modelHash: int) -> float:
    return _if(0x539DE94D44FDFD0D, modelHash)

def GET_VEHICLE_ESTIMATED_MAX_SPEED(vehicle: int) -> float:
    return _if(0x53AF99BAA671CA47, vehicle)

def SET_GLIDER_ACTIVE(vehicle: int, state: bool) -> None:
    _iv(0x544996C0081ABDEB, vehicle, state)

def STOP_PLAYBACK_RECORDED_VEHICLE(vehicle: int) -> None:
    _iv(0x54833611C17ABDEA, vehicle)

def ADD_VEHICLE_COMBAT_ANGLED_AVOIDANCE_AREA(p0: float, p1: float, p2: float, p3: float, p4: float, p5: float, p6: float) -> int:
    return _ii(0x54B0F614960F4A5F, p0, p1, p2, p3, p4, p5, p6)

def CLEAR_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle: int) -> None:
    _iv(0x55E1D2758F34E437, vehicle)

def GET_TYRE_HEALTH(vehicle: int, wheelIndex: int) -> float:
    return _if(0x55EAB010FAEE9380, vehicle, wheelIndex)

def _GET_VEHICLE_CURRENT_DRIVE_GEAR(vehicle: int) -> int:
    return _ii(0x56185A25D45A0DCD, vehicle)

def IS_VEHICLE_WEAPON_DISABLED(weaponHash: int, vehicle: int, owner: int) -> bool:
    return _ib(0x563B65A643ED072E, weaponHash, vehicle, owner)

def SET_VEHICLE_TANK_TURRET_POSITION(vehicle: int, position: float, p2: bool) -> None:
    _iv(0x56B94C6D7127DFBA, vehicle, position, p2)

def SET_CARGOBOB_PICKUP_MAGNET_ENSURE_PICKUP_ENTITY_UPRIGHT(vehicle: int, p1: bool) -> None:
    _iv(0x56EB5E94318D3FB6, vehicle, p1)

def SET_CARGOBOB_FORCE_DONT_DETACH_VEHICLE(cargobob: int, toggle: bool) -> None:
    _iv(0x571FEB383F629926, cargobob, toggle)

def IS_VEHICLE_STOPPED(vehicle: int) -> bool:
    return _ib(0x5721B434AD84D57A, vehicle)

def GET_TIME_POSITION_IN_RECORDING(vehicle: int) -> float:
    return _if(0x5746F3A7AB7FE544, vehicle)

def IS_ENTITY_ATTACHED_TO_HANDLER_FRAME(vehicle: int, entity: int) -> bool:
    return _ib(0x57715966069157AD, vehicle, entity)

def SET_VEHICLE_WINDOW_TINT(vehicle: int, tint: int) -> None:
    _iv(0x57C51E6BAD752696, vehicle, tint)

def DOES_VEHICLE_HAVE_STUCK_VEHICLE_CHECK(vehicle: int) -> bool:
    return _ib(0x57E4C39DE5EE8470, vehicle)

def SET_VEHICLE_TAIL_LIGHTS(vehicle: int, toggle: bool) -> None:
    _iv(0x5815BD2763178DF4, vehicle, toggle)

def SET_ADDITIONAL_ROTATION_FOR_RECORDED_VEHICLE_PLAYBACK(vehicle: int, x: float, y: float, z: float, p4: int) -> None:
    _iv(0x5845066D8A1EA7F7, vehicle, x, y, z, p4)

def GET_VEHICLE_MODEL_VALUE(vehicleModel: int) -> int:
    return _ii(0x5873C14A52D74236, vehicleModel)

def SET_MISSION_TRAIN_COORDS(train: int, x: float, y: float, z: float) -> None:
    _iv(0x591CA673AA6AB736, train, x, y, z)

def SET_TAXI_LIGHTS(vehicle: int, state: bool) -> None:
    _iv(0x598803E85E8448D9, vehicle, state)

def ARE_WINGS_OF_PLANE_INTACT(plane: int) -> bool:
    return _ib(0x5991A01434CE9677, plane)

def SET_VEHICLE_CAN_BREAK(vehicle: int, toggle: bool) -> None:
    _iv(0x59BF8C3D52C92F66, vehicle, toggle)

def SET_PEDS_CAN_FALL_OFF_THIS_VEHICLE_FROM_LARGE_FALL_DAMAGE(vehicle: int, toggle: bool, p2: float) -> None:
    _iv(0x59C3757B3B7408E8, vehicle, toggle, p2)

def GET_BOAT_VEHICLE_MODEL_AGILITY(modelHash: int) -> float:
    return _if(0x5AA3F878A178C4FC, modelHash)

def SET_DRIFT_TYRES(vehicle: int, toggle: bool) -> None:
    _iv(0x5AC79C98C5C17F05, vehicle, toggle)

def _SET_VEHICLE_MAX_LAUNCH_ENGINE_REVS(vehicle: int, modifier: float) -> None:
    _iv(0x5AE614ECA5FDD423, vehicle, modifier)

def SET_VEHICLE_PROVIDES_COVER(vehicle: int, toggle: bool) -> None:
    _iv(0x5AFEEDD9BB2899D7, vehicle, toggle)

def DELETE_MISSION_TRAIN(train: int) -> None:
    _iv(0x5B76B14AE875C795, train)

def SET_INVERT_VEHICLE_CONTROLS(vehicle: int, state: bool) -> None:
    _iv(0x5B91B229243351A8, vehicle, state)

def HAS_VEHICLE_PETROLTANK_SET_ON_FIRE_BY_ENTITY(p0: int, p1: int) -> bool:
    return _ib(0x5BA68A0840D546AC, p0, p1)

def SET_USE_DOUBLE_CLICK_FOR_CAR_JUMP(toggle: bool) -> None:
    _iv(0x5BBCF35BF6E456F7, toggle)

def SET_VEHICLE_ALLOW_NO_PASSENGERS_LOCKON(veh: int, toggle: bool) -> None:
    _iv(0x5D14D4154BFE7B2C, veh, toggle)

def GET_VEHICLE_ACCELERATION(vehicle: int) -> float:
    return _if(0x5DD35C8D074E57AE, vehicle)

def SET_VEHICLE_NO_EXPLOSION_DAMAGE_FROM_DRIVER(vehicle: int, toggle: bool) -> None:
    _iv(0x5E569EC46EC21CAE, vehicle, toggle)

def GET_VEHICLE_LIVERY2_COUNT(vehicle: int) -> int:
    return _ii(0x5ECB40269053C0D4, vehicle)

def OVERRIDE_PLANE_DAMAGE_THREHSOLD(vehicle: int, health: float) -> None:
    _iv(0x5EE5632F47AE9695, vehicle, health)

def GET_IS_LEFT_VEHICLE_HEADLIGHT_DAMAGED(vehicle: int) -> bool:
    return _ib(0x5EF77C9ADD3B11A3, vehicle)

def CLEAR_VEHICLE_CUSTOM_SECONDARY_COLOUR(vehicle: int) -> None:
    _iv(0x5FFBDEEC3E8E2009, vehicle)

def GET_VEHICLE_LIVERY2(vehicle: int) -> int:
    return _ii(0x60190048C0764A26, vehicle)

def ROLL_UP_WINDOW(vehicle: int, windowIndex: int) -> None:
    _iv(0x602E548F46E24D59, vehicle, windowIndex)

def SET_ALL_LOW_PRIORITY_VEHICLE_GENERATORS_ACTIVE(active: bool) -> None:
    _iv(0x608207E7A8FB787C, active)

def SET_VEHICLE_EXTRA_COLOUR_6(vehicle: int, color: int) -> None:
    _iv(0x6089CDF6A57F326C, vehicle, color)

def SET_VEHICLE_LIVERY(vehicle: int, livery: int) -> None:
    _iv(0x60BF608F1B8CD1B6, vehicle, livery)

def IS_ANY_VEHICLE_NEAR_POINT(x: float, y: float, z: float, radius: float) -> bool:
    return _ib(0x61E1DD6125A3EEE6, x, y, z, radius)

def _GET_VEHICLE_MODEL_NUM_DRIVE_GEARS(vehicleModel: int) -> int:
    return _ii(0x61F02E4E9A7A61EA, vehicleModel)

def IS_ANY_ENTITY_ATTACHED_TO_HANDLER_FRAME(vehicle: int) -> bool:
    return _ib(0x62CA17B74C435651, vehicle)

def GET_VEHICLE_MOD_KIT(vehicle: int) -> int:
    return _ii(0x6325D1A044AE510D, vehicle)

def PAUSE_PLAYBACK_RECORDED_VEHICLE(vehicle: int) -> None:
    _iv(0x632A689BF42301B1, vehicle)

def IS_THIS_MODEL_AN_AMPHIBIOUS_CAR(model: int) -> bool:
    return _ib(0x633F6F44A537EBB6, model)

def IS_HELI_LANDING_AREA_BLOCKED(vehicle: int) -> bool:
    return _ib(0x634148744F385576, vehicle)

def IS_ENTRY_POINT_FOR_SEAT_CLEAR(ped: int, vehicle: int, seatIndex: int, side: bool, onEnter: bool) -> bool:
    return _ib(0x639431E895B9AA57, ped, vehicle, seatIndex, side, onEnter)

def CREATE_MISSION_TRAIN(variation: int, x: float, y: float, z: float, direction: bool, p5: int, p6: int) -> int:
    return _ii(0x63C6CCA8E68AE8C8, variation, x, y, z, direction, p5, p6)

def TRACK_VEHICLE_VISIBILITY(vehicle: int) -> None:
    _iv(0x64473AEFDCF47DCA, vehicle)

def GET_IS_DOOR_VALID(vehicle: int, doorId: int) -> bool:
    return _ib(0x645F4B6E8499F632, vehicle, doorId)

def SET_VEHICLE_FORWARD_SPEED_XY(vehicle: int, speed: float) -> None:
    _iv(0x6501129C9E0FFA05, vehicle, speed)

def SET_SLOW_DOWN_EFFECT_DISABLED(disabled: bool) -> None:
    _iv(0x65B080555EA48149, disabled)

def GET_BOAT_BOOM_POSITION_RATIO(vehicle: int) -> float:
    return _if(0x6636C535F6CC2725, vehicle)

def _IS_VEHICLE_GEN9_EXCLUSIVE_MODEL(vehicleModel: int) -> bool:
    return _ib(0x6638C0F19DE692FE, vehicleModel)

def SET_PLAYBACK_SPEED(vehicle: int, speed: float) -> None:
    _iv(0x6683AB880E427778, vehicle, speed)

def SET_CARGOBOB_PICKUP_MAGNET_REDUCED_STRENGTH(cargobob: int, p1: float) -> None:
    _iv(0x66979ACF5102FD2F, cargobob, p1)

def SET_OVERRIDE_VEHICLE_DOOR_TORQUE(p0: int, p1: int, p2: int) -> None:
    _iv(0x66E3AAFACE2D1EB8, p0, p1, p2)

def GET_VEHICLE_TYRES_CAN_BURST(vehicle: int) -> bool:
    return _ib(0x678B9BB8C3F58FEB, vehicle)

def IS_VEHICLE_STUCK_TIMER_UP(vehicle: int, p1: int, ms: int) -> bool:
    return _ib(0x679BE1DAF71DA874, vehicle, p1, ms)

def SET_VEHICLE_IS_STOLEN(vehicle: int, isStolen: bool) -> None:
    _iv(0x67B2C79AA7FF5738, vehicle, isStolen)

def SET_VEHICLE_HANDBRAKE(vehicle: int, toggle: bool) -> None:
    _iv(0x684785568EF26A22, vehicle, toggle)

def SET_CARGOBOB_PICKUP_MAGNET_PULL_ROPE_LENGTH(vehicle: int, p1: float) -> None:
    _iv(0x685D5561680D088B, vehicle, p1)

def GET_VEHICLE_COLOUR_COMBINATION(vehicle: int) -> int:
    return _ii(0x6A842D197F845D56, vehicle)

def SET_VEHICLE_IMPATIENCE_TIMER(vehicle: int, p1: int) -> None:
    _iv(0x6A973569BA094650, vehicle, p1)

def ATTACH_CONTAINER_TO_HANDLER_FRAME_WHEN_LINED_UP(vehicle: int, entity: int) -> None:
    _iv(0x6A98C2ECF57FA5D4, vehicle, entity)

def HAS_VEHICLE_PHONE_EXPLOSIVE_DEVICE() -> bool:
    return _ib(0x6ADAABD3068C5235)

def SET_VEHICLE_MOD(vehicle: int, modType: int, modIndex: int, customTires: bool) -> None:
    _iv(0x6AF0636DDEDCB6DD, vehicle, modType, modIndex, customTires)

def HAVE_VEHICLE_REAR_DOORS_BEEN_BLOWN_OPEN_BY_STICKYBOMB(vehicle: int) -> bool:
    return _ib(0x6B407F2525E93644, vehicle)

def POP_OUT_VEHICLE_WINDSCREEN(vehicle: int) -> None:
    _iv(0x6D645D59FB5F5AD3, vehicle)

def CLEAR_VEHICLE_ROUTE_HISTORY(vehicle: int) -> None:
    _iv(0x6D6AF961B72728AE, vehicle)

def SET_CARGOBOB_PICKUP_MAGNET_REDUCED_FALLOFF(cargobob: int, p1: float) -> None:
    _iv(0x6D8EAC07506291FB, cargobob, p1)

def SET_VEHICLE_REDUCE_GRIP_LEVEL(vehicle: int, val: int) -> None:
    _iv(0x6DEE944E1EE90CFB, vehicle, val)

def SET_HELI_CONTROL_LAGGING_RATE_SCALAR(helicopter: int, multiplier: float) -> None:
    _iv(0x6E0859B530A365CC, helicopter, multiplier)

def DOES_CARGOBOB_HAVE_PICKUP_MAGNET(cargobob: int) -> bool:
    return _ib(0x6E08BF5B3722BAC9, cargobob)

def SET_VEHICLE_TYRE_FIXED(vehicle: int, tyreIndex: int) -> None:
    _iv(0x6E13FC662B882D1D, vehicle, tyreIndex)

def GET_TYRE_WEAR_RATE(vehicle: int, wheelIndex: int) -> float:
    return _if(0x6E387895952F4F71, vehicle, wheelIndex)

def SET_PLAYBACK_TO_USE_AI_TRY_TO_REVERT_BACK_LATER(vehicle: int, time: int, drivingStyle: int, p3: bool) -> None:
    _iv(0x6E63860BBB190730, vehicle, time, drivingStyle, p3)

def GET_VEHICLE_HOMING_LOCKEDONTO_STATE(p0: int) -> int:
    return _ii(0x6EAAEFC76ACC311F, p0)

def SET_VEHICLE_STOP_INSTANTLY_WHEN_PLAYER_INACTIVE(vehicle: int, toggle: bool) -> None:
    _iv(0x6EBFB22D646FFC18, vehicle, toggle)

def SET_HOVER_MODE_WING_RATIO(vehicle: int, ratio: float) -> None:
    _iv(0x70A252F60A3E036B, vehicle, ratio)

def SET_VEHICLE_PETROL_TANK_HEALTH(vehicle: int, health: float) -> None:
    _iv(0x70DB57649FA8D0D8, vehicle, health)

def SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle: int, r: int, g: int, b: int) -> None:
    _iv(0x7141766F91D15BEA, vehicle, r, g, b)

def GET_DOES_VEHICLE_HAVE_TOMBSTONE(vehicle: int) -> bool:
    return _ib(0x71AFB258CCED3A27, vehicle)

def SET_VEHICLE_EXPLODES_ON_HIGH_EXPLOSION_DAMAGE(vehicle: int, toggle: bool) -> None:
    _iv(0x71B0892EC081D60A, vehicle, toggle)

def _IS_VEHICLE_ON_BOOST_PAD(vehicle: int) -> bool:
    return _ib(0x71C6302CBCA6CA35, vehicle)

def SET_CARGOBOB_EXTA_PICKUP_RANGE(p0: int, p1: int) -> None:
    _iv(0x72BECCF4B829522E, p0, p1)

def SET_BIKE_EASY_TO_LAND(vehicle: int, toggle: bool) -> None:
    _iv(0x73561D4425A021A2, vehicle, toggle)

def DELETE_ALL_TRAINS() -> None:
    _iv(0x736A718577F39C7D)

def SET_VEHICLE_TANK_STATIONARY(vehicle: int, p1: bool) -> None:
    _iv(0x737E398138550FFF, vehicle, p1)

def SET_TYRE_HEALTH(vehicle: int, wheelIndex: int, health: float) -> None:
    _iv(0x74C68EF97645E79D, vehicle, wheelIndex, health)

def SET_VEHICLE_SHOOT_AT_TARGET(driver: int, entity: int, xTarget: float, yTarget: float, zTarget: float) -> None:
    _iv(0x74CD9A9327A282EA, driver, entity, xTarget, yTarget, zTarget)

def IS_TAXI_LIGHT_ON(vehicle: int) -> bool:
    return _ib(0x7504C0F113AB50FC, vehicle)

def ARE_PLANE_PROPELLERS_INTACT(plane: int) -> bool:
    return _ib(0x755D6D5267CBBD7E, plane)

def SET_DISABLE_MAP_COLLISION(vehicle: int) -> None:
    _iv(0x75627043C6AA90AD, vehicle)

def VEHICLE_SET_ENABLE_NORMALISE_RAMP_CAR_VERTICAL_VELOCTIY(p0: int, p1: int) -> None:
    _iv(0x756AE6E962168A04, p0, p1)

def PRELOAD_VEHICLE_MOD(vehicle: int, modType: int, modIndex: int) -> None:
    _iv(0x758F49C24925568A, vehicle, modType, modIndex)

def SET_BOAT_ANCHOR(vehicle: int, toggle: bool) -> None:
    _iv(0x75DBEC174AEEAD10, vehicle, toggle)

def GET_VEHICLE_NEON_COLOUR(vehicle: int, r: int, g: int, b: int) -> None:
    _iv(0x7619EEE8C886757F, vehicle, r, g, b)

def SET_VEHICLE_DONT_TERMINATE_TASK_WHEN_ACHIEVED(vehicle: int) -> None:
    _iv(0x76D26A22750E849E, vehicle)

def FIX_VEHICLE_WINDOW(vehicle: int, windowIndex: int) -> None:
    _iv(0x772282EBEB95E682, vehicle, windowIndex)

def GET_VEHICLE_MOD(vehicle: int, modType: int) -> int:
    return _ii(0x772960298DA26FDB, vehicle, modType)

def SET_VEHICLE_DOORS_SHUT(vehicle: int, closeInstantly: bool) -> None:
    _iv(0x781B3D62BB013EF5, vehicle, closeInstantly)

def EXPLODE_VEHICLE_IN_CUTSCENE(vehicle: int, p1: bool) -> None:
    _iv(0x786A4EB67B01BF0B, vehicle, p1)

def SET_SHOULD_RESET_TURRET_IN_SCRIPTED_CAMERAS(vehicle: int, shouldReset: bool) -> None:
    _iv(0x78CEEE41F49F421F, vehicle, shouldReset)

def SET_POSITION_OFFSET_FOR_RECORDED_VEHICLE_PLAYBACK(vehicle: int, x: float, y: float, z: float) -> None:
    _iv(0x796A877E459B99EA, vehicle, x, y, z)

def SET_VEHICLE_DIRT_LEVEL(vehicle: int, dirtLevel: float) -> None:
    _iv(0x79D3B596FE44EE8B, vehicle, dirtLevel)

def SET_VEHICLE_EXTENDED_REMOVAL_RANGE(vehicle: int, range: int) -> None:
    _iv(0x79DF7E806202CE01, vehicle, range)

def ROLL_DOWN_WINDOW(vehicle: int, windowIndex: int) -> None:
    _iv(0x7AD9E6CE657D69E3, vehicle, windowIndex)

def SET_SPEED_BOOST_EFFECT_DISABLED(disabled: bool) -> None:
    _iv(0x7BBE7FF626A591FE, disabled)

def CREATE_PICK_UP_ROPE_FOR_CARGOBOB(cargobob: int, state: int) -> None:
    _iv(0x7BEB0C7A235F6F3B, cargobob, state)

def DETACH_CONTAINER_FROM_HANDLER_FRAME(vehicle: int) -> None:
    _iv(0x7C0043FDFF6436BC, vehicle)

def STOP_BRINGING_VEHICLE_TO_HALT(vehicle: int) -> None:
    _iv(0x7C06330BFDDA182E, vehicle)

def SET_VEHICLE_DOOR_OPEN(vehicle: int, doorId: int, loose: bool, openInstantly: bool) -> None:
    _iv(0x7C65DAC73C35C862, vehicle, doorId, loose, openInstantly)

def GET_VEHICLE_NUMBER_PLATE_TEXT(vehicle: int) -> str:
    return _is(0x7CE1CCB9B293020E, vehicle)

def GET_VEHICLE_EXTRA_COLOUR_5(vehicle: int, color: int) -> None:
    _iv(0x7D1464D472D32136, vehicle, color)

def GET_VEHICLE_PETROL_TANK_HEALTH(vehicle: int) -> float:
    return _if(0x7D5DABE888D2D074, vehicle)

def SET_VEHICLE_ALLOW_HOMING_MISSLE_LOCKON(vehicle: int, toggle: bool, p2: bool) -> None:
    _iv(0x7D6F9A3EF26136A0, vehicle, toggle, p2)

def START_PLAYBACK_RECORDED_VEHICLE_WITH_FLAGS(vehicle: int, recording: int, script: str, flags: int, time: int, drivingStyle: int) -> None:
    _iv(0x7D80FD645D4DA346, vehicle, recording, script, flags, time, drivingStyle)

def SET_VEHICLE_EXTRA(vehicle: int, extraId: int, disable: bool) -> None:
    _iv(0x7EE3A3C5E4A40CC9, vehicle, extraId, disable)

def IS_COP_VEHICLE_IN_AREA_3D(x1: float, x2: float, y1: float, y2: float, z1: float, z2: float) -> bool:
    return _ib(0x7EEF65D5F153E26A, x1, x2, y1, y2, z1, z2)

def IS_THIS_MODEL_A_CAR(model: int) -> bool:
    return _ib(0x7F6DB52EEFC96DF8, model)

def SET_HELI_RESIST_TO_EXPLOSION(vehicle: int, toggle: bool) -> None:
    _iv(0x8074CC1886802912, vehicle, toggle)

def _GET_VEHICLE_TRAILER_PARENT_VEHICLE(trailer: int) -> int:
    return _ii(0x80D9D32636369C92, trailer)

def SET_RANDOM_TRAINS(toggle: bool) -> None:
    _iv(0x80D9F74197EA47D9, toggle)

def SET_ALLOW_RAMMING_SOOP_OR_RAMP(p0: int, p1: int) -> None:
    _iv(0x80E3357FDEF45C21, p0, p1)

def GET_VEHICLE_MOD_COLOR_2(vehicle: int, paintType: int, color: int) -> None:
    _iv(0x81592BE4E3878728, vehicle, paintType, color)

def SET_VEHICLE_MOD_COLOR_2(vehicle: int, paintType: int, color: int) -> None:
    _iv(0x816562BADFDEC83E, vehicle, paintType, color)

def GET_VEHICLE_WEAPON_RESTRICTED_AMMO(vehicle: int, weaponIndex: int) -> int:
    return _ii(0x8181CE2F25CB9BB7, vehicle, weaponIndex)

def REQUEST_VEHICLE_ASSET(vehicleHash: int, vehicleAsset: int) -> None:
    _iv(0x81A15811460FAB3A, vehicleHash, vehicleAsset)

def SET_ROCKET_BOOST_ACTIVE(vehicle: int, active: bool) -> None:
    _iv(0x81E1552E35DC3839, vehicle, active)

def SET_DISABLE_PED_STAND_ON_TOP(vehicle: int, toggle: bool) -> None:
    _iv(0x8235F1BEAD557629, vehicle, toggle)

def SET_VEHICLE_DETONATION_MODE(toggle: bool) -> None:
    _iv(0x82E0AC411E41A5B4, toggle)

def REMOVE_VEHICLE_STUCK_CHECK(vehicle: int) -> None:
    _iv(0x8386BFB614D06749, vehicle)

def GET_VEHICLE_CUSTOM_SECONDARY_COLOUR(vehicle: int, r: int, g: int, b: int) -> None:
    _iv(0x8389CD56CA8072DC, vehicle, r, g, b)

def SUPPRESS_NEONS_ON_VEHICLE(vehicle: int, toggle: bool) -> None:
    _iv(0x83F813570FF519DE, vehicle, toggle)

def GET_LAST_PED_IN_VEHICLE_SEAT(vehicle: int, seatIndex: int) -> int:
    return _ii(0x83F969AA1EE2A664, vehicle, seatIndex)

def SET_RANDOM_BOATS(toggle: bool) -> None:
    _iv(0x84436EC293B1415F, toggle)

def IS_TOGGLE_MOD_ON(vehicle: int, modType: int) -> bool:
    return _ib(0x84B233A8C8FC8AE7, vehicle, modType)

def _SET_VEHICLE_EXPLOSIVE_DAMAGE_SCALE(vehicle: int, scale: float) -> int:
    return _ii(0x84D7FFD223CAAFFD, vehicle, scale)

def SET_HYDRAULIC_SUSPENSION_RAISE_FACTOR(vehicle: int, wheelId: int, value: float) -> None:
    _iv(0x84EA99C62CB3EF0C, vehicle, wheelId, value)

def SET_CAR_HIGH_SPEED_BUMP_SEVERITY_MULTIPLIER(multiplier: float) -> None:
    _iv(0x84FD40F56075E816, multiplier)

def GET_VEHICLE_IS_DUMMY(p0: int) -> bool:
    return _ib(0x8533CAFDE1F0F336, p0)

def ROLL_DOWN_WINDOWS(vehicle: int) -> None:
    _iv(0x85796B0549DDE156, vehicle)

def _SET_BOUNDS_AFFECT_WATER_PROBES(vehicle: int, toggle: bool) -> None:
    _iv(0x85FC953F6C6CBDE1, vehicle, toggle)

def SET_IGNORE_PLANES_SMALL_PITCH_CHANGE(p0: int, p1: int) -> None:
    _iv(0x8664170EF165C4A6, p0, p1)

def SET_VEHICLE_WEAPON_CAN_TARGET_OBJECTS(vehicle: int, toggle: bool) -> None:
    _iv(0x86B4B6212CB8B627, vehicle, toggle)

def SET_VEHICLE_BOBBLEHEAD_VELOCITY(x: float, y: float, p2: float) -> None:
    _iv(0x870B8B7A766615C8, x, y, p2)

def GET_VEHICLE_ATTACHED_TO_CARGOBOB(cargobob: int) -> int:
    return _ii(0x873B82D42AC2B9E5, cargobob)

def SET_PICKUP_ROPE_LENGTH_FOR_CARGOBOB(cargobob: int, length1: float, length2: float, p3: bool) -> None:
    _iv(0x877C1EAEAC531023, cargobob, length1, length2, p3)

def SET_TRAILER_LEGS_LOWERED(vehicle: int) -> None:
    _iv(0x878C75C09FBDB942, vehicle)

def GET_VEHICLE_LIVERY_COUNT(vehicle: int) -> int:
    return _ii(0x87B63E25A529D526, vehicle)

def OPEN_BOMB_BAY_DOORS(vehicle: int) -> None:
    _iv(0x87E7F24270732CB1, vehicle)

def SET_VEHICLE_FORCE_INTERIORLIGHT(vehicle: int, toggle: bool) -> None:
    _iv(0x8821196D91FA2DE5, vehicle, toggle)

def UNPAUSE_PLAYBACK_RECORDED_VEHICLE(vehicle: int) -> None:
    _iv(0x8879EE09268305D5, vehicle)

def SET_FORCE_FIX_LINK_MATRICES(vehicle: int) -> None:
    _iv(0x887FA38787DE8C72, vehicle)

def SET_VEHICLE_USE_MORE_RESTRICTIVE_SPAWN_CHECKS(vehicle: int, p1: bool) -> None:
    _iv(0x88BC673CA9E0AE99, vehicle, p1)

def GET_MOD_TEXT_LABEL(vehicle: int, modType: int, modValue: int) -> str:
    return _is(0x8935624F8C5592CC, vehicle, modType, modValue)

def IS_HANDLER_FRAME_LINED_UP_WITH_CONTAINER(vehicle: int, entity: int) -> bool:
    return _ib(0x89D630CF5EA96D23, vehicle, entity)

def SET_VEHICLE_GRAVITY(vehicle: int, toggle: bool) -> None:
    _iv(0x89F149B6131E57DA, vehicle, toggle)

def SET_VEHICLE_DISABLE_HEIGHT_MAP_AVOIDANCE(vehicle: int, p1: bool) -> None:
    _iv(0x8AA9180DE2FEDD45, vehicle, p1)

def SET_VEHICLE_UNDRIVEABLE(vehicle: int, toggle: bool) -> None:
    _iv(0x8ABA6AF54B942B95, vehicle, toggle)

def DOES_VEHICLE_HAVE_ROOF(vehicle: int) -> bool:
    return _ib(0x8AC862B0B32C5B80, vehicle)

def SET_VEHICLE_FULLBEAM(vehicle: int, toggle: bool) -> None:
    _iv(0x8B7FD87F0DDB421E, vehicle, toggle)

def SET_VEHICLE_AUTOMATICALLY_ATTACHES(vehicle: int, p1: bool, p2: int) -> int:
    return _ii(0x8BA6F76BC53A1493, vehicle, p1, p2)

def GET_VEHICLE_MODEL_ACCELERATION(modelHash: int) -> float:
    return _if(0x8C044C5C84505B6A, modelHash)

def GET_VEHICLE_NEON_ENABLED(vehicle: int, index: int) -> bool:
    return _ib(0x8C4B92553E4766A5, vehicle, index)

def IS_VEHICLE_SPRAYABLE(vehicle: int) -> bool:
    return _ib(0x8D474C8FAEFF6CDE, vehicle)

def FIND_SPAWN_COORDINATES_FOR_HELI(ped: int) -> 'gta.Vector3':
    return _ivec(0x8DC9675797123522, ped)

def SET_VEHICLE_NEON_COLOUR(vehicle: int, r: int, g: int, b: int) -> None:
    _iv(0x8E0A582209A62695, vehicle, r, g, b)

def SET_HYDRAULIC_VEHICLE_STATE(vehicle: int, state: int) -> None:
    _iv(0x8EA86DF356801C7D, vehicle, state)

def SET_DISABLE_RETRACTING_WEAPON_BLADES(toggle: bool) -> None:
    _iv(0x8F0D5BA1C2CC91D7, toggle)

def GET_VEHICLE_DIRT_LEVEL(vehicle: int) -> float:
    return _if(0x8F17BC8BA08DA62B, vehicle)

def GET_VEHICLE_LOCK_ON_TARGET(vehicle: int, entity: int) -> bool:
    return _ib(0x8F5EBAB1F260CFCE, vehicle, entity)

def RAISE_CONVERTIBLE_ROOF(vehicle: int, instantlyRaise: bool) -> None:
    _iv(0x8F5FB35D7E88FC70, vehicle, instantlyRaise)

def SET_BOAT_SINKS_WHEN_WRECKED(vehicle: int, toggle: bool) -> None:
    _iv(0x8F719973E1445BA2, vehicle, toggle)

def SET_VEHICLE_STEERING_BIAS_SCALAR(p0: int, p1: float) -> None:
    _iv(0x9007A2F21DC108D4, p0, p1)

def DETACH_VEHICLE_FROM_TRAILER(vehicle: int) -> None:
    _iv(0x90532EDF0D2BDD86, vehicle)

def GET_CAR_HAS_JUMP(vehicle: int) -> bool:
    return _ib(0x9078C0C5EF8C19E9, vehicle)

def SET_VEHICLE_NUMBER_PLATE_TEXT_INDEX(vehicle: int, plateIndex: int) -> None:
    _iv(0x9088EB5A43FFB0A1, vehicle, plateIndex)

def GET_VEHICLE_MOD_MODIFIER_VALUE(vehicle: int, modType: int, modIndex: int) -> int:
    return _ii(0x90A38E9838E0A8C1, vehicle, modType, modIndex)

def SET_AMBIENT_VEHICLE_RANGE_MULTIPLIER_THIS_FRAME(value: float) -> None:
    _iv(0x90B6DA738A9A25DA, value)

def GET_IS_VEHICLE_SECONDARY_COLOUR_CUSTOM(vehicle: int) -> bool:
    return _ib(0x910A32E7AAD2656C, vehicle)

def SET_DISABLE_VEHICLE_ENGINE_FIRES(vehicle: int, toggle: bool) -> None:
    _iv(0x91A0BD635321F145, vehicle, toggle)

def HAS_INSTANT_FILL_VEHICLE_POPULATION_FINISHED() -> bool:
    return _ib(0x91D6DD290888CBAB)

def LOWER_FORKLIFT_FORKS(forklift: int) -> None:
    _iv(0x923A293361DF44E5, forklift)

def GET_POSITION_OF_VEHICLE_RECORDING_ID_AT_TIME(id: int, time: float) -> 'gta.Vector3':
    return _ivec(0x92523B76657A517D, id, time)

def GET_NUMBER_OF_VEHICLE_DOORS(vehicle: int) -> int:
    return _ii(0x92922A607497B14D, vehicle)

def SET_VEHICLE_BRAKE_LIGHTS(vehicle: int, toggle: bool) -> None:
    _iv(0x92B35082E0B42F66, vehicle, toggle)

def REMOVE_VEHICLE_MOD(vehicle: int, modType: int) -> None:
    _iv(0x92D619E420858204, vehicle, modType)

def _GET_VEHICLE_THROTTLE(vehicle: int) -> float:
    return _if(0x92D96892FC06AF22, vehicle)

def SET_VEHICLE_HAS_STRONG_AXLES(vehicle: int, toggle: bool) -> None:
    _iv(0x92F0CF722BC4202F, vehicle, toggle)

def MODIFY_VEHICLE_TOP_SPEED(vehicle: int, value: float) -> None:
    _iv(0x93A3996368C94158, vehicle, value)

def SET_VEHICLE_LOD_MULTIPLIER(vehicle: int, multiplier: float) -> None:
    _iv(0x93AE6A61BE015BF1, vehicle, multiplier)

def SET_VEHICLE_DOOR_SHUT(vehicle: int, doorId: int, closeInstantly: bool) -> None:
    _iv(0x93D9BD300D7789E5, vehicle, doorId, closeInstantly)

def SKIP_TIME_IN_PLAYBACK_RECORDED_VEHICLE(vehicle: int, time: float) -> None:
    _iv(0x9438F7AD68771A20, vehicle, time)

def SET_HELI_CAN_PICKUP_ENTITY_THAT_HAS_PICK_UP_DISABLED(vehicle: int, toggle: bool) -> None:
    _iv(0x94A68DA412C4007D, vehicle, toggle)

def IS_THIS_MODEL_A_JETSKI(model: int) -> bool:
    return _ib(0x9537097412CF75FE, model)

def SET_VEHICLE_DEFORMATION_FIXED(vehicle: int) -> None:
    _iv(0x953DA1E1B12C0491, vehicle)

def DOES_VEHICLE_EXIST_WITH_DECORATOR(decorator: str) -> int:
    return _ii(0x956B409B984D9BF7, decorator)

def SET_VEHICLE_NUMBER_PLATE_TEXT(vehicle: int, plateText: str) -> None:
    _iv(0x95A88F0B409CDA47, vehicle, plateText)

def SET_TRAILER_LEGS_RAISED(vehicle: int) -> None:
    _iv(0x95CF53B3D687F9FA, vehicle)

def SET_VEHICLE_DAMAGE_SCALES(vehicle: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x9640E30A7F395E4B, vehicle, p1, p2, p3, p4)

def SET_VEHICLE_DOORS_LOCKED_FOR_NON_SCRIPT_PLAYERS(vehicle: int, toggle: bool) -> None:
    _iv(0x9737A37136F07E75, vehicle, toggle)

def REMOVE_PICK_UP_ROPE_FOR_CARGOBOB(cargobob: int) -> None:
    _iv(0x9768CF648F54C804, cargobob)

def SET_DISABLE_AUTOMATIC_CRASH_TASK(vehicle: int, toggle: bool) -> None:
    _iv(0x97841634EF7DF1D6, vehicle, toggle)

def SET_FORCE_HD_VEHICLE(vehicle: int, toggle: bool) -> None:
    _iv(0x97CE68CB032583F0, vehicle, toggle)

def SET_VEHICLE_ENGINE_CAN_DEGRADE(vehicle: int, toggle: bool) -> None:
    _iv(0x983765856F2564F9, vehicle, toggle)

def SET_VEHICLE_CAUSES_SWERVING(vehicle: int, toggle: bool) -> None:
    _iv(0x9849DE24FCF23CCC, vehicle, toggle)

def DOES_VEHICLE_HAVE_SEARCHLIGHT(vehicle: int) -> bool:
    return _ib(0x99015ED7DBEA5113, vehicle)

def GET_ENTITY_ATTACHED_TO_CARGOBOB(p0: int) -> int:
    return _ii(0x99093F60746708CA, p0)

def SET_VEHICLE_SHUNT_ON_STICK(toggle: bool) -> None:
    _iv(0x99A05839C46CE316, toggle)

def ADD_VEHICLE_PHONE_EXPLOSIVE_DEVICE(vehicle: int) -> None:
    _iv(0x99AD4CCCB128CBC9, vehicle)

def SET_VEHICLE_KERS_ALLOWED(vehicle: int, toggle: bool) -> None:
    _iv(0x99C82F8A139F3E4E, vehicle, toggle)

def FORCE_SUB_THROTTLE_FOR_TIME(vehicle: int, p1: float, p2: float) -> None:
    _iv(0x99CAD8E7AFDB60FA, vehicle, p1, p2)

def SET_CARGOBOB_PICKUP_MAGNET_ACTIVE(cargobob: int, isActive: bool) -> None:
    _iv(0x9A665550F8DA349B, cargobob, isActive)

def SET_VEHICLE_GENERATOR_AREA_OF_INTEREST(x: float, y: float, z: float, radius: float) -> None:
    _iv(0x9A75585FB2E54FAD, x, y, z, radius)

def HAVE_VEHICLE_MODS_STREAMED_IN(vehicle: int) -> bool:
    return _ib(0x9A83F5F9963775EF, vehicle)

def SET_VEHICLE_FLIGHT_NOZZLE_POSITION_IMMEDIATE(vehicle: int, angle: float) -> None:
    _iv(0x9AA47FFF660CB932, vehicle, angle)

def GET_LANDING_GEAR_STATE(vehicle: int) -> int:
    return _ii(0x9B0F3DCA3DB0F4CD, vehicle)

def GET_ALL_VEHICLES(vehsStruct: int) -> int:
    return _ii(0x9B8E1BF04B51F2E8, vehsStruct)

def SET_VEHICLE_COUNTERMEASURE_AMMO(vehicle: int, counterMeasureCount: int) -> None:
    _iv(0x9BDA23BF666F0855, vehicle, counterMeasureCount)

def SET_CARGOBOB_PICKUP_MAGNET_SET_AMBIENT_MODE(vehicle: int, p1: bool, p2: bool) -> None:
    _iv(0x9BDDC73CC6A115D4, vehicle, p1, p2)

def SET_VEHICLE_ACT_AS_IF_HAS_SIREN_ON(vehicle: int, p1: bool) -> None:
    _iv(0x9BECD4B9FEF3F8A6, vehicle, p1)

def START_VEHICLE_HORN(vehicle: int, duration: int, mode: int, forever: bool) -> None:
    _iv(0x9C8C6504B5B63D2C, vehicle, duration, mode, forever)

def GET_VEHICLE_PLATE_TYPE(vehicle: int) -> int:
    return _ii(0x9CCC9525BF2408E0, vehicle)

def SET_BIKE_ON_STAND(vehicle: int, x: float, y: float) -> None:
    _iv(0x9CFA4896C3A53CBB, vehicle, x, y)

def GET_NUM_VEHICLE_WINDOW_TINTS() -> int:
    return _ii(0x9D1224004B3A6707)

def VEHICLE_SET_JET_WASH_FORCE_ENABLED(p0: int) -> None:
    _iv(0x9D30687C57BAA0BB, p0)

def SET_VEHICLE_IN_CAR_MOD_SHOP(vehicle: int, toggle: bool) -> None:
    _iv(0x9D44FCCE98450843, vehicle, toggle)

def CREATE_SCRIPT_VEHICLE_GENERATOR(x: float, y: float, z: float, heading: float, p4: float, p5: float, modelHash: int, p7: int, p8: int, p9: int, p10: int, p11: bool, p12: bool, p13: bool, p14: bool, p15: bool, p16: int) -> int:
    return _ii(0x9DEF883114668116, x, y, z, heading, p4, p5, modelHash, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16)

def SET_NITROUS_IS_ACTIVE(vehicle: int, toggle: bool) -> None:
    _iv(0x9E566EA551F4F1A6, vehicle, toggle)

def SMASH_VEHICLE_WINDOW(vehicle: int, windowIndex: int) -> None:
    _iv(0x9E5B5E4D2CCD2259, vehicle, windowIndex)

def IS_BIG_VEHICLE(vehicle: int) -> bool:
    return _ib(0x9F243D3919F442FE, vehicle)

def SET_VEHICLE_BLIP_THROTTLE_RANDOMLY(vehicle: int, p1: bool) -> None:
    _iv(0x9F3F689B814F2599, vehicle, p1)

def GET_IN_VEHICLE_CLIPSET_HASH_FOR_SEAT(vehicle: int, p1: int) -> int:
    return _ii(0xA01BC64DD4BFBBAC, vehicle, p1)

def IS_THIS_MODEL_A_PLANE(model: int) -> bool:
    return _ib(0xA0948AB42D7BA0DE, model)

def GET_VEHICLE_MAX_TRACTION(vehicle: int) -> float:
    return _if(0xA132FB5370554DB0, vehicle)

def SET_HELI_BLADES_FULL_SPEED(vehicle: int) -> None:
    _iv(0xA178472EBB8AE60D, vehicle)

def SET_CARGOBOB_PICKUP_MAGNET_FALLOFF(cargobob: int, p1: float) -> None:
    _iv(0xA17BAD153B51547E, cargobob, p1)

def GET_VEHICLE_COLOURS(vehicle: int, colorPrimary: int, colorSecondary: int) -> None:
    _iv(0xA19435F193E081AC, vehicle, colorPrimary, colorSecondary)

def IS_THIS_MODEL_AN_AMPHIBIOUS_QUADBIKE(model: int) -> bool:
    return _ib(0xA1A9FC1C76A6730D, model)

def SET_VEHICLE_DAMAGE(vehicle: int, xOffset: float, yOffset: float, zOffset: float, damage: float, radius: float, focusOnModel: bool) -> None:
    _iv(0xA1DD317EA8FD4F29, vehicle, xOffset, yOffset, zOffset, damage, radius, focusOnModel)

def ATTACH_ENTITY_TO_CARGOBOB(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int) -> None:
    _iv(0xA1DD82F3CCF9A01E, p0, p1, p2, p3, p4, p5)

def GET_IS_VEHICLE_SHUNTING(vehicle: int) -> bool:
    return _ib(0xA2459F72C14E2E8D, vehicle)

def SET_FLEEING_VEHICLES_USE_SWITCHED_OFF_NODES(p0: int) -> None:
    _iv(0xA247F9EF01D8082E, p0)

def SET_VEHICLE_DOORS_LOCKED_FOR_ALL_PLAYERS(vehicle: int, toggle: bool) -> None:
    _iv(0xA2F80B8D040727CC, vehicle, toggle)

def SET_VEHICLE_WHEELS_CAN_BREAK_OFF_WHEN_BLOW_UP(vehicle: int, toggle: bool) -> None:
    _iv(0xA37B9A517B133349, vehicle, toggle)

def SET_VEHICLE_CEILING_HEIGHT(vehicle: int, height: float) -> None:
    _iv(0xA46413066687A328, vehicle, height)

def GENERATE_VEHICLE_CREATION_POS_FROM_PATHS(outVec: int, p1: int, outVec1: int, p3: int, p4: int, p5: int, p6: int, p7: int, p8: int) -> bool:
    return _ib(0xA4822F1CF23F4810, outVec, p1, outVec1, p3, p4, p5, p6, p7, p8)

def NETWORK_CAP_EMPTY_CROWDING_VEHICLES_REMOVAL(p0: int) -> None:
    _iv(0xA4A9A4C40E615885, p0)

def SET_PLAYBACK_TO_USE_AI(vehicle: int, drivingStyle: int) -> None:
    _iv(0xA549C3B37EA28131, vehicle, drivingStyle)

def GET_NUM_MOD_COLORS(paintType: int, p1: bool) -> int:
    return _ii(0xA551BE18C11A476D, paintType, p1)

def SET_VEHICLE_DOOR_LATCHED(vehicle: int, doorId: int, p2: bool, p3: bool, p4: bool) -> None:
    _iv(0xA5A9653A8D2CAF48, vehicle, doorId, p2, p3, p4)

def SET_VEHICLE_LIVERY2(vehicle: int, livery: int) -> None:
    _iv(0xA6D3A8750DC73270, vehicle, livery)

def REQUEST_VEHICLE_HIGH_DETAIL_MODEL(vehicle: int) -> None:
    _iv(0xA6E9FDCB2C76785E, vehicle)

def REMOVE_VEHICLE_WINDOW(vehicle: int, windowIndex: int) -> None:
    _iv(0xA711568EEDB43069, vehicle, windowIndex)

def VEHICLE_SET_PARACHUTE_MODEL_TINT_INDEX(vehicle: int, textureVariation: int) -> None:
    _iv(0xA74AD2439468C883, vehicle, textureVariation)

def IS_VEHICLE_IN_SUBMARINE_MODE(vehicle: int) -> bool:
    return _ib(0xA77DC70BD689A1E5, vehicle)

def GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS(vehicle: int) -> int:
    return _ii(0xA7C4F2C6E744A550, vehicle)

def SET_CAN_ADJUST_GROUND_CLEARANCE(vehicle: int, p1: bool) -> None:
    _iv(0xA7DCDF4DED40A8F4, vehicle, p1)

def GET_IS_RIGHT_VEHICLE_HEADLIGHT_DAMAGED(vehicle: int) -> bool:
    return _ib(0xA7ECB73355EB2F20, vehicle)

def GET_VEHICLE_ENVEFF_SCALE(vehicle: int) -> float:
    return _if(0xA82819CAC9C4C403, vehicle)

def GET_VEHICLE_CAN_DEPLOY_PARACHUTE(vehicle: int) -> bool:
    return _ib(0xA916396DF4154EE3, vehicle)

def IS_VEHICLE_VISIBLE(vehicle: int) -> bool:
    return _ib(0xAA0A52D24FB98293, vehicle)

def SET_TRAIN_SPEED(train: int, speed: float) -> None:
    _iv(0xAA0BC91BE0B796E3, train, speed)

def CLEAR_VEHICLE_PHONE_EXPLOSIVE_DEVICE() -> None:
    _iv(0xAA3F739ABDDCF21F)

def SET_DIP_STRAIGHT_DOWN_WHEN_CRASHING_PLANE(vehicle: int, toggle: bool) -> None:
    _iv(0xAA653AE61924B0A0, vehicle, toggle)

def SET_VEHICLE_NOT_STEALABLE_AMBIENTLY(vehicle: int, p1: bool) -> None:
    _iv(0xAB04325045427AAE, vehicle, p1)

def SET_GOON_BOSS_VEHICLE(vehicle: int, toggle: bool) -> None:
    _iv(0xAB31EF4DE6800CE9, vehicle, toggle)

def SET_VEHICLE_FORWARD_SPEED(vehicle: int, speed: float) -> None:
    _iv(0xAB54A438726D25D5, vehicle, speed)

def SKIP_TO_END_AND_STOP_PLAYBACK_RECORDED_VEHICLE(vehicle: int) -> None:
    _iv(0xAB8E2EDA0C0A5883, vehicle)

def IS_THIS_MODEL_A_TRAIN(model: int) -> bool:
    return _ib(0xAB935175B22E822B, model)

def GET_HELI_TAIL_BOOM_HEALTH(vehicle: int) -> float:
    return _if(0xAC51915D27E4A5F7, vehicle)

def REMOVE_VEHICLE_ASSET(vehicleAsset: int) -> None:
    _iv(0xACE699C71AB9DEB5, vehicleAsset)

def SET_LAST_DRIVEN_VEHICLE(vehicle: int) -> None:
    _iv(0xACFB2463CC22BED2, vehicle)

def SET_PLANE_TURBULENCE_MULTIPLIER(vehicle: int, multiplier: float) -> None:
    _iv(0xAD2D28A1AFDFF131, vehicle, multiplier)

def IS_MISSION_TRAIN(train: int) -> bool:
    return _ib(0xAD464F2E18836BFC, train)

def GET_VEHICLE_MAX_BRAKING(vehicle: int) -> float:
    return _if(0xAD7E85FC227197C4, vehicle)

def DETACH_VEHICLE_FROM_ANY_CARGOBOB(vehicle: int) -> bool:
    return _ib(0xADF7BE450512C12F, vehicle)

def GET_IS_VEHICLE_ENGINE_RUNNING(vehicle: int) -> bool:
    return _ib(0xAE31E7DF9B5B132E, vehicle)

def HIDE_TOMBSTONE(vehicle: int, toggle: bool) -> None:
    _iv(0xAE71FB656C600587, vehicle, toggle)

def GET_HELI_TAIL_ROTOR_HEALTH(vehicle: int) -> float:
    return _if(0xAE8CE82A4219AC8C, vehicle)

def IS_PLAYBACK_USING_AI_GOING_ON_FOR_VEHICLE(vehicle: int) -> bool:
    return _ib(0xAEA8FD591FAD4106, vehicle)

def ARE_FOLDING_WINGS_DEPLOYED(vehicle: int) -> bool:
    return _ib(0xAEF12960FA943792, vehicle)

def DETACH_ENTITY_FROM_CARGOBOB(cargobob: int, entity: int) -> bool:
    return _ib(0xAF03011701811146, cargobob, entity)

def CREATE_VEHICLE(modelHash: int, x: float, y: float, z: float, heading: float, isNetwork: bool, bScriptHostVeh: bool, p7: bool) -> int:
    return _ii(0xAF35D0D2583051B0, modelHash, x, y, z, heading, isNetwork, bScriptHostVeh, p7)

def REQUEST_VEHICLE_RECORDING(recording: int, script: str) -> None:
    _iv(0xAF514CABE74CBF15, recording, script)

def SET_VEHICLE_DISABLE_COLLISION_UPON_CREATION(vehicle: int, disable: bool) -> None:
    _iv(0xAF60E6A2936F982A, vehicle, disable)

def _SET_OVERRIDE_TRACTION_LOSS_MULTIPLIER(vehicle: int, modifier: float) -> None:
    _iv(0xAFD262ACCA64479A, vehicle, modifier)

def SET_VEHICLE_FORCE_AFTERBURNER(vehicle: int, toggle: bool) -> None:
    _iv(0xB055A34527CB8FD7, vehicle, toggle)

def SET_DISABLE_SUPERDUMMY(vehicle: int, p1: bool) -> None:
    _iv(0xB088E9A47AE6EDD5, vehicle, p1)

def IS_PED_EXCLUSIVE_DRIVER_OF_VEHICLE(ped: int, vehicle: int, outIndex: int) -> bool:
    return _ib(0xB09D25E77C33EB3F, ped, vehicle, outIndex)

def IS_BOAT_ANCHORED(vehicle: int) -> bool:
    return _ib(0xB0AD1238A709B1A2, vehicle)

def _SET_DISABLE_EXPLODE_FROM_BODY_DAMAGE_RECEIVED_BY_AI_VEHICLE(vehicle: int, disable: bool) -> None:
    _iv(0xB0B7DF5CB876FF5E, vehicle, disable)

def IS_VEHICLE_ON_ALL_WHEELS(vehicle: int) -> bool:
    return _ib(0xB104CD1BABF302E2, vehicle)

def GET_DISPLAY_NAME_FROM_VEHICLE_MODEL(modelHash: int) -> str:
    return _is(0xB215AAC32D25D019, modelHash)

def SET_DEPLOY_FOLDING_WINGS(vehicle: int, deploy: bool, p2: bool) -> None:
    _iv(0xB251E0B33E58B424, vehicle, deploy, p2)

def ALLOW_AMBIENT_VEHICLES_TO_AVOID_ADVERSE_CONDITIONS(vehicle: int) -> None:
    _iv(0xB264C4D2F2B0A78B, vehicle)

def SET_FORCE_LOW_LOD_ANCHOR_MODE(vehicle: int, p1: bool) -> None:
    _iv(0xB28B1FE5BFADD7F5, vehicle, p1)

def GET_LAST_DRIVEN_VEHICLE() -> int:
    return _ii(0xB2D06FAEDE65B577)

def SET_CLEAR_FREEZE_WAITING_ON_COLLISION_ONCE_PLAYER_ENTERS(vehicle: int, toggle: bool) -> None:
    _iv(0xB2E0C0D6922D31F2, vehicle, toggle)

def SET_VEHICLE_LIGHT_MULTIPLIER(vehicle: int, multiplier: float) -> None:
    _iv(0xB385454F8791F57C, vehicle, multiplier)

def GET_VEHICLE_MOD_VARIATION(vehicle: int, modType: int) -> int:
    return _ii(0xB3924ECD70E095DC, vehicle, modType)

def SET_RANDOM_VEHICLE_DENSITY_MULTIPLIER_THIS_FRAME(multiplier: float) -> None:
    _iv(0xB3B3359379FE77D3, multiplier)

def GET_VEHICLE_WHEEL_TYPE(vehicle: int) -> int:
    return _ii(0xB3ED1BFB4BE636DC, vehicle)

def GET_VEHICLE_MOD_COLOR_1_NAME(vehicle: int, p1: bool) -> str:
    return _is(0xB45085B721EFD38C, vehicle, p1)

def IS_VEHICLE_STUCK_ON_ROOF(vehicle: int) -> bool:
    return _ib(0xB497F06B288DCFDF, vehicle)

def GET_LIVERY_NAME(vehicle: int, liveryIndex: int) -> str:
    return _is(0xB4C7A93837C91A1F, vehicle, liveryIndex)

def GET_RANDOM_VEHICLE_BACK_BUMPER_IN_SPHERE(p0: float, p1: float, p2: float, p3: float, p4: int, p5: int, p6: int) -> int:
    return _ii(0xB50807EABE20A8DC, p0, p1, p2, p3, p4, p5, p6)

def IS_THIS_MODEL_A_BIKE(model: int) -> bool:
    return _ib(0xB50C0B0CEDC6CE84, model)

def SET_VEHICLE_CHEAT_POWER_INCREASE(vehicle: int, value: float) -> None:
    _iv(0xB59E4BD37AE292DB, vehicle, value)

def SET_VEHICLE_TYRE_SMOKE_COLOR(vehicle: int, r: int, g: int, b: int) -> None:
    _iv(0xB5BA80F839791C0F, vehicle, r, g, b)

def SET_VEHICLE_EXCLUSIVE_DRIVER(vehicle: int, ped: int, index: int) -> None:
    _iv(0xB5C51B5502E85E83, vehicle, ped, index)

def IS_VEHICLE_SIREN_AUDIO_ON(vehicle: int) -> bool:
    return _ib(0xB5CC40FBCB586380, vehicle)

def SET_VEHICLE_INDICATOR_LIGHTS(vehicle: int, turnSignal: int, toggle: bool) -> None:
    _iv(0xB5D45264751B7DF0, vehicle, turnSignal, toggle)

def GET_VEHICLE_TYRE_SMOKE_COLOR(vehicle: int, r: int, g: int, b: int) -> None:
    _iv(0xB635392A4938B3C3, vehicle, r, g, b)

def GET_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle: int, r: int, g: int, b: int) -> None:
    _iv(0xB64CF2CCA9D95F52, vehicle, r, g, b)

def SET_VEHICLE_DOORS_LOCKED(vehicle: int, doorLockStatus: int) -> None:
    _iv(0xB664292EAECF7FA6, vehicle, doorLockStatus)

def SET_USE_DESIRED_Z_CRUISE_SPEED_FOR_LANDING(vehicle: int, toggle: bool) -> None:
    _iv(0xB68CFAF83A02768D, vehicle, toggle)

def ADD_VEHICLE_UPSIDEDOWN_CHECK(vehicle: int) -> None:
    _iv(0xB72E26D81006005B, vehicle)

def GET_VEHICLE_EXTRA_COLOUR_6(vehicle: int, color: int) -> None:
    _iv(0xB7635E80A5C31BFF, vehicle, color)

def SET_VEHICLE_BODY_HEALTH(vehicle: int, value: float) -> None:
    _iv(0xB77D05AC8C78AADB, vehicle, value)

def SET_VEHICLE_DOORS_LOCKED_FOR_TEAM(vehicle: int, team: int, toggle: bool) -> None:
    _iv(0xB81F6D4A8F5EEBA8, vehicle, team, toggle)

def SET_TASK_VEHICLE_GOTO_PLANE_MIN_HEIGHT_ABOVE_TERRAIN(plane: int, height: int) -> None:
    _iv(0xB893215D8D4C015B, plane, height)

def IS_VEHICLE_DOOR_DAMAGED(veh: int, doorID: int) -> bool:
    return _ib(0xB8E181E559464527, veh, doorID)

def GET_VEHICLE_HEALTH_PERCENTAGE(vehicle: int, maxEngineHealth: float, maxPetrolTankHealth: float, maxBodyHealth: float, maxMainRotorHealth: float, maxTailRotorHealth: float, maxUnkHealth: float) -> float:
    return _if(0xB8EF61207C2393A9, vehicle, maxEngineHealth, maxPetrolTankHealth, maxBodyHealth, maxMainRotorHealth, maxTailRotorHealth, maxUnkHealth)

def SET_VEHICLE_KEEP_ENGINE_ON_WHEN_ABANDONED(vehicle: int, toggle: bool) -> None:
    _iv(0xB8FBC8B1330CA9B4, vehicle, toggle)

def START_VEHICLE_ALARM(vehicle: int) -> None:
    _iv(0xB8FF7AB45305C345, vehicle)

def GET_VEHICLE_LIGHTS_STATE(vehicle: int, lightsOn: int, highbeamsOn: int) -> bool:
    return _ib(0xB91B4C20085BD12F, vehicle, lightsOn, highbeamsOn)

def SET_VEHICLE_NEON_INDEX_COLOUR(vehicle: int, index: int) -> None:
    _iv(0xB93B2867F7B479D1, vehicle, index)

def SET_CARJACK_MISSION_REMOVAL_PARAMETERS(p0: int, p1: int) -> None:
    _iv(0xB9562064627FF9DB, p0, p1)

def IS_VEHICLE_TYRE_BURST(vehicle: int, wheelID: int, completely: bool) -> bool:
    return _ib(0xBA291848A0815CA9, vehicle, wheelID, completely)

def EXPLODE_VEHICLE(vehicle: int, isAudible: bool, isInvisible: bool) -> None:
    _iv(0xBA71116ADF5B514C, vehicle, isAudible, isInvisible)

def GET_IS_BOAT_CAPSIZED(vehicle: int) -> bool:
    return _ib(0xBA91D045575699AD, vehicle)

def SET_VEHICLE_MAX_SPEED(vehicle: int, speed: float) -> None:
    _iv(0xBAA045B4E42F3C06, vehicle, speed)

def _SET_PLANE_AVOIDS_OTHERS(vehicle: int, toggle: bool) -> None:
    _iv(0xBAFB99B304BC52A7, vehicle, toggle)

def SET_VEHICLE_USES_MP_PLAYER_DAMAGE_MULTIPLIER(p0: int, p1: int) -> None:
    _iv(0xBB2333BB87DDD87F, p0, p1)

def GET_PED_IN_VEHICLE_SEAT(vehicle: int, seatIndex: int, p2: bool) -> int:
    return _ii(0xBB40DD2270B65366, vehicle, seatIndex, p2)

def SET_MISSION_TRAIN_AS_NO_LONGER_NEEDED(train: int, p1: bool) -> None:
    _iv(0xBBE7648349B49BE8, train, p1)

def SET_VEHICLE_INTERIORLIGHT(vehicle: int, toggle: bool) -> None:
    _iv(0xBC2042F090AF6AD3, vehicle, toggle)

def SET_LIGHTS_CUTOFF_DISTANCE_TWEAK(distance: float) -> None:
    _iv(0xBC3CCA5844452B06, distance)

def IS_HELI_PART_BROKEN(vehicle: int, p1: bool, p2: bool, p3: bool) -> bool:
    return _ib(0xBC74B4BE25EB6C8A, vehicle, p1, p2, p3)

def GET_VEHICLE_HAS_PARACHUTE(vehicle: int) -> bool:
    return _ib(0xBC9CFF381338CB4F, vehicle)

def SET_CARGOBOB_PICKUP_MAGNET_STRENGTH(cargobob: int, strength: float) -> None:
    _iv(0xBCBFCD9D1DAC19E2, cargobob, strength)

def GET_DOES_VEHICLE_HAVE_DAMAGE_DECALS(vehicle: int) -> bool:
    return _ib(0xBCDC5017D3CE1E9E, vehicle)

def SET_PLAYERS_LAST_VEHICLE(vehicle: int) -> None:
    _iv(0xBCDF8BAF56C87B6A, vehicle)

def SET_BOAT_WRECKED(vehicle: int) -> None:
    _iv(0xBD32E46AA95C1DD2, vehicle)

def TRANSFORM_TO_SUBMARINE(vehicle: int, noAnimation: bool) -> bool:
    return _ib(0xBE4C854FFDB6EEBE, vehicle, noAnimation)

def SET_VEHICLE_WILL_FORCE_OTHER_VEHICLES_TO_STOP(vehicle: int, toggle: bool) -> None:
    _iv(0xBE5C1255A1830FF5, vehicle, toggle)

def SET_VEHICLE_INDIVIDUAL_DOORS_LOCKED(vehicle: int, doorId: int, doorLockStatus: int) -> None:
    _iv(0xBE70724027F85BCD, vehicle, doorId, doorLockStatus)

def _GET_REMAINING_NITROUS_DURATION(vehicle: int) -> float:
    return _if(0xBEC4B8653462450E, vehicle)

def IS_THIS_MODEL_A_BICYCLE(model: int) -> bool:
    return _ib(0xBF94DD42F63BDED2, model)

def GET_VEHICLE_MODEL_MAX_BRAKING_MAX_MODS(modelHash: int) -> float:
    return _if(0xBFBA3BA79CFF7EBF, modelHash)

def SET_VEHICLE_NAME_DEBUG(vehicle: int, name: str) -> None:
    _iv(0xBFDF984E2C22B94F, vehicle, name)

def GET_ENTRY_POINT_POSITION(vehicle: int, doorId: int) -> 'gta.Vector3':
    return _ivec(0xC0572928C0ABFDA3, vehicle, doorId)

def SET_PICKUP_ROPE_LENGTH_WITHOUT_CREATING_ROPE_FOR_CARGOBOB(p0: int, p1: int, p2: int) -> None:
    _iv(0xC0ED6438E6D39BA8, p0, p1, p2)

def IS_VEHICLE_SEARCHLIGHT_ON(vehicle: int) -> bool:
    return _ib(0xC0F97FCE55094987, vehicle)

def SET_ALL_VEHICLE_GENERATORS_ACTIVE_IN_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, toggle: bool, p7: bool) -> None:
    _iv(0xC12321827687FE4D, x1, y1, z1, x2, y2, z2, toggle, p7)

def SWING_BOAT_BOOM_FREELY(vehicle: int, toggle: bool) -> None:
    _iv(0xC1F981A6F74F0C23, vehicle, toggle)

def SET_HYDRAULIC_WHEEL_STATE(vehicle: int, wheelId: int, state: int, value: float, p4: int) -> None:
    _iv(0xC24075310A8B9CD1, vehicle, wheelId, state, value, p4)

def DETACH_VEHICLE_FROM_TOW_TRUCK(towTruck: int, vehicle: int) -> None:
    _iv(0xC2DB6B6708350ED8, towTruck, vehicle)

def SET_VEHICLE_BROKEN_PARTS_DONT_AFFECT_AI_HANDLING(vehicle: int, p1: bool) -> None:
    _iv(0xC361AA040D6637A8, vehicle, p1)

def SET_VEHICLE_USE_PLAYER_LIGHT_SETTINGS(vehicle: int, toggle: bool) -> None:
    _iv(0xC45C27EF50F36ADC, vehicle, toggle)

def GET_VEHICLE_ENGINE_HEALTH(vehicle: int) -> float:
    return _if(0xC45D23BAF168AAB8, vehicle)

def SET_VEHICLE_REMOVE_AGGRESSIVE_CARJACK_MISSION(p0: int) -> None:
    _iv(0xC4B3347BD68BD609, p0)

def SET_VEHICLE_LIMIT_SPEED_WHEN_PLAYER_INACTIVE(vehicle: int, toggle: bool) -> None:
    _iv(0xC50CE861B55EAB8B, vehicle, toggle)

def REMOVE_VEHICLE_UPSIDEDOWN_CHECK(vehicle: int) -> None:
    _iv(0xC53EB42A499A7E90, vehicle)

def GET_RANDOM_VEHICLE_FRONT_BUMPER_IN_SPHERE(p0: float, p1: float, p2: float, p3: float, p4: int, p5: int, p6: int) -> int:
    return _ii(0xC5574E0AEB86BA68, p0, p1, p2, p3, p4, p5, p6)

def SET_SUBMARINE_CRUSH_DEPTHS(vehicle: int, p1: bool, depth1: float, depth2: float, depth3: float) -> None:
    _iv(0xC59872A5134879C7, vehicle, p1, depth1, depth2, depth3)

def SET_TURRET_HIDDEN(vehicle: int, index: int, toggle: bool) -> None:
    _iv(0xC60060EB0D8AC7B1, vehicle, index, toggle)

def FORCE_SUBMARINE_NEURTAL_BUOYANCY(p0: int, p1: int) -> None:
    _iv(0xC67DB108A9ADE3BE, p0, p1)

def IS_VEHICLE_BEING_BROUGHT_TO_HALT(vehicle: int) -> bool:
    return _ib(0xC69BB1D832A710EF, vehicle)

def GET_FLYING_VEHICLE_MODEL_AGILITY(modelHash: int) -> float:
    return _if(0xC6AD107DDC9054CC, modelHash)

def CLEAR_NITROUS(vehicle: int) -> None:
    _iv(0xC889AE921400E1ED, vehicle)

def SET_OVERRIDE_NITROUS_LEVEL(vehicle: int, toggle: bool, level: float, power: float, rechargeTime: float, disableSound: bool) -> None:
    _iv(0xC8E9B6B71B8E660D, vehicle, toggle, level, power, rechargeTime, disableSound)

def SET_TYRE_MAXIMUM_GRIP_DIFFERENCE_DUE_TO_WEAR_RATE(vehicle: int, wheelIndex: int, multiplier: float) -> None:
    _iv(0xC970D0E0FC31D768, vehicle, wheelIndex, multiplier)

def GET_VEHICLE_INDIVIDUAL_DOOR_LOCK_STATUS(vehicle: int, doorId: int) -> int:
    return _ii(0xCA4AC3EAAE46EC7B, vehicle, doorId)

def SET_NUMBER_OF_PARKED_VEHICLES(value: int) -> None:
    _iv(0xCAA15F13EBD417FF, value)

def SET_VEHICLE_USES_LARGE_REAR_RAMP(vehicle: int, toggle: bool) -> None:
    _iv(0xCAC66558B944DA67, vehicle, toggle)

def GET_ATTACHED_PICK_UP_HOOK_POSITION(cargobob: int) -> 'gta.Vector3':
    return _ivec(0xCBDB9B923CACC92D, cargobob)

def SET_VEHICLE_ALARM(vehicle: int, state: bool) -> None:
    _iv(0xCDE5E70C1DDB954C, vehicle, state)

def SET_DISABLE_VERTICAL_FLIGHT_MODE_TRANSITION(vehicle: int, toggle: bool) -> None:
    _iv(0xCE2B43770B655F8F, vehicle, toggle)

def IS_VEHICLE_IN_GARAGE_AREA(garageName: str, vehicle: int) -> bool:
    return _ib(0xCEE4490CD57BB3C2, garageName, vehicle)

def SET_CARGOBOB_PICKUP_ROPE_DAMPING_MULTIPLIER(p0: int, p1: int) -> None:
    _iv(0xCF1182F682F65307, p0, p1)

def SET_VEHICLE_READY_FOR_CLEANUP(p0: int) -> None:
    _iv(0xCF9159024555488C, p0)

def CONTROL_LANDING_GEAR(vehicle: int, state: int) -> None:
    _iv(0xCFC8BE9A5E1FE575, vehicle, state)

def LOCK_DOORS_WHEN_NO_LONGER_NEEDED(vehicle: int) -> None:
    _iv(0xCFD778E7904C255E, vehicle)

def GET_ARE_BOMB_BAY_DOORS_OPEN(aircraft: int) -> bool:
    return _ib(0xD0917A423314BBA8, aircraft)

def DETACH_VEHICLE_FROM_ANY_TOW_TRUCK(vehicle: int) -> bool:
    return _ib(0xD0E9CE05A1E68CD8, vehicle)

def SET_SPECIAL_FLIGHT_MODE_RATIO(vehicle: int, ratio: float) -> None:
    _iv(0xD138FA15C9776837, vehicle, ratio)

def GET_POSITION_OF_VEHICLE_RECORDING_AT_TIME(recording: int, time: float, script: str) -> 'gta.Vector3':
    return _ivec(0xD242728AA6F0FBA2, recording, time, script)

def IS_VEHICLE_EXTRA_TURNED_ON(vehicle: int, extraId: int) -> bool:
    return _ib(0xD2E6822DBFD6C8BD, vehicle, extraId)

def SET_VEHICLE_AVOID_PLAYER_VEHICLE_RIOT_VAN_MISSION(p0: int) -> None:
    _iv(0xD3301660A57C9272, p0)

def VEHICLE_SET_OVERRIDE_SIDE_RATIO(p0: int, p1: int) -> int:
    return _ii(0xD3E51C0AB8C26EEE, p0, p1)

def IS_VEHICLE_ATTACHED_TO_CARGOBOB(cargobob: int, vehicleAttached: int) -> bool:
    return _ib(0xD40148F22E81A1D9, cargobob, vehicleAttached)

def SET_DISABLE_DAMAGE_WITH_PICKED_UP_ENTITY(p0: int, p1: int) -> bool:
    return _ib(0xD4196117AF7BB974, p0, p1)

def SET_DISABLE_RANDOM_TRAINS_THIS_FRAME(toggle: bool) -> None:
    _iv(0xD4B8E3D1917BC86B, toggle)

def GET_VEHICLE_IS_MERCENARY(vehicle: int) -> bool:
    return _ib(0xD4C4642CB7F50B5D, vehicle)

def SET_VEHICLE_DOOR_BROKEN(vehicle: int, doorId: int, deleteDoor: bool) -> None:
    _iv(0xD4D4F6A4AB575A33, vehicle, doorId, deleteDoor)

def SET_VEHICLE_EXPLODES_ON_EXPLOSION_DAMAGE_AT_ZERO_BODY_HEALTH(vehicle: int, toggle: bool) -> None:
    _iv(0xD565F438137F0E10, vehicle, toggle)

def RESET_VEHICLE_STUCK_TIMER(vehicle: int, nullAttributes: int) -> None:
    _iv(0xD7591B0065AFAA7A, vehicle, nullAttributes)

def SET_VEHICLE_HAS_MUTED_SIRENS(vehicle: int, toggle: bool) -> None:
    _iv(0xD8050E0EB60CF274, vehicle, toggle)

def SET_SCRIPT_VEHICLE_GENERATOR(vehicleGenerator: int, enabled: bool) -> None:
    _iv(0xD9D620E0AC6DC4B0, vehicleGenerator, enabled)

def SET_RANDOM_BOATS_MP(toggle: bool) -> None:
    _iv(0xDA5E12F728DB30CA, toggle)

def GET_VEHICLE_FLIGHT_NOZZLE_POSITION(plane: int) -> float:
    return _if(0xDA62027C8BDB326E, plane)

def _SET_DRIFT_SLIP_ANGLE_LIMITS(vehicle: int, durationScalar: float, amplitudeScalar: float, slipAngleLimit: float) -> None:
    _iv(0xDAF4C98C18AC6F06, vehicle, durationScalar, amplitudeScalar, slipAngleLimit)

def REQUEST_VEHICLE_DIAL(vehicle: int) -> None:
    _iv(0xDBA3C090E3D74690, vehicle)

def SET_DONT_ALLOW_PLAYER_TO_ENTER_VEHICLE_IF_LOCKED_FOR_PLAYER(vehicle: int, p1: bool) -> None:
    _iv(0xDBC631F109350B8C, vehicle, p1)

def GET_VEHICLE_CLASS_MAX_TRACTION(vehicleClass: int) -> float:
    return _if(0xDBC86D85C5059461, vehicleClass)

def _ENABLE_INDIVIDUAL_PLANE_PROPELLER(vehicle: int, propeller: int) -> None:
    _iv(0xDC05D2777F855F44, vehicle, propeller)

def GET_VEHICLE_MODEL_MAX_BRAKING(modelHash: int) -> float:
    return _if(0xDC53FD41B4ED944C, modelHash)

def GET_HAS_RETRACTABLE_WHEELS(vehicle: int) -> bool:
    return _ib(0xDCA174A42133F08C, vehicle)

def IS_THIS_MODEL_A_HELI(model: int) -> bool:
    return _ib(0xDCE4334788AF94EA, model)

def SET_VEHICLE_STEER_FOR_BUILDINGS(vehicle: int, p1: int) -> None:
    _iv(0xDCE97BDF8A0EABC8, vehicle, p1)

def SET_PLANE_CONTROL_SECTIONS_SHOULD_BREAK_OFF_FROM_EXPLOSIONS(vehicle: int, toggle: bool) -> None:
    _iv(0xDD8A2D3337F04196, vehicle, toggle)

def LOWER_CONVERTIBLE_ROOF(vehicle: int, instantlyLower: bool) -> None:
    _iv(0xDED51F703D0FA83D, vehicle, instantlyLower)

def GET_VEHICLE_CLASS_FROM_NAME(modelHash: int) -> int:
    return _ii(0xDEDF1C8BD47C2200, modelHash)

def GET_VEHICLE_SIZE(vehicle: int, out1: int, out2: int) -> None:
    _iv(0xDF7E3EEB29642C38, vehicle, out1, out2)

def SET_VEHICLE_ACTIVE_DURING_PLAYBACK(vehicle: int, toggle: bool) -> None:
    _iv(0xDFFCEF48E511DB48, vehicle, toggle)

def SET_SCRIPT_ROCKET_BOOST_RECHARGE_TIME(vehicle: int, seconds: float) -> None:
    _iv(0xE00F2AB100B76E89, vehicle, seconds)

def CLEAR_LAST_DRIVEN_VEHICLE() -> None:
    _iv(0xE01903C47C7AC89E)

def SET_VEHICLE_USE_CUTSCENE_WHEEL_COMPRESSION(p0: int, p1: bool, p2: bool, p3: bool) -> bool:
    return _ib(0xE023E8AC4EF7C117, p0, p1, p2, p3)

def SET_VEHICLE_USED_FOR_PILOT_SCHOOL(vehicle: int, toggle: bool) -> None:
    _iv(0xE05DD0E9707003A3, vehicle, toggle)

def SET_PLANE_RESIST_TO_EXPLOSION(vehicle: int, toggle: bool) -> None:
    _iv(0xE16142B94664DEFD, vehicle, toggle)

def RESET_FORMATION_LEADER() -> None:
    _iv(0xE2F53F172B45EDE1)

def SET_CARGOBOB_PICKUP_MAGNET_SET_TARGETED_MODE(vehicle: int, cargobob: int) -> None:
    _iv(0xE301BD63E9E13CF0, vehicle, cargobob)

def REMOVE_VEHICLE_COMBAT_AVOIDANCE_AREA(p0: int) -> None:
    _iv(0xE30524E1871F481D, p0)

def IS_TURRET_SEAT(vehicle: int, seatIndex: int) -> bool:
    return _ib(0xE33FFA906CE74880, vehicle, seatIndex)

def POP_OFF_VEHICLE_ROOF_WITH_IMPULSE(vehicle: int, x: float, y: float, z: float) -> None:
    _iv(0xE38CB9D7D39FDBCC, vehicle, x, y, z)

def GET_NUM_VEHICLE_MODS(vehicle: int, modType: int) -> int:
    return _ii(0xE38E9162A2500646, vehicle, modType)

def SET_BOAT_REMAINS_ANCHORED_WHILE_PLAYER_IS_DRIVER(vehicle: int, toggle: bool) -> None:
    _iv(0xE3EBAAE484798530, vehicle, toggle)

def SET_VEHICLE_XENON_LIGHT_COLOR_INDEX(vehicle: int, colorIndex: int) -> None:
    _iv(0xE41033B25D003A07, vehicle, colorIndex)

def GET_VEHICLE_HAS_LANDING_GEAR(vehicle: int) -> bool:
    return _ib(0xE43701C36CAFF1A4, vehicle)

def COPY_VEHICLE_DAMAGES(sourceVehicle: int, targetVehicle: int) -> None:
    _iv(0xE44A982368A4AF23, sourceVehicle, targetVehicle)

def GET_VEHICLE_CAUSE_OF_DESTRUCTION(vehicle: int) -> int:
    return _ii(0xE495D1EF4C91FD20, vehicle)

def GET_HELI_MAIN_ROTOR_HEALTH(vehicle: int) -> float:
    return _if(0xE4CB7541F413D2C5, vehicle)

def SET_VEHICLE_BRAKE(vehicle: int, toggle: bool) -> None:
    _iv(0xE4E2FD323574965C, vehicle, toggle)

def SET_AIRCRAFT_PILOT_SKILL_NOISE_SCALAR(vehicle: int, p1: float) -> None:
    _iv(0xE5810AC70602F2F5, vehicle, p1)

def SET_DISABLE_TURRET_MOVEMENT(vehicle: int, turretId: int) -> None:
    _iv(0xE615BB7A7752C76A, vehicle, turretId)

def GET_VEHICLE_HOMING_LOCKON_STATE(vehicle: int) -> int:
    return _ii(0xE6B0E8CFC3633BF0, vehicle)

def SET_ENABLE_VEHICLE_SLIPSTREAMING(toggle: bool) -> None:
    _iv(0xE6C0C80B8C867537, toggle)

def SET_HELI_TURBULENCE_SCALAR(vehicle: int, p1: float) -> None:
    _iv(0xE6F13851780394DA, vehicle, p1)

def _GET_VEHICLE_EXHAUST_BONE(vehicle: int, index: int, boneIndex: int, axisX: int) -> bool:
    return _ib(0xE728F090D538CB18, vehicle, index, boneIndex, axisX)

def IS_VEHICLE_ATTACHED_TO_TRAILER(vehicle: int) -> bool:
    return _ib(0xE7CF3C4F9F489F0C, vehicle)

def SET_BOAT_LOW_LOD_ANCHOR_DISTANCE(vehicle: int, value: float) -> None:
    _iv(0xE842A9398079BD82, vehicle, value)

def SET_VEHICLE_MAY_BE_USED_BY_GOTO_POINT_ANY_MEANS(vehicle: int, p1: bool) -> None:
    _iv(0xE851E480B814D4BA, vehicle, p1)

def GET_HAS_VEHICLE_BEEN_HIT_BY_SHUNT(vehicle: int) -> bool:
    return _ib(0xE8718FAF591FD224, vehicle)

def GET_VEHICLE_MOD_COLOR_1(vehicle: int, paintType: int, color: int, pearlescentColor: int) -> None:
    _iv(0xE8D65CA700C9A693, vehicle, paintType, color, pearlescentColor)

def GET_VEHICLE_BOMB_AMMO(vehicle: int) -> int:
    return _ii(0xEA12BD130D7569A1, vehicle)

def DELETE_VEHICLE(vehicle: int) -> None:
    _iv(0xEA386986E786A54F, vehicle)

def _ARE_MISSILE_BAYS_DEPLOYED(vehicle: int) -> bool:
    return _ib(0xEA4743874D515F13, vehicle)

def SET_PARKED_VEHICLE_DENSITY_MULTIPLIER_THIS_FRAME(multiplier: float) -> None:
    _iv(0xEAE6DCC7EEE3DB1D, multiplier)

def SET_VEHICLE_TYRES_CAN_BURST(vehicle: int, toggle: bool) -> None:
    _iv(0xEB9DC3C7D8596C46, vehicle, toggle)

def NETWORK_USE_HIGH_PRECISION_TRAIN_BLENDING(vehicle: int, toggle: bool) -> None:
    _iv(0xEC0C1D4922AF9754, vehicle, toggle)

def GET_BOTH_VEHICLE_HEADLIGHTS_DAMAGED(vehicle: int) -> bool:
    return _ib(0xEC69ADF931AAE0C3, vehicle)

def SET_VEHICLE_TYRE_BURST(vehicle: int, index: int, onRim: bool, p3: float) -> None:
    _iv(0xEC6A202EE4960385, vehicle, index, onRim, p3)

def SET_BOAT_IGNORE_LAND_PROBES(p0: int, p1: int) -> None:
    _iv(0xED5EDE9E676643C9, p0, p1)

def SET_CARGOBOB_PICKUP_MAGNET_PULL_STRENGTH(cargobob: int, p1: float) -> None:
    _iv(0xED8286F71A819BAA, cargobob, p1)

def SET_DISABLE_HELI_EXPLODE_FROM_BODY_DAMAGE(vehicle: int, disable: bool) -> None:
    _iv(0xEDBC8405B3895CC9, vehicle, disable)

def GET_VEHICLE_COLOURS_WHICH_CAN_BE_SET(vehicle: int) -> int:
    return _ii(0xEEBFC7A7EFDC35B4, vehicle)

def DETONATE_VEHICLE_PHONE_EXPLOSIVE_DEVICE() -> None:
    _iv(0xEF49CF0270307CBE)

def SET_CHECK_FOR_ENOUGH_ROOM_FOR_PED(vehicle: int, p1: bool) -> None:
    _iv(0xEF9D388F8D377F44, vehicle, p1)

def SET_SCRIPT_RAMP_IMPULSE_SCALE(vehicle: int, impulseScale: float) -> None:
    _iv(0xEFC13B1CE30D755D, vehicle, impulseScale)

def GET_ENTITY_ATTACHED_TO_TOW_TRUCK(towTruck: int) -> int:
    return _ii(0xEFEA18DCF10F8F75, towTruck)

def SET_VEHICLE_SLIPSTREAMING_SHOULD_TIME_OUT(toggle: bool) -> None:
    _iv(0xF051D9BFB6BA39C0, toggle)

def SET_USE_HIGHER_CAR_JUMP(vehicle: int, toggle: bool) -> None:
    _iv(0xF06A16CA55D138D8, vehicle, toggle)

def GET_IS_VEHICLE_PRIMARY_COLOUR_CUSTOM(vehicle: int) -> bool:
    return _ib(0xF095C0405307B21B, vehicle)

def DISABLE_VEHCILE_DYNAMIC_AMBIENT_SCALES(vehicle: int, p1: int, p2: int) -> None:
    _iv(0xF0E4BA16D1DB546C, vehicle, p1, p2)

def GET_ROTATION_OF_VEHICLE_RECORDING_ID_AT_TIME(id: int, time: float) -> 'gta.Vector3':
    return _ivec(0xF0F2103EFAF8CBA7, id, time)

def REMOVE_VEHICLE_RECORDING(recording: int, script: str) -> None:
    _iv(0xF1160ACCF98A3FC8, recording, script)

def GET_VEHICLE_NUMBER_PLATE_TEXT_INDEX(vehicle: int) -> int:
    return _ii(0xF11BC2DD9A3E7195, vehicle)

def SET_SPECIAL_FLIGHT_MODE_ALLOWED(vehicle: int, toggle: bool) -> None:
    _iv(0xF1211889DF15A763, vehicle, toggle)

def SET_VEHICLE_OUT_OF_CONTROL(vehicle: int, killDriver: bool, explodeOnImpact: bool) -> None:
    _iv(0xF19D095E42D430CC, vehicle, killDriver, explodeOnImpact)

def DISABLE_VEHICLE_EXPLOSION_BREAK_OFF_PARTS() -> None:
    _iv(0xF25E02CB9C5818F8)

def GET_VEHICLE_BODY_HEALTH(vehicle: int) -> float:
    return _if(0xF271147EB7B40F12, vehicle)

def SET_VEHICLE_DOOR_CONTROL(vehicle: int, doorId: int, speed: int, angle: float) -> None:
    _iv(0xF2BFA0430F0A0FCB, vehicle, doorId, speed, angle)

def SET_CONVERTIBLE_ROOF(vehicle: int, p1: bool) -> None:
    _iv(0xF39C4F538B5124C2, vehicle, p1)

def VEHICLE_SET_EXTENABLE_SIDE_TARGET_RATIO(p0: int, p1: int) -> int:
    return _ii(0xF3B0E0AED097A3F5, p0, p1)

def GET_VEHICLE_COLOR(vehicle: int, r: int, g: int, b: int) -> None:
    _iv(0xF3CC740D36221548, vehicle, r, g, b)

def SET_VEHICLE_EXTRA_COLOUR_5(vehicle: int, color: int) -> None:
    _iv(0xF40DD601A65F7F19, vehicle, color)

def GET_VEHICLE_MODEL_ESTIMATED_MAX_SPEED(modelHash: int) -> float:
    return _if(0xF417C2502FFFED43, modelHash)

def SWING_BOAT_BOOM_TO_RATIO(vehicle: int, ratio: float) -> None:
    _iv(0xF488C566413B4232, vehicle, ratio)

def SET_VEHICLE_SIREN(vehicle: int, toggle: bool) -> None:
    _iv(0xF4924635A19EB37D, vehicle, toggle)

def SET_VEHICLE_BOMB_AMMO(vehicle: int, bombCount: int) -> None:
    _iv(0xF4B2ED59DEB5D774, vehicle, bombCount)

def DISABLE_VEHICLE_WEAPON(disabled: bool, weaponHash: int, vehicle: int, owner: int) -> None:
    _iv(0xF4FC6A6F67D8D856, disabled, weaponHash, vehicle, owner)

def DOES_SCRIPT_VEHICLE_GENERATOR_EXIST(vehicleGenerator: int) -> bool:
    return _ib(0xF6086BC836400876, vehicleGenerator)

def SET_WHEELS_EXTENDED_INSTANTLY(vehicle: int) -> None:
    _iv(0xF660602546D27BA8, vehicle)

def GET_VEHICLE_DOORS_LOCKED_FOR_PLAYER(vehicle: int, player: int) -> bool:
    return _ib(0xF6AF6CB341349015, vehicle, player)

def GET_CLOSEST_VEHICLE(x: float, y: float, z: float, radius: float, modelHash: int, flags: int) -> int:
    return _ii(0xF73EB622C4F1689B, x, y, z, radius, modelHash, flags)

def ARE_PLANE_CONTROL_PANELS_INTACT(vehicle: int, p1: bool) -> bool:
    return _ib(0xF78F94D60248C737, vehicle, p1)

def SET_DISTANT_CARS_ENABLED(toggle: bool) -> None:
    _iv(0xF796359A959DF65D, toggle)

def GET_MAKE_NAME_FROM_VEHICLE_MODEL(modelHash: int) -> str:
    return _is(0xF7AF4F159FF99F97, modelHash)

def SET_VEHICLE_IS_WANTED(vehicle: int, state: bool) -> None:
    _iv(0xF7EC25A3EBEEC726, vehicle, state)

def IS_SEAT_WARP_ONLY(vehicle: int, seatIndex: int) -> bool:
    return _ib(0xF7F203E31F96F6A1, vehicle, seatIndex)

def GET_VEHICLE_COUNTERMEASURE_AMMO(vehicle: int) -> int:
    return _ii(0xF846AA63DF56B804, vehicle)

def ENABLE_VEHICLE_DYNAMIC_AMBIENT_SCALES(vehicle: int) -> None:
    _iv(0xF87D9F2301F7D206, vehicle)

def SET_AIRCRAFT_IGNORE_HIGHTMAP_OPTIMISATION(vehicle: int, p1: int) -> None:
    _iv(0xF8B49F5BA7F850E7, vehicle, p1)

def GET_CONVERTIBLE_ROOF_STATE(vehicle: int) -> int:
    return _ii(0xF8C397922FC03F41, vehicle)

def SET_VEHICLE_BULLDOZER_ARM_POSITION(vehicle: int, position: float, p2: bool) -> None:
    _iv(0xF8EBCCC96ADB9FB7, vehicle, position, p2)

def _GET_VEHICLE_CURRENT_REV_RATIO(vehicle: int) -> float:
    return _if(0xF9DDA40BC293A61E, vehicle)

def SET_GLOBAL_POSITION_OFFSET_FOR_RECORDED_VEHICLE_PLAYBACK(vehicle: int, x: float, y: float, z: float) -> None:
    _iv(0xFAF2A78061FD9EF4, vehicle, x, y, z)

def SET_VEHICLE_BURNOUT(vehicle: int, toggle: bool) -> None:
    _iv(0xFB8794444A7D60FB, vehicle, toggle)

def SET_VEHICLE_NEEDS_TO_BE_HOTWIRED(vehicle: int, toggle: bool) -> None:
    _iv(0xFBA550EA44404EE6, vehicle, toggle)

def GET_VEHICLE_MOD_KIT_TYPE(vehicle: int) -> int:
    return _ii(0xFC058F5121E54C32, vehicle)

def SET_CAR_BOOT_OPEN(vehicle: int) -> None:
    _iv(0xFC40CBF7B90CA77C, vehicle)

def SET_HELI_BLADES_SPEED(vehicle: int, speed: float) -> None:
    _iv(0xFD280B4D7F3ABC4D, vehicle, speed)

def SWITCH_TRAIN_TRACK(trackId: int, state: bool) -> None:
    _iv(0xFD813BB7DB977F20, trackId, state)

def _GET_VEHICLE_DESIRED_DRIVE_GEAR(vehicle: int) -> int:
    return _ii(0xFD8CE53356B5D745, vehicle)

def SET_HELI_TAIL_ROTOR_HEALTH(vehicle: int, health: float) -> None:
    _iv(0xFE205F38AAA58E5B, vehicle, health)

def GET_VEHICLE_DOOR_ANGLE_RATIO(vehicle: int, doorId: int) -> float:
    return _if(0xFE3F9C29F7B32BD5, vehicle, doorId)

def SET_VEHICLE_TOW_TRUCK_ARM_POSITION(vehicle: int, position: float) -> None:
    _iv(0xFE54B92A344583CA, vehicle, position)

def SET_ROCKET_BOOST_FILL(vehicle: int, percentage: float) -> None:
    _iv(0xFEB2DDED3509562E, vehicle, percentage)
