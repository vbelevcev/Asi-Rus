"""Auto-generated raw native bindings for namespace NETWORK.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_str as _is, _invoke_vector3 as _ivec


def _NETWORK_SET_TUNABLES_REGISTRATION_CONTEXTS(tunableContextData: int) -> None:
    _iv(0x014A73449675121D, tunableContextData)

def GET_TIME_OFFSET(timeA: int, timeB: int) -> int:
    return _ii(0x017008CCDAD48503, timeA, timeB)

def NETWORK_GET_PLATFORM_PARTY_MEMBER_COUNT() -> int:
    return _ii(0x01ABCE5E7CBDA196)

def NETWORK_HAS_CONTROL_OF_ENTITY(entity: int) -> bool:
    return _ib(0x01BF60A500E28887, entity)

def NETWORK_CAN_SEND_LOCAL_INVITE(gamerHandle: int) -> bool:
    return _ib(0x021ABCBD98EC4320, gamerHandle)

def NETWORK_CANCEL_TRANSITION_MATCHMAKING() -> None:
    _iv(0x023782EFC70585EE)

def NETWORK_SHOULD_SHOW_PROMOTION_ALERT_SCREEN() -> bool:
    return _ib(0x023ACAB2DC9DC4A4)

def _NETWORK_IS_AMERICAS_VERSION() -> bool:
    return _ib(0x0292BD7F3766CEBC)

def NETWORK_GET_GAMER_STATUS_RESULT(p0: int, p1: int) -> bool:
    return _ib(0x02A8BEC6FD9AF660, p0, p1)

def UGC_HAS_GET_FINISHED() -> bool:
    return _ib(0x02ADA21EA2F6918F)

def NETWORK_GET_LOCAL_SCENE_FROM_NETWORK_ID(netId: int) -> int:
    return _ii(0x02C40BF885C567B6, netId)

def NETWORK_IS_PLAYER_TALKING(player: int) -> bool:
    return _ib(0x031E11F3D447647E, player)

def NETWORK_SET_OBJECT_CAN_BLEND_WHEN_FIXED(object: int, toggle: bool) -> None:
    _iv(0x0379DAF89BA09AA5, object, toggle)

def NETWORK_CLEAR_INVALID_OBJECT_MODELS() -> None:
    _iv(0x03B2F03A53D85E41)

def NETWORK_SESSION_RESERVE_SLOTS_TRANSITION(p0: int, p1: int, p2: int) -> bool:
    return _ib(0x041C7F2A6C9894E6, p0, p1, p2)

def NETWORK_GET_PRIMARY_CLAN_DATA_CANCEL() -> None:
    _iv(0x042E4B70B93E6054)

def NETWORK_IS_TUNABLE_CLOUD_REQUEST_PENDING() -> bool:
    return _ib(0x0467C11ED88B7D28)

def NETWORK_IS_IN_SPECTATOR_MODE() -> bool:
    return _ib(0x048746E388762E11)

def NETWORK_TRANSITION_FINISH(p0: int, p1: int, p2: int) -> bool:
    return _ib(0x04918A41BC9B8157, p0, p1, p2)

def _NETWORK_GET_RANDOM_FLOAT_RANGED(rangeStart: float, rangeEnd: float) -> float:
    return _if(0x04BD27B5ACB67067, rangeStart, rangeEnd)

def NETWORK_IS_ACTIVITY_SESSION() -> bool:
    return _ib(0x05095437424397FA)

def NETWORK_IS_SIGNED_IN() -> bool:
    return _ib(0x054354A99211EB96)

def NETWORK_CLEAR_FOLLOWERS() -> None:
    _iv(0x058F43EC59A8631A)

def NETWORK_REGISTER_ENTITY_AS_NETWORKED(entity: int) -> None:
    _iv(0x06FAACD625D80CAA, entity)

def NETWORK_CAN_PLAY_MULTIPLAYER_WITH_GAMER(gamerHandle: int) -> bool:
    return _ib(0x07DD29D5E22763F1, gamerHandle)

def NETWORK_CHECK_TEXT_COMMUNICATION_PRIVILEGES(p0: int, p1: int, p2: int) -> bool:
    return _ib(0x07EAB372C8841D99, p0, p1, p2)

def FACEBOOK_POST_COMPLETED_HEIST(heistName: str, cashEarned: int, xpEarned: int) -> bool:
    return _ib(0x098AB65B9ED9A9EC, heistName, cashEarned, xpEarned)

def NETWORK_GET_ENTITY_IS_LOCAL(entity: int) -> bool:
    return _ib(0x0991549DE4D64762, entity)

def _NETWORK_CONFIRM_GAME_RESTART() -> None:
    _iv(0x0A141818CA2311AD)

def CAN_REGISTER_MISSION_PICKUPS(amount: int) -> bool:
    return _ib(0x0A49D1CB6E34AF72, amount)

def FACEBOOK_POST_COMPLETED_MILESTONE(milestoneId: int) -> bool:
    return _ib(0x0AE1F1653B554AB9, milestoneId)

def GET_MAX_NUM_NETWORK_VEHICLES() -> int:
    return _ii(0x0AFCE529F69B21FF)

def CLOUD_GET_AVAILABILITY_CHECK_RESULT() -> bool:
    return _ib(0x0B0CC10720653F3B)

def TITLE_TEXTURE_DOWNLOAD_REQUEST(filePath: str, name: str, p2: bool) -> int:
    return _ii(0x0B203B4AFDE53A4F, filePath, name, p2)

def NETWORK_IS_TRANSITION_HOST() -> bool:
    return _ib(0x0B824797C9BF2159)

def NETWORK_IS_PENDING_FRIEND(p0: int) -> bool:
    return _ib(0x0BE73DA6984A6E33, p0)

def GET_MAX_NUM_NETWORK_PEDS() -> int:
    return _ii(0x0C1F7D49C39D2289)

def _NETWORK_CLEAR_TUNABLES_REGISTRATION_CONTEXTS() -> None:
    _iv(0x0C87C83C8950432B)

def NETWORK_SET_TRANSITION_VISIBILITY_LOCK(p0: bool, p1: bool) -> None:
    _iv(0x0C978FDA19692C2C, p0, p1)

def GET_NUM_CREATED_MISSION_VEHICLES(p0: bool) -> int:
    return _ii(0x0CD9AB83489430EA, p0)

def NETWORK_CHECK_PRIVILEGES(p0: int, p1: int, p2: int) -> bool:
    return _ib(0x0CF6CC51AA18F0F8, p0, p1, p2)

def NETWORK_SET_INVITE_FAILED_MESSAGE_FOR_INVITE_MENU(p0: int, p1: int) -> None:
    _iv(0x0D77A82DC2D0DA59, p0, p1)

def _NETWORK_GET_TUNABLES_REGISTRATION_INT(tunableName: int, defaultValue: int) -> int:
    return _ii(0x0D94071E55F4C9CE, tunableName, defaultValue)

def NETWORK_IS_TRANSITION_CLOSED_CREW() -> bool:
    return _ib(0x0DBD5D7E3C5BEC3B)

def NETWORK_GET_AVERAGE_PING(player: int) -> float:
    return _if(0x0E3A041ED6AC2B45, player)

def NETWORK_SET_ACTIVITY_PLAYER_MAX(p0: int) -> None:
    _iv(0x0E4F77F7B9D74D84, p0)

def NETWORK_SET_ATTRIBUTE_DAMAGE_TO_PLAYER(ped: int, player: int) -> bool:
    return _ib(0x0EDE326D47CD0F3E, ped, player)

def PED_TO_NET(ped: int) -> int:
    return _ii(0x0EDEC3C276198689, ped)

def NETWORK_IS_GAMER_IN_MY_SESSION(gamerHandle: int) -> bool:
    return _ib(0x0F10B05DDF8D16E9, gamerHandle)

def NETWORK_ALLOW_CLONING_WHILE_IN_TUTORIAL(p0: int, p1: int) -> None:
    _iv(0x0F1A4B45B7693B95, p0, p1)

def NETWORK_OVERRIDE_RECEIVE_RESTRICTIONS_ALL(toggle: bool) -> None:
    _iv(0x0FF2862B61A58AF9, toggle)

def NETWORK_IS_SIGNED_ONLINE() -> bool:
    return _ib(0x1077788E268557C2)

def NETWORK_GET_TUNABLE_CLOUD_CRC() -> int:
    return _ii(0x10BD227A753B0D84)

def NETWORK_IS_GAME_IN_PROGRESS() -> bool:
    return _ib(0x10FAB35428CCC9D7)

def NETWORK_CLAN_RELEASE_EMBLEM(p0: int) -> None:
    _iv(0x113E6E3E50E286B0, p0)

def NETWORK_SESSION_SET_SCRIPT_VALIDATE_JOIN() -> None:
    _iv(0x1153FA02A659051C)

def NETWORK_SEND_IMPORTANT_TRANSITION_INVITE_VIA_PRESENCE(gamerHandle: int, p1: str, dataCount: int, p3: int) -> bool:
    return _ib(0x1171A97A3D3981B6, gamerHandle, p1, dataCount, p3)

def NETWORK_GET_PLATFORM_PARTY_MEMBERS(data: int, dataSize: int) -> int:
    return _ii(0x120364DE2845DAF8, data, dataSize)

def NETWORK_IS_ACTIVITY_SPECTATOR() -> bool:
    return _ib(0x12103B9E0C9F92FB)

def NETWORK_GET_LAST_PLAYER_POS_RECEIVED_OVER_NETWORK(player: int) -> 'gta.Vector3':
    return _ivec(0x125E6D638B8605D4, player)

def SET_PLAYER_INVISIBLE_LOCALLY(player: int, bIncludePlayersVehicle: bool) -> None:
    _iv(0x12B37D54667DB0B8, player, bIncludePlayersVehicle)

def GET_NUM_CREATED_MISSION_OBJECTS(p0: bool) -> int:
    return _ii(0x12B6281B6C6706C0, p0)

def NETWORK_CLAN_REQUEST_EMBLEM(p0: int) -> bool:
    return _ib(0x13518FF1C6B28938, p0)

def NETWORK_HAS_AGE_RESTRICTIONS() -> bool:
    return _ib(0x1353F87E89946207)

def NETWORK_CAN_GAMER_PLAY_MULTIPLAYER_WITH_ME(gamerHandle: int) -> bool:
    return _ib(0x135F9B7B7ADD2185, gamerHandle)

def NETWORK_TRANSITION_SET_IN_PROGRESS(p0: int) -> None:
    _iv(0x1398582B7F72B3ED, p0)

def SET_NON_PARTICIPANTS_OF_THIS_SCRIPT_AS_GHOSTS(p0: bool) -> None:
    _iv(0x13F1FCB111B820B0, p0)

def NETWORK_CLEAR_OFFLINE_INVITE_PENDING() -> None:
    _iv(0x140E6A44870A11CE)

def NETWORK_ALLOW_REMOTE_SYNCED_SCENE_LOCAL_PLAYER_REQUESTS(p0: int) -> None:
    _iv(0x144DA052257AE7D8, p0)

def NETWORK_IS_QUEUING_FOR_SESSION_JOIN() -> bool:
    return _ib(0x14922ED3E38761F0)

def UGC_COPY_CONTENT(p0: int, p1: int) -> bool:
    return _ib(0x152D90E4C1B4738A, p0, p1)

def NETWORK_AM_I_BLOCKED_BY_GAMER(gamerHandle: int) -> bool:
    return _ib(0x15337C7C268A27B2, gamerHandle)

def GET_USER_STARTER_ACCESS() -> int:
    return _ii(0x155467ACA0F55705)

def UGC_QUERY_BY_CONTENT_ID(contentId: str, latestVersion: bool, contentTypeName: str) -> bool:
    return _ib(0x158EC424F35EC469, contentId, latestVersion, contentTypeName)

def TEXTURE_DOWNLOAD_REQUEST(gamerHandle: int, filePath: str, name: str, p3: bool) -> int:
    return _ii(0x16160DA74A8E74A2, gamerHandle, filePath, name, p3)

def UGC_DID_DESCRIPTION_REQUEST_SUCCEED(p0: int) -> bool:
    return _ib(0x162C23CA83ED0A62, p0)

def NETWORK_CONCEAL_ENTITY(entity: int, toggle: bool) -> None:
    _iv(0x1632BE0AC1E62876, entity, toggle)

def NETWORK_IS_CONNECTED_VIA_RELAY(player: int) -> bool:
    return _ib(0x16D3D49902F697BB, player)

def UGC_REQUEST_CONTENT_DATA_FROM_INDEX(p0: int, p1: int) -> int:
    return _ii(0x171DF6A0C07FB3DC, p0, p1)

def NETWORK_PLAYER_GET_CHEATER_REASON() -> int:
    return _ii(0x172F75B6EE2233BA)

def RESET_GHOST_ALPHA() -> None:
    _iv(0x17330EBF2F2124A8)

def UGC_CLEAR_CREATE_RESULT() -> None:
    _iv(0x17440AA15D1D3739)

def NETWORK_KEEP_ENTITY_COLLISION_DISABLED_AFTER_ANIM_SCENE(p0: int, p1: int) -> None:
    _iv(0x17C9E241111A674D, p0, p1)

def NETWORK_START_SOLO_TUTORIAL_SESSION() -> None:
    _iv(0x17E0198B3882C2CB)

def NETWORK_GET_CONTENT_MODIFIER_LIST_ID(contentHash: int) -> int:
    return _ii(0x187382F8A3E0A6C3, contentHash)

def NETWORK_CLEAR_GROUP_ACTIVITY() -> None:
    _iv(0x1888694923EF4591)

def NETWORK_DOES_ENTITY_EXIST_WITH_NETWORK_ID(netId: int) -> bool:
    return _ib(0x18A47D074708FD68, netId)

def NETWORK_GET_NUM_PARTICIPANTS() -> int:
    return _ii(0x18D0456E86604654)

def NETWORK_ACCESS_TUNABLE_FLOAT_MODIFICATION_DETECTION_REGISTRATION_HASH(contextHash: int, nameHash: int, value: int) -> bool:
    return _ib(0x1950DAE9848A4739, contextHash, nameHash, value)

def NETWORK_PLAYER_IS_BADSPORT() -> bool:
    return _ib(0x19D8DA0E5A68045A)

def NETWORK_IS_FRIEND(gamerHandle: int) -> bool:
    return _ib(0x1A24A179F9B31654, gamerHandle)

def UGC_GET_CONTENT_RATING(p0: int, p1: int) -> float:
    return _if(0x1ACCFBA3D8DAB2EE, p0, p1)

def NETWORK_IS_PLAYER_A_PARTICIPANT_ON_SCRIPT(player: int, script: str, instance_id: int) -> bool:
    return _ib(0x1AD5B71586B94820, player, script, instance_id)

def NETWORK_GET_PARTICIPANT_INDEX(index: int) -> int:
    return _ii(0x1B84DF6AF2A46938, index)

def NETWORK_SET_PLAYER_IS_PASSIVE(toggle: bool) -> None:
    _iv(0x1B857666604B1A74, toggle)

def NETWORK_SET_THIS_SCRIPT_IS_NETWORK_SCRIPT(maxNumMissionParticipants: int, p1: bool, instanceId: int) -> None:
    _iv(0x1CA59E306ECB80A5, maxNumMissionParticipants, p1, instanceId)

def IS_COMMERCE_DATA_FETCH_IN_PROGRESS() -> bool:
    return _ib(0x1D4DC17C38FEAFF0)

def UGC_GET_CONTENT_HAS_LO_RES_PHOTO(p0: int) -> bool:
    return _ib(0x1D610EB0FEA716D9, p0)

def NETWORK_GET_HOST_OF_SCRIPT(scriptName: str, instance_id: int, position_hash: int) -> int:
    return _ii(0x1D6A14F1F9A736FC, scriptName, instance_id, position_hash)

def NETWORK_SET_RICH_PRESENCE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x1DCCACDCFC569362, p0, p1, p2, p3)

def UGC_PUBLISH(contentId: str, baseContentId: str, contentTypeName: str) -> bool:
    return _ib(0x1DE0F5F50D723CAA, contentId, baseContentId, contentTypeName)

def GET_NUM_RESERVED_MISSION_PEDS(p0: bool, p1: int) -> int:
    return _ii(0x1F13D5AE5CB17E17, p0, p1)

def NETWORK_CLAN_GET_LOCAL_MEMBERSHIPS_COUNT() -> int:
    return _ii(0x1F471B79ACC90BEF)

def NETWORK_FADE_IN_ENTITY(entity: int, state: bool, p2: int) -> None:
    _iv(0x1F4ED342ACEFE62D, entity, state, p2)

def NETWORK_SET_PRIVILEGE_CHECK_RESULT_NOT_NEEDED() -> None:
    _iv(0x1F7BC3539F9E0224)

def NETWORK_TRANSITION_SET_CONTENT_CREATOR(p0: int) -> None:
    _iv(0x1F8E00FB18239600, p0)

def NETWORK_GET_FRIEND_COUNT() -> int:
    return _ii(0x203F1CFD823B27A4)

def _NETWORK_DOES_COMMUNICATION_GROUP_HAVE_SETTINGS_ENABLED(communicationType: int) -> bool:
    return _ib(0x20C12650830A64EC, communicationType)

def _NETWORK_GET_ACCESS_CODE_LABEL_BODY(accessCode: int) -> str:
    return _is(0x214CA1730793EBA8, accessCode)

def NETWORK_GET_PLAYER_LOUDNESS(player: int) -> float:
    return _if(0x21A1684A25C2867F, player)

def IS_ENTITY_A_GHOST(entity: int) -> bool:
    return _ib(0x21D04D7BC538C146, entity)

def NETWORK_PREVENT_SCRIPT_HOST_MIGRATION() -> None:
    _iv(0x2302C0264EA58D31)

def NETWORK_ADD_FOLLOWERS(p0: int, p1: int) -> None:
    _iv(0x236406F60CF216D6, p0, p1)

def NETWORK_DISABLE_REALTIME_MULTIPLAYER() -> None:
    _iv(0x236905C700FDB54D)

def NETWORK_HAS_CACHED_PLAYER_HEAD_BLEND_DATA(player: int) -> bool:
    return _ib(0x237D5336A9A54108, player)

def NETWORK_SESSION_WAS_INVITED() -> bool:
    return _ib(0x23DFB504655D0CE4)

def SET_ENTITY_LOCALLY_VISIBLE(entity: int) -> None:
    _iv(0x241E289B5C059EDC, entity)

def NETWORK_GET_PRESENCE_INVITE_CONTENT_ID(p0: int) -> str:
    return _is(0x24409FC4C55CB22D, p0)

def UGC_DID_CREATE_SUCCEED() -> bool:
    return _ib(0x24E4E51FC16305F9)

def NETWORK_GET_PLAYER_INDEX(player: int) -> int:
    return _ii(0x24FB80D107371267, player)

def NETWORK_GET_SIGNALLING_INFO(p0: int) -> None:
    _iv(0x2555CF7DA5473794, p0)

def NETWORK_GET_POSITION_HASH_OF_THIS_SCRIPT() -> int:
    return _ii(0x257ED0FADF750BCF)

def NETWORK_ADD_CLIENT_ENTITY_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> int:
    return _ii(0x25B99872D588A101, x1, y1, z1, x2, y2, z2)

def NETWORK_HAVE_ONLINE_PRIVILEGES() -> bool:
    return _ib(0x25CB5A9F37BFD063)

def NETWORK_REMOVE_ALL_QUEUED_JOIN_REQUESTS() -> None:
    _iv(0x25D990F8E0E3F13C)

def NETWORK_ARE_TRANSITION_DETAILS_VALID(p0: int) -> bool:
    return _ib(0x2615AA2A695930C1, p0)

def NETWORK_MARK_AS_PREFERRED_ACTIVITY(p0: bool) -> None:
    _iv(0x261E97AD7BCF3D40, p0)

def NETWORK_SET_SCRIPT_CONTROLLING_TEAMS(p0: int) -> None:
    _iv(0x265559DA40B3F327, p0)

def DELAY_MP_STORE_OPEN() -> None:
    _iv(0x265635150FB0D82E)

def NETWORK_ALLOW_REMOTE_ATTACHMENT_MODIFICATION(entity: int, toggle: bool) -> None:
    _iv(0x267C78C60E806B9A, entity, toggle)

def NETWORK_GET_PRESENCE_INVITE_SESSION_ID(p0: int) -> int:
    return _ii(0x26E1CD96B0903D60, p0)

def NETWORK_HAS_AUTOMUTE_OVERRIDE() -> bool:
    return _ib(0x26F07DD83A5F7F98)

def NETWORK_SESSION_MARK_VISIBLE(toggle: bool) -> None:
    _iv(0x271CC6AB59EBF9A5, toggle)

def UGC_SET_BOOKMARKED(contentId: str, bookmarked: bool, contentTypeName: str) -> bool:
    return _ib(0x274A1519DFC1094F, contentId, bookmarked, contentTypeName)

def NETWORK_IS_ACTIVITY_SPECTATOR_FROM_HANDLE(gamerHandle: int) -> bool:
    return _ib(0x2763BBAA72A7BCB9, gamerHandle)

def IS_OBJECT_REASSIGNMENT_IN_PROGRESS() -> bool:
    return _ib(0x28123C8B056CC8AA)

def NETWORK_ON_RETURN_TO_SINGLE_PLAYER() -> None:
    _iv(0x283B6062A2C01E9B)

def NETWORK_GET_THIS_SCRIPT_IS_NETWORK_SCRIPT() -> bool:
    return _ib(0x2910669969E9535E)

def NETWORK_IS_TRANSITION_MATCHMAKING() -> bool:
    return _ib(0x292564C735375EDF)

def SET_NETWORK_ID_CAN_MIGRATE(netId: int, toggle: bool) -> None:
    _iv(0x299EEB23175895FC, netId, toggle)

def UGC_HAS_MODIFY_FINISHED() -> bool:
    return _ib(0x299EF3C576773506)

def NETWORK_EXPLODE_HELI(vehicle: int, isAudible: bool, isInvisible: bool, netId: int) -> None:
    _iv(0x2A5E0621DD815A9A, vehicle, isAudible, isInvisible, netId)

def GET_COMMERCE_ITEM_NUM_CATS(index: int) -> int:
    return _ii(0x2A7776C709904AB0, index)

def NETWORK_USE_HIGH_PRECISION_BLENDING(netID: int, toggle: bool) -> None:
    _iv(0x2B1813ABA29016C5, netID, toggle)

def NETWORK_ADD_CLIENT_ENTITY_ANGLED_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, radius: float) -> int:
    return _ii(0x2B1C623823DB0D9D, x1, y1, z1, x2, y2, z2, radius)

def NETWORK_OPEN_TRANSITION_MATCHMAKING() -> None:
    _iv(0x2B3A8F7CA3A38FDE)

def NETWORK_CLAN_CREWINFO_GET_CREWRANKTITLE(p0: int, p1: str) -> bool:
    return _ib(0x2B51EDBEFC301339, p0, p1)

def NETWORK_CAN_QUEUE_FOR_PREVIOUS_SESSION_JOIN() -> bool:
    return _ib(0x2BF66D2E7414F686)

def NETWORK_SET_CURRENT_PUBLIC_CONTENT_ID(missionId: str) -> None:
    _iv(0x2C863ACDCD12B3DB, missionId)

def RESERVE_LOCAL_NETWORK_MISSION_PEDS(amount: int) -> None:
    _iv(0x2C8DF5D129595281, amount)

def NETWORK_GET_GAMER_STATUS_FROM_QUEUE() -> bool:
    return _ib(0x2CC848A861D01493)

def NETWORK_SET_IN_PROGRESS_FINISH_TIME(p0: int) -> None:
    _iv(0x2CE9D95E4051AECD, p0)

def NETWORK_SESSION_DO_FRIEND_MATCHMAKING(p0: int, p1: int, p2: int) -> bool:
    return _ib(0x2CFC76E0D087C994, p0, p1, p2)

def UGC_IS_DESCRIPTION_REQUEST_IN_PROGRESS(p0: int) -> bool:
    return _ib(0x2D5DC831176D0114, p0)

def NETWORK_SET_LOCAL_PLAYER_INVINCIBLE_TIME(time: int) -> None:
    _iv(0x2D95C7E2D7E07307, time)

def NETWORK_GET_KILLER_OF_PLAYER(player: int, weaponHash: int) -> int:
    return _ii(0x2DA41ED6E1FCD7A5, player, weaponHash)

def NETWORK_LAUNCH_TRANSITION() -> bool:
    return _ib(0x2DCF46CB1A4F0884)

def NETWORK_HAS_BONE_BEEN_HIT_BY_KILLER(boneIndex: int) -> bool:
    return _ib(0x2E0BF682CC778D49, boneIndex)

def NETWORK_IS_ANY_PLAYER_NEAR(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int) -> bool:
    return _ib(0x2E4C123D1C8A710E, p0, p1, p2, p3, p4, p5, p6)

def NETWORK_IS_FRIEND_IN_SAME_TITLE(friendName: str) -> bool:
    return _ib(0x2EA9A3BEDF3F17B8, friendName)

def IS_COMMERCE_STORE_OPEN() -> bool:
    return _ib(0x2EAC52B4019E2782)

def NETWORK_SESSION_CANCEL_INVITE() -> None:
    _iv(0x2FBF47B1B36D36F9)

def NETWORK_IS_IN_PLATFORM_PARTY() -> bool:
    return _ib(0x2FC5650B0271CB57)

def NETWORK_EXPLODE_VEHICLE(vehicle: int, isAudible: bool, isInvisible: bool, netId: int) -> bool:
    return _ib(0x301A42153C9AD707, vehicle, isAudible, isInvisible, netId)

def NETWORK_OVERRIDE_CHAT_RESTRICTIONS(player: int, toggle: bool) -> None:
    _iv(0x3039AE5AD2C9C0C4, player, toggle)

def UGC_GET_CONTENT_IS_PUBLISHED(p0: int) -> bool:
    return _ib(0x3054F114121C21EA, p0)

def UGC_TEXTURE_DOWNLOAD_REQUEST(p0: str, p1: int, p2: int, p3: int, p4: str, p5: bool) -> int:
    return _ii(0x308F96458B7087CC, p0, p1, p2, p3, p4, p5)

def NETWORK_SET_TRANSITION_ACTIVITY_ID(p0: int) -> None:
    _iv(0x30DE938B516F0AD2, p0)

def UGC_GET_MY_CONTENT(p0: int, p1: int, p2: str, p3: int) -> bool:
    return _ib(0x3195F8DD0D531052, p0, p1, p2, p3)

def NETWORK_SEND_TRANSITION_GAMER_INSTRUCTION(gamerHandle: int, p1: str, p2: int, p3: int, p4: bool) -> bool:
    return _ib(0x31D1D2B858D25E6B, gamerHandle, p1, p2, p3, p4)

def UGC_GET_CONTENT_LANGUAGE(p0: int) -> int:
    return _ii(0x32DD916F3F7C9672, p0)

def SET_NETWORK_ID_VISIBLE_IN_CUTSCENE_HACK(netId: int, p1: bool, p2: bool) -> None:
    _iv(0x32EBD154CB6B8B99, netId, p1, p2)

def NETWORK_SESSION_DO_FREEROAM_QUICKMATCH(p0: int, p1: int, p2: int) -> bool:
    return _ib(0x330ED4D05491934F, p0, p1, p2)

def NETWORK_REGISTER_PLAYER_BROADCAST_VARIABLES(vars: int, numVars: int, debugName: str) -> None:
    _iv(0x3364AA97340CA215, vars, numVars, debugName)

def _NETWORK_LOAD_GAMER_DISPLAY_NAME(gamerHandle: int) -> str:
    return _is(0x338ECE3637937BC2, gamerHandle)

def NETWORK_GET_LAST_VEL_RECEIVED_OVER_NETWORK(entity: int) -> 'gta.Vector3':
    return _ivec(0x33DE49EDF4DDE77A, entity)

def NETWORK_SESSION_LEAVE_SINGLE_PLAYER() -> None:
    _iv(0x3442775428FD2DAA)

def TEXTURE_DOWNLOAD_GET_NAME(p0: int) -> str:
    return _is(0x3448505B6E35262D, p0)

def NETWORK_BLOCK_INVITES(toggle: bool) -> None:
    _iv(0x34F9E9049454A7A0, toggle)

def NETWORK_GET_AVERAGE_PACKET_LOSS(player: int) -> float:
    return _if(0x350C23949E43686C, player)

def NETWORK_IS_TUTORIAL_SESSION_CHANGE_PENDING() -> bool:
    return _ib(0x35F0B98A8387274D)

def NETWORK_GET_NUM_SCRIPT_PARTICIPANTS(scriptName: str, instance_id: int, position_hash: int) -> int:
    return _ii(0x3658E8CD94FC121A, scriptName, instance_id, position_hash)

def NET_TO_VEH(netHandle: int) -> int:
    return _ii(0x367B936610BA360C, netHandle)

def _NETWORK_GET_TUNABLES_REGISTRATION_FLOAT(tunableName: int, defaultValue: float) -> float:
    return _if(0x367E5E33E7F0DD1A, tunableName, defaultValue)

def NETWORK_SET_PLAYER_MENTAL_STATE(p0: int) -> None:
    _iv(0x367EF5E2F439B4C6, p0)

def UGC_GET_CONTENT_FILE_VERSION(p0: int, p1: int) -> int:
    return _ii(0x37025B27D9B658B1, p0, p1)

def NETWORK_GET_RESPAWN_RESULT(randomInt: int, coordinates: int, heading: int) -> None:
    _iv(0x371EA43692861CF1, randomInt, coordinates, heading)

def NETWORK_GET_UNRELIABLE_RESEND_COUNT(player: int) -> int:
    return _ii(0x3765C3A3E8192E10, player)

def NETWORK_ADD_ENTITY_ANGLED_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, width: float) -> int:
    return _ii(0x376C6375BA60293A, x1, y1, z1, x2, y2, z2, width)

def NETWORK_IS_TRANSITION_OPEN_TO_MATCHMAKING() -> bool:
    return _ib(0x37A4494483B9F5C9)

def NETWORK_GET_ENTITY_FROM_OBJECT_ID(p0: int) -> int:
    return _ii(0x37D5F739FD494675, p0)

def NETWORK_GET_INVITE_REPLY_STATUS(p0: int) -> int:
    return _ii(0x3855FB5EB2C5E8B2, p0)

def NETWORK_HANDLE_FROM_PLAYER(player: int, gamerHandle: int, gamerHandleSize: int) -> None:
    _iv(0x388EB2B86C73B6B3, player, gamerHandle, gamerHandleSize)

def NETWORK_TRIGGER_DAMAGE_EVENT_FOR_ZERO_WEAPON_HASH(entity: int, toggle: bool) -> None:
    _iv(0x38B7C51AB1EDC7D8, entity, toggle)

def NETWORK_DOES_NETWORK_ID_EXIST(netId: int) -> bool:
    return _ib(0x38CE16C96BD11344, netId)

def NETWORK_GET_PRESENCE_INVITE_HANDLE(p0: int, p1: int) -> bool:
    return _ib(0x38D5B0FEBB086F75, p0, p1)

def NETWORK_MARK_AS_WAITING_ASYNC(p0: bool) -> None:
    _iv(0x39917E1B4CB0F911, p0)

def UGC_GET_CONTENT_HASH() -> int:
    return _ii(0x3A17A27D75C74887)

def NETWORK_SEND_TEXT_MESSAGE(message: str, gamerHandle: int) -> bool:
    return _ib(0x3A214F2EC889B100, message, gamerHandle)

def CLOUD_DID_REQUEST_SUCCEED(requestId: int) -> bool:
    return _ib(0x3A3D5568AF297CD5, requestId)

def NETWORK_ACCESS_TUNABLE_INT_MODIFICATION_DETECTION_REGISTRATION_HASH(contextHash: int, nameHash: int, value: int) -> bool:
    return _ib(0x3A8B55FDA4C8DDEF, contextHash, nameHash, value)

def NETWORK_DO_TRANSITION_TO_FREEMODE(p0: int, p1: int, p2: bool, players: int, p4: bool) -> bool:
    return _ib(0x3AAD8B2FCA1E289F, p0, p1, p2, players, p4)

def NETWORK_GET_PLAYER_TUTORIAL_SESSION_INSTANCE(player: int) -> int:
    return _ii(0x3B39236746714134, player)

def NETWORK_SET_MISSION_FINISHED() -> None:
    _iv(0x3B3D11CD9FFCDFC9)

def NETWORK_SET_OVERRIDE_TUTORIAL_SESSION_CHAT(toggle: bool) -> None:
    _iv(0x3C5C1E2C2FF814B1, toggle)

def NETWORK_QUERY_RESPAWN_RESULTS(p0: int) -> int:
    return _ii(0x3C891A251567DFCE, p0)

def NETWORK_IS_PLAYER_A_PARTICIPANT(player: int) -> bool:
    return _ib(0x3CA58F6CB7CBD784, player)

def NETWORK_SET_CURRENT_CHAT_OPTION(newChatOption: int) -> None:
    _iv(0x3DAD00265FBF356B, newChatOption)

def NETWORK_GET_PRESENCE_INVITE_FROM_ADMIN(p0: int) -> bool:
    return _ib(0x3DBF2DF0AEB7D289, p0)

def NETWORK_SET_RICH_PRESENCE_STRING(p0: int, textLabel: str) -> None:
    _iv(0x3E200C2BCF4164EB, p0, textLabel)

def NETWORK_REGISTER_HOST_BROADCAST_VARIABLES(vars: int, numVars: int, debugName: str) -> None:
    _iv(0x3E9B2F01C50DF595, vars, numVars, debugName)

def NETWORK_DO_TRANSITION_TO_GAME(p0: bool, maxPlayers: int) -> bool:
    return _ib(0x3E9BB38102A589B0, p0, maxPlayers)

def NETWORK_SESSION_SET_MATCHMAKING_PROPERTY_ID(p0: bool) -> None:
    _iv(0x3F52E880AAF6C8CA, p0)

def NETWORK_HAS_TRANSITION_INVITE_BEEN_ACKED(p0: int) -> bool:
    return _ib(0x3F9990BF5F22759C, p0)

def SET_NETWORK_ID_PASS_CONTROL_IN_TUTORIAL(netId: int, state: bool) -> None:
    _iv(0x3FA36981311FA4FF, netId, state)

def NETWORK_PLAYER_HAS_HEADSET(player: int) -> bool:
    return _ib(0x3FB99A8B08D18FD6, player)

def NETWORK_SET_NO_LONGER_NEEDED(entity: int, toggle: bool) -> None:
    _iv(0x3FC795691834481D, entity, toggle)

def NETWORK_DISABLE_PROXIMITY_MIGRATION(netID: int) -> None:
    _iv(0x407091CF6037118E, netID)

def _NETWORK_GET_COMMUNICATION_GROUP_FLAGS(communicationType: int) -> int:
    return _ii(0x40DF02F371F40883, communicationType)

def UGC_GET_CACHED_DESCRIPTION(p0: int, p1: int) -> str:
    return _is(0x40F7E66472DF3E5C, p0, p1)

def NETWORK_ACCESS_TUNABLE_INT_HASH(tunableContext: int, tunableName: int, value: int) -> bool:
    return _ib(0x40FCE03E50E8DBE8, tunableContext, tunableName, value)

def NETWORK_GET_FRIEND_DISPLAY_NAME(friendIndex: int) -> str:
    return _is(0x4164F227D052E293, friendIndex)

def FADE_OUT_LOCAL_PLAYER(p0: bool) -> None:
    _iv(0x416DBD4CD6ED8DD2, p0)

def NETWORK_SET_IN_SPECTATOR_MODE_EXTENDED(toggle: bool, playerPed: int, p2: bool) -> None:
    _iv(0x419594E137637120, toggle, playerPed, p2)

def NETWORK_CAN_RECEIVE_LOCAL_INVITE(gamerHandle: int) -> bool:
    return _ib(0x421E34C55F125964, gamerHandle)

def NETWORK_HAVE_ROS_LEADERBOARD_WRITE_PRIV() -> bool:
    return _ib(0x422D396F80A96547)

def NETWORK_IS_ENTITY_FADING(entity: int) -> bool:
    return _ib(0x422F32CC7E56ABAD, entity)

def NETWORK_WAS_GAME_SUSPENDED() -> bool:
    return _ib(0x4237E822315D8BA9)

def NETWORK_SET_IN_SPECTATOR_MODE(toggle: bool, playerPed: int) -> None:
    _iv(0x423DE3854BB50894, toggle, playerPed)

def NETWORK_IS_FRIEND_ONLINE(name: str) -> bool:
    return _ib(0x425A44533437B64D, name)

def RESERVE_LOCAL_NETWORK_MISSION_VEHICLES(amount: int) -> None:
    _iv(0x42613035157E4208, amount)

def NETWORK_GET_GAMERTAG_FROM_HANDLE(gamerHandle: int) -> str:
    return _is(0x426141162EBE5CDB, gamerHandle)

def NETWORK_GET_ENTITY_KILLER_OF_PLAYER(player: int, weaponHash: int) -> int:
    return _ii(0x42B2DAA6B596F5F8, player, weaponHash)

def NETWORK_OVERRIDE_CLOCK_RATE(ms: int) -> None:
    _iv(0x42BF1D2E723B6D7E, ms)

def NETWORK_REQUEST_CLOUD_TUNABLES() -> None:
    _iv(0x42FB3B532D526E6C)

def NETWORK_SET_SAME_TEAM_AS_LOCAL_PLAYER(p0: int, p1: int) -> bool:
    return _ib(0x4348BFDA56023A2F, p0, p1)

def FACEBOOK_CAN_POST_TO_FACEBOOK() -> bool:
    return _ib(0x43865688AE10F0D7)

def NETWORK_CLEAR_FOLLOW_INVITE() -> bool:
    return _ib(0x439BFDE3CD0610F6)

def NETWORK_CLOSE_TRANSITION_MATCHMAKING() -> None:
    _iv(0x43F4DBA69710E01E)

def RESET_STORE_NETWORK_GAME_TRACKING() -> None:
    _iv(0x444C4525ECE0A4B9)

def NETWORK_CHECK_DATA_MANAGER_SUCCEEDED_FOR_HANDLE(p0: int, gamerHandle: int) -> bool:
    return _ib(0x44B37CDCAE765AAE, p0, gamerHandle)

def NETWORK_QUIT_MP_TO_DESKTOP() -> None:
    _iv(0x45A83257ED02D9BC)

def UGC_IS_MODIFYING() -> bool:
    return _ib(0x45E816772E93A9DB)

def NETWORK_ADD_MAP_ENTITY_TO_SYNCHRONISED_SCENE(netScene: int, modelHash: int, x: float, y: float, z: float, p5: float, p6: str, p7: float, p8: float, flags: int) -> None:
    _iv(0x45F35C0EDC33B03B, netScene, modelHash, x, y, z, p5, p6, p7, p8, flags)

def NETWORK_DO_TRANSITION_TO_NEW_GAME(p0: bool, maxPlayers: int, p2: bool) -> bool:
    return _ib(0x4665F51EFED00034, p0, maxPlayers, p2)

def HAS_NETWORK_TIME_STARTED() -> bool:
    return _ib(0x46718ACEEDEAFC84)

def REMOTE_CHEATER_PLAYER_DETECTED(player: int, a: int, b: int) -> bool:
    return _ib(0x472841A026D26D8B, player, a, b)

def NETWORK_ATTACH_SYNCHRONISED_SCENE_TO_ENTITY(netScene: int, entity: int, bone: int) -> None:
    _iv(0x478DCBD2A98B705A, netScene, entity, bone)

def _NETWORK_GET_GAME_RESTART_REASON_MESSAGE_LABEL() -> str:
    return _is(0x47B11D51FC50A259)

def NETWORK_SESSION_SET_UNIQUE_CREW_LIMIT_TRANSITION(p0: int) -> None:
    _iv(0x4811BBAC21C5FCD5, p0)

def TEXTURE_DOWNLOAD_RELEASE(p0: int) -> None:
    _iv(0x487EB90B98E9FB19, p0)

def NETWORK_CLAN_GET_MEMBERSHIP_VALID(p0: int, p1: int) -> bool:
    return _ib(0x48A59CF88D43DF0E, p0, p1)

def NETWORK_CLAN_GET_MEMBERSHIP_DESC(memberDesc: int, p1: int) -> bool:
    return _ib(0x48DE78AF2C8885B8, memberDesc, p1)

def NETWORK_PLAYER_GET_USERID(player: int, userID: int) -> str:
    return _is(0x4927FC39CD0869A0, player, userID)

def NETWORK_ADD_ENTITY_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> int:
    return _ii(0x494C8FB299290269, x1, y1, z1, x2, y2, z2)

def NETWORK_GET_PRESENCE_INVITE_INVITER(p0: int) -> str:
    return _is(0x4962CC4AA2F345B7, p0)

def NETWORK_SESSION_SET_MATCHMAKING_GROUP(matchmakingGroup: int) -> None:
    _iv(0x49EC8030F5015F8B, matchmakingGroup)

def NETWORK_ENTITY_AREA_IS_OCCUPIED(areaHandle: int) -> bool:
    return _ib(0x4A2D4E8BF4265B0F, areaHandle)

def UGC_GET_CONTENT_DESCRIPTION(index: int) -> str:
    return _is(0x4A56710BAB5C4DB4, index)

def NETWORK_INVITE_GAMERS_TO_TRANSITION(p0: int, p1: int) -> bool:
    return _ib(0x4A595C32F77DFF76, p0, p1)

def NETWORK_SET_PRESENCE_SESSION_INVITES_BLOCKED(toggle: bool) -> None:
    _iv(0x4A9FDE3A5A6D0437, toggle)

def NETWORK_CHECK_DATA_MANAGER_FOR_HANDLE(p0: int, gamerHandle: int) -> bool:
    return _ib(0x4AD490AE1536933B, p0, gamerHandle)

def SET_ENTITY_GHOSTED_FOR_GHOST_PLAYERS(entity: int, toggle: bool) -> None:
    _iv(0x4BA166079D658ED4, entity, toggle)

def NETWORK_START_RESPAWN_SEARCH_IN_ANGLED_AREA_FOR_PLAYER(player: int, x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, width: float, p8: float, p9: float, p10: float, flags: int) -> bool:
    return _ib(0x4BA92A18502BCA61, player, x1, y1, z1, x2, y2, z2, width, p8, p9, p10, flags)

def NETWORK_IGNORE_REMOTE_WAYPOINTS() -> None:
    _iv(0x4C2A9FDC22377075)

def CLOUD_HAS_REQUEST_COMPLETED(requestId: int) -> bool:
    return _ib(0x4C61B39930D045DA, requestId)

def NETWORK_GET_GAME_MODE() -> int:
    return _ii(0x4C9034162368E206)

def NETWORK_GET_ASSISTED_DAMAGE_OF_ENTITY(player: int, entity: int, p2: int) -> bool:
    return _ib(0x4CACA84440FA26F6, player, entity, p2)

def UGC_DID_QUERY_CREATORS_SUCCEED() -> bool:
    return _ib(0x4D02279C83BE69FE)

def NETWORK_HAS_CONTROL_OF_NETWORK_ID(netId: int) -> bool:
    return _ib(0x4D36070FE0215186, netId)

def NETWORK_HAS_INVITED_GAMER(p0: int) -> bool:
    return _ib(0x4D86CD31E8976ECE, p0)

def NETWORK_ENTITY_AREA_HAVE_ALL_REPLIED(areaHandle: int) -> bool:
    return _ib(0x4DF7CFFF471A7FB1, areaHandle)

def UGC_GET_CONTENT_RATING_NEGATIVE_COUNT(p0: int, p1: int) -> int:
    return _ii(0x4E548C0D7AE39FF9, p0, p1)

def RESERVE_NETWORK_MISSION_OBJECTS(amount: int) -> None:
    _iv(0x4E5C93BD0C32FBF8, amount)

def NETWORK_CAN_SESSION_END() -> bool:
    return _ib(0x4EEBC3694E49C572)

def CLOUD_CHECK_AVAILABILITY() -> None:
    _iv(0x4F18196C8D38768D)

def NETWORK_IS_TRANSITION_BUSY() -> bool:
    return _ib(0x520F3282A53D26B7)

def NETWORK_APPLY_TRANSITION_PARAMETER(p0: int, p1: int) -> None:
    _iv(0x521638ADA1BA0D18, p0, p1)

def NETWORK_SET_LOCAL_PLAYER_SYNC_LOOK_AT(toggle: bool) -> None:
    _iv(0x524FF0AEFF9C3973, toggle)

def _SET_FREEMODE_REPORT_DATA(gamerHandle: int, reportData: int) -> None:
    _iv(0x527803286A8B6C81, gamerHandle, reportData)

def NETWORK_GET_HIGHEST_RELIABLE_RESEND_COUNT(player: int) -> int:
    return _ii(0x52C1EADAF7B10302, player)

def UGC_GET_TOP_RATED_CONTENT(p0: int, p1: int, p2: int, p3: int) -> bool:
    return _ib(0x5324A0E3E4CE3570, p0, p1, p2, p3)

def NETWORK_SESSION_GET_PRIVATE_SLOTS() -> int:
    return _ii(0x53AFD64C6758F2F9)

def NETWORK_NEED_TO_START_NEW_GAME_BUT_BLOCKED() -> bool:
    return _ib(0x53C10C8BD774F2C9)

def NETWORK_IS_TRANSITION_STARTED() -> bool:
    return _ib(0x53FA83401D9C07FE)

def NETWORK_PLAYER_IS_ROCKSTAR_DEV(player: int) -> bool:
    return _ib(0x544ABDDA3B409B6D, player)

def NETWORK_SESSION_SET_UNIQUE_CREW_ONLY_CREWS_TRANSITION(p0: bool) -> None:
    _iv(0x5539C3EBF104A53A, p0)

def NETWORK_PERMISSIONS_HAS_GAMER_RECORD(gamerHandle: int) -> bool:
    return _ib(0x559EBF901A8C68E0, gamerHandle)

def UGC_GET_CONTENT_ID(p0: int) -> str:
    return _is(0x55AA95F481D694D2, p0)

def NETWORK_IS_THREAD_A_NETWORK_SCRIPT(threadId: int) -> bool:
    return _ib(0x560B423D73015E77, threadId)

def NETWORK_REPORT_CODE_TAMPER() -> None:
    _iv(0x5626D9D6810730D5)

def NETWORK_PLAYER_INDEX_IS_CHEATER(player: int) -> bool:
    return _ib(0x565E430DB3B05BEC, player)

def NETWORK_SESSION_GET_MATCHMAKING_GROUP_FREE(p0: int) -> int:
    return _ii(0x56CE820830EF040B, p0)

def NETWORK_IS_FRIEND_IN_MULTIPLAYER(friendName: str) -> bool:
    return _ib(0x57005C18827F3A28, friendName)

def NETWORK_MARK_TRANSITION_GAMER_AS_FULLY_JOINED(p0: int) -> bool:
    return _ib(0x5728BB6D63E3FF1D, p0)

def TEXTURE_DOWNLOAD_HAS_FAILED(p0: int) -> bool:
    return _ib(0x5776ED562C134687, p0)

def NETWORK_CLAN_SERVICE_IS_VALID() -> bool:
    return _ib(0x579CCED0265D4896)

def PARTICIPANT_ID_TO_INT() -> int:
    return _ii(0x57A3BDDAD8E5AA0A)

def NETWORK_IS_PLAYER_BLOCKED_BY_ME(player: int) -> bool:
    return _ib(0x57AF1F8E27483721, player)

def NETWORK_OVERRIDE_SEND_RESTRICTIONS_ALL(toggle: bool) -> None:
    _iv(0x57B192B4D4AD23D5, toggle)

def NETWORK_GET_SCRIPT_STATUS() -> int:
    return _ii(0x57D158647A6BFABF)

def NETWORK_ARE_HANDLES_THE_SAME(gamerHandle1: int, gamerHandle2: int) -> bool:
    return _ib(0x57DBA049E110F217, gamerHandle1, gamerHandle2)

def NETWORK_CAN_BAIL() -> bool:
    return _ib(0x580CE4438479CC61)

def NETWORK_CLAN_GET_EMBLEM_TXD_NAME(netHandle: int, txdName: str) -> bool:
    return _ib(0x5835D9CD92E83184, netHandle, txdName)

def UGC_GET_CONTENT_CREATOR_GAMER_HANDLE(p0: int, p1: int) -> bool:
    return _ib(0x584770794D758C18, p0, p1)

def NETWORK_HASH_FROM_GAMER_HANDLE(gamerHandle: int) -> int:
    return _ii(0x58575AC3CF2CA8EC, gamerHandle)

def OPEN_COMMERCE_STORE(p0: str, p1: str, p2: int) -> None:
    _iv(0x58C21165F6545892, p0, p1, p2)

def NETWORK_GET_DISPLAYNAMES_FROM_HANDLES(p0: int, p1: int, p2: int) -> int:
    return _ii(0x58CC181719256197, p0, p1, p2)

def IS_USER_OLD_ENOUGH_TO_ACCESS_STORE() -> bool:
    return _ib(0x59328EB08C5CEB2B)

def NETWORK_HAS_ROS_PRIVILEGE_PLAYED_LAST_GEN() -> bool:
    return _ib(0x593570C289A77688)

def SHUTDOWN_AND_LAUNCH_SINGLE_PLAYER_GAME() -> None:
    _iv(0x593850C16A36B692)

def NETWORK_CHECK_USER_CONTENT_PRIVILEGES(p0: int, p1: int, p2: bool) -> bool:
    return _ib(0x595F028698072DD9, p0, p1, p2)

def UGC_GET_CREATOR_NUM() -> int:
    return _ii(0x597F8DBA9B206FC7)

def NETWORK_GET_RANDOM_INT() -> int:
    return _ii(0x599E4FA1F87EB5FF)

def NETWORK_SESSION_SET_NUM_BOSSES(num: int) -> None:
    _iv(0x59D421683D31835A, num)

def NETWORK_JOIN_PREVIOUSLY_FAILED_SESSION() -> bool:
    return _ib(0x59DF79317F85A7E0)

def UGC_GET_MODIFY_RESULT() -> int:
    return _ii(0x5A0A3D1A186A5508)

def UGC_RELEASE_CACHED_DESCRIPTION(p0: int) -> bool:
    return _ib(0x5A34CD9C3C5BEC44, p0)

def NETWORK_IS_TRANSITION_PRIVATE() -> bool:
    return _ib(0x5A6AA44FF8E931E6)

def NETWORK_START_RESPAWN_SEARCH_FOR_PLAYER(player: int, x: float, y: float, z: float, radius: float, p5: float, p6: float, p7: float, flags: int) -> bool:
    return _ib(0x5A6FFA2433E2F14C, player, x, y, z, radius, p5, p6, p7, flags)

def NETWORK_DID_GET_GAMER_STATUS_SUCCEED() -> bool:
    return _ib(0x5AE17C6B0134B7F1)

def NETWORK_GET_PRIMARY_CLAN_DATA_SUCCESS() -> bool:
    return _ib(0x5B4F04F19376A0BA)

def NETWORK_SESSION_VOICE_SET_TIMEOUT(timeout: int) -> None:
    _iv(0x5B8ED3DB018927B1, timeout)

def NETWORK_CLAN_DOWNLOAD_MEMBERSHIP_PENDING(p0: int) -> bool:
    return _ib(0x5B9E023DC6EBEDC0, p0)

def NETWORK_HAS_CONTROL_OF_PICKUP(pickup: int) -> bool:
    return _ib(0x5BC9495F0B3B6FA6, pickup)

def NETWORK_SHOW_PSN_UGC_RESTRICTION() -> None:
    _iv(0x5C497525F803486B)

def NETWORK_SET_ANTAGONISTIC_TO_PLAYER(toggle: bool, player: int) -> None:
    _iv(0x5C707A667DF8B9FA, toggle, player)

def UGC_LOAD_OFFLINE_QUERY(p0: int) -> bool:
    return _ib(0x5CAE833B0EE0C500, p0)

def NETWORK_HAS_RECEIVED_HOST_BROADCAST_DATA() -> bool:
    return _ib(0x5D10B3795F3FC886)

def NETWORK_IS_TRANSITION_SOLO() -> bool:
    return _ib(0x5DC577201723960A)

def UGC_REQUEST_CACHED_DESCRIPTION(p0: int) -> int:
    return _ii(0x5E0165278F6339EE, p0)

def UGC_HAS_CREATE_FINISHED() -> bool:
    return _ib(0x5E24341A7F92A74B)

def NETWORK_ENABLE_VOICE_BANDWIDTH_RESTRICTION(player: int) -> None:
    _iv(0x5E3AA4CA2B6FB0EE, player)

def NETWORK_HAVE_PLATFORM_SUBSCRIPTION() -> bool:
    return _ib(0x5EA784D197556507)

def NETWORK_GET_TIMEOUT_TIME() -> int:
    return _ii(0x5ED0356A0CE3A34F)

def NETWORK_HAVE_ROS_MULTIPLAYER_PRIV() -> bool:
    return _ib(0x5F91D5D0B36AA310)

def NETWORK_TEXT_CHAT_IS_TYPING() -> bool:
    return _ib(0x5FCF4D7069B09026)

def SET_LOCAL_PLAYER_AS_GHOST(toggle: bool, p1: bool) -> None:
    _iv(0x5FFE9B4144F9712F, toggle, p1)

def NETWORK_SESSION_SET_GAMEMODE(p0: int) -> None:
    _iv(0x600F8CB31C7AAB6E, p0)

def NETWORK_HAVE_ROS_SOCIAL_CLUB_PRIV() -> bool:
    return _ib(0x606E4D3E3CCCF3EB)

def NETWORK_CHECK_ROS_LINK_WENTDOWN_NOT_NET() -> bool:
    return _ib(0x60EDD13EB3AC1FF3)

def NETWORK_GET_NUM_TRANSITION_NON_ASYNC_GAMERS() -> int:
    return _ii(0x617F49C2668E6155)

def UGC_CLEAR_OFFLINE_QUERY() -> None:
    _iv(0x61A885D3F7CFEE9A)

def SET_NETWORK_VEHICLE_AS_GHOST(vehicle: int, toggle: bool) -> None:
    _iv(0x6274C4712850841E, vehicle, toggle)

def NETWORK_REQUEST_INVITE_CONFIRMED_EVENT() -> bool:
    return _ib(0x62A0296C1BB1CEB3)

def FACEBOOK_HAS_POST_COMPLETED() -> bool:
    return _ib(0x62B9FEC9A11F10EF)

def _NETWORK_HAS_PLAYER_PASSED_CHECK_TYPE(checkType: int, gamerHandle: int) -> bool:
    return _ib(0x62E29CDA11F9C230, checkType, gamerHandle)

def NETWORK_IS_PLAYER_FADING(player: int) -> bool:
    return _ib(0x631DC5DFF4B110E3, player)

def NETWORK_GET_INSTANCE_ID_OF_THIS_SCRIPT() -> int:
    return _ii(0x638A3A81733086DB)

def UGC_HAS_QUERY_CREATORS_FINISHED() -> bool:
    return _ib(0x63B406D7884BFA95)

def NETWORK_IS_PLAYER_IN_MP_CUTSCENE(player: int) -> bool:
    return _ib(0x63F9EE203C3619F2, player)

def NETWORK_GET_LAST_ENTITY_POS_RECEIVED_OVER_NETWORK(entity: int) -> 'gta.Vector3':
    return _ivec(0x64D779659BC37B19, entity)

def NETWORK_IS_PRIVILEGE_CHECK_IN_PROGRESS() -> bool:
    return _ib(0x64E5C4CC82847B73)

def NETWORK_FINISH_BROADCASTING_DATA() -> None:
    _iv(0x64F62AFB081E260D)

def NETWORK_GET_TRANSITION_HOST(gamerHandle: int) -> bool:
    return _ib(0x65042B9774C4435E, gamerHandle)

def NETWORK_IS_TRANSITION_CLOSED_FRIENDS() -> bool:
    return _ib(0x6512765E3BE78C50)

def NETWORK_PLAYER_IS_CHEATER() -> bool:
    return _ib(0x655B91F1495A9090)

def SET_GHOST_ALPHA(alpha: int) -> None:
    _iv(0x658500AE6D723A7E, alpha)

def NETWORK_SKIP_RADIO_WARNING() -> bool:
    return _ib(0x659CF2EF7F550C4F)

def GET_COMMERCE_ITEM_ID(index: int) -> str:
    return _is(0x662635855957C411, index)

def NETWORK_HAVE_SCS_PRIVATE_MSG_PRIV() -> bool:
    return _ib(0x66B59CFFD78467AF)

def ARE_CUTSCENE_ENTITIES_NETWORKED() -> bool:
    return _ib(0x66D6A5E9C511214A)

def NETWORK_SET_INVITE_ON_CALL_FOR_INVITE_MENU(p0: int) -> None:
    _iv(0x66F010A4B031A331, p0)

def UGC_GET_GET_BY_CATEGORY(p0: int, p1: int, p2: int, p3: str, p4: int) -> bool:
    return _ib(0x678BB03C1A3BD51E, p0, p1, p2, p3, p4)

def NETWORK_SESSION_VOICE_LEAVE() -> bool:
    return _ib(0x6793E42BE02B575D)

def NETWORK_HAS_SOCIAL_CLUB_ACCOUNT() -> bool:
    return _ib(0x67A5589628E0CFF6)

def GET_IS_LIVE_AREA_LAUNCH_WITH_CONTENT() -> bool:
    return _ib(0x67FC09BC554A75E5)

def NETWORK_IS_IN_TRANSITION() -> bool:
    return _ib(0x68049AEFF83D8F0A)

def UGC_RELEASE_ALL_CACHED_DESCRIPTIONS() -> None:
    _iv(0x68103E2247887242)

def NETWORK_SET_CAN_RECEIVE_RS_INVITES(p0: bool) -> None:
    _iv(0x68980414688F7F9D, p0)

def UGC_QUERY_BY_CATEGORY(p0: int, p1: int, p2: int, p3: str, p4: int, p5: bool) -> bool:
    return _ib(0x692D58DF40657E8C, p0, p1, p2, p3, p4, p5)

def CAN_REGISTER_MISSION_ENTITIES(ped_amt: int, vehicle_amt: int, object_amt: int, pickup_amt: int) -> bool:
    return _ib(0x69778E7564BADE6D, ped_amt, vehicle_amt, object_amt, pickup_amt)

def NETWORK_ACCESS_TUNABLE_BOOL_MODIFICATION_DETECTION_REGISTRATION_HASH(contextHash: int, nameHash: int, value: int) -> bool:
    return _ib(0x697F508861875B42, contextHash, nameHash, value)

def NETWORK_SET_IGNORE_SPECTATOR_CHAT_LIMITS_SAME_TEAM(toggle: bool) -> None:
    _iv(0x6A5D89D7769A40D8, toggle)

def NETWORK_ALLOW_INVITE_PROCESS_IN_PLAYER_SWITCH(p0: bool) -> None:
    _iv(0x6B07B9CE4D390375, p0)

def NETWORK_IS_TRANSITION_HOST_FROM_HANDLE(gamerHandle: int) -> bool:
    return _ib(0x6B5C83BA3EFE6A10, gamerHandle)

def NETWORK_SHOW_CHAT_RESTRICTION_MSC(player: int) -> None:
    _iv(0x6BFF5F84102DF80A, player)

def NETWORK_GET_PLAYER_INDEX_FROM_PED(ped: int) -> int:
    return _ii(0x6C0E2E0125610278, ped)

def NETWORK_GET_RESPAWN_RESULT_FLAGS(p0: int) -> int:
    return _ii(0x6C34F1208B8923FD, p0)

def NETWORK_IS_IN_MP_CUTSCENE() -> bool:
    return _ib(0x6CC27C9FA2040220)

def NETWORK_CLEAR_QUEUED_JOIN_REQUEST() -> None:
    _iv(0x6CE50E47F5543D0C)

def NETWORK_GET_GLOBAL_MULTIPLAYER_CLOCK(hours: int, minutes: int, seconds: int) -> None:
    _iv(0x6D03BFBD643B2A02, hours, minutes, seconds)

def NETWORK_CLEAR_FOUND_GAMERS() -> None:
    _iv(0x6D14CCEE1B40381A)

def UGC_QUERY_MOST_RECENTLY_CREATED_CONTENT(offset: int, count: int, contentTypeName: str, p3: int) -> bool:
    return _ib(0x6D4CB481FAC835E8, offset, count, contentTypeName, p3)

def IS_DAMAGE_TRACKER_ACTIVE_ON_NETWORK_ID(netID: int) -> bool:
    return _ib(0x6E192E33AD436366, netID)

def NETWORK_IS_ADDING_FRIEND() -> bool:
    return _ib(0x6EA101606F6E4D81)

def NETWORK_SESSION_HOST(p0: int, maxPlayers: int, p2: bool) -> bool:
    return _ib(0x6F3D4ED9BEE4E61D, p0, maxPlayers, p2)

def GET_COMMERCE_ITEM_CAT(index: int, index2: int) -> str:
    return _is(0x6F44CBF56D79FAC0, index, index2)

def NETWORK_OVERRIDE_TEAM_RESTRICTIONS(team: int, toggle: bool) -> None:
    _iv(0x6F697A66CE78674E, team, toggle)

def NETWORK_IS_HANDLE_VALID(gamerHandle: int, gamerHandleSize: int) -> bool:
    return _ib(0x6F79B93B0A8E4133, gamerHandle, gamerHandleSize)

def NETWORK_CHECK_CAN_ACCESS_AND_ALERT() -> bool:
    return _ib(0x6FA9825D0B5A721B)

def NETWORK_IS_TITLE_UPDATE_REQUIRED() -> bool:
    return _ib(0x6FB7BB3607D27FA2)

def NETWORK_GET_NET_STATISTICS_INFO(p0: int) -> None:
    _iv(0x6FD992C4A1C1B986, p0)

def NETWORK_IS_PARTICIPANT_ACTIVE(p0: int) -> bool:
    return _ib(0x6FF8FF40B6357D45, p0)

def NETWORK_SESSION_SET_CREW_LIMIT_MAX_MEMBERS_TRANSITION(p0: int) -> None:
    _iv(0x702BC4D605522539, p0)

def UGC_GET_CONTENT_USER_NAME(p0: int) -> str:
    return _is(0x703F12425ECA8BF5, p0)

def NETWORK_SET_OVERRIDE_SPECTATOR_MODE(toggle: bool) -> None:
    _iv(0x70DA3BF8DACD3210, toggle)

def UGC_GET_CONTENT_HAS_PLAYER_RECORD(p0: int) -> bool:
    return _ib(0x70EA8DA57840F9BE, p0)

def NETWORK_IS_ENTITY_CONCEALED(entity: int) -> bool:
    return _ib(0x71302EC70689052A, entity)

def REMOVE_ALL_STICKY_BOMBS_FROM_ENTITY(entity: int, ped: int) -> None:
    _iv(0x715135F4B82AC90D, entity, ped)

def FILLOUT_PM_PLAYER_LIST_WITH_NAMES(p0: int, p1: int, p2: int, p3: int) -> bool:
    return _ib(0x716B6DB9D1886106, p0, p1, p2, p3)

def NETWORK_IS_GAMER_TALKING(gamerHandle: int) -> bool:
    return _ib(0x71C33B22606CD88A, gamerHandle)

def NETWORK_HAS_MADE_INVITE_DECISION(gamerHandle: int) -> bool:
    return _ib(0x71DC455F5CD1C2B1, gamerHandle)

def NETWORK_DO_TRANSITION_QUICKMATCH(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int) -> bool:
    return _ib(0x71FB0EBCD4915D56, p0, p1, p2, p3, p4, p5)

def NETWORK_SET_CURRENTLY_SELECTED_GAMER_HANDLE_FROM_INVITE_MENU(p0: int) -> bool:
    return _ib(0x7206F674F2A3B1BB, p0)

def GET_COMMERCE_ITEM_TEXTURENAME(index: int) -> str:
    return _is(0x722F5D28B61C5EA8, index)

def NETWORK_IS_NETWORK_ID_REMOTELY_CONTROLLED(netId: int) -> bool:
    return _ib(0x7242F8B741CE1086, netId)

def NETWORK_RESET_BODY_TRACKER() -> None:
    _iv(0x72433699B4E6DD64)

def NETWORK_REMOVE_ALL_TRANSITION_INVITE() -> None:
    _iv(0x726E0375C7A26368)

def CAN_REGISTER_MISSION_VEHICLES(amount: int) -> bool:
    return _ib(0x7277F1F2E085EE74, amount)

def NETWORK_HAS_INVITED_GAMER_TO_TRANSITION(p0: int) -> bool:
    return _ib(0x7284A47B3540E6CF, p0)

def NETWORK_GET_PRESENCE_INVITE_PLAYLIST_CURRENT(p0: int) -> int:
    return _ii(0x728C4CC7920CD102, p0)

def NETWORK_CLAN_CREWINFO_GET_STRING_VALUE(animDict: str, animName: str) -> bool:
    return _ib(0x729E3401F0430686, animDict, animName)

def _NETWORK_GET_HOST_BROADCAST_DATA_SIZE_UNSYNCED(scriptNameHash: int, instance: int, positionHash: int, handlerNum: int) -> int:
    return _ii(0x72C8588ABE22C972, scriptNameHash, instance, positionHash, handlerNum)

def RELEASE_ALL_COMMERCE_ITEM_IMAGES() -> None:
    _iv(0x72D0706CD6CCDB58)

def NETWORK_HAVE_USER_CONTENT_PRIVILEGES(p0: int) -> bool:
    return _ib(0x72D918C99BCACC54, p0)

def NETWORK_UNREGISTER_NETWORKED_ENTITY(entity: int) -> None:
    _iv(0x7368E683BB9038D6, entity)

def NETWORK_GET_TRANSITION_MEMBERS(data: int, dataCount: int) -> int:
    return _ii(0x73B000F7FBC55829, data, dataCount)

def NETWORK_GET_ACTIVITY_PLAYER_NUM(p0: bool) -> int:
    return _ii(0x73E2B500410DA5A2, p0)

def NETWORK_REQUEST_TO_BE_HOST_OF_THIS_SCRIPT() -> None:
    _iv(0x741A3D8380319A81)

def NETWORK_ADD_PED_TO_SYNCHRONISED_SCENE(ped: int, netScene: int, animDict: str, animnName: str, speed: float, speedMultiplier: float, duration: int, flag: int, playbackRate: float, p9: int) -> None:
    _iv(0x742A637471BCECD9, ped, netScene, animDict, animnName, speed, speedMultiplier, duration, flag, playbackRate, p9)

def NETWORK_GET_PRESENCE_INVITE_INDEX_BY_ID(p0: int) -> int:
    return _ii(0x742B58F723233ED9, p0)

def NETWORK_IS_OFFLINE_INVITE_PENDING() -> bool:
    return _ib(0x74698374C45701D2)

def NETWORK_SESSION_IS_CLOSED_CREW() -> bool:
    return _ib(0x74732C6CA90DA2B4)

def NETWORK_GET_CURRENTLY_SELECTED_GAMER_HANDLE_FROM_INVITE_MENU(p0: int) -> bool:
    return _ib(0x74881E6BCAE2327C, p0)

def NETWORK_GET_NP_UNAVAILABLE_REASON() -> int:
    return _ii(0x74FB3E29E6D10FA9)

def NETWORK_SET_ACTIVITY_SPECTATOR(toggle: bool) -> None:
    _iv(0x75138790B4359A74, toggle)

def NETWORK_REMOVE_TRANSITION_INVITE(p0: int) -> None:
    _iv(0x7524B431B2E6F7EE, p0)

def NETWORK_CLAN_IS_ROCKSTAR_CLAN(clanDesc: int, bufferSize: int) -> bool:
    return _ib(0x7543BB439F63792B, clanDesc, bufferSize)

def GET_USER_PREMIUM_ACCESS() -> int:
    return _ii(0x754615490A029508)

def UGC_GET_CONTENT_RATING_COUNT(p0: int, p1: int) -> int:
    return _ii(0x759299C5BB31D2A9, p0, p1)

def SET_LOCAL_PLAYER_VISIBLE_LOCALLY(bIncludePlayersVehicle: bool) -> None:
    _iv(0x7619364C82D3BF14, bIncludePlayersVehicle)

def UGC_GET_CONTENT_TOTAL() -> int:
    return _ii(0x769951E2455E2EB5)

def RESERVE_NETWORK_MISSION_VEHICLES(amount: int) -> None:
    _iv(0x76B02E21ED27A469, amount)

def SET_NETWORK_ID_VISIBLE_IN_CUTSCENE_REMAIN_HACK(p0: int, p1: int, p2: int) -> None:
    _iv(0x76B3F29D3F967692, p0, p1, p2)

def NETWORK_HAS_SOCIAL_NETWORKING_SHARING_PRIV() -> bool:
    return _ib(0x76BF03FADBF154F5)

def NETWORK_HAS_FOLLOW_INVITE() -> bool:
    return _ib(0x76D9B976C4C09FDE)

def NETWORK_PLAYER_GET_NAME(player: int) -> str:
    return _is(0x7718D2E2060837D2, player)

def USE_PLAYER_COLOUR_INSTEAD_OF_TEAM_COLOUR(toggle: bool) -> None:
    _iv(0x77758139EC9B66C7, toggle)

def NETWORK_IS_SHOWING_SYSTEM_UI_OR_RECENTLY_REQUESTED_UPSELL() -> bool:
    return _ib(0x7788DFE15016A182)

def NETWORK_IS_CONNETED_TO_NP_PRESENCE() -> bool:
    return _ib(0x7808619F31FF22DB)

def NETWORK_CHECK_ONLINE_PRIVILEGES(p0: int, p1: bool) -> bool:
    return _ib(0x78321BEA235FD8CD, p0, p1)

def NETWORK_REMOVE_INVALID_OBJECT_MODEL(modelHash: int) -> None:
    _iv(0x791EDB5803B2F468, modelHash)

def UGC_DID_MODIFY_SUCCEED() -> bool:
    return _ib(0x793FF272D5B365F4)

def NETWORK_SET_CURRENT_DATA_MANAGER_HANDLE(p0: int) -> bool:
    return _ib(0x796A87B3B68D1F3D, p0)

def RESERVE_LOCAL_NETWORK_MISSION_OBJECTS(amount: int) -> None:
    _iv(0x797F9C5E661D920E, amount)

def NETWORK_GET_DESTROYER_OF_NETWORK_ID(netId: int, weaponHash: int) -> int:
    return _ii(0x7A1ADEEF01740A24, netId, weaponHash)

def GET_NETWORK_TIME() -> int:
    return _ii(0x7A5487FE9FAA6B48)

def NETWORK_SET_SCRIPT_READY_FOR_EVENTS(toggle: bool) -> None:
    _iv(0x7AC752103856FB20, toggle)

def _NETWORK_INVITE_GET_JOIN_FAIL_REASON() -> str:
    return _is(0x7B335F84501145BB)

def NETWORK_CREATE_SYNCHRONISED_SCENE(x: float, y: float, z: float, xRot: float, yRot: float, zRot: float, rotationOrder: int, useOcclusionPortal: bool, looped: bool, p9: float, animTime: float, p11: float) -> int:
    return _ii(0x7CD6BC4C2BBDD526, x, y, z, xRot, yRot, zRot, rotationOrder, useOcclusionPortal, looped, p9, animTime, p11)

def UGC_GET_CONTENT_DESCRIPTION_HASH(p0: int) -> int:
    return _ii(0x7CF0448787B23758, p0)

def NETWORK_SET_LOOK_AT_TALKERS(p0: bool) -> None:
    _iv(0x7D395EA61622E116, p0)

def NETWORK_GET_BONE_ID_OF_FATAL_HIT() -> int:
    return _ii(0x7DB53B37A2F211A0)

def NETWORK_IS_INACTIVE_PROFILE(p0: int) -> bool:
    return _ib(0x7E58745504313A2E, p0)

def NETWORK_CAN_ENTER_MULTIPLAYER() -> bool:
    return _ib(0x7E782A910C362C25)

def IS_ENTITY_IN_GHOST_COLLISION(entity: int) -> bool:
    return _ib(0x7EF7649B64D7FF10, entity)

def NETWORK_ADD_INVALID_OBJECT_MODEL(modelHash: int, p1: int) -> None:
    _iv(0x7F562DBC212E81F9, modelHash, p1)

def _NETWORK_GET_GAME_RESTART_REASON() -> int:
    return _ii(0x7F7E8401F81CB65B)

def NETWORK_SESSION_VOICE_RESPOND_TO_REQUEST(p0: bool, p1: int) -> None:
    _iv(0x7F8413B7FC2AA6B9, p0, p1)

def UGC_GET_CONTENT_HAS_HI_RES_PHOTO(p0: int) -> bool:
    return _ib(0x7FCC39C46C3C03BD, p0)

def UGC_REQUEST_CONTENT_DATA_FROM_PARAMS(contentTypeName: str, contentId: str, p2: int, p3: int, p4: int) -> int:
    return _ii(0x7FD2990AF016795E, contentTypeName, contentId, p2, p3, p4)

def CAN_REGISTER_MISSION_OBJECTS(amount: int) -> bool:
    return _ib(0x800DD4721A8B008B, amount)

def NETWORK_HAVE_ROS_BANNED_PRIV() -> bool:
    return _ib(0x8020A73847E0CA7D)

def NETWORK_IS_CLOUD_BACKGROUND_SCRIPT_REQUEST_PENDING() -> bool:
    return _ib(0x8132C0EB8B2B3293)

def UGC_GET_GET_BY_CONTENT_ID(contentId: str, contentTypeName: str) -> bool:
    return _ib(0x815E5E3073DA1D67, contentId, contentTypeName)

def NETWORK_ENTITY_GET_OBJECT_ID(entity: int) -> int:
    return _ii(0x815F18AD865F057F, entity)

def NETWORK_GET_PLAYER_OWNS_WAYPOINT(player: int) -> bool:
    return _ib(0x82377B65E943F72D, player)

def NETWORK_GET_HOST_PLAYER_INDEX() -> int:
    return _ii(0x8251FB94DC4FDFC8)

def NETWORK_SHOULD_SHOW_STRICT_NAT_WARNING() -> bool:
    return _ib(0x82A2B386716608F1)

def NETWORK_GET_ASSISTED_KILL_OF_ENTITY(player: int, entity: int, p2: int) -> bool:
    return _ib(0x83660B734994124D, player, entity, p2)

def SET_NETWORK_ENABLE_HIGH_SPEED_EDGE_FALL_DETECTION(vehicle: int, toggle: bool) -> None:
    _iv(0x838DA0936A24ED4D, vehicle, toggle)

def NETWORK_IS_HOST_OF_THIS_SCRIPT() -> bool:
    return _ib(0x83CD99A1E6061AB5)

def NETWORK_CHECK_COMMUNICATION_PRIVILEGES(p0: int, p1: int, p2: bool) -> bool:
    return _ib(0x83F28CE49FBBFFBA, p0, p1, p2)

def NETWORK_SHOW_ACCOUNT_UPGRADE_UI() -> None:
    _iv(0x83FE8D7229593017)

def NETWORK_GET_TALKER_PROXIMITY() -> float:
    return _if(0x84F0F13120B4E098)

def NETWORK_HAS_VALID_ROS_CREDENTIALS() -> bool:
    return _ib(0x85443FF4C328F53B)

def NETWORK_SESSION_IS_IN_VOICE_SESSION() -> bool:
    return _ib(0x855BC38818F6F684)

def NETWORK_SHOW_PROFILE_UI(gamerHandle: int) -> None:
    _iv(0x859ED1CEA343FCA8, gamerHandle)

def NETWORK_QUEUE_GAMER_FOR_STATUS(p0: int) -> bool:
    return _ib(0x85A0EF54A500882C, p0)

def NETWORK_DOES_TUNABLE_EXIST(tunableContext: str, tunableName: str) -> bool:
    return _ib(0x85E5F8B9B898B20A, tunableContext, tunableName)

def NETWORK_CLEAR_GET_GAMER_STATUS() -> None:
    _iv(0x86E0660E4F5C956D)

def NETWORK_REQUEST_CONTROL_OF_DOOR(doorID: int) -> bool:
    return _ib(0x870DDFD5A4A796E4, doorID)

def UGC_GET_CONTENT_RATING_POSITIVE_COUNT(p0: int, p1: int) -> int:
    return _ii(0x87E5C46C187FE0AE, p0, p1)

def NETWORK_IS_FRIEND_HANDLE_ONLINE(gamerHandle: int) -> bool:
    return _ib(0x87EB7A3FFCB314DB, gamerHandle)

def NETWORK_AM_I_BLOCKED_BY_PLAYER(player: int) -> bool:
    return _ib(0x87F395D957D4353D, player)

def NETWORK_GET_PRESENCE_INVITE_IS_TOURNAMENT(p0: int) -> bool:
    return _ib(0x8806CEBFABD3CE05, p0)

def IS_STORE_AVAILABLE_TO_USER() -> bool:
    return _ib(0x883D79C4071E18B3)

def GET_IS_LAUNCH_FROM_LIVE_AREA() -> bool:
    return _ib(0x88B588B41FF7868E)

def GET_NETWORK_TIME_ACCURATE() -> int:
    return _ii(0x89023FBBF9200E9F)

def NETWORK_TRIGGER_DAMAGE_EVENT_FOR_ZERO_DAMAGE(entity: int, toggle: bool) -> None:
    _iv(0x890E2C5ABED7236D, entity, toggle)

def _NETWORK_HAS_ROS_PRIVILEGE_MP_VOICE_COMMUNICATION() -> bool:
    return _ib(0x8956A309BE90057C)

def NETWORK_IS_LOCAL_PLAYER_INVINCIBLE() -> bool:
    return _ib(0x8A8694B48715B000)

def GET_CONTENT_TO_LOAD_TYPE() -> int:
    return _ii(0x8B0C2964BA471961)

def NETWORK_TRANSITION_START(p0: int, p1: int, p2: int, p3: int) -> bool:
    return _ib(0x8B4FFC790CA131EF, p0, p1, p2, p3)

def NETWORK_SESSION_SET_MATCHMAKING_GROUP_MAX(playerType: int, playerCount: int) -> None:
    _iv(0x8B6A4DD0AF9CE215, playerType, playerCount)

def GET_STATUS_OF_TEXTURE_DOWNLOAD(p0: int) -> int:
    return _ii(0x8BD6C6DEA20E82C6, p0)

def NETWORK_ACCESS_TUNABLE_INT(tunableContext: str, tunableName: str, value: int) -> bool:
    return _ib(0x8BE1146DFD5D4468, tunableContext, tunableName, value)

def NETWORK_SET_VEHICLE_DRIVEN_IN_TEST_DRIVE(toggle: bool) -> None:
    _iv(0x8C70252FC40F320B, toggle)

def NETWORK_IS_PLAYER_MUTED_BY_ME(player: int) -> bool:
    return _ib(0x8C71288AE68EDE39, player)

def UGC_GET_CONTENT_CREATED_BY_LOCAL_PLAYER(p0: int) -> bool:
    return _ib(0x8C8D2739BA44AF0F, p0)

def NETWORK_IS_REFRESHING_ROS_CREDENTIALS() -> bool:
    return _ib(0x8D11E61A4ABF49CC)

def NETWORK_IS_HOST() -> bool:
    return _ib(0x8DB296B814EDDA07)

def NETWORK_IS_CHATTING_IN_PLATFORM_PARTY(gamerHandle: int) -> bool:
    return _ib(0x8DE9945BCC9AEC52, gamerHandle)

def NETWORK_ADD_FRIEND(gamerHandle: int, message: str) -> bool:
    return _ib(0x8E02D73914064223, gamerHandle, message)

def NETWORK_SET_SPECTATOR_TO_NON_SPECTATOR_TEXT_CHAT(toggle: bool) -> None:
    _iv(0x8EF52ACAECC51D9C, toggle)

def _NETWORK_INVITE_CLEAR_JOIN_FAIL_REASON() -> None:
    _iv(0x8EF5F5811A940F82)

def NETWORK_CAN_COMMUNICATE_WITH_GAMER(gamerHandle: int) -> bool:
    return _ib(0x8F5D1AD832AEB06C, gamerHandle)

def NETWORK_IS_USING_ONLINE_PROMOTION() -> bool:
    return _ib(0x906CA41A4B74ECA4)

def PARTICIPANT_ID() -> int:
    return _ii(0x90986E8876CE0A83)

def NETWORK_IS_PLAYER_CONCEALED(player: int) -> bool:
    return _ib(0x919B3C98ED8292F9, player)

def NETWORK_HAS_ROS_PRIVILEGE_SPECIAL_EDITION_CONTENT() -> bool:
    return _ib(0x91B87C55093DE351)

def NETWORK_REQUEST_CLOUD_BACKGROUND_SCRIPTS() -> bool:
    return _ib(0x924426BFFD82E915)

def NETWORK_REMOVE_ENTITY_AREA(areaHandle: int) -> bool:
    return _ib(0x93CF869BAA0C4874, areaHandle)

def NETWORK_IS_PLAYER_CONNECTED(player: int) -> bool:
    return _ib(0x93DC1BE4E1ABE9D1, player)

def UGC_DID_GET_SUCCEED() -> bool:
    return _ib(0x941E5306BCD7C2C7)

def NETWORK_SET_MINIMUM_RANK_FOR_MISSION(p0: bool) -> None:
    _iv(0x94538037EE44F5CF, p0)

def NETWORK_SKIP_RADIO_RESET_NEXT_CLOSE() -> None:
    _iv(0x9465E683B12D3F6B)

def NETWORK_IS_GETTING_GAMER_STATUS() -> bool:
    return _ib(0x94A8394D150B013A)

def NETWORK_SESSION_DO_CREW_MATCHMAKING(crewId: int, p1: int, p2: int, maxPlayers: int) -> bool:
    return _ib(0x94BC51E9449D917F, crewId, p1, p2, maxPlayers)

def NETWORK_BAIL(p0: int, p1: int, p2: int) -> None:
    _iv(0x95914459A87EBA28, p0, p1, p2)

def NETWORK_ENTITY_USE_HIGH_PRECISION_ROTATION(netId: int, toggle: bool) -> None:
    _iv(0x95BAF97C82464629, netId, toggle)

def NETWORK_GET_AGE_GROUP() -> int:
    return _ii(0x9614B71F8ADB982B)

def SET_REMOTE_PLAYER_VISIBLE_IN_CUTSCENE(player: int, locallyVisible: bool) -> None:
    _iv(0x96320E6549DAE7B4, player, locallyVisible)

def SET_STORE_ENABLED(toggle: bool) -> None:
    _iv(0x9641A9FF718E9C5E, toggle)

def CLEAR_SERVICE_EVENT_ARGUMENTS() -> None:
    _iv(0x966DD84FB6A46017)

def _NETWORK_GET_ACCESS_CODE_LABEL_HEADING(accessCode: int) -> str:
    return _is(0x967E6FB554E1B6DE, accessCode)

def NETWORK_ACCESS_TUNABLE_FLOAT_HASH(tunableContext: int, tunableName: int, value: int) -> bool:
    return _ib(0x972BC203BBC4C4D5, tunableContext, tunableName, value)

def NETWORK_TRANSITION_BLOCK_JOIN_REQUESTS(p0: bool) -> None:
    _iv(0x973D76AA760A6CB6, p0)

def NETWORK_IS_MULTIPLAYER_DISABLED() -> bool:
    return _ib(0x9747292807126EDA)

def NETWORK_LEAVE_PED_BEHIND_BEFORE_WARP(player: int, x: float, y: float, z: float, p4: bool, p5: bool) -> None:
    _iv(0x9769F811D1785B03, player, x, y, z, p4, p5)

def UGC_GET_MOST_RECENTLY_PLAYED_CONTENT(p0: int, p1: int, p2: int, p3: int) -> bool:
    return _ib(0x97A770BEEF227E2B, p0, p1, p2, p3)

def NETWORK_OVERRIDE_SEND_RESTRICTIONS(player: int, toggle: bool) -> None:
    _iv(0x97DD4C5944CC2E6A, player, toggle)

def _NETWORK_GET_COMMUNICATION_GROUP_DEFAULT_FLAGS(communicationType: int) -> int:
    return _ii(0x97F35B898D2D067F, communicationType)

def UGC_GET_CONTENT_HAS_PLAYER_BOOKMARKED(p0: int) -> bool:
    return _ib(0x993CBE59D350D225, p0)

def NETWORK_APPLY_CACHED_PLAYER_HEAD_BLEND_DATA(ped: int, player: int) -> bool:
    return _ib(0x99B72C7ABDE5C910, ped, player)

def OBJ_TO_NET(object: int) -> int:
    return _ii(0x99BFDC94A603E541, object)

def NETWORK_START_SYNCHRONISED_SCENE(netScene: int) -> None:
    _iv(0x9A1B3FCDB36C8697, netScene)

def NETWORK_IS_CLOUD_AVAILABLE() -> bool:
    return _ib(0x9A4CF4F48AD77302)

def GET_CLOUD_TIME_AS_INT() -> int:
    return _ii(0x9A73240B49945C76)

def NETWORK_GET_PRIMARY_CLAN_DATA_CLEAR() -> bool:
    return _ib(0x9AA46BADAD0E27ED)

def NETWORK_HAS_PLAYER_STARTED_TRANSITION(player: int) -> bool:
    return _ib(0x9AC9CCBFA8C29795, player)

def _NETWORK_HAS_ROS_PRIVILEGE_REPORTING() -> bool:
    return _ib(0x9BA54B3CFB82ADDD)

def UGC_QUERY_MY_CONTENT(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int) -> bool:
    return _ib(0x9BF438815F5D96EA, p0, p1, p2, p3, p4, p5)

def NETWORK_SESSION_VOICE_HOST() -> bool:
    return _ib(0x9C1556705F864230)

def NETWORK_DO_TRANSITION_QUICKMATCH_WITH_GROUP(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int, p7: int) -> bool:
    return _ib(0x9C4AB58491FDC98A, p0, p1, p2, p3, p4, p5, p6, p7)

def NETWORK_SET_IN_MP_CUTSCENE(p0: bool, p1: bool) -> None:
    _iv(0x9CA5DE655269FEC4, p0, p1)

def NETWORK_JOIN_TRANSITION(player: int) -> bool:
    return _ib(0x9D060B08CD63321A, player)

def NETWORK_SET_ACTIVITY_SPECTATOR_MAX(maxSpectators: int) -> None:
    _iv(0x9D277B76D1D12222, maxSpectators)

def NETWORK_IS_SCRIPT_ACTIVE(scriptName: str, instance_id: int, p2: bool, position_hash: int) -> bool:
    return _ib(0x9D40DF90FAD26098, scriptName, instance_id, p2, position_hash)

def NETWORK_AM_I_MUTED_BY_PLAYER(player: int) -> bool:
    return _ib(0x9D6981DFC91A8604, player)

def SET_NETWORK_ID_CAN_BE_REASSIGNED(netId: int, toggle: bool) -> None:
    _iv(0x9D724B400A7E8FFC, netId, toggle)

def NETWORK_IS_TRANSITION_TO_GAME() -> bool:
    return _ib(0x9D7696D8F4FA6CB7)

def NETWORK_SET_PROXIMITY_AFFECTS_TEAM(toggle: bool) -> None:
    _iv(0x9D7AFCBF21C51712, toggle)

def NETWORK_INVITE_GAMERS(p0: int, p1: int, p2: int, p3: int) -> bool:
    return _ib(0x9D80CD1D0E6327DE, p0, p1, p2, p3)

def NETWORK_GET_FOUND_GAMER(p0: int, p1: int) -> bool:
    return _ib(0x9DCFF2AFB68B3476, p0, p1)

def NETWORK_DISABLE_INVINCIBLE_FLASHING(player: int, toggle: bool) -> None:
    _iv(0x9DD368BF06983221, player, toggle)

def NETWORK_IS_SESSION_STARTED() -> bool:
    return _ib(0x9DE624D2FC4B603F)

def NETWORK_ARE_PLAYERS_IN_SAME_TUTORIAL_SESSION(player: int, index: int) -> bool:
    return _ib(0x9DE986FC9A87C474, player, index)

def GET_TIME_AS_STRING(time: int) -> str:
    return _is(0x9E23B1777A927DAD, time)

def NETWORK_DO_TRANSITION_TO_NEW_FREEMODE(p0: int, p1: int, players: int, p3: bool, p4: bool, p5: bool) -> bool:
    return _ib(0x9E80A5BA8109F974, p0, p1, players, p3, p4, p5)

def SHUTDOWN_AND_LOAD_MOST_RECENT_SAVE() -> bool:
    return _ib(0x9ECA15ADFE141431)

def NETWORK_GAMERTAG_FROM_HANDLE_START(gamerHandle: int) -> bool:
    return _ib(0x9F0C0A981D73FA56, gamerHandle)

def _NETWORK_CAN_TEXT_FROM_GAMER_BE_VIEWED(gamerHandle: int) -> bool:
    return _ib(0x9F633448E4C73207, gamerHandle)

def UGC_GET_CREW_CONTENT(p0: int, p1: int, p2: int, p3: str, p4: int) -> bool:
    return _ib(0x9F6E2821885CAEE2, p0, p1, p2, p3, p4)

def NETWORK_CLAN_JOIN(clanDesc: int) -> bool:
    return _ib(0x9FAAA4F4FC71F87F, clanDesc)

def UGC_IS_CREATING() -> bool:
    return _ib(0x9FEDF86898F100E9)

def NETWORK_JOIN_GROUP_ACTIVITY() -> bool:
    return _ib(0xA06509A691D12BE4)

def NETWORK_SUPPRESS_INVITE(toggle: bool) -> None:
    _iv(0xA0682D67EF1FBA3D, toggle)

def NETWORK_DO_TRANSITION_QUICKMATCH_ASYNC(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int) -> bool:
    return _ib(0xA091A5E44F0072E5, p0, p1, p2, p3, p4, p5)

def NETWORK_HAVE_ROS_CREATE_TICKET_PRIV() -> bool:
    return _ib(0xA0AD7E2AF5349F61)

def NETWORK_SET_VEHICLE_DRIVEN_LOCATION(location: int) -> None:
    _iv(0xA0CE91E47531D3BB, location)

def NETWORK_IS_LOGGED_IN_TO_PSN() -> bool:
    return _ib(0xA0FA4EC6A05DA44E)

def NETWORK_HANDLE_FROM_MEMBER_ID(memberId: str, gamerHandle: int, gamerHandleSize: int) -> None:
    _iv(0xA0FD21BED61E5C4C, memberId, gamerHandle, gamerHandleSize)

def NETWORK_GET_NETWORK_ID_FROM_ENTITY(entity: int) -> int:
    return _ii(0xA11700682F3AD45C, entity)

def NETWORK_CLAN_IS_EMBLEM_READY(p0: int, p1: int) -> bool:
    return _ib(0xA134777FF7F33331, p0, p1)

def NETWORK_CAN_TEXT_CHAT_WITH_GAMER(gamerHandle: int) -> bool:
    return _ib(0xA150A4F065806B1F, gamerHandle)

def IS_NETWORK_ID_OWNED_BY_PARTICIPANT(netId: int) -> bool:
    return _ib(0xA1607996431332DF, netId)

def NETWORK_GET_NUM_FOUND_GAMERS() -> int:
    return _ii(0xA1B043EE79A916FB)

def UGC_CLEAR_MODIFY_RESULT() -> None:
    _iv(0xA1E5E0204A6FCC70)

def NETWORK_SESSION_FORCE_CANCEL_INVITE() -> None:
    _iv(0xA29177F7703B5644)

def SET_NETWORK_VEHICLE_MAX_POSITION_DELTA_MULTIPLIER(vehicle: int, multiplier: float) -> None:
    _iv(0xA2A707979FE754DC, vehicle, multiplier)

def GET_TIME_DIFFERENCE(timeA: int, timeB: int) -> int:
    return _ii(0xA2C6FC031D46FFF0, timeA, timeB)

def NETWORK_SET_DO_NOT_LAUNCH_FROM_JOIN_AS_MIGRATED_HOST(toggle: bool) -> None:
    _iv(0xA2E9C1AB8A92E8CD, toggle)

def REQUEST_COMMERCE_ITEM_IMAGE(index: int) -> bool:
    return _ib(0xA2F952104FC6DD4B, index)

def NETWORK_GET_NUM_CONNECTED_PLAYERS() -> int:
    return _ii(0xA4A79DD2D9600654)

def NETWORK_ADD_PED_TO_SYNCHRONISED_SCENE_WITH_IK(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int, p7: int, p8: int, p9: int) -> None:
    _iv(0xA5EAFE473E45C442, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)

def NETWORK_HOST_TRANSITION(p0: int, p1: int, p2: int, p3: int, p4: int, p5: bool, p6: bool, p7: int, p8: int, p9: int) -> bool:
    return _ib(0xA60BB5CE242BB254, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)

def NETWORK_REQUEST_CONTROL_OF_NETWORK_ID(netId: int) -> bool:
    return _ib(0xA670B3662FAFFBD0, netId)

def SET_NETWORK_ID_VISIBLE_IN_CUTSCENE(netId: int, p1: bool, p2: bool) -> None:
    _iv(0xA6928482543022B4, netId, p1, p2)

def NETWORK_HAS_ROS_PRIVILEGE(index: int) -> bool:
    return _ib(0xA699957E60D80214, index)

def _NETWORK_MULTIPLAYER_CROSSPLAY_NOT_ALLOWED() -> bool:
    return _ib(0xA6BC0D9BCF9662FA)

def NETWORK_GET_MAX_NUM_PARTICIPANTS() -> int:
    return _ii(0xA6C90FBC38E395EE)

def NETWORK_SET_CUSTOM_ARENA_BALL_PARAMS(netId: int) -> None:
    _iv(0xA6FCECCF4721D679, netId)

def GET_MAX_NUM_NETWORK_PICKUPS() -> int:
    return _ii(0xA72835064DD63E4C)

def NETWORK_SESSION_BLOCK_JOIN_REQUESTS(toggle: bool) -> None:
    _iv(0xA73667484D7037C3, toggle)

def FACEBOOK_DID_POST_SUCCEED() -> bool:
    return _ib(0xA75E2B6733DA5142)

def UGC_GET_MOST_RECENTLY_CREATED_CONTENT(p0: int, p1: int, p2: int, p3: int) -> bool:
    return _ib(0xA7862BC5ED1DFD7E, p0, p1, p2, p3)

def UGC_GET_CONTENT_CATEGORY(p0: int) -> int:
    return _ii(0xA7BAB11E7C9C6C5A, p0)

def SET_REMOTE_PLAYER_AS_GHOST(player: int, p1: bool) -> None:
    _iv(0xA7C511FA1C5BDA38, player, p1)

def NETWORK_OVERRIDE_COORDS_AND_HEADING(entity: int, x: float, y: float, z: float, heading: float) -> None:
    _iv(0xA7E30DE9272B6D49, entity, x, y, z, heading)

def SET_NETWORK_ID_ALWAYS_EXISTS_FOR_PLAYER(netId: int, player: int, toggle: bool) -> None:
    _iv(0xA8A024587329F36A, netId, player, toggle)

def NETWORK_IS_PLATFORM_SUBSCRIPTION_CHECK_PENDING() -> bool:
    return _ib(0xA8ACB6459542A8C8)

def UGC_GET_CONTENT_IS_VERIFIED(p0: int) -> bool:
    return _ib(0xA9240A96C74CCA13, p0)

def NETWORK_CLAN_DOWNLOAD_MEMBERSHIP(gamerHandle: int) -> bool:
    return _ib(0xA989044E70010ABE, gamerHandle)

def NETWORK_GET_PREDICTED_VELOCITY(entity: int, maxSpeedToPredict: float) -> 'gta.Vector3':
    return _ivec(0xAA5FAFCD2C5F5E47, entity, maxSpeedToPredict)

def NETWORK_ACCESS_TUNABLE_BOOL(tunableContext: str, tunableName: str) -> bool:
    return _ib(0xAA6A47A573ABB75A, tunableContext, tunableName)

def NETWORK_SET_CURRENT_SPAWN_LOCATION_OPTION(mpSettingSpawn: int) -> None:
    _iv(0xAA6D5451DC3448B6, mpSettingSpawn)

def GET_NUM_RESERVED_MISSION_OBJECTS(p0: bool, p1: int) -> int:
    return _ii(0xAA81B5F10BC43AC2, p0, p1)

def SET_NETWORK_CUTSCENE_ENTITIES(toggle: bool) -> None:
    _iv(0xAAA553E7DD28A457, toggle)

def NETWORK_CLAN_GET_MEMBERSHIP_COUNT(p0: int) -> int:
    return _ii(0xAAB11F6C4ADBC2C1, p0)

def NETWORK_SESSION_VOICE_CONNECT_TO_PLAYER(gamerHandle: int) -> None:
    _iv(0xABD5E88B8A2D3DB2, gamerHandle)

def _NETWORK_GET_BROADCAST_DATA_PLAYER_UPDATE_SIZE(scriptNameHash: int, instance: int, positionHash: int, handlerNum: int) -> int:
    return _ii(0xAC3F722321800755, scriptNameHash, instance, positionHash, handlerNum)

def NETWORK_HAS_PENDING_INVITE() -> bool:
    return _ib(0xAC8C7B9B88C4A668)

def CONVERT_POSIX_TIME(posixTime: int, timeStructure: int) -> None:
    _iv(0xAC97AF97FA68E5D5, posixTime, timeStructure)

def NETWORK_IS_PLAYER_ON_BLOCKLIST(gamerHandle: int) -> bool:
    return _ib(0xAD4326FCA30D62F8, gamerHandle)

def NETWORK_IS_IN_TUTORIAL_SESSION() -> bool:
    return _ib(0xADA24309FE08DACF)

def NETWORK_GET_MUTE_COUNT_FOR_PLAYER(p0: int, p1: int, p2: int) -> None:
    _iv(0xADB57E5B663CCA8B, p0, p1, p2)

def UGC_GET_CONTENT_IS_USING_SC_NICKNAME(p0: int) -> bool:
    return _ib(0xAEAB987727C5A8A4, p0)

def NETWORK_DUMP_NET_IF_CONFIG() -> None:
    _iv(0xAEDF1BC1C133D6E3)

def NETWORK_HAVE_COMMUNICATION_PRIVILEGES(p0: int, player: int) -> bool:
    return _ib(0xAEEF48CDF5B6CE7C, p0, player)

def NETWORK_CAN_ACCESS_MULTIPLAYER(loadingState: int) -> bool:
    return _ib(0xAF50DA1A3F8B1BA4, loadingState)

def NETWORK_OVERRIDE_TRANSITION_CHAT(p0: bool) -> None:
    _iv(0xAF66059A131AA269, p0)

def NETWORK_GET_MAX_FRIENDS() -> int:
    return _ii(0xAFEBB0D5D8F687D2)

def NETWORK_GAMERTAG_FROM_HANDLE_PENDING() -> bool:
    return _ib(0xB071E27958EF4CF0)

def NETWORK_HAS_ENTITY_BEEN_REGISTERED_WITH_THIS_THREAD(entity: int) -> bool:
    return _ib(0xB07D3185E11657A5, entity)

def NETWORK_CLAN_PLAYER_IS_ACTIVE(gamerHandle: int) -> bool:
    return _ib(0xB124B57F571D8F18, gamerHandle)

def NETWORK_RETAIN_ACTIVITY_GROUP() -> None:
    _iv(0xB13E88E655E5A3BC)

def IS_DAMAGE_TRACKER_ACTIVE_ON_PLAYER(player: int) -> bool:
    return _ib(0xB2092A1EAA7FD45F, player)

def NETWORK_SET_SCRIPT_AUTOMUTED(p0: int) -> bool:
    return _ib(0xB309EBEA797E001F, p0)

def _NETWORK_GET_TUNABLES_REGISTRATION_BOOL(tunableName: int, defaultValue: bool) -> bool:
    return _ib(0xB327CF1B8C2C0EA3, tunableName, defaultValue)

def NETWORK_WAITING_POP_CLEAR_TUTORIAL_SESSION() -> bool:
    return _ib(0xB37E4E6A2388CA7B)

def NETWORK_CLAN_ANY_DOWNLOAD_MEMBERSHIP_PENDING() -> bool:
    return _ib(0xB3F64A6A91432477)

def GET_COMMERCE_ITEM_NAME(index: int) -> str:
    return _is(0xB4271092CA7EDF48, index)

def NETWORK_SESSION_CHANGE_SLOTS(slots: int, p1: bool) -> None:
    _iv(0xB4AB419E0D86ACAE, slots, p1)

def VEH_TO_NET(vehicle: int) -> int:
    return _ii(0xB4C94523F023419C, vehicle)

def NETWORK_GET_PRIMARY_CLAN_DATA_PENDING() -> bool:
    return _ib(0xB5074DB804E28CE7)

def NETWORK_CAN_VIEW_GAMER_USER_CONTENT(gamerHandle: int) -> bool:
    return _ib(0xB57A49545BA53CE7, gamerHandle)

def NETWORK_SESSION_IS_VOICE_SESSION_ACTIVE() -> bool:
    return _ib(0xB5D3453C98456528)

def TRIGGER_COMMERCE_DATA_FETCH(p0: int) -> None:
    _iv(0xB606E6CC59664972, p0)

def RESERVE_NETWORK_MISSION_PEDS(amount: int) -> None:
    _iv(0xB60FEBA45333D36F, amount)

def NETWORK_REQUEST_CONTROL_OF_ENTITY(entity: int) -> bool:
    return _ib(0xB69317BF5E782347, entity)

def UGC_GET_CREATORS_BY_USER_ID(p0: int, p1: int) -> bool:
    return _ib(0xB746D20B17F2A229, p0, p1)

def NETWORK_FORCE_LOCAL_PLAYER_SCAR_SYNC() -> None:
    _iv(0xB7C7F6AD6424304B)

def UGC_GET_GET_BY_CONTENT_IDS(data: int, dataCount: int, contentTypeName: str) -> bool:
    return _ib(0xB8322EEB38BE7C26, data, dataCount, contentTypeName)

def NETWORK_IS_PLAYER_ACTIVE(player: int) -> bool:
    return _ib(0xB8DFD30D6973E135, player)

def NETWORK_SESSION_LEAVE(p0: int) -> bool:
    return _ib(0xB9351A07A0D458B1, p0)

def _NETWORK_GET_PLAYER_BROADCAST_DATA_SIZE_UNSYNCED(scriptNameHash: int, instance: int, positionHash: int, handlerNum: int) -> int:
    return _ii(0xB99CD664FD4720A1, scriptNameHash, instance, positionHash, handlerNum)

def NETWORK_SESSION_HOST_FRIENDS_ONLY(p0: int, maxPlayers: int) -> bool:
    return _ib(0xB9CFD27A5D578D83, p0, maxPlayers)

def NETWORK_SESSION_IS_VISIBLE() -> bool:
    return _ib(0xBA416D68C631496A)

def NETWORK_SET_OBJECT_SCOPE_DISTANCE(object: int, range: float) -> None:
    _iv(0xBA7F0B77D80A4EB7, object, range)

def UGC_CLEAR_QUERY_RESULTS() -> None:
    _iv(0xBA96394A0EECFA65)

def NETWORK_ARE_SOCIAL_CLUB_POLICIES_CURRENT() -> bool:
    return _ib(0xBA9775570DB788CF)

def NETWORK_SET_VOICE_ACTIVE(toggle: bool) -> None:
    _iv(0xBABEC9E69A91C57B, toggle)

def NETWORK_IS_FRIEND_INDEX_ONLINE(friendIndex: int) -> bool:
    return _ib(0xBAD8F2A42B844821, friendIndex)

def UGC_GET_CONTENT_PATH(p0: int, p1: int) -> str:
    return _is(0xBAF6BABF9E7CCC13, p0, p1)

def NETWORK_CLAN_REMOTE_MEMBERSHIPS_ARE_IN_CACHE(p0: int) -> bool:
    return _ib(0xBB6E6FEE99D866B2, p0)

def NETWORK_CONCEAL_PLAYER(player: int, toggle: bool, p2: bool) -> None:
    _iv(0xBBDF066252829606, player, toggle, p2)

def NETWORK_HASH_FROM_PLAYER_HANDLE(player: int) -> int:
    return _ii(0xBC1D768F2F5D6C05, player)

def CAN_REGISTER_MISSION_PEDS(amount: int) -> bool:
    return _ib(0xBCBF4FEF9FA5D781, amount)

def NETWORK_CACHE_LOCAL_PLAYER_HEAD_BLEND_DATA() -> None:
    _iv(0xBD0BE0BFC927EAC1)

def NETWORK_IS_NP_AVAILABLE() -> bool:
    return _ib(0xBD545D44CCE70597)

def NETWORK_SESSION_IS_DISPLAYING_INVITE_CONFIRMATION() -> bool:
    return _ib(0xBDB6F89C729CF388)

def NET_TO_PED(netHandle: int) -> int:
    return _ii(0xBDCD95FC216A8B3E, netHandle)

def NETWORK_SESSION_DO_ACTIVITY_QUICKMATCH(p0: int, p1: int, p2: int, p3: int, p4: int) -> bool:
    return _ib(0xBE3E347A87ACEB82, p0, p1, p2, p3, p4)

def ACTIVATE_DAMAGE_TRACKER_ON_PLAYER(player: int, toggle: bool) -> None:
    _iv(0xBEC0816FF5ACBCDA, player, toggle)

def UGC_GET_CONTENT_NAME(p0: int) -> str:
    return _is(0xBF09786A7FCAB582, p0)

def NETWORK_LEAVE_PED_BEHIND_BEFORE_CUTSCENE(player: int, p1: bool) -> None:
    _iv(0xBF22E0F32968E967, player, p1)

def _NETWORK_GET_COMMUNICATION_GROUP_VALUE(communicationType: int) -> int:
    return _ii(0xBF66ACD9AE81A99F, communicationType)

def NET_TO_ENT(netHandle: int) -> int:
    return _ii(0xBFFEAB45A9A9094A, netHandle)

def UGC_GET_ROOT_CONTENT_ID(p0: int) -> str:
    return _is(0xC0173D6BFF4E0348, p0)

def NETWORK_IS_DOOR_NETWORKED(doorHash: int) -> bool:
    return _ib(0xC01E93FAC20C3346, doorHash)

def NETWORK_GET_PRIMARY_CLAN_DATA_NEW(p0: int, p1: int) -> bool:
    return _ib(0xC080FF658B2E41DA, p0, p1)

def NETWORK_IS_PUSH_TO_TALK_ACTIVE() -> bool:
    return _ib(0xC0D2AF00BCC234CA)

def NETWORK_SEND_TRANSITION_INVITE_VIA_PRESENCE(gamerHandle: int, p1: str, dataCount: int, p3: int) -> bool:
    return _ib(0xC116FF9B4D488291, gamerHandle, p1, dataCount, p3)

def NETWORK_UGC_NAV(p0: int, p1: int) -> None:
    _iv(0xC1447451DDB512F0, p0, p1)

def NETWORK_SESSION_VALIDATE_JOIN(p0: bool) -> None:
    _iv(0xC19F6C8E7865A6FF, p0)

def NETWORK_HAS_ROS_PRIVILEGE_END_DATE(privilege: int, banType: int, timeData: int) -> bool:
    return _ib(0xC22912B1D85F26B1, privilege, banType, timeData)

def NETWORK_STOP_SYNCHRONISED_SCENE(netScene: int) -> None:
    _iv(0xC254481A4574CB2F, netScene)

def NETWORK_CLAN_HAS_CREWINFO_METADATA_BEEN_RECEIVED() -> bool:
    return _ib(0xC32EA7A2F6CA7557)

def UGC_HAS_PERMISSION_TO_WRITE() -> bool:
    return _ib(0xC33E7CBC06EC1A8D)

def NETWORK_TRANSITION_ADD_STAGE(hash: int, p1: int, p2: int, state: int, p4: int) -> bool:
    return _ib(0xC3BFED92026A2AAD, hash, p1, p2, state, p4)

def NETWORK_SEND_INVITE_VIA_PRESENCE(gamerHandle: int, p1: str, dataCount: int, p3: int) -> bool:
    return _ib(0xC3C7A6AFDB244624, gamerHandle, p1, dataCount, p3)

def NETWORK_HAS_CONFIRMED_INVITE() -> bool:
    return _ib(0xC42DD763159F3461)

def NETWORK_GET_DESTROYER_OF_ENTITY(entity: int, weaponHash: int) -> int:
    return _ii(0xC434133D9BA52777, entity, weaponHash)

def NETWORK_DISABLE_LEAVE_REMOTE_PED_BEHIND(toggle: bool) -> None:
    _iv(0xC505036A35AFD01B, toggle)

def UGC_GET_CREATE_CONTENT_ID() -> str:
    return _is(0xC55A0B40FFB1ED23)

def NETWORK_IS_TRANSITION_LEAVE_POSTPONED() -> bool:
    return _ib(0xC571D0E77D8BBC29)

def CLOUD_DELETE_MEMBER_FILE(p0: str) -> int:
    return _ii(0xC64DED7EF0D2FE37, p0)

def NETWORK_SESSION_JOIN_INVITE() -> None:
    _iv(0xC6F8AB8A4189CF3A)

def NETWORK_SET_TASK_CUTSCENE_INSCOPE_MULTIPLER(multiplier: float) -> None:
    _iv(0xC6FCEE21C6FCEE21, multiplier)

def UGC_QUERY_BY_CONTENT_IDS(data: int, count: int, latestVersion: bool, contentTypeName: str) -> bool:
    return _ib(0xC7397A83F7A2A462, data, count, latestVersion, contentTypeName)

def NETWORK_TRY_ACCESS_TUNABLE_BOOL_HASH(tunableContext: int, tunableName: int, defaultValue: bool) -> bool:
    return _ib(0xC7420099936CE286, tunableContext, tunableName, defaultValue)

def NETWORK_SESSION_HOST_SINGLE_PLAYER(p0: int) -> None:
    _iv(0xC74C33FCA52856D5, p0)

def NETWORK_GET_ENTITY_IS_NETWORKED(entity: int) -> bool:
    return _ib(0xC7827959479DCC78, entity)

def CLOUD_IS_CHECKING_AVAILABILITY() -> bool:
    return _ib(0xC7ABAC5DE675EE3B)

def NETWORK_GET_HOST_OF_THIS_SCRIPT() -> int:
    return _ii(0xC7B4D79B01FA7A5C)

def GET_MAX_NUM_NETWORK_OBJECTS() -> int:
    return _ii(0xC7BE335216B5EC7C)

def NETWORK_MEMBER_ID_FROM_GAMER_HANDLE(gamerHandle: int) -> str:
    return _is(0xC82630132081BB6F, gamerHandle)

def UGC_WAS_QUERY_FORCE_CANCELLED() -> bool:
    return _ib(0xC87E740D9F3872CC)

def NETWORK_ACTION_FOLLOW_INVITE() -> bool:
    return _ib(0xC88156EBB786F8D5)

def NETWORK_CLAN_GET_MEMBERSHIP(p0: int, clanMembership: int, p2: int) -> bool:
    return _ib(0xC8BC2011F67B3411, p0, clanMembership, p2)

def NETWORK_CAN_SET_WAYPOINT() -> bool:
    return _ib(0xC927EC229934AF60)

def NETWORK_FORCE_LOCAL_USE_OF_SYNCED_SCENE_CAMERA(netScene: int) -> None:
    _iv(0xC9B43A33D09CADA7, netScene)

def NETWORK_SET_GAMER_INVITED_TO_TRANSITION(gamerHandle: int) -> None:
    _iv(0xCA2C8073411ECDB6, gamerHandle)

def NETWORK_DISABLE_VOICE_BANDWIDTH_RESTRICTION(player: int) -> None:
    _iv(0xCA575C391FEA25CC, player)

def NETWORK_SKIP_RADIO_RESET_NEXT_OPEN() -> None:
    _iv(0xCA59CCAE5D01E4CE)

def GET_COMMERCE_PRODUCT_PRICE(index: int) -> str:
    return _is(0xCA94551B50B4932C, index)

def NETWORK_IS_IN_SESSION() -> bool:
    return _ib(0xCA97246103B63917)

def NETWORK_SESSION_ADD_ACTIVE_MATCHMAKING_GROUP(groupId: int) -> None:
    _iv(0xCAE55F48D3D7875C, groupId)

def GET_NUM_CREATED_MISSION_PEDS(p0: bool) -> int:
    return _ii(0xCB215C4B56A7FAE7, p0)

def IS_TIME_LESS_THAN(timeA: int, timeB: int) -> bool:
    return _ib(0xCB2CF5148012C8D0, timeA, timeB)

def NETWORK_HAS_CONTROL_OF_DOOR(doorHash: int) -> bool:
    return _ib(0xCB3C68ADB06195DF, doorHash)

def _NETWORK_GET_BATTLEYE_ERROR_MESSAGE_LABEL(errorCode: int) -> str:
    return _is(0xCBA50F371E45B90D, errorCode)

def FILLOUT_PM_PLAYER_LIST(gamerHandle: int, p1: int, p2: int) -> bool:
    return _ib(0xCBBD7C4991B64809, gamerHandle, p1, p2)

def NETWORK_SYNC_CLOCK_TIME_OVERRIDE() -> None:
    _iv(0xCBD02360C5E16871)

def NETWORK_SET_TALKER_PROXIMITY(value: float) -> None:
    _iv(0xCBF12D65F95AD686, value)

def NETWORK_HAS_VIEW_GAMER_USER_CONTENT_RESULT(gamerHandle: int) -> bool:
    return _ib(0xCCA4318E1AB03F1F, gamerHandle)

def UGC_GET_CONTENT_USER_ID(p0: int) -> str:
    return _is(0xCD67AD041A394C9C, p0)

def NETWORK_USE_LOGARITHMIC_BLENDING_THIS_FRAME(entity: int) -> None:
    _iv(0xCD71A4ECAB22709E, entity)

def NETWORK_SESSION_GET_UNIQUE_CREW_LIMIT() -> int:
    return _ii(0xCDC936BF35EDCB73)

def NETWORK_GET_ENTITY_FROM_NETWORK_ID(netId: int) -> int:
    return _ii(0xCE4E5D9B0A4FF560, netId)

def NETWORK_GET_PLAYER_FROM_GAMER_HANDLE(gamerHandle: int) -> int:
    return _ii(0xCE5F689CF5A0A49D, gamerHandle)

def NETWORK_IS_GAMER_MUTED_BY_ME(gamerHandle: int) -> bool:
    return _ib(0xCE60DE011B6C7978, gamerHandle)

def NETWORK_GET_PRIMARY_CLAN_DATA_START(p0: int, p1: int) -> bool:
    return _ib(0xCE86D8191B762107, p0, p1)

def NETWORK_SESSION_IS_PRIVATE() -> bool:
    return _ib(0xCEF70AA5B3F89BA1)

def NETWORK_GET_NUM_PRESENCE_INVITES() -> int:
    return _ii(0xCEFA968912D0F78D)

def GET_NUM_RESERVED_MISSION_VEHICLES(p0: bool, p1: int) -> int:
    return _ii(0xCF3A965906452031, p0, p1)

def NETWORK_GET_TOTAL_NUM_PLAYERS() -> int:
    return _ii(0xCF61D4B4702EE9EB)

def NETWORK_ADD_SYNCHRONISED_SCENE_CAMERA(netScene: int, animDict: str, animName: str) -> None:
    _iv(0xCF8BD3B0BD6D42D7, netScene, animDict, animName)

def UGC_GET_CONTENT_UPDATED_DATE(p0: int, p1: int) -> None:
    _iv(0xCFD115B373C0DF63, p0, p1)

def _NETWORK_HIDE_ENTITY_IN_TUTORIAL_SESSION(netHandle: int, hide: bool) -> None:
    _iv(0xCFE359CCCFE359CC, netHandle, hide)

def NETWORK_REMAIN_IN_GAME_CHAT(p0: bool) -> None:
    _iv(0xCFEB46DCD7D8D5EB, p0)

def NETWORK_BLOCK_JOIN_QUEUE_INVITES(toggle: bool) -> None:
    _iv(0xCFEB8AF24FC1D0BB, toggle)

def UGC_SET_DELETED(p0: int, p1: bool, p2: str) -> bool:
    return _ib(0xD05D1A6C74DA3498, p0, p1, p2)

def NETWORK_IS_TRANSITION_VISIBILITY_LOCKED() -> bool:
    return _ib(0xD0A484CB2F829FBE)

def NETWORK_END_TUTORIAL_SESSION() -> None:
    _iv(0xD0AFAFF5A51D72F7)

def SET_LOCAL_PLAYER_VISIBLE_IN_CUTSCENE(p0: bool, p1: bool) -> None:
    _iv(0xD1065D68947E7B6E, p0, p1)

def NETWORK_TRY_TO_SET_THIS_SCRIPT_IS_NETWORK_SCRIPT(p0: int, p1: bool, p2: int) -> bool:
    return _ib(0xD1110739EEADB592, p0, p1, p2)

def NETWORK_LEAVE_TRANSITION() -> bool:
    return _ib(0xD23A1A815D21DB19)

def NETWORK_SESSION_IS_AWAITING_INVITE_RESPONSE() -> bool:
    return _ib(0xD313DE83394AF134)

def NETWORK_GET_NUMBER_BODY_TRACKER_HITS() -> int:
    return _ii(0xD38C4A6D047C019D)

def NETWORK_GET_PRESENCE_INVITE_PLAYLIST_LENGTH(p0: int) -> int:
    return _ii(0xD39B3FFF8FFDD5BF, p0)

def NETWORK_GET_AVERAGE_LATENCY(player: int) -> float:
    return _if(0xD414BE129BB81B32, player)

def ACTIVATE_DAMAGE_TRACKER_ON_NETWORK_ID(netID: int, toggle: bool) -> None:
    _iv(0xD45B1FFCCD52FF19, netID, toggle)

def NETWORK_HANDLE_FROM_FRIEND(friendIndex: int, gamerHandle: int, gamerHandleSize: int) -> None:
    _iv(0xD45CB817D7E177D2, friendIndex, gamerHandle, gamerHandleSize)

def UGC_IS_GETTING() -> bool:
    return _ib(0xD53ACDBEF24A46E8)

def UGC_GET_BOOKMARKED_CONTENT(p0: int, p1: int, p2: str, p3: int) -> bool:
    return _ib(0xD5A4B59980401588, p0, p1, p2, p3)

def NETWORK_SET_TEAM_ONLY_CHAT(toggle: bool) -> None:
    _iv(0xD5B4883AC32F24C3, toggle)

def NETWORK_DISPLAYNAMES_FROM_HANDLES_START(p0: int, p1: int) -> int:
    return _ii(0xD66C9E72B3CC4982, p0, p1)

def NETWORK_SESSION_GET_KICK_VOTE(player: int) -> bool:
    return _ib(0xD6D09A6F32F49EF1, player)

def NETWORK_REGISTER_HIGH_FREQUENCY_PLAYER_BROADCAST_VARIABLES(p0: int, p1: int, p2: int) -> None:
    _iv(0xD6D7478CA62B8D41, p0, p1, p2)

def SET_INVERT_GHOSTING(p0: bool) -> None:
    _iv(0xD7B6C73CAD419BCF, p0)

def NETWORK_IS_CLOCK_TIME_OVERRIDDEN() -> bool:
    return _ib(0xD7C95D322FF57522)

def IS_SPHERE_VISIBLE_TO_ANOTHER_MACHINE(p0: float, p1: float, p2: float, p3: float) -> bool:
    return _ib(0xD82CF8E64C8729D8, p0, p1, p2, p3)

def NETWORK_SET_ENTITY_CAN_BLEND(entity: int, toggle: bool) -> None:
    _iv(0xD830567D88A1E873, entity, toggle)

def NETWORK_IS_SESSION_ACTIVE() -> bool:
    return _ib(0xD83C2B94E7508980)

def NET_TO_OBJ(netHandle: int) -> int:
    return _ii(0xD8515F5FEA14CB3F, netHandle)

def _NETWORK_HAS_ROS_PRIVILEGE_MP_TEXT_COMMUNICATION() -> bool:
    return _ib(0xD9719341663C385F)

def NETWORK_CLEAR_CLOCK_TIME_OVERRIDE() -> None:
    _iv(0xD972DF67326F966E)

def NETWORK_IS_SCRIPT_ACTIVE_BY_HASH(scriptHash: int, p1: int, p2: bool, p3: int) -> bool:
    return _ib(0xDA7DE67F5FE5EE13, scriptHash, p1, p2, p3)

def NETWORK_GET_PLAYER_ACCOUNT_ID(player: int) -> int:
    return _ii(0xDB663CC9FF3407A9, player)

def NETWORK_APPLY_VOICE_PROXIMITY_OVERRIDE(x: float, y: float, z: float) -> None:
    _iv(0xDBD2056652689917, x, y, z)

def _NETWORK_DOES_COMMUNICATION_GROUP_HAVE_PERMISSION(communicationType: int) -> bool:
    return _ib(0xDBDF80673BBA3D65, communicationType)

def IS_SPHERE_VISIBLE_TO_PLAYER(p0: int, p1: float, p2: float, p3: float, p4: float) -> bool:
    return _ib(0xDC3A310219E5DA62, p0, p1, p2, p3, p4)

def FACEBOOK_POST_CREATE_CHARACTER() -> bool:
    return _ib(0xDC48473142545431)

def NETWORK_HANDLE_FROM_USER_ID(userId: str, gamerHandle: int, gamerHandleSize: int) -> None:
    _iv(0xDCD51DD8F87AEC5C, userId, gamerHandle, gamerHandleSize)

def IS_NETWORK_VEHICLE_RUNNING_RESPOT_TIMER(networkID: int) -> bool:
    return _ib(0xDD7CEF5B3A4DA8A6, networkID)

def NETWORK_IS_FINDING_GAMERS() -> bool:
    return _ib(0xDDDF64C91BFCF0AA)

def NETWORK_OVERRIDE_RECEIVE_RESTRICTIONS(player: int, toggle: bool) -> None:
    _iv(0xDDF73E2B1FEC5AB4, player, toggle)

def IS_TIME_MORE_THAN(timeA: int, timeB: int) -> bool:
    return _ib(0xDE350F8651E4346C, timeA, timeB)

def NETWORK_FADE_OUT_ENTITY(entity: int, normal: bool, slow: bool) -> None:
    _iv(0xDE564951F95E09ED, entity, normal, slow)

def NETWORK_RESOLVE_PRIVILEGE_USER_CONTENT() -> bool:
    return _ib(0xDE9225854F37BF72)

def NETWORK_START_USER_CONTENT_PERMISSIONS_CHECK(netHandle: int) -> int:
    return _ii(0xDEB2B99A1AF1A2A6, netHandle)

def NETWORK_AM_I_MUTED_BY_GAMER(gamerHandle: int) -> bool:
    return _ib(0xDF02A2C93F1F26DA, gamerHandle)

def NETWORK_GET_PRESENCE_INVITE_ID(p0: int) -> int:
    return _ii(0xDFF09646E12EC386, p0)

def NETWORK_SESSION_GET_HOST_AIM_PREFERENCE() -> int:
    return _ii(0xDFFA5BE8381C3314)

def SET_ENTITY_VISIBLE_IN_CUTSCENE(p0: int, p1: bool, p2: bool) -> None:
    _iv(0xE0031D3C8F36AB82, p0, p1, p2)

def _NETWORK_SESSION_LEAVE_INCLUDING_REASON(leaveFlags: int, leaveReason: int) -> bool:
    return _ib(0xE0128328CF1FD9F4, leaveFlags, leaveReason)

def NETWORK_CLEAR_VOICE_CHANNEL() -> None:
    _iv(0xE036A705F989E049)

def SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(netId: int, toggle: bool) -> None:
    _iv(0xE05E81A888FA63C8, netId, toggle)

def UGC_GET_CONTENT_NUM() -> int:
    return _ii(0xE0A6138401BCB837)

def NETWORK_GET_FRIEND_NAME(friendIndex: int) -> str:
    return _is(0xE11EBBB2A783FE8B, friendIndex)

def SET_ENTITY_LOCALLY_INVISIBLE(entity: int) -> None:
    _iv(0xE135A9FF3F5D05D8, entity)

def CAN_REGISTER_MISSION_DOORS(p0: int) -> bool:
    return _ib(0xE16AA70CE9BEEDC3, p0)

def _NETWORK_HAVE_PLATFORM_COMMUNICATION_PRIVILEGES() -> bool:
    return _ib(0xE1E02509169C124E)

def REFRESH_PLAYER_LIST_STATS(p0: int) -> bool:
    return _ib(0xE26CCFF8094D8C74, p0)

def NETWORK_GET_RANDOM_INT_RANGED(rangeStart: int, rangeEnd: int) -> int:
    return _ii(0xE30CF56F1EFA5F43, rangeStart, rangeEnd)

def GET_RESERVED_MISSION_ENTITIES_IN_AREA(x: float, y: float, z: float, p3: int, out1: int, out2: int, out3: int) -> None:
    _iv(0xE42D626EEC94E5D9, x, y, z, p3, out1, out2, out3)

def _NETWORK_GET_BROADCAST_DATA_HOST_UPDATE_SIZE(scriptNameHash: int, instance: int, positionHash: int, handlerNum: int) -> int:
    return _ii(0xE448693B3EA3B92C, scriptNameHash, instance, positionHash, handlerNum)

def NETWORK_DOES_TUNABLE_EXIST_HASH(tunableContext: int, tunableName: int) -> bool:
    return _ib(0xE4E53E1419D81127, tunableContext, tunableName)

def NETWORK_FIND_GAMERS_IN_CREW(crewId: int) -> bool:
    return _ib(0xE532D6811B3A4D2A, crewId)

def _NETWORK_SET_COMMUNICATION_GROUP_FLAGS(communicationType: int, communicationGroupFlag: int) -> None:
    _iv(0xE549F846DE7D32D5, communicationType, communicationGroupFlag)

def NETWORK_ACCESS_TUNABLE_FLOAT(tunableContext: str, tunableName: str, value: int) -> bool:
    return _ib(0xE5608CA7BC163A5F, tunableContext, tunableName, value)

def NETWORK_SESSION_GET_INVITER(gamerHandle: int) -> None:
    _iv(0xE57397B4A3429DD0, gamerHandle)

def SET_LOCAL_PLAYER_INVISIBLE_LOCALLY(bIncludePlayersVehicle: bool) -> None:
    _iv(0xE5F773C1A1D9D168, bIncludePlayersVehicle)

def NETWORK_ENTITY_AREA_DOES_EXIST(areaHandle: int) -> bool:
    return _ib(0xE64A3CA08DFA37A9, areaHandle)

def NETWORK_APPLY_PED_SCAR_DATA(ped: int, p1: int) -> None:
    _iv(0xE66C690248F11150, ped, p1)

def NETWORK_ENABLE_EXTRA_VEHICLE_ORIENTATION_BLEND_CHECKS(netId: int, toggle: bool) -> None:
    _iv(0xE6717E652B8C8D8A, netId, toggle)

def NETWORK_OVERRIDE_CLOCK_TIME(hours: int, minutes: int, seconds: int) -> None:
    _iv(0xE679E3E06E363892, hours, minutes, seconds)

def IS_PLAYER_IN_CUTSCENE(player: int) -> bool:
    return _ib(0xE73092F4157CD126, player)

def NETWORK_GET_LOCAL_HANDLE(gamerHandle: int, gamerHandleSize: int) -> None:
    _iv(0xE86051786B66CD8E, gamerHandle, gamerHandleSize)

def NETWORK_HAS_HEADSET() -> bool:
    return _ib(0xE870F9F1F7B4F1FA)

def NETWORK_IS_GAMER_BLOCKED_BY_ME(gamerHandle: int) -> bool:
    return _ib(0xE944C4F5AF1B5883, gamerHandle)

def UGC_CANCEL_QUERY() -> None:
    _iv(0xE9B99B6853181409)

def _NETWORK_TRIGGER_DAMAGE_EVENT_FOR_ZERO_PED_DAMAGE(entity: int, trigger: bool) -> None:
    _iv(0xE9D0244ACBEE1BC4, entity, trigger)

def IS_COMMERCE_DATA_VALID() -> bool:
    return _ib(0xEA14EEF5B7CD2C30)

def NETWORK_ACCESS_TUNABLE_BOOL_HASH(tunableContext: int, tunableName: int) -> bool:
    return _ib(0xEA16B69D93D71A45, tunableContext, tunableName)

def NETWORK_RESURRECT_LOCAL_PLAYER(x: float, y: float, z: float, heading: float, p4: bool, changetime: bool, p6: bool, p7: int, p8: int) -> None:
    _iv(0xEA23C49EAA83ACFB, x, y, z, heading, p4, changetime, p6, p7, p8)

def NETWORK_REGISTER_HIGH_FREQUENCY_HOST_BROADCAST_VARIABLES(p0: int, p1: int, p2: int) -> None:
    _iv(0xEA8C0DDB10E2822A, p0, p1, p2)

def NETWORK_BAIL_TRANSITION(p0: int, p1: int, p2: int) -> None:
    _iv(0xEAA572036990CD1B, p0, p1, p2)

def NETWORK_IS_NP_PENDING() -> bool:
    return _ib(0xEBCAB9E5048434F4)

def NETWORK_APPLY_TRANSITION_PARAMETER_STRING(p0: int, string: str, p2: bool) -> None:
    _iv(0xEBEFC2E77084F599, p0, string, p2)

def NETWORK_REMOVE_AND_CANCEL_ALL_INVITES() -> None:
    _iv(0xEBF8284D8CADEB53)

def UGC_HAS_DESCRIPTION_REQUEST_FINISHED(p0: int) -> bool:
    return _ib(0xEBFA8D50ADDC54C4, p0)

def SET_NETWORK_VEHICLE_RESPOT_TIMER(netId: int, time: int, p2: int, p3: int) -> None:
    _iv(0xEC51713AB6EC36E8, netId, time, p2, p3)

def BAD_SPORT_PLAYER_LEFT_DETECTED(gamerHandle: int, event: int, amountReceived: int) -> bool:
    return _ib(0xEC5E3AF5289DCA81, gamerHandle, event, amountReceived)

def NETWORK_SESSION_HOST_CLOSED(p0: int, maxPlayers: int) -> bool:
    return _ib(0xED34C0C02C098BB7, p0, maxPlayers)

def UGC_GET_QUERY_RESULT() -> int:
    return _ii(0xEDF7F927136C224B)

def NETWORK_CLAN_PLAYER_GET_DESC(clanDesc: int, bufferSize: int, gamerHandle: int) -> bool:
    return _ib(0xEEE6EACBE8874FBA, clanDesc, bufferSize, gamerHandle)

def NETWORK_CHANGE_TRANSITION_SLOTS(p0: int, p1: bool) -> None:
    _iv(0xEEEDA5E6D7080987, p0, p1)

def NETWORK_SESSION_IS_VOICE_SESSION_BUSY() -> bool:
    return _ib(0xEF0912DDF7C4CB4B)

def NETWORK_SET_TRANSITION_CREATOR_HANDLE(p0: int) -> None:
    _iv(0xEF26739BCD9907D5, p0)

def NETWORK_SET_VOICE_CHANNEL(channel: int) -> None:
    _iv(0xEF6212C2EFEF1A23, channel)

def NETWORK_IS_CABLE_CONNECTED() -> bool:
    return _ib(0xEFFB25453D8600F9)

def NETWORK_REMOVE_PRESENCE_INVITE(p0: int) -> bool:
    return _ib(0xF0210268DB0974B1, p0)

def NETWORK_CLEAR_VOICE_PROXIMITY_OVERRIDE() -> None:
    _iv(0xF03755696450470C)

def NETWORK_REMOVE_AND_CANCEL_ALL_TRANSITION_INVITES() -> None:
    _iv(0xF083835B70BA9BFE)

def NETWORK_PATCH_POST_CUTSCENE_HS4F_TUN_ENT(ped: int) -> None:
    _iv(0xF0BC9BCD24A511D5, ped)

def GET_CLOUD_TIME_AS_STRING() -> str:
    return _is(0xF12E6CD06C73D69E)

def NETWORK_SEED_RANDOM_NUMBER_GENERATOR(seed: int) -> None:
    _iv(0xF1B84178F8674195, seed)

def NETWORK_SET_ENTITY_ONLY_EXISTS_FOR_PARTICIPANTS(entity: int, toggle: bool) -> None:
    _iv(0xF1CA12B18AEF5298, entity, toggle)

def NETWORK_SESSION_SET_MATCHMAKING_MENTAL_STATE(p0: int) -> None:
    _iv(0xF1EEA2DDA9FFA69D, p0)

def NETWORK_ADD_ENTITY_TO_SYNCHRONISED_SCENE(entity: int, netScene: int, animDict: str, animName: str, speed: float, speedMulitiplier: float, flag: int) -> None:
    _iv(0xF2404D68CBC855FA, entity, netScene, animDict, animName, speed, speedMulitiplier, flag)

def GET_NUM_COMMERCE_ITEMS() -> int:
    return _ii(0xF2EAC213D5EA0623)

def NETWORK_GAMER_HAS_HEADSET(gamerHandle: int) -> bool:
    return _ib(0xF2FD55CB574BCC55, gamerHandle)

def NETWORK_SESSION_IS_SOLO() -> bool:
    return _ib(0xF3929C2379B60CCE)

def NETWORK_IS_SESSION_BUSY() -> bool:
    return _ib(0xF4435D66A8E2905E)

def NETWORK_CLAN_GET_UI_FORMATTED_TAG(clanDesc: int, bufferSize: int, formattedTag: str) -> None:
    _iv(0xF45352426FF3A4F0, clanDesc, bufferSize, formattedTag)

def NETWORK_SET_NO_SPECTATOR_CHAT(toggle: bool) -> None:
    _iv(0xF46A1E03E8755980, toggle)

def NETWORK_SESSION_SET_UNIQUE_CREW_LIMIT(p0: int) -> None:
    _iv(0xF49ABC20D8552257, p0)

def UGC_IS_LANGUAGE_SUPPORTED(p0: int) -> bool:
    return _ib(0xF53E48461B71EECB, p0)

def IS_TIME_EQUAL_TO(timeA: int, timeB: int) -> bool:
    return _ib(0xF5BC95857BD6D512, timeA, timeB)

def NETWORK_TRANSITION_SET_ACTIVITY_ISLAND(p0: int) -> None:
    _iv(0xF6F4383B7C92F11A, p0)

def NETWORK_FIND_MATCHED_GAMERS(attribute: int, fallbackLimit: float, lowerLimit: float, upperLimit: float) -> bool:
    return _ib(0xF7B2CFDE5C9F700D, attribute, fallbackLimit, lowerLimit, upperLimit)

def NETWORK_SET_FRIENDLY_FIRE_OPTION(toggle: bool) -> None:
    _iv(0xF808475FA571D823, toggle)

def NETWORK_STORE_INVITE_THROUGH_RESTART() -> None:
    _iv(0xF814FEC6A19FD6E0)

def UGC_SET_QUERY_DATA_FROM_OFFLINE(p0: bool) -> None:
    _iv(0xF98DDE0A8ED09323, p0)

def NETWORK_DID_FIND_GAMERS_SUCCEED() -> bool:
    return _ib(0xF9B83B77929D8863)

def UGC_GET_FRIEND_CONTENT(p0: int, p1: int, p2: str, p3: int) -> bool:
    return _ib(0xF9E1CCAE8BA4C281, p0, p1, p2, p3)

def NETWORK_SEND_QUEUED_JOIN_REQUEST() -> None:
    _iv(0xFA2888E3833C8E96)

def NETWORK_SESSION_KICK_PLAYER(player: int) -> None:
    _iv(0xFA8904DC5F304220, player)

def NETWORK_ACCEPT_PRESENCE_INVITE(p0: int) -> bool:
    return _ib(0xFA91550DF9318B22, p0)

def SET_PLAYER_VISIBLE_LOCALLY(player: int, bIncludePlayersVehicle: bool) -> None:
    _iv(0xFAA10F1FAFB11AF2, player, bIncludePlayersVehicle)

def NETWORK_HIDE_PROJECTILE_IN_CUTSCENE() -> None:
    _iv(0xFAC18E7356BD3210)

def SET_LAST_VIEWED_SHOP_ITEM(p0: int, p1: int, p2: int) -> None:
    _iv(0xFAE628F1E9ADB239, p0, p1, p2)

def NETWORK_ACCESS_TUNABLE_MODIFICATION_DETECTION_CLEAR() -> bool:
    return _ib(0xFAFC23AEE23868DB)

def NETWORK_FIND_LARGEST_BUNCH_OF_PLAYERS(p0: int, p1: int) -> bool:
    return _ib(0xFB1F9381E80FA13F, p0, p1)

def NETWORK_CLEAR_TRANSITION_CREATOR_HANDLE() -> None:
    _iv(0xFB3272229A82C759)

def NETWORK_ALLOW_GANG_TO_JOIN_TUTORIAL_SESSION(teamId: int, instanceId: int) -> None:
    _iv(0xFB680D403909DC70, teamId, instanceId)

def NETWORK_CANCEL_RESPAWN_SEARCH() -> None:
    _iv(0xFB8F2A6F3DF08CBE)

def UGC_GET_CREATE_RESULT() -> int:
    return _ii(0xFBC5E768C7A77A6A)

def NETWORK_SESSION_IS_CLOSED_FRIENDS() -> bool:
    return _ib(0xFBCFA2EA2E206890)

def NETWORK_SET_IN_FREE_CAM_MODE(toggle: bool) -> None:
    _iv(0xFC18DB55AE19E046, toggle)

def GET_ONLINE_VERSION() -> str:
    return _is(0xFCA9373EF340AC0A)

def NETWORK_GAMERTAG_FROM_HANDLE_SUCCEEDED() -> bool:
    return _ib(0xFD00798DBA7523DD)

def UGC_SET_USING_OFFLINE_CONTENT(p0: bool) -> None:
    _iv(0xFD75DABC0957BF33, p0)

def NETWORK_IS_IN_PLATFORM_PARTY_CHAT() -> bool:
    return _ib(0xFD8B834A8BA05048)

def NETWORK_BLOCK_PROXY_MIGRATION_BETWEEN_TUTORIAL_SESSIONS(p0: int) -> None:
    _iv(0xFEA7A352DDB34D52, p0)

def NETWORK_GET_NUM_UNACKED_RELIABLES(player: int) -> int:
    return _ii(0xFF8FCF9FFC458A1C, player)

def NETWORK_JOIN_PREVIOUSLY_FAILED_TRANSITION() -> bool:
    return _ib(0xFFE1E5B792D92B34)
