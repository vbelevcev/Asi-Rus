"""Auto-generated raw native bindings for namespace LOCALIZATION.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_int as _ii


def GET_CURRENT_LANGUAGE() -> int:
    return _ii(0x2BDD44CC428A7EAE)

def LOCALIZATION_GET_SYSTEM_LANGUAGE() -> int:
    return _ii(0x497420E022796B3F)

def LOCALIZATION_GET_SYSTEM_DATE_TYPE() -> int:
    return _ii(0xA8AE43AEC1A61314)
