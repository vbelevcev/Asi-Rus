"""Auto-generated raw native bindings for namespace STREAMING.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if


def IS_NEW_LOAD_SCENE_LOADED() -> bool:
    return _ib(0x01B8247A7A8B9AD1)

def REMOVE_CLIP_SET(clipSet: str) -> None:
    _iv(0x01F73A131C18CD94, clipSet)

def FORCE_ALLOW_TIME_BASED_FADING_THIS_FRAME() -> None:
    _iv(0x03F1A106BDA7DD3E)

def REQUEST_COLLISION_AT_COORD(x: float, y: float, z: float) -> None:
    _iv(0x07503F7948F491A7, x, y, z)

def STREAMVOL_IS_VALID(unused: int) -> bool:
    return _ib(0x07C313F94746702C, unused)

def SET_RESTORE_FOCUS_ENTITY(p0: int) -> None:
    _iv(0x0811381EF5062FEC, p0)

def GET_PLAYER_SWITCH_INTERP_OUT_DURATION() -> int:
    return _ii(0x08C2D6C52A3104BB)

def END_SRL() -> None:
    _iv(0x0A41540E63C9EE17)

def STREAMVOL_CREATE_LINE(p0: float, p1: float, p2: float, p3: float, p4: float, p5: float, p6: int) -> int:
    return _ii(0x0AD9710CEE2F590F, p0, p1, p2, p3, p4, p5, p6)

def ADD_MODEL_TO_CREATOR_BUDGET(modelHash: int) -> bool:
    return _ib(0x0BC3144DEB678666, modelHash)

def GET_LODSCALE() -> float:
    return _if(0x0C15B0E443B2349D)

def SET_PLAYER_SWITCH_ESTABLISHING_SHOT(name: str) -> None:
    _iv(0x0FDE9DBFC0A6BC65, name)

def REMOVE_ANIM_SET(animSet: str) -> None:
    _iv(0x16350528F93024B3, animSet)

def SET_FOCUS_ENTITY(entity: int) -> None:
    _iv(0x198F77705FA0931D, entity)

def IS_MODEL_A_VEHICLE(model: int) -> bool:
    return _ib(0x19AAC8F07BFEC53E, model)

def SET_SCENE_STREAMING_TRACKS_CAM_POS_THIS_FRAME() -> None:
    _iv(0x1E9057A74FD73E23)

def STREAMVOL_DELETE(unused: int) -> None:
    _iv(0x1EE7D8DF4425F053, unused)

def STREAMVOL_CREATE_FRUSTUM(p0: float, p1: float, p2: float, p3: float, p4: float, p5: float, p6: float, p7: int, p8: int) -> int:
    return _ii(0x1F3F018BC3AFA77C, p0, p1, p2, p3, p4, p5, p6, p7, p8)

def SET_SRL_LONG_JUMP_MODE(p0: bool) -> None:
    _iv(0x20C6C7E4EB082A7F, p0)

def GET_PLAYER_SHORT_SWITCH_STATE() -> int:
    return _ii(0x20F898A5D9782800)

def NEW_LOAD_SCENE_START(posX: float, posY: float, posZ: float, offsetX: float, offsetY: float, offsetZ: float, radius: float, p7: int) -> bool:
    return _ib(0x212A8D0D2BABFAC2, posX, posY, posZ, offsetX, offsetY, offsetZ, radius, p7)

def STREAMVOL_CREATE_SPHERE(x: float, y: float, z: float, rad: float, p4: int, p5: int) -> int:
    return _ii(0x219C7B8D53E429FD, x, y, z, rad, p4, p5)

def HAS_COLLISION_FOR_MODEL_LOADED(model: int) -> bool:
    return _ib(0x22CCA434E368F03A, model)

def DOES_ANIM_DICT_EXIST(animDict: str) -> bool:
    return _ib(0x2DA49C3B79856961, animDict)

def IS_ENTITY_FOCUS(entity: int) -> bool:
    return _ib(0x2DDFF3FB9075D747, entity)

def HAS_CLIP_SET_LOADED(clipSet: str) -> bool:
    return _ib(0x318234F4F3738AF3, clipSet)

def CLEAR_FOCUS() -> None:
    _iv(0x31B73D1EA9F01DA2)

def IS_MODEL_IN_CDIMAGE(model: int) -> bool:
    return _ib(0x35B9E0803292B641, model)

def PREFETCH_SRL(srl: str) -> None:
    _iv(0x3D245789CE12982C, srl)

def GET_USED_CREATOR_BUDGET() -> float:
    return _if(0x3D3D8B3BE5A83D35)

def GET_NUMBER_OF_STREAMING_REQUESTS() -> int:
    return _ii(0x4060057271CEBC89)

def SET_RENDER_HD_ONLY(toggle: bool) -> None:
    _iv(0x40AEFD1A244741F2, toggle)

def REQUEST_IPL(iplName: str) -> None:
    _iv(0x41B4893843BBDB74, iplName)

def IS_NETWORK_LOADING_SCENE() -> bool:
    return _ib(0x41CA5A33160EA4AB)

def SET_DITCH_POLICE_MODELS(toggle: bool) -> None:
    _iv(0x42CBE54462D92634, toggle)

def ALLOW_PLAYER_SWITCH_PAN() -> None:
    _iv(0x43D1680C6D19A8E9)

def LOAD_SCENE(x: float, y: float, z: float) -> None:
    _iv(0x4448EB75B4904BDB, x, y, z)

def GET_PLAYER_SWITCH_STATE() -> int:
    return _ii(0x470555300D10B2A5)

def SUPPRESS_HD_MAP_STREAMING_THIS_FRAME() -> None:
    _iv(0x472397322E92A856)

def SET_ALL_MAPDATA_CULLED(p0: int) -> None:
    _iv(0x4E52E752C76E7E7A, p0)

def IPL_GROUP_SWAP_IS_ACTIVE() -> bool:
    return _ib(0x5068F488DDB54DD8)

def GET_PLAYER_SWITCH_INTERP_OUT_CURRENT_TIME() -> int:
    return _ii(0x5B48A06DD0E792A5)

def IS_SWITCH_SKIPPING_DESCENT() -> bool:
    return _ib(0x5B74EA8CFD5E3E7E)

def SET_PLAYER_SHORT_SWITCH_STYLE(p0: int) -> None:
    _iv(0x5F2013F8BC24EE69, p0)

def REMOVE_NAMED_PTFX_ASSET(fxName: str) -> None:
    _iv(0x5F61EBBE1A00F96D, fxName)

def IPL_GROUP_SWAP_CANCEL() -> None:
    _iv(0x63EB2B972A218CAC)

def SET_STREAMING(toggle: bool) -> None:
    _iv(0x6E0C692677008888, toggle)

def REQUEST_ANIM_SET(animSet: str) -> None:
    _iv(0x6EA47DAE7FAD0EED, animSet)

def SET_GAME_PAUSES_FOR_STREAMING(toggle: bool) -> None:
    _iv(0x717CD6E6FAEBBEDC, toggle)

def IS_SAFE_TO_START_PLAYER_SWITCH() -> bool:
    return _ib(0x71E7B2E657449AAD)

def ALLOW_PLAYER_SWITCH_OUTRO() -> None:
    _iv(0x74DE2E8739086740)

def IS_MODEL_A_PED(model: int) -> bool:
    return _ib(0x75816577FEA6DAD5, model)

def SET_REDUCE_PED_MODEL_BUDGET(toggle: bool) -> None:
    _iv(0x77B5F9A36BF96710, toggle)

def GET_PLAYER_SWITCH_JUMP_CUT_INDEX() -> int:
    return _ii(0x78C0D93253149435)

def STREAMVOL_HAS_LOADED(unused: int) -> bool:
    return _ib(0x7D41E9D2D17C5B2D, unused)

def LOAD_GLOBAL_WATER_FILE(waterType: int) -> None:
    _iv(0x7E3F55ED251B76D3, waterType)

def SET_REDUCE_VEHICLE_MODEL_BUDGET(toggle: bool) -> None:
    _iv(0x80C527893080CCF3, toggle)

def HAS_NAMED_PTFX_ASSET_LOADED(fxName: str) -> bool:
    return _ib(0x8702416E512EC454, fxName)

def IS_IPL_ACTIVE(iplName: str) -> bool:
    return _ib(0x88A741E44A2B3495, iplName)

def REMOVE_PTFX_ASSET() -> None:
    _iv(0x88C6814073DD4A73)

def REQUEST_MODELS_IN_ROOM(interior: int, roomName: str) -> None:
    _iv(0x8A7A40100EDFEC58, interior, roomName)

def SET_PED_POPULATION_BUDGET(p0: int) -> None:
    _iv(0x8C95333CFC3340F3, p0)

def ALLOW_PLAYER_SWITCH_ASCENT() -> None:
    _iv(0x8E2A065ABDAE6994)

def REQUEST_COLLISION_FOR_MODEL(model: int) -> None:
    _iv(0x923CB32A3B874FCB, model)

def IS_SWITCH_TO_MULTI_FIRSTPART_FINISHED() -> bool:
    return _ib(0x933BBEEB8C61B5F4)

def REQUEST_PTFX_ASSET() -> None:
    _iv(0x944955FB2A3935C8)

def IPL_GROUP_SWAP_START(iplName1: str, iplName2: str) -> None:
    _iv(0x95A7DABDDBB78AE7, iplName1, iplName2)

def STOP_PLAYER_SWITCH() -> None:
    _iv(0x95C0A5BBDC189AA1)

def REQUEST_MODEL(model: int) -> None:
    _iv(0x963D27A58DF860AC, model)

def HAS_MODEL_LOADED(model: int) -> bool:
    return _ib(0x98A4EB5D89A0C952, model)

def SET_ISLAND_ENABLED(name: str, toggle: bool) -> None:
    _iv(0x9A9D1BA639675CF1, name, toggle)

def BEGIN_SRL() -> None:
    _iv(0x9BADDC94EF83B823)

def REQUEST_MENU_PED_MODEL(model: int) -> None:
    _iv(0xA0261AEF7ACFC51E, model)

def IS_NEW_LOAD_SCENE_ACTIVE() -> bool:
    return _ib(0xA41A05B6CB741B85)

def SET_SRL_TIME(p0: float) -> None:
    _iv(0xA74A541C6884E7B8, p0)

def OVERRIDE_LODSCALE_THIS_FRAME(scaling: float) -> None:
    _iv(0xA76359FC80B2438E, scaling)

def SWITCH_TO_MULTI_FIRSTPART(ped: int, flags: int, switchType: int) -> None:
    _iv(0xAAB3200ED59016BC, ped, flags, switchType)

def NEW_LOAD_SCENE_START_SPHERE(x: float, y: float, z: float, radius: float, p4: int) -> bool:
    return _ib(0xACCFB4ACF53551B0, x, y, z, radius, p4)

def ALLOW_PLAYER_SWITCH_DESCENT() -> None:
    _iv(0xAD5FDF34B81BFE79)

def SET_MAPDATACULLBOX_ENABLED(name: str, toggle: bool) -> None:
    _iv(0xAF12610C644A35C9, name, toggle)

def GET_PLAYER_SWITCH_TYPE() -> int:
    return _ii(0xB3C94A90D9FC9E62)

def INIT_CREATOR_BUDGET() -> None:
    _iv(0xB5A4DB34FE89B88A)

def GET_IDEAL_PLAYER_SWITCH_TYPE(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> int:
    return _ii(0xB5D7B26B45720E05, x1, y1, z1, x2, y2, z2)

def REQUEST_NAMED_PTFX_ASSET(fxName: str) -> None:
    _iv(0xB80D8756B4668AB6, fxName)

def SET_HD_AREA(x: float, y: float, z: float, radius: float) -> None:
    _iv(0xB85F26619073E775, x, y, z, radius)

def SET_FOCUS_POS_AND_VEL(x: float, y: float, z: float, offsetX: float, offsetY: float, offsetZ: float) -> None:
    _iv(0xBB7454BAFF08FE25, x, y, z, offsetX, offsetY, offsetZ)

def IS_STREAMVOL_ACTIVE() -> bool:
    return _ib(0xBC9823AB80A3DCAC)

def DISABLE_SWITCH_OUTRO_FX() -> None:
    _iv(0xBD605B8E0E18B3BB)

def LOAD_ALL_OBJECTS_NOW() -> None:
    _iv(0xBD6E84632DD4CB3F)

def SET_SRL_READAHEAD_TIMES(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xBEB2D9A1D9A8F55A, p0, p1, p2, p3)

def REMAP_LODSCALE_RANGE_THIS_FRAME(p0: float, p1: float, p2: float, p3: float) -> None:
    _iv(0xBED8CA5FF5E04113, p0, p1, p2, p3)

def IS_MODEL_VALID(model: int) -> bool:
    return _ib(0xC0296A2EDF545E92, model)

def NEW_LOAD_SCENE_STOP() -> None:
    _iv(0xC197616D221FF4A4)

def SET_PLAYER_SWITCH_OUTRO(cameraCoordX: float, cameraCoordY: float, cameraCoordZ: float, camRotationX: float, camRotationY: float, camRotationZ: float, camFov: float, camFarClip: float, rotationOrder: int) -> None:
    _iv(0xC208B673CE446B61, cameraCoordX, cameraCoordY, cameraCoordZ, camRotationX, camRotationY, camRotationZ, camFov, camFarClip, rotationOrder)

def NETWORK_UPDATE_LOAD_SCENE() -> bool:
    return _ib(0xC4582015556D1C46)

def HAS_ANIM_SET_LOADED(animSet: str) -> bool:
    return _ib(0xC4EA073D86FB29B0, animSet)

def REQUEST_ADDITIONAL_COLLISION_AT_COORD(x: float, y: float, z: float) -> None:
    _iv(0xC9156DC11411A9EA, x, y, z)

def HAS_PTFX_ASSET_LOADED() -> bool:
    return _ib(0xCA7D9B86ECA7481B)

def SET_VEHICLE_POPULATION_BUDGET(p0: int) -> None:
    _iv(0xCB9E1EB3BE2AF4E9, p0)

def SHUTDOWN_CREATOR_BUDGET() -> None:
    _iv(0xCCE26000E9A6FAD7)

def CLEAR_HD_AREA() -> None:
    _iv(0xCE58B1CFB9290813)

def IS_SRL_LOADED() -> bool:
    return _ib(0xD0263801A4C5B0BB)

def HAS_ANIM_DICT_LOADED(animDict: str) -> bool:
    return _ib(0xD031A9162D01088C, animDict)

def REQUEST_CLIP_SET(clipSet: str) -> None:
    _iv(0xD2A71E1A77418A49, clipSet)

def REQUEST_ANIM_DICT(animDict: str) -> None:
    _iv(0xD3BD40951412FEF6, animDict)

def ENABLE_SWITCH_PAUSE_BEFORE_DESCENT() -> None:
    _iv(0xD4793DFF3AF2ABCD)

def SWITCH_TO_MULTI_SECONDPART(ped: int) -> None:
    _iv(0xD8295AF639FD9CB8, ped)

def IS_PLAYER_SWITCH_IN_PROGRESS() -> bool:
    return _ib(0xD9D2CFFF49FAB35F)

def IS_SWITCH_READY_FOR_DESCENT() -> bool:
    return _ib(0xDFA80CB25D0A19B3)

def SET_INTERIOR_ACTIVE(interiorID: int, toggle: bool) -> None:
    _iv(0xE37B76C387BE28ED, interiorID, toggle)

def SET_MODEL_AS_NO_LONGER_NEEDED(model: int) -> None:
    _iv(0xE532F5D78798DAAB, model)

def REMOVE_IPL(iplName: str) -> None:
    _iv(0xEE6C5AD3ECE0A82D, iplName)

def SET_SRL_POST_CUTSCENE_CAMERA(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int) -> None:
    _iv(0xEF39EE20C537E98C, p0, p1, p2, p3, p4, p5)

def REMOVE_MODEL_FROM_CREATOR_BUDGET(modelHash: int) -> None:
    _iv(0xF086AD9354FAC3A3, modelHash)

def IPL_GROUP_SWAP_FINISH() -> None:
    _iv(0xF4A0DADB70F57FA6)

def REMOVE_ANIM_DICT(animDict: str) -> None:
    _iv(0xF66A602F829E2A06, animDict)

def GET_GLOBAL_WATER_FILE() -> int:
    return _ii(0xF741BD853611592D)

def SET_SRL_FORCE_PRESTREAM(p0: int) -> None:
    _iv(0xF8155A7F03DDFC8E, p0)

def START_PLAYER_SWITCH(from_: int, to: int, flags: int, switchType: int) -> None:
    _iv(0xFAA23F2CBA159D67, from_, to, flags, switchType)

def IPL_GROUP_SWAP_IS_READY() -> bool:
    return _ib(0xFB199266061F820A)
