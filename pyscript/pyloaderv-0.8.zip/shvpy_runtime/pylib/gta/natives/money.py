"""Auto-generated raw native bindings for namespace MONEY.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_str as _is


def NETWORK_SPENT_PAY_BUSINESS_SUPPLIES(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x0035BB914316F1E3, p0, p1, p2, p3)

def NETWORK_EARN_WAGE_PAYMENT_BONUS(amount: int) -> None:
    _iv(0x005ACA7100BD101D, amount)

def NETWORK_SPEND_VEHICLE_REQUESTED(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x02D24A35A9CC3503, p0, p1, p2, p3, p4)

def NETWORK_SPEND_UPGRADE_ARENA(amount: int, p1: bool, p2: bool, p3: str) -> None:
    _iv(0x037ABB06825D7AB1, amount, p1, p2, p3)

def NETWORK_DELETE_CHARACTER(characterSlot: int, p1: bool, p2: bool) -> None:
    _iv(0x05A50AF38947EB8D, characterSlot, p1, p2)

def NETWORK_SPENT_ORDER_WAREHOUSE_VEHICLE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x05F04155A226FBBF, p0, p1, p2, p3)

def NETWORK_EARN_CASINO_TIME_TRIAL_WIN(amount: int) -> None:
    _iv(0x0819DB99FD2FBBD8, amount)

def NETWORK_SPEND_GOON(p0: int, p1: int, amount: int) -> None:
    _iv(0x08A1B82B91900682, p0, p1, amount)

def NETWORK_EARN_BOSS(p0: int, p1: int, p2: int) -> None:
    _iv(0x08B0CA7A6AB3AC32, p0, p1, p2)

def NETWORK_GET_CAN_TRANSFER_CASH(amount: int) -> bool:
    return _ib(0x08E8EEADFD0DC4A0, amount)

def NETWORK_EARN_CASINO_MISSION_PARTICIPATION(amount: int) -> None:
    _iv(0x09E8F18641BE2575, amount)

def NETWORK_EARN_FROM_BUSINESS_HUB_SELL(p0: int, p1: int, p2: int) -> None:
    _iv(0x0B39CF0D53F1C883, p0, p1, p2)

def NETWORK_SPENT_UPRADE_BUNKER(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x0C82D21A77C22D49, p0, p1, p2, p3)

def NETWORK_EARN_AGENCY(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x0CB1BE0633C024A8, p0, p1, p2, p3)

def NETWORK_SPENT_BUY_TILTROTOR(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x0CCE73BC7A11E885, p0, p1, p2, p3)

def NETWORK_SPENT_PA_SERVICE_SNACK(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x0D30EB83668E63C5, p0, p1, p2, p3)

def NETWORK_EARN_CHALLENGE(amount: int, p1: int, p2: int) -> None:
    _iv(0x0DD362F14F18942A, amount, p1, p2)

def NETWORK_EARN_SELL_BASE(amount: int, baseNameHash: int) -> None:
    _iv(0x0E1E2FF3F4EC11AA, amount, baseNameHash)

def NETWORK_EARN_ARENA_CAREER_PROGRESSION(amount: int, p1: int) -> None:
    _iv(0x0F99F70C61F14619, amount, p1)

def NETWORK_SPENT_PA_HELI_PICKUP(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x0FE8E1FCD2B86B33, p0, p1, p2, p3)

def _NETWORK_SPEND_UPGRADE_ACID_LAB_EQUIPMENT(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x110EE9D486C23126, p0, p1, p2, p3)

def NETWORK_SPENT_PA_SERVICE_HELI(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x112209CE0290C03A, p0, p1, p2, p3)

def NETWORK_EARN_FIRST_TIME_BONUS(p0: int, p1: int, p2: int) -> None:
    _iv(0x11B0A20C493F7E36, p0, p1, p2)

def NETWORK_SPEND_APARTMENT_UTILITIES(amount: int, p1: bool, p2: bool, data: int) -> None:
    _iv(0x1254B5B3925EFD3D, amount, p1, p2, data)

def NETWORK_EARN_DOOMSDAY_FINALE_BONUS(amount: int, vehicleHash: int) -> None:
    _iv(0x128A747F4A230952, amount, vehicleHash)

def NETWORK_SPENT_BUY_BUNKER(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x12D148D26538D0F9, p0, p1, p2, p3)

def NETWORK_EARN_FROM_BOUNTY(amount: int, gamerHandle: int, p2: int, p3: int) -> None:
    _iv(0x131BB5DA15453ACF, amount, gamerHandle, p2, p3)

def _NETWORK_EARN_SOURCE_PARTICIPATION_ACID_LAB(p0: int, p1: int) -> None:
    _iv(0x136F11B5DF1B304D, p0, p1)

def NETWORK_GET_PVC_TRANSFER_BALANCE() -> int:
    return _ii(0x13A8DE2FD77D04F3)

def NETWORK_SPEND_CAR_CLUB_MEMBERSHIP(amount1: int, p1: int, p2: int, amount2: int, p4: int) -> None:
    _iv(0x1464E17207CD36E2, amount1, p1, p2, amount2, p4)

def NETWORK_EARN_AWARD_CONTRACT(p0: int, p1: int) -> None:
    _iv(0x146D4EB6D22A403F, p0, p1)

def NETWORK_SPENT_ARENA_JOIN_SPECTATOR(amount: int, p1: int, p2: bool, p3: bool) -> None:
    _iv(0x14EAEA58F93B55AF, amount, p1, p2, p3)

def NETWORK_CASINO_CAN_BET(hash: int) -> bool:
    return _ib(0x158C16F5E4CF41F8, hash)

def NETWORK_EARN_GANGOPS_WAGES_BONUS(amount: int, p1: int) -> None:
    _iv(0x15BB2A5C757EB91F, amount, p1)

def NETWORK_SPENT_UPGRADE_TILTROTOR(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x165E135D6DFA2907, p0, p1, p2, p3)

def NETWORK_SPENT_TAXI(amount: int, p1: bool, p2: bool, p3: int, p4: int) -> None:
    _iv(0x17C3A7D31EAE39F9, amount, p1, p2, p3, p4)

def NETWORK_DEDUCT_CASH(amount: int, p1: str, p2: str, p3: bool, p4: bool, p5: bool) -> None:
    _iv(0x18B7AE224B087E26, amount, p1, p2, p3, p4, p5)

def NETWORK_SPEND_AGENCY(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x1B2120405080125C, p0, p1, p2, p3, p4)

def NETWORK_SERVICE_EARN_GANGOPS_RIVAL_DELIVERY(earnedMoney: int) -> None:
    _iv(0x1B882107C23A9022, earnedMoney)

def NETWORK_SPEND_BOUNTY_HUNTER_MISSION(amount: int, p1: bool, p2: bool) -> None:
    _iv(0x1BEA0CD93470BB1F, amount, p1, p2)

def NETWORK_EARN_GANGOPS_FINALE(amount: int, p1: str) -> None:
    _iv(0x1C121FC9545E0D52, amount, p1)

def NETWORK_CAN_SHARE_JOB_CASH() -> bool:
    return _ib(0x1C2473301B1C66BA)

def NETWORK_SPENT_BETTING(amount: int, p1: int, matchId: str, p3: bool, p4: bool) -> None:
    _iv(0x1C436FD11FFA692F, amount, p1, matchId, p3, p4)

def NETWORK_SPENT_UPGRADE_NIGHTCLUB_AND_WAREHOUSE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x1DC9B749E7AE282B, p0, p1, p2, p3)

def NETWORK_EARN_FROM_FMBB_BOSS_WORK(p0: int) -> None:
    _iv(0x1FDA0AA679C9919B, p0)

def PROCESS_CASH_GIFT(p0: int, p1: int, p2: str) -> str:
    return _is(0x20194D48EAEC9A41, p0, p1, p2)

def NETWORK_SPENT_UPGRADE_HACKER_TRUCK(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x226C284C830D0CA8, p0, p1, p2, p3)

def NETWORK_EARN_FIXER_RIVAL_DELIVERY(p0: int, p1: int) -> None:
    _iv(0x235D41210B3A1A5E, p0, p1)

def NETWORK_EARN_GANGOPS_ELITE(amount: int, p1: str, actIndex: int) -> None:
    _iv(0x2597A0D4A4FC2C77, amount, p1, actIndex)

def _NETWORK_SPENT_GENERIC(price: int, p1: bool, p2: bool, stat: int, spent: int, p5: str, p6: str, data: int) -> None:
    _iv(0x2803B027479FB640, price, p1, p2, stat, spent, p5, p6, data)

def NETWORK_SPENT_CASH_DROP(amount: int, p1: bool, p2: bool) -> None:
    _iv(0x289016EC778D60E0, amount, p1, p2)

def NETWORK_SPENT_JOB_SKIP(amount: int, matchId: str, p2: bool, p3: bool) -> None:
    _iv(0x28F174A67B8D0C2F, amount, matchId, p2, p3)

def _NETWORK_SPEND_UPGRADE_ACID_LAB_SCOOP(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0x2940558E05BCC2EC, p0, p1, p2, p3)

def NETWORK_SPENT_BOUNTY(p0: int, p1: bool, p2: bool) -> None:
    _iv(0x29B260B84947DFCC, p0, p1, p2)

def NETWORK_SPEND_GANGOPS_REPAIR_COST(p0: int, p1: int, p2: int) -> None:
    _iv(0x2A7CEC72C3443BCC, p0, p1, p2)

def NETWORK_SPENT_PURCHASE_HACKER_TRUCK(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x2A93C46AAB1EACC9, p0, p1, p2, p3)

def NETWORK_SPENT_UPGRADE_OFFICE_GARAGE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x2AFC2D19B50797F2, p0, p1, p2, p3)

def NETWORK_EARN_FROM_CHALLENGE_WIN(p0: int, p1: int, p2: bool) -> None:
    _iv(0x2B171E6B2F64D8DF, p0, p1, p2)

def NETWORK_EARN_BIKER_SHOP(p0: int, p1: int) -> None:
    _iv(0x2C5809EB9DF57257, p0, p1)

def NETWORK_SPEND_GUNRUNNING(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x2CEB0E0BC2A77C05, p0, p1, p2, p3)

def NETWORK_EARN_GANGOPS_WAGES(amount: int, p1: int) -> None:
    _iv(0x2DCB19ABAB0380A8, amount, p1)

def NETWORK_SPENT_TRADE_IMPEXP_WAREHOUSE_PROPERTY(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x2FAB6614CE22E196, p0, p1, p2, p3)

def NETWORK_BUY_CONTRABAND_MISSION(p0: int, p1: int, p2: int, p3: bool, p4: bool) -> None:
    _iv(0x30FD873ECE50E9F6, p0, p1, p2, p3, p4)

def NETWORK_EARN_FROM_HANGAR_TRADE(p0: int, p1: int) -> None:
    _iv(0x31BA138F6304FB9F, p0, p1)

def NETWORK_SPENT_PURCHASE_IMPEXP_WAREHOUSE_PROPERTY(amount: int, data: int, p2: bool, p3: bool) -> None:
    _iv(0x33981D6804E62F49, amount, data, p2, p3)

def NETWORK_SPEND_BUY_CASINO(amount: int, p1: bool, p2: bool, data: int) -> None:
    _iv(0x34A6FC4D06C4DA0F, amount, p1, p2, data)

def NETWORK_EARN_WAGE_PAYMENT(amount: int, p1: int) -> None:
    _iv(0x35F8DA0E8A31EF1B, amount, p1)

def NETWORK_SPENT_UPGRADE_TRUCK(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x365E877C61D6988B, p0, p1, p2, p3)

def NETWORK_EARN_AUTOSHOP_BUSINESS(p0: int, p1: int, p2: int) -> None:
    _iv(0x36A7FD5A7194B03E, p0, p1, p2)

def NETWORK_EARN_AGENCY_CONTRACT(p0: int, p1: int) -> None:
    _iv(0x38482AD49CB905C7, p0, p1)

def NETWORK_CASINO_CAN_BET_PVC() -> bool:
    return _ib(0x394DCDB9E836B7A9)

def NETWORK_CAN_BET(amount: int) -> bool:
    return _ib(0x3A54E33660DED67F, amount)

def NETWORK_CASINO_BUY_CHIPS(p0: int, p1: int) -> bool:
    return _ib(0x3BD101471C7F9EEC, p0, p1)

def NETWORK_INITIALIZE_CASH(wallet: int, bank: int) -> None:
    _iv(0x3DA5ECD1A56CBA6D, wallet, bank)

def NETWORK_SPENT_UPGRADE_BASE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x3DD3F33A5D55EA6F, p0, p1, p2, p3)

def NETWORK_EARN_FROM_WAREHOUSE(amount: int, id: int) -> None:
    _iv(0x3E4ADAFF1830F146, amount, id)

def NETWORK_EARN_CASINO_HEIST_AWARDS(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x3EC7471E6909798A, p0, p1, p2, p3, p4)

def NETWORK_EARN_FROM_PERSONAL_VEHICLE(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int, p7: int, p8: int) -> None:
    _iv(0x3F4D00167E41E0AD, p0, p1, p2, p3, p4, p5, p6, p7, p8)

def NETWORK_SPEND_BUY_ARENA(amount: int, p1: bool, p2: bool, p3: str) -> None:
    _iv(0x40D5DA9550B7CB46, amount, p1, p2, p3)

def _NETWORK_EARN_JUGGALO_STORY_MISSION_PARTICIPATION(p0: int, p1: int) -> None:
    _iv(0x40FF6CCCC476185C, p0, p1)

def NETWORK_SPENT_UPGRADE_IMPEXP_WAREHOUSE_PROPERTY(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x4128464231E3CA0B, p0, p1, p2, p3)

def NETWORK_EARN_FROM_BUSINESS_BATTLE(p0: int) -> None:
    _iv(0x42FCE14F50F27291, p0)

def NETWORK_EARN_FROM_NOT_BADSPORT(amount: int) -> None:
    _iv(0x4337511FA8221D36, amount)

def NETWORK_SPEND_ARCADE(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x43AA7FAC4E6D6687, p0, p1, p2, p3, p4)

def _NETWORK_SPEND_RENAME_ACID_PRODUCT(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x446798F7495DD7D8, p0, p1, p2, p3)

def NETWORK_EARN_SIGHTSEEING_REWARD(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x45087AE480B233AC, p0, p1, p2, p3)

def NETWORK_EARN_FROM_HOLDUPS(amount: int) -> None:
    _iv(0x45B8154E077D9E4D, amount)

def NETWORK_SPEND_UPGRADE_CASINO(amount: int, p1: bool, p2: bool, data: int) -> None:
    _iv(0x4740D62BC1B4EBEA, amount, p1, p2, data)

def NETWORK_SPEND_CASINO_HEIST_SKIP_MISSION(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x487009DD91D93429, p0, p1, p2, p3)

def _NETWORK_SPEND_UPGRADE_ACID_LAB_MINES(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0x4B99AB08C92C54E4, p0, p1, p2, p3)

def NETWORK_EARN_UPGRADE_ARCADE(p0: int, p1: int, p2: int) -> None:
    _iv(0x4C3B75694F7E0D9C, p0, p1, p2)

def NETWORK_SPENT_BUY_BASE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x4EA3F425C7744D21, p0, p1, p2, p3)

def NETWORK_GET_PVC_BALANCE() -> int:
    return _ii(0x4F54F3B6C202FB4E)

def NETWORK_EARN_DAILY_OBJECTIVE_EVENT(amount: int) -> None:
    _iv(0x5128DF14A5BB86FC, amount)

def NETWORK_EARN_FROM_AI_TARGET_KILL(p0: int, p1: int) -> None:
    _iv(0x515B4A22E4D3C6D7, p0, p1)

def NETWORK_SPENT_BOAT_PICKUP(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0x524EE43A37232C00, p0, p1, p2, p3)

def NETWORK_EARN_DAILY_VEHICLE(p0: int, p1: int) -> None:
    _iv(0x533073E8A596008C, p0, p1)

def NETWORK_SPEND_BEACH_PARTY(p0: int) -> None:
    _iv(0x54ABA22FA6371249, p0)

def NETWORK_EARN_COLLECTABLES_ACTION_FIGURES(amount: int) -> None:
    _iv(0x5517F90043466049, amount)

def NETWORK_SPEND_UPGRADE_ARCADE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x5574637681911FDA, p0, p1, p2, p3)

def NETWORK_EARN_PURCHASE_CLUB_HOUSE(p0: int, p1: int) -> None:
    _iv(0x55A1E095DB052FA5, p0, p1)

def _NETWORK_EARN_AVENGER(amount: int, p1: int) -> None:
    _iv(0x55F006B9D4A46C1D, amount, p1)

def NETWORK_EARN_CASINO_MISSION_REWARD(amount: int) -> None:
    _iv(0x566FD402B25787DE, amount)

def NETWORK_RECEIVE_PLAYER_JOBSHARE_CASH(value: int, gamerHandle: int) -> None:
    _iv(0x56A3B51944C50598, value, gamerHandle)

def NETWORK_YOHAN_SOURCE_GOODS(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x59498BC8B1C8B15C, p0, p1, p2, p3)

def NETWORK_EARN_AWARD_SHORT_TRIP(p0: int, p1: int) -> None:
    _iv(0x5B4DBDED84D6A420, p0, p1)

def NETWORK_EARN_TARGET_REFUND(amount: int, p1: int) -> None:
    _iv(0x5B669CF2299A271F, amount, p1)

def NETWORK_SPENT_EMPLOY_ASSASSINS(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x5BBBD92186E1F1C5, p0, p1, p2, p3)

def NETWORK_SPENT_JUKEBOX(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x5BCDE0F640C773D2, p0, p1, p2, p3)

def NETWORK_EARN_COLLECTABLE_COMPLETED_COLLECTION(amount: int, p1: int) -> None:
    _iv(0x5C9B198AF5A54FA6, amount, p1)

def NETWORK_GET_VC_BALANCE() -> int:
    return _ii(0x5CBAD97E059E1B94)

def NETWORK_CAN_RECEIVE_PLAYER_CASH(p0: int, p1: int, p2: int, p3: int) -> bool:
    return _ib(0x5D17BE59D2123284, p0, p1, p2, p3)

def NETWORK_GET_EVC_BALANCE() -> int:
    return _ii(0x5D1E75F91C07DEE5)

def NETWORK_SPENT_BALLISTIC_EQUIPMENT(amount: int, p1: bool, p2: bool) -> None:
    _iv(0x5D97630A8A0EF123, amount, p1, p2)

def NETWORK_EARN_ARENA_WAR_ASSASSINATE_TARGET(amount: int) -> None:
    _iv(0x5E7AE8AABE8B7C0D, amount)

def NETWORK_SPEND_GANGOPS_TRIP_SKIP(amount: int, p1: bool, p2: bool) -> None:
    _iv(0x5ECE6FD7B4EC8D6A, amount, p1, p2)

def NETWORK_SPENT_CHANGE_APPEARANCE(p0: int, p1: int, p2: int) -> None:
    _iv(0x5F456788B05FAEAC, p0, p1, p2)

def NETWORK_PAY_EMPLOYEE_WAGE(p0: int, p1: bool, p2: bool) -> None:
    _iv(0x5FD5ED82CBBE9989, p0, p1, p2)

def NETWORK_EARN_FROM_BEND_JOB(amount: int, heistHash: str) -> None:
    _iv(0x61326EE6DF15B0CA, amount, heistHash)

def NETWORK_SPENT_UPGRADE_HANGAR(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x615EB504B0788DAF, p0, p1, p2, p3)

def NETWORK_SPEND_ARENA_PREMIUM(amount: int, p1: bool, p2: bool) -> None:
    _iv(0x619496D837EFD920, amount, p1, p2)

def NETWORK_SPEND_SUV_FST_TRVL(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0x61A2DF64ED2D396E, p0, p1, p2, p3)

def NETWORK_EARN_FIXER_PREP(p0: int, p1: int) -> None:
    _iv(0x6283E5DE4C4460C6, p0, p1)

def NETWORK_EARN_ARENA_WAR(amount: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x631F1CB8FB4130AA, amount, p1, p2, p3)

def NETWORK_BUY_PROPERTY(cost: int, propertyName: int, p2: bool, p3: bool) -> None:
    _iv(0x650A08A280870AF6, cost, propertyName, p2, p3)

def NETWORK_SPEND_NIGHTCLUB_AND_WAREHOUSE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x65482BFD0923C8A1, p0, p1, p2, p3)

def NETWORK_EARN_AGENCY_SAFE(p0: int, p1: int) -> None:
    _iv(0x663B4B9D11742A12, p0, p1)

def NETWORK_SPENT_UPGRADE_BUSINESS_PROPERTY(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x675D19C6067CAE08, p0, p1, p2, p3)

def NETWORK_EARN_SPIN_THE_WHEEL_CASH(amount: int) -> None:
    _iv(0x676C48776CACBB5A, amount)

def NETWORK_EARN_FROM_JOB_BONUS(p0: int, p1: int, p2: int) -> None:
    _iv(0x6816FB4416760775, p0, p1, p2)

def NETWORK_SPENT_PURCHASE_OFFICE_PROPERTY(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x69EF772B192614C1, p0, p1, p2, p3, p4)

def NETWORK_SPENT_FROM_ROCKSTAR(p0: int, p1: bool, p2: bool) -> None:
    _iv(0x6A445B64ED7ABEB5, p0, p1, p2)

def NETWORK_SPENT_CINEMA(p0: int, p1: int, p2: bool, p3: bool) -> None:
    _iv(0x6B38ECB05A63A685, p0, p1, p2, p3)

def NETWORK_EARN_FROM_SMUGGLER_WORK(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int) -> None:
    _iv(0x6B7E4FB50D5F3D65, p0, p1, p2, p3, p4, p5)

def NETWORK_SPEND_SUBMARINE(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int) -> None:
    _iv(0x6C8BC1488527AAAB, p0, p1, p2, p3, p4, p5)

def NETWORK_SPEND_UPGRADE_AGENCY(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x6CCA64840589A3B6, p0, p1, p2, p3)

def NETWORK_SPENT_BUY_PASSIVE_MODE(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0x6D3A430D1A809179, p0, p1, p2, p3)

def NETWORK_SPENT_BUY_REVEAL_PLAYERS(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0x6E176F1B18BC0637, p0, p1, p2, p3)

def NETWORK_EARN_FROM_DAILY_OBJECTIVES(amount: int, type: str, characterSlot: int) -> None:
    _iv(0x6EA318C91C1A8786, amount, type, characterSlot)

def WAS_VC_WITHDRAWAL_SUCCESSFUL(p0: int) -> bool:
    return _ib(0x6FCF8DDEA146C45B, p0)

def NETWORK_SPENT_PURCHASE_BUSINESS_PROPERTY(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x6FD97159FE3C971A, p0, p1, p2, p3)

def NETWORK_GET_STRING_BANK_WALLET_BALANCE(character: int) -> str:
    return _is(0x700AF71AE615E6DD, character)

def NETWORK_SPEND_ARENA_SPECTATOR_BOX(amount: int, type: int, p2: bool, p3: bool) -> None:
    _iv(0x7049BF858601DC0F, amount, type, p2, p3)

def NETWORK_EARN_FROM_CASHING_OUT(amount: int) -> None:
    _iv(0x718FBBF67414FA36, amount)

def NETWORK_EARN_BIKER(p0: int) -> None:
    _iv(0x71BEC32FA466E105, p0)

def NETWORK_EARN_CASINO_HEIST(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int) -> None:
    _iv(0x72E7C7B9615FA3C3, p0, p1, p2, p3, p4, p5, p6)

def NETWORK_CAN_SPEND_MONEY2(p0: int, p1: bool, p2: bool, p3: bool, p4: int, p5: int, p6: int) -> bool:
    return _ib(0x7303E27CC6532080, p0, p1, p2, p3, p4, p5, p6)

def NETWORK_EARN_AWARD_PHONE(p0: int, p1: int) -> None:
    _iv(0x7397A115030F1BE3, p0, p1)

def NETWORK_BUY_SMOKES(p0: int, p1: bool, p2: bool) -> None:
    _iv(0x75AF80E61248EEBD, p0, p1, p2)

def NETWORK_BUY_AIRSTRIKE(cost: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0x763B4BD305338F19, cost, p1, p2, p3)

def NETWORK_GET_VC_BANK_BALANCE() -> int:
    return _ii(0x76EF28DA05EA395A)

def NETWORK_SPEND_GANGOPS_CANNON(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x771ADB0E7635B7BF, p0, p1, p2, p3)

def _NETWORK_EARN_SELL_ACID(p0: int, p1: int) -> None:
    _iv(0x79B656937DF6DF5D, p0, p1)

def NETWORK_EARN_RDR_BONUS(amount: int, p1: int) -> None:
    _iv(0x7A5349B773584675, amount, p1)

def NETWORK_BUY_BOUNTY(amount: int, victim: int, p2: bool, p3: bool, p4: int) -> None:
    _iv(0x7B718E197453F2D9, amount, victim, p2, p3, p4)

def NETWORK_SPENT_HELI_PICKUP(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0x7BF1D73DB2ECA492, p0, p1, p2, p3)

def NETWORK_ECONOMY_HAS_FIXED_CRAZY_NUMBERS() -> bool:
    return _ib(0x7C4FCCD2E4DEB394)

def NETWORK_SPENT_PLAYER_HEALTHCARE(p0: int, p1: int, p2: bool, p3: bool) -> None:
    _iv(0x7C99101F7FCE2EE5, p0, p1, p2, p3)

def NETWORK_SPEND_SET_DISCOUNT(p0: bool) -> None:
    _iv(0x7E2F4E8F44CAF4E0, p0)

def NETWORK_SPENT_TELESCOPE(p0: int, p1: bool, p2: bool) -> None:
    _iv(0x7FE61782AD94CC09, p0, p1, p2)

def NETWORK_SPENT_ARREST_BAIL(p0: int, p1: bool, p2: bool) -> None:
    _iv(0x812F5488B1B2A299, p0, p1, p2)

def NETWORK_MONEY_CAN_BET(amount: int, p1: bool, p2: bool) -> bool:
    return _ib(0x81404F3DC124FE5B, amount, p1, p2)

def NETWORK_BUY_HELI_STRIKE(cost: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0x81AA4610E3FD3A69, cost, p1, p2, p3)

def NETWORK_SPENT_REQUEST_JOB(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0x8204DA7934DF3155, p0, p1, p2, p3)

def NETWORK_MANUAL_DELETE_CHARACTER(characterSlot: int) -> None:
    _iv(0x821418C727FCACD7, characterSlot)

def NETWORK_EARN_FROM_BETTING(amount: int, p1: str) -> None:
    _iv(0x827A5BA1A44ACA6D, amount, p1)

def NETWORK_EARN_CASINO_COLLECTABLE_COMPLETED_COLLECTION(amount: int) -> None:
    _iv(0x83AD64F53F4E9483, amount)

def _NETWORK_SPEND_RENAME_ACID_LAB(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x842B1C5AF61ACDE9, p0, p1, p2, p3)

def NETWORK_EARN_FROM_PROPERTY(amount: int, propertyName: int) -> None:
    _iv(0x849648349D77F5C5, amount, propertyName)

def NETWORK_EARN_FROM_DESTROYING_CONTRABAND(p0: int, p1: int, p2: int) -> None:
    _iv(0x84C0116D012E8FC2, p0, p1, p2)

def NETWORK_EARN_COLLECTABLE_ITEM(amount: int, p1: int) -> None:
    _iv(0x84FF63BD4966F33D, amount, p1)

def NETWORK_EARN_FROM_BUSINESS_PRODUCT(amount: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x8586789730B10CAF, amount, p1, p2, p3)

def NETWORK_SPEND_BUY_ARCADE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x870289A558348378, p0, p1, p2, p3)

def NETWORK_SPENT_NIGHTCLUB_ENTRY_FEE(player: int, amount: int, p1: int, p2: bool, p3: bool) -> None:
    _iv(0x876056684281655D, player, amount, p1, p2, p3)

def NETWORK_SPEND_CASINO_GENERIC(amount: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x88BF9B612B84D3C3, amount, p1, p2, p3, p4)

def NETWORK_EARN_AWARD_FIXER_MISSION(p0: int, p1: int) -> None:
    _iv(0x88D6C327D6C57C45, p0, p1)

def NETWORK_SPEND_UPGRADE_SUB(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x89049A84065CE68E, p0, p1, p2, p3)

def NETWORK_CASINO_CAN_BUY_CHIPS_PVC() -> bool:
    return _ib(0x8968D4D8C6C40C11)

def NETWORK_BUY_FAIRGROUND_RIDE(amount: int, p1: int, p2: bool, p3: bool, p4: int) -> None:
    _iv(0x8A7B3952DD64D2B5, amount, p1, p2, p3, p4)

def NETWORK_EARN_SELL_PRIZE_VEHICLE(amount: int, p1: int, p2: int) -> None:
    _iv(0x8BCB27A057DF7B7F, amount, p1, p2)

def _NETWORK_SPENT_AIR_FREIGHT(hangarCargoSourcingPrice: int, fromBank: bool, fromBankAndWallet: bool, cost: int, warehouseId: int, warehouseSlot: int) -> None:
    _iv(0x8C7E8D6F96C9E948, hangarCargoSourcingPrice, fromBank, fromBankAndWallet, cost, warehouseId, warehouseSlot)

def NETWORK_SPENT_UPGRADE_OFFICE_PROPERTY(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x8E243837643D9583, p0, p1, p2, p3, p4)

def NETWORK_SPEND_BUY_SUB(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x90CD7C6871FBF1B4, p0, p1, p2, p3)

def NETWORK_SPEND_BIKE_SHOP(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x923AEA8E78F8DF0B, p0, p1, p2, p3)

def NETWORK_EARN_FROM_SELL_BUNKER(amount: int, bunkerHash: int) -> None:
    _iv(0x9251B6ABF2D0A5B4, amount, bunkerHash)

def NETWORK_SPEND_CAR_CLUB_BAR(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0x925227803A0EAA1B, p0, p1, p2, p3)

def NETWORK_SPEND_BUSINESS_PROPERTY_FEES(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x92D1CFDA1227FF1C, p0, p1, p2, p3)

def NETWORK_PAY_MATCH_ENTRY_FEE(amount: int, matchId: str, p2: bool, p3: bool) -> None:
    _iv(0x9346E14F2AF74D46, amount, matchId, p2, p3)

def NETWORK_SPEND_INTERACTION_MENU_ABILITY(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x93AA4165CB67E925, p0, p1, p2, p3)

def NETWORK_SPENT_CARGO_SOURCING(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int) -> None:
    _iv(0x948705F6F9C50824, p0, p1, p2, p3, p4, p5)

def _NETWORK_SPENT_STEALTH_MODULE(amount: int, fromBank: bool, fromBankAndWallet: bool, p3: int) -> None:
    _iv(0x95CE79A6939C537A, amount, fromBank, fromBankAndWallet, p3)

def NETWORK_EARN_CASINO_AWARD(amount: int, hash: int) -> None:
    _iv(0x973A9781A34F8DEB, amount, hash)

def CAN_PAY_AMOUNT_TO_BOSS(p0: int, p1: int, amount: int, p3: int) -> bool:
    return _ib(0x9777734DAD16992F, p0, p1, amount, p3)

def _NETWORK_EARN_TAXI_JOB(p0: int, p1: int) -> None:
    _iv(0x991E1588FAD9019D, p0, p1)

def NETWORK_SPENT_ROBBED_BY_MUGGER(amount: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0x995A65F15F581359, amount, p1, p2, p3)

def NETWORK_SPENT_PURCHASE_CLUB_HOUSE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x998E18CEB44487FC, p0, p1, p2, p3)

def NETWORK_SPEND_SPIN_THE_WHEEL_PAYMENT(amount: int, p1: int, p2: bool) -> None:
    _iv(0x9A5BD1D0000B339C, amount, p1, p2)

def NETWORK_SPEND_EARNED_FROM_BANK_AND_WALLETS(amount: int) -> int:
    return _ii(0x9B5016A6433A68C5, amount)

def NETWORK_SPEND_AUTOSHOP_MODIFY(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x9BEA350D7C48061B, p0, p1, p2, p3, p4)

def _NETWORK_EARN_DAILY_STASH_HOUSE_PARTICIPATION(p0: int, p1: int) -> None:
    _iv(0x9C0C6BD0F94CE391, p0, p1)

def NETWORK_SPENT_REQUEST_HEIST(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0x9D26502BB97BFE62, p0, p1, p2, p3)

def NETWORK_EARN_HEIST_AWARD(p0: int, p1: int, p2: int) -> None:
    _iv(0x9D4FDBB035229669, p0, p1, p2)

def NETWORK_SPENT_PAY_VEHICLE_INSURANCE_PREMIUM(amount: int, vehicleModel: int, gamerHandle: int, notBankrupt: bool, hasTheMoney: bool) -> None:
    _iv(0x9FF28D88C766E3E8, amount, vehicleModel, gamerHandle, notBankrupt, hasTheMoney)

def NETWORK_EARN_FROM_GANGATTACK_PICKUP(amount: int) -> None:
    _iv(0xA03D4ACE0A3284CE, amount)

def NETWORK_SPEND_GANGOPS_START_STRAND(type: int, amount: int, p2: bool, p3: bool) -> None:
    _iv(0xA19EC0786E326E06, type, amount, p2, p3)

def _NETWORK_SPEND_BUY_MFGARAGE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xA2ED36DCF0FCA413, p0, p1, p2, p3)

def NETWORK_GET_CAN_SPEND_FROM_BANK(amount: int) -> bool:
    return _ib(0xA31FD6A0865B6D14, amount)

def NETWORK_BUY_BACKUP_GANG(p0: int, p1: int, p2: bool, p3: bool, npcProvider: int) -> None:
    _iv(0xA3EDDAA42411D3B9, p0, p1, p2, p3, npcProvider)

def NETWORK_GET_VC_WALLET_BALANCE(characterSlot: int) -> int:
    return _ii(0xA40F9C2623F6A8B5, characterSlot)

def NETWORK_EARN_BEACH_PARTY_LOST_FOUND(p0: int, p1: int, p2: int) -> None:
    _iv(0xA51338E0DCCD4065, p0, p1, p2)

def NETWORK_SPENT_TRADE_BUSINESS_PROPERTY(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xA51B086B0B2C0F7A, p0, p1, p2, p3)

def NETWORK_SPENT_BUY_OFFTHERADAR(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0xA628A745E2275C5D, p0, p1, p2, p3)

def NETWORK_SPENT_BULL_SHARK(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0xA6DD8458CE24012C, p0, p1, p2, p3)

def NETWORK_GET_STRING_BANK_BALANCE() -> str:
    return _is(0xA6FA3979BED01B81)

def NETWORK_SPENT_VEHICLE_EXPORT_MODS(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int, p7: int, p8: int, p9: int) -> None:
    _iv(0xA75CCF58A60A5FD1, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)

def NETWORK_EARN_FROM_CLUB_MANAGEMENT_PARTICIPATION(p0: int, p1: int) -> None:
    _iv(0xA75EAC69F59E96E7, p0, p1)

def _NETWORK_SPEND_UPGRADE_ACID_LAB_ARMOR(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0xA7D541C9ACD63133, p0, p1, p2, p3)

def _NETWORK_EARN_STREET_DEALER(p0: int, p1: int) -> None:
    _iv(0xA81017EE1324FDFE, p0, p1)

def NETWORK_EARN_ARENA_WAR_EVENT_CARGO(amount: int) -> None:
    _iv(0xA82959062361B259, amount)

def _NETWORK_EARN_AWARD_TAXI(p0: int, p1: int) -> None:
    _iv(0xA914768AD35CD3A5, p0, p1)

def NETWORK_EARN_GANGOPS_SETUP(amount: int, p1: str) -> None:
    _iv(0xA9160796D47A2CF8, amount, p1)

def NETWORK_CLEAR_CHARACTER_WALLET(characterSlot: int) -> None:
    _iv(0xA921DED15FDF28F5, characterSlot)

def NETWORK_EARN_COLLECTABLES(p0: int, p1: int, p2: int) -> None:
    _iv(0xA95CFB4E02390842, p0, p1, p2)

def NETWORK_SPENT_UPGRADE_WAREHOUSE_PROPERTY(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xA95F667A755725DA, p0, p1, p2, p3)

def NETWORK_EARN_GANGOPS_AWARD(amount: int, p1: str, p2: int) -> None:
    _iv(0xA9A31475F530DFDA, amount, p1, p2)

def NETWORK_CAN_SPEND_MONEY(p0: int, p1: bool, p2: bool, p3: bool, p4: int, p5: int) -> bool:
    return _ib(0xAB3CAA6B422164DA, p0, p1, p2, p3, p4, p5)

def NETWORK_SPENT_BUY_TRUCK(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xAC272C0AE01B4BD8, p0, p1, p2, p3)

def NETWORK_EARN_CASINO_STORY_MISSION_REWARD(amount: int) -> None:
    _iv(0xAC95ED552157E092, amount)

def NETWORK_SPENT_CALL_PLAYER(p0: int, p1: int, p2: bool, p3: bool) -> None:
    _iv(0xACDE7185B374177C, p0, p1, p2, p3)

def NETWORK_SPENT_AMMO_DROP(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0xB162DC95C0A3317B, p0, p1, p2, p3)

def NETWORK_SPENT_HANGAR_UTILITY_CHARGES(amount: int, p1: bool, p2: bool) -> None:
    _iv(0xB18AC2ECBB15CB6A, amount, p1, p2)

def NETWORK_EARN_FROM_CRATE_DROP(amount: int) -> None:
    _iv(0xB1CC1B9EC3007A2A, amount)

def NETWORK_SPENT_HANGAR_STAFF_CHARGES(amount: int, p1: bool, p2: bool) -> None:
    _iv(0xB1F1346FD57685D7, amount, p1, p2)

def NETWORK_SPENT_PROSTITUTES(p0: int, p1: bool, p2: bool) -> None:
    _iv(0xB21B89501CFAC79E, p0, p1, p2)

def NETWORK_EARN_FROM_JOB(amount: int, p1: str) -> None:
    _iv(0xB2CC4836834E8A98, amount, p1)

def _NETWORK_SPEND_BUY_SUPPLIES(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0xB48185C0CA67B16B, p0, p1, p2, p3)

def NETWORK_SPENT_PA_SERVICE_DANCER(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xB49ECA122467D05F, p0, p1, p2, p3)

def NETWORK_SPENT_PURCHASE_OFFICE_GARAGE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xB4C2EC463672474E, p0, p1, p2, p3)

def NETWORK_EARN_NIGHTCLUB_DANCING(p0: int) -> None:
    _iv(0xB4DEAE67F35E2ACD, p0)

def NETWORK_EARN_FROM_VEHICLE(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int, p7: int) -> None:
    _iv(0xB539BD8A4C1EECF8, p0, p1, p2, p3, p4, p5, p6, p7)

def NETWORK_SPEND_ARCADE_MGMT(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0xB5B58E24868CB09E, p0, p1, p2, p3, p4)

def NETWORK_EARN_TUNER_AWARD(p0: int, p1: int, p2: int) -> None:
    _iv(0xB846F547D3792DF6, p0, p1, p2)

def NETWORK_SPEND_SET_COMMON_FIELDS(p0: int, p1: int, p2: int, p3: bool) -> None:
    _iv(0xB9F7A469460E7A4A, p0, p1, p2, p3)

def NETWORK_EARN_FIXER_FINALE(p0: int, p1: int) -> None:
    _iv(0xBA154373C5FE51E8, p0, p1)

def NETWORK_EARN_CARCLUB_MEMBERSHIP(p0: int) -> None:
    _iv(0xBC6227792A188E2E, p0)

def NETWORK_EARN_TUNER_ROBBERY(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0xBCB266247193AC61, p0, p1, p2, p3, p4)

def NETWORK_SPENT_PURCHASE_WAREHOUSE_PROPERTY(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xBD0EFB25CCA8F97A, p0, p1, p2, p3)

def _NETWORK_EARN_AWARD_RANDOM_EVENT(p0: int, p1: int) -> None:
    _iv(0xBEAFBB1B98B7EF55, p0, p1)

def _NETWORK_EARN_GENERIC(amount: int, earn: int, p2: str, p3: str, data: int) -> None:
    _iv(0xBF7B5BB7ED890380, amount, earn, p2, p3, data)

def NETWORK_SPEND_HIDDEN(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xBF8793B91EA094A7, p0, p1, p2, p3)

def NETWORK_EARN_UPGRADE_AUTOSHOP(p0: int, p1: int) -> None:
    _iv(0xC10322A8D3E061EE, p0, p1)

def NETWORK_SPENT_IMPORT_EXPORT_REPAIR(p0: int, p1: int, p2: int) -> None:
    _iv(0xC1952F3773BA18FE, p0, p1, p2)

def _NETWORK_EARN_AWARD_DAILY_STASH(p0: int, p1: int) -> None:
    _iv(0xC30650FA74A19D02, p0, p1)

def _NETWORK_EARN_FOOLIGAN_JOB_PARTICIPATION(p0: int, p1: int) -> None:
    _iv(0xC376B92D0E060970, p0, p1)

def NETWORK_EARN_FROM_FMBB_PHONECALL_MISSION(p0: int) -> None:
    _iv(0xC5156361F26E2212, p0)

def NETWORK_EARN_AUTOSHOP_INCOME(p0: int, p1: int) -> None:
    _iv(0xC66D1CF99ED7FE25, p0, p1)

def NETWORK_EARN_NIGHTCLUB_AND_WAREHOUSE(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int) -> None:
    _iv(0xC6E74CF8C884C880, p0, p1, p2, p3, p4, p5, p6)

def NETWORK_EARN_FROM_PREMIUM_JOB(amount: int, p1: str) -> None:
    _iv(0xC8407624CEF2354B, amount, p1)

def NETWORK_SPEND_CASINO_CLUB(amount1: int, p1: int, p2: bool, p3: int, p4: int, p5: int, p6: int, amount2: int, p8: int) -> None:
    _iv(0xC991C255AA6D90B2, amount1, p1, p2, p3, p4, p5, p6, amount2, p8)

def NETWORK_SPENT_BANK_INTEREST(p0: int, p1: bool, p2: bool) -> None:
    _iv(0xCA230C9682556CF1, p0, p1, p2)

def _NETWORK_EARN_SELL_PARTICIPATION_ACID_LAB(p0: int, p1: int) -> None:
    _iv(0xCA3EF9B09A8D76B4, p0, p1)

def _NETWORK_EARN_DAILY_STASH_HOUSE_COMPLETED(p0: int, p1: int) -> None:
    _iv(0xCABC9874AFA70D6D, p0, p1)

def NETWORK_EARN_DAR_CHALLENGE(amount: int, p1: int) -> None:
    _iv(0xCAC672087B4A24AB, amount, p1)

def NETWORK_SPENT_PURCHASE_HANGAR(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xCCB339CC970452DA, p0, p1, p2, p3)

def NETWORK_DEFER_CASH_TRANSACTIONS_UNTIL_SHOP_SAVE() -> None:
    _iv(0xCD0F5B5D932AE473)

def NETWORK_SPENT_MOVE_SUBMARINE(p0: int, p1: int, p2: int) -> None:
    _iv(0xCD4D66B43B1DD28D, p0, p1, p2)

def NETWORK_EARN_GOON(p0: int, p1: int, p2: int) -> None:
    _iv(0xCDA1C62BE2777802, p0, p1, p2)

def _NETWORK_EARN_FOOLIGAN_JOB(p0: int, p1: int) -> None:
    _iv(0xCE4452AE85F5E252, p0, p1)

def _NETWORK_SPEND_UPGRADE_MFGARAGE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xCF8F346DDDC66643, p0, p1, p2, p3)

def _NETWORK_EARN_AWARD_DEAD_DROP(p0: int, p1: int) -> None:
    _iv(0xD01EBAEA1F905EF6, p0, p1)

def NETWORK_EARN_UPGRADE_AGENCY(p0: int, p1: int) -> None:
    _iv(0xD07C7C3F1995108C, p0, p1)

def _NETWORK_EARN_AWARD_ACID_LAB(p0: int, p1: int) -> None:
    _iv(0xD1A8165767AD2D23, p0, p1)

def NETWORK_SPEND_CAR_CLUB_TAKEOVER(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xD1E46824E6FB92B5, p0, p1, p2, p3)

def NETWORK_EARN_ISLAND_HEIST(amount1: int, p1: int, p2: int, p3: int, amount2: int, p5: int) -> None:
    _iv(0xD21D111C46BA9F15, amount1, p1, p2, p3, amount2, p5)

def NETWORK_EARN_ARCADE(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int) -> None:
    _iv(0xD29334ED1A256DBF, p0, p1, p2, p3, p4, p5)

def NETWORK_SPEND_CASINO_HEIST(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int, p7: int, p8: int, p9: int, p10: int) -> None:
    _iv(0xD30E8392F407C328, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)

def NETWORK_SPENT_NO_COPS(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0xD5BB406F4E04019F, p0, p1, p2, p3)

def _NETWORK_SPENT_MISSILE_JAMMER(amount: int, fromBank: bool, fromBankAndWallet: bool, p3: int) -> None:
    _iv(0xD687100F616163F4, amount, fromBank, fromBankAndWallet, p3)

def NETWORK_SPENT_MC_ABILITY(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0xD7CCCBA28C4ECAF0, p0, p1, p2, p3, p4)

def NETWORK_SPEND_COMP_SUV(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xD86581F9E7CDA383, p0, p1, p2, p3)

def NETWORK_SPENT_WAGER(p0: int, p1: int, amount: int) -> None:
    _iv(0xD99DB210089617FE, p0, p1, amount)

def NETWORK_BUY_HEALTHCARE(cost: int, p1: bool, p2: bool) -> None:
    _iv(0xD9B067E55253E3DD, cost, p1, p2)

def NETWORK_SPENT_HOLDUPS(p0: int, p1: bool, p2: bool) -> None:
    _iv(0xD9B86B9872039763, p0, p1, p2)

def NETWORK_SPEND_SOURCE_BIKE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xD9DF467CBE4398C8, p0, p1, p2, p3)

def NETWORK_SPEND_GANGOPS_SKIP_MISSION(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xDA947AE8880D5C18, p0, p1, p2, p3)

def NETWORK_SPEND_BOSS(p0: int, p1: int, p2: int) -> None:
    _iv(0xDBC966A01C02BCA7, p0, p1, p2)

def NETWORK_GET_CAN_SPEND_FROM_BANK_AND_WALLET(amount: int, characterSlot: int) -> bool:
    return _ib(0xDC18531D7019A535, amount, characterSlot)

def _NETWORK_EARN_BONUS_OBJECTIVE(amount: int, p1: int, p2: int) -> None:
    _iv(0xDCEF983C24191997, amount, p1, p2)

def NETWORK_SPEND_NIGHTCLUB_BAR_DRINK(amount: int, p1: int, p2: bool, p3: bool) -> None:
    _iv(0xDD21B016E4289465, amount, p1, p2, p3)

def NETWORK_SPEND_UPGRADE_AUTOSHOP(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xDD829AA198FDC46C, p0, p1, p2, p3)

def _NETWORK_EARN_AWARD_JUGGALO_MISSION(p0: int, p1: int) -> None:
    _iv(0xDDF047577F1A02A7, p0, p1)

def NETWORK_EARN_YATCH_MISSION(amount: int, p1: int) -> None:
    _iv(0xDE68E30D89F97132, amount, p1)

def _NETWORK_EARN_SMUGGLER_OPS(p0: int, p1: int, p2: int) -> None:
    _iv(0xDEA273D5F8A9661A, p0, p1, p2)

def NETWORK_EARN_FROM_JOBX2(amount: int, p1: str) -> None:
    _iv(0xDEBBF584665411D0, amount, p1)

def NETWORK_EARN_SMUGGLER_AGENCY(amount: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xDEE612F2D71B0308, amount, p1, p2, p3)

def NETWORK_EARN_RC_TIME_TRIAL(amount: int) -> None:
    _iv(0xDFF49EE984E7AAE8, amount)

def _NETWORK_EARN_JUGGALO_STORY_MISSION(p0: int, p1: int) -> None:
    _iv(0xE01D10BA8CD53621, p0, p1)

def _NETWORK_CLEAR_TRANSACTION_TELEMETRY_NONCE() -> None:
    _iv(0xE03B9F95556E48E9)

def NETWORK_EARN_ARENA_SKILL_LEVEL_PROGRESSION(amount: int, p1: int) -> None:
    _iv(0xE08256F972C7BB2C, amount, p1)

def NETWORK_EARN_NIGHTCLUB(p0: int, p1: int) -> None:
    _iv(0xE0F82D68C7039158, p0, p1)

def HAS_VC_WITHDRAWAL_COMPLETED(p0: int) -> bool:
    return _ib(0xE154B48B68EF72BC, p0)

def NETWORK_SPENT_BUY_WANTEDLEVEL(p0: int, p1: int, p2: bool, p3: bool, p4: int) -> None:
    _iv(0xE1B13771A843C4F6, p0, p1, p2, p3, p4)

def NETWORK_SPENT_PA_SERVICE_IMPOUND(p0: int, p1: int, p2: int) -> None:
    _iv(0xE23ADC6FCB1F29AE, p0, p1, p2)

def DEPOSIT_VC(amount: int) -> bool:
    return _ib(0xE260E0BB9CD995AC, amount)

def NETWORK_SPENT_RDR_HATCHET_BONUS(amount: int, p1: bool, p2: bool) -> None:
    _iv(0xE284D46FFDB82E36, amount, p1, p2)

def NETWORK_EARN_AGENCY_PHONE(p0: int, p1: int, p2: int) -> None:
    _iv(0xE29F3D5FA63B1B82, p0, p1, p2)

def NETWORK_EARN_FROM_ISLAND_HEIST_DJ_MISSION(p0: int, p1: int) -> None:
    _iv(0xE2BB399D90942091, p0, p1)

def NETWORK_EARN_DISPATCH_CALL(amount: int, p1: int) -> None:
    _iv(0xE2E244AB823B4483, amount, p1)

def _NETWORK_EARN_SETUP_PARTICIPATION_ACID_LAB(p0: int, p1: int) -> None:
    _iv(0xE3942D59E8A7F70D, p0, p1)

def NETWORK_SPENT_HIRE_MUGGER(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0xE404BFB981665BF0, p0, p1, p2, p3)

def NETWORK_SPEND_MAKE_IT_RAIN(amount: int, p1: bool, p2: bool) -> None:
    _iv(0xE5F5A060439C2F5D, amount, p1, p2)

def NETWORK_SPENT_HIRE_MERCENARY(p0: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0xE7B80E2BF9D80BD6, p0, p1, p2, p3)

def NETWORK_SPENT_MOVE_YACHT(amount: int, p1: bool, p2: bool) -> None:
    _iv(0xE7DF4E0545DFB56E, amount, p1, p2)

def NETWORK_SPEND_ISLAND_HEIST(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xE86689E5F82DE429, p0, p1, p2, p3)

def NETWORK_EARN_HACKER_TRUCK(p0: int, amount: int, p2: int, p3: int) -> None:
    _iv(0xE8815FE993896AD3, p0, amount, p2, p3)

def NETWORK_SPENT_ORDER_BODYGUARD_VEHICLE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xE8B0B270B6E7C76E, p0, p1, p2, p3)

def NETWORK_GET_REMAINING_TRANSFER_BALANCE() -> int:
    return _ii(0xEA560AC9EEB1E19B)

def NETWORK_SPEND_BUY_AGENCY(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xEA8CD3C9B3C35884, p0, p1, p2, p3)

def NETWORK_SPEND_PLAY_ARCADE(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0xEAD3D81F2C3A1458, p0, p1, p2, p3, p4)

def NETWORK_SPEND_SUPPLY(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xEBD482B82ACB8BAD, p0, p1, p2, p3)

def NETWORK_SPENT_CARWASH(p0: int, p1: int, p2: int, p3: bool, p4: bool) -> None:
    _iv(0xEC03C719DB2F4306, p0, p1, p2, p3, p4)

def NETWORK_EARN_FROM_CONTRABAND(amount: int, p1: int) -> None:
    _iv(0xECA658CE2A4E5A72, amount, p1)

def NETWORK_EARN_FROM_PICKUP(amount: int) -> None:
    _iv(0xED1517D3AF17C698, amount)

def _NETWORK_SPENT_SKIP_CARGO_SOURCE_SETUP(amount: int, fromBank: bool, fromBankAndWallet: bool, cost: int) -> None:
    _iv(0xED1B407BADA42CEC, amount, fromBank, fromBankAndWallet, cost)

def NETWORK_EARN_GANGOPS_PREP_PARTICIPATION(amount: int) -> None:
    _iv(0xED26584F6BDCBBFD, amount)

def NETWORK_CASINO_SELL_CHIPS(p0: int, p1: int) -> bool:
    return _ib(0xED44897CB336F480, p0, p1)

def NETWORK_GET_CAN_SPEND_FROM_WALLET(amount: int, characterSlot: int) -> bool:
    return _ib(0xED5AB8860415BABA, amount, characterSlot)

def NETWORK_SPENT_PA_SERVICE_VEHICLE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xED5FD7AF10F5E262, p0, p1, p2, p3)

def NETWORK_SPENT_PURCHASE_NIGHTCLUB_AND_WAREHOUSE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xED76D195E6E3BF7F, p0, p1, p2, p3)

def NETWORK_EARN_FROM_VEHICLE_EXPORT(amount: int, p1: int, p2: int) -> None:
    _iv(0xEDEAD9A91EC768B3, amount, p1, p2)

def NETWORK_SPENT_IN_STRIPCLUB(p0: int, p1: bool, p2: int, p3: bool) -> None:
    _iv(0xEE99784E4467689C, p0, p1, p2, p3)

def NETWORK_SPEND_BUY_AUTOSHOP(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xEEB7E5D1FEB20869, p0, p1, p2, p3)

def NETWORK_BUY_ITEM(amount: int, item: int, p2: int, p3: int, p4: bool, item_name: str, p6: int, p7: int, p8: int, p9: bool) -> None:
    _iv(0xF0077C797F66A355, amount, item, p2, p3, p4, item_name, p6, p7, p8, p9)

def _NETWORK_SPEND_BUY_ACID_LAB(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xF1E26A7924327152, p0, p1, p2, p3)

def NETWORK_EARN_FIXER_AGENCY_SHORT_TRIP(p0: int, p1: int) -> None:
    _iv(0xF4A8E57460BF2037, p0, p1)

def NETWORK_EARN_FROM_ROB_ARMORED_CARS(amount: int) -> None:
    _iv(0xF514621E8EA463D0, amount)

def NETWORK_CASINO_CAN_BET_AMOUNT(p0: int) -> bool:
    return _ib(0xF62F6D9528358FE4, p0)

def NETWORK_EARN_BOUNTY_HUNTER_REWARD(p0: int) -> None:
    _iv(0xF6B170F9A02E9E87, p0)

def NETWORK_SPENT_REHIRE_DJ(amount: int, p1: int, p2: bool, p3: bool) -> None:
    _iv(0xF6C8A544E4CF14FC, amount, p1, p2, p3)

def WITHDRAW_VC(amount: int) -> int:
    return _ii(0xF70EFA14FE091429, amount)

def _NETWORK_EARN_PROGRESS_HUB(p0: int, p1: int) -> None:
    _iv(0xF8332B06F0EECC9C, p0, p1)

def NETWORK_EARN_FROM_IMPORT_EXPORT(amount: int, modelHash: int) -> None:
    _iv(0xF92A014A634442D6, amount, modelHash)

def NETWORK_GET_STRING_WALLET_BALANCE(characterSlot: int) -> str:
    return _is(0xF9B10B529DCFB33B, characterSlot)

def NETWORK_REFUND_CASH(index: int, context: str, reason: str, p3: bool) -> None:
    _iv(0xF9C812CD7C46E817, index, context, reason, p3)

def NETWORK_EARN_FROM_CRIMINAL_MASTERMIND(p0: int, p1: int, p2: int) -> None:
    _iv(0xFA009A62990671D4, p0, p1, p2)

def NETWORK_SPENT_UPGRADE_CLUB_HOUSE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xFA07759E6FDDD7CF, p0, p1, p2, p3)

def NETWORK_EARN_ASSASSINATE_TARGET_KILLED(amount: int) -> None:
    _iv(0xFA700D8A9905F78A, amount)

def NETWORK_GIVE_PLAYER_JOBSHARE_CASH(amount: int, gamerHandle: int) -> None:
    _iv(0xFB18DF9CB95E0105, amount, gamerHandle)

def NETWORK_GET_PLAYER_IS_HIGH_EARNER() -> bool:
    return _ib(0xFB2456B2040A6A67)

def NETWORK_EARN_FROM_AMBIENT_JOB(p0: int, p1: str, p2: int) -> None:
    _iv(0xFB6DB092FBAE29E6, p0, p1, p2)

def NETWORK_SPEND_CASINO_MEMBERSHIP(amount: int, p1: bool, p2: bool, p3: int) -> None:
    _iv(0xFBBE0570EDF39D46, amount, p1, p2, p3)

def NETWORK_SPENT_RENAME_ORGANIZATION(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xFC4EE00A7B3BFB76, p0, p1, p2, p3)

def NETWORK_EARN_BB_EVENT_BONUS(amount: int) -> None:
    _iv(0xFDD8D2440DAF1590, amount)

def NETWORK_EARN_DAILY_VEHICLE_BONUS(p0: int) -> None:
    _iv(0xFE65AFE7308E32B2, p0)

def NETWORK_SPENT_BOSS_GOON(amount: int, p1: bool, p2: bool) -> bool:
    return _ib(0xFFBE02CD385356BD, amount, p1, p2)

def NETWORK_EARN_FMBB_WAGE_BONUS(p0: int) -> None:
    _iv(0xFFFBA1B1F7C0B6F4, p0)
