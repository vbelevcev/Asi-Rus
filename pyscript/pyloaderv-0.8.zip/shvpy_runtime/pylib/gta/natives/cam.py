"""Auto-generated raw native bindings for namespace CAM.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_vector3 as _ivec


def IS_GAMEPLAY_CAM_SHAKING() -> bool:
    return _ib(0x016C090630DF1F89)

def SET_GAMEPLAY_CAM_MAX_MOTION_BLUR_STRENGTH_THIS_UPDATE(p0: float) -> None:
    _iv(0x0225778816FDC28C, p0)

def SET_CAM_ACTIVE(cam: int, active: bool) -> None:
    _iv(0x026FB97D0A425F84, cam, active)

def IS_CAM_SPLINE_PAUSED(cam: int) -> bool:
    return _ib(0x0290F35C0AD97864, cam)

def IS_CAM_RENDERING(cam: int) -> bool:
    return _ib(0x02EC0AF5C5A49B7A, cam)

def IS_CAM_INTERPOLATING(cam: int) -> bool:
    return _ib(0x036F97C908C2B52C, cam)

def GET_CAM_DOF_STRENGTH(cam: int) -> float:
    return _if(0x06D153C0B99B6128, cam)

def RENDER_SCRIPT_CAMS(render: bool, ease: bool, easeTime: int, p3: bool, p4: bool, p5: int) -> None:
    _iv(0x07E5B515DB0636FC, render, ease, easeTime, p3, p4, p5)

def ADD_CAM_SPLINE_NODE_USING_CAMERA_FRAME(cam: int, cam2: int, length: int, p3: int) -> None:
    _iv(0x0A9F2A468B328E74, cam, cam2, length, p3)

def FORCE_VEHICLE_CAM_STUNT_SETTINGS_THIS_UPDATE() -> None:
    _iv(0x0AA27680A0BD43FA)

def SET_FIRST_PERSON_AIM_CAM_NEAR_CLIP_THIS_UPDATE(p0: float) -> None:
    _iv(0x0AF7B437918103B3, p0)

def STOP_GAMEPLAY_CAM_SHAKING(p0: bool) -> None:
    _iv(0x0EF93E9F3D08C178, p0)

def ADD_CAM_SPLINE_NODE_USING_CAMERA(cam: int, cam2: int, length: int, p3: int) -> None:
    _iv(0x0FB82563989CF4FB, cam, cam2, length, p3)

def SET_FIRST_PERSON_SHOOTER_CAMERA_HEADING(yaw: float) -> None:
    _iv(0x103991D4A307D472, yaw)

def SET_FIRST_PERSON_FLASH_EFFECT_VEHICLE_MODEL_HASH(vehicleModel: int) -> None:
    _iv(0x11FA5D3479C7DD47, vehicleModel)

def SET_CUTSCENE_CAM_FAR_CLIP_THIS_UPDATE(p0: float) -> None:
    _iv(0x12DED8CA53D47EA5, p0)

def SET_CAM_SPLINE_DURATION(cam: int, timeDuration: int) -> None:
    _iv(0x1381539FEE034CDA, cam, timeDuration)

def HARD_ATTACH_CAM_TO_PED_BONE(cam: int, ped: int, boneIndex: int, p3: float, p4: float, p5: float, p6: float, p7: float, p8: float, p9: bool) -> None:
    _iv(0x149916F50C34A40D, cam, ped, boneIndex, p3, p4, p5, p6, p7, p8, p9)

def GET_GAMEPLAY_CAM_COORD() -> 'gta.Vector3':
    return _ivec(0x14D6F5678D8F1B37)

def GET_FINAL_RENDERED_CAM_MOTION_BLUR_STRENGTH() -> float:
    return _if(0x162F9D995753DC19)

def SET_CAM_USE_SHALLOW_DOF_MODE(cam: int, toggle: bool) -> None:
    _iv(0x16A96863A17552BB, cam, toggle)

def DISABLE_CINEMATIC_SLOW_MO_THIS_UPDATE() -> bool:
    return _ib(0x17FCA7199A530203)

def SET_GAMEPLAY_ENTITY_HINT(entity: int, xOffset: float, yOffset: float, zOffset: float, p4: bool, time: int, easeInTime: int, easeOutTime: int, p8: int) -> None:
    _iv(0x189E955A8313E298, entity, xOffset, yOffset, zOffset, p4, time, easeInTime, easeOutTime, p8)

def SET_FOLLOW_VEHICLE_CAM_ZOOM_LEVEL(zoomLevel: int) -> None:
    _iv(0x19464CB6E4078C8A, zoomLevel)

def GET_CAM_ACTIVE_VIEW_MODE_CONTEXT() -> int:
    return _ii(0x19CAFA3C87F7C2FF)

def DISABLE_AIM_CAM_THIS_UPDATE() -> None:
    _iv(0x1A31FE0049E542F6)

def SET_CAM_DEBUG_NAME(camera: int, name: str) -> None:
    _iv(0x1B93E0107865DD40, camera, name)

def STOP_SCRIPT_GLOBAL_SHAKING(p0: bool) -> None:
    _iv(0x1C9D7949FA533490, p0)

def IS_IN_VEHICLE_MOBILE_PHONE_CAMERA_RENDERING() -> bool:
    return _ib(0x1F2300CB7FA7B7F6)

def HARD_ATTACH_CAM_TO_ENTITY(cam: int, entity: int, xRot: float, yRot: float, zRot: float, xOffset: float, yOffset: float, zOffset: float, isRelative: bool) -> None:
    _iv(0x202A5ED9CE01D6E7, cam, entity, xRot, yRot, zRot, xOffset, yOffset, zOffset, isRelative)

def SET_FIRST_PERSON_FLASH_EFFECT_VEHICLE_MODEL_NAME(vehicleName: str) -> None:
    _iv(0x21E253A7F8DA5DFB, vehicleName)

def STOP_CINEMATIC_CAM_SHAKING(p0: bool) -> None:
    _iv(0x2238E588E588A6D7, p0)

def SET_CAM_SPLINE_PHASE(cam: int, p1: float) -> None:
    _iv(0x242B5874F0A4E052, cam, p1)

def STOP_CODE_GAMEPLAY_HINT(p0: bool) -> None:
    _iv(0x247ACBC4ABBC9D1C, p0)

def GET_CAM_FAR_DOF(cam: int) -> float:
    return _if(0x255F8DAFD540D397, cam)

def GET_FINAL_RENDERED_REMOTE_PLAYER_CAM_ROT(player: int, rotationOrder: int) -> 'gta.Vector3':
    return _ivec(0x26903D9CD1175F2C, player, rotationOrder)

def ALLOW_MOTION_BLUR_DECAY(p0: int, p1: bool) -> None:
    _iv(0x271017B9BA825366, p0, p1)

def USE_SCRIPT_CAM_FOR_AMBIENT_POPULATION_ORIGIN_THIS_FRAME(p0: bool, p1: bool) -> None:
    _iv(0x271401846BD26E92, p0, p1)

def FORCE_BONNET_CAMERA_RELATIVE_HEADING_AND_PITCH(p0: float, p1: float) -> None:
    _iv(0x28B022A17B068A3A, p0, p1)

def SET_CAM_VIEW_MODE_FOR_CONTEXT(context: int, viewMode: int) -> None:
    _iv(0x2A2173E46DAECD12, context, viewMode)

def SET_GAMEPLAY_CAM_IGNORE_ENTITY_COLLISION_THIS_UPDATE(entity: int) -> None:
    _iv(0x2AED6301F67007D5, entity)

def SET_GAMEPLAY_PED_HINT(ped: int, x1: float, y1: float, z1: float, p4: bool, duration: int, blendOutDuration: int, blendInDuration: int) -> None:
    _iv(0x2B486269ACD548D3, ped, x1, y1, z1, p4, duration, blendOutDuration, blendInDuration)

def SET_CAM_DOF_MAX_NEAR_IN_FOCUS_DISTANCE_BLEND_LEVEL(camera: int, p1: float) -> None:
    _iv(0x2C654B4943BDDF7C, camera, p1)

def SET_FIRST_PERSON_AIM_CAM_RELATIVE_HEADING_LIMITS_THIS_UPDATE(p0: float, p1: float) -> None:
    _iv(0x2F7F2B26DD3F18EE, p0, p1)

def IS_INTERPOLATING_FROM_SCRIPT_CAMS() -> bool:
    return _ib(0x3044240D2E0FA842)

def STOP_CUTSCENE_CAM_SHAKING(p0: int) -> None:
    _iv(0x324C5AA411DA7737, p0)

def GET_FOLLOW_PED_CAM_ZOOM_LEVEL() -> int:
    return _ii(0x33E6C8EFD0CD93E9)

def _ACTIVATE_CAM_WITH_INTERP_AND_FOV_CURVE(camTo: int, camFrom: int, duration: int, easeLocation: int, easeRotation: int, easeFov: int) -> None:
    _iv(0x34CFC4C2A38E83E3, camTo, camFrom, duration, easeLocation, easeRotation, easeFov)

def FORCE_TIGHTSPACE_CUSTOM_FRAMING_THIS_UPDATE() -> None:
    _iv(0x380B4968D1E09E55)

def IS_GAMEPLAY_CAM_RENDERING() -> bool:
    return _ib(0x39B5D1B10383F0C8)

def GET_GAMEPLAY_CAM_RELATIVE_PITCH() -> float:
    return _if(0x3A6867B4845BEDA2)

def SET_CAM_DOF_PLANES(cam: int, p1: float, p2: float, p3: float, p4: float) -> None:
    _iv(0x3CF48F6F96E749DC, cam, p1, p2, p3, p4)

def SET_CAM_NEAR_DOF(cam: int, nearDOF: float) -> None:
    _iv(0x3FA4BF0A7AB7DE2C, cam, nearDOF)

def SET_ALLOW_CUSTOM_VEHICLE_DRIVE_BY_CAM_THIS_UPDATE(p0: bool) -> None:
    _iv(0x4008EDF7D6E48175, p0)

def OVERRIDE_CAM_SPLINE_VELOCITY(cam: int, p1: int, p2: float, p3: float) -> None:
    _iv(0x40B62FA033EB0346, cam, p1, p2, p3)

def SET_CAM_ANIM_CURRENT_PHASE(cam: int, phase: float) -> None:
    _iv(0x4145A4C44FF3B5A6, cam, phase)

def SET_THIRD_PERSON_AIM_CAM_NEAR_CLIP_THIS_UPDATE(p0: float) -> None:
    _iv(0x42156508606DE65E, p0)

def USE_DEDICATED_STUNT_CAMERA_THIS_UPDATE(camName: str) -> None:
    _iv(0x425A920FDB9A0DDA, camName)

def SET_FOLLOW_PED_CAM_THIS_UPDATE(camName: str, p1: int) -> bool:
    return _ib(0x44A113DD6FFC48D1, camName, p1)

def SET_CAM_INHERIT_ROLL_VEHICLE(cam: int, p1: bool) -> None:
    _iv(0x45F1DE9C34B93AE6, cam, p1)

def SET_SCRIPTED_CAMERA_IS_FIRST_PERSON_THIS_FRAME(p0: bool) -> None:
    _iv(0x469F2ECDEC046337, p0)

def SET_CAM_DOF_FOCAL_LENGTH_MULTIPLIER(camera: int, multiplier: float) -> None:
    _iv(0x47B595D60664CFFA, camera, multiplier)

def FORCE_CAMERA_RELATIVE_HEADING_AND_PITCH(roll: float, pitch: float, yaw: float) -> None:
    _iv(0x48608C3464F58AB4, roll, pitch, yaw)

def ARE_WIDESCREEN_BORDERS_ACTIVE() -> bool:
    return _ib(0x4879E4FE39074CDF)

def SET_GAMEPLAY_CAM_MOTION_BLUR_SCALING_THIS_UPDATE(p0: float) -> None:
    _iv(0x487A82C650EB7799, p0)

def DISABLE_CAM_COLLISION_FOR_OBJECT(entity: int) -> None:
    _iv(0x49482F9FCD825AAA, entity)

def SET_CAM_COORD(cam: int, posX: float, posY: float, posZ: float) -> None:
    _iv(0x4D41783FB745E42E, cam, posX, posY, posZ)

def IS_CINEMATIC_FIRST_PERSON_VEHICLE_INTERIOR_CAM_RENDERING() -> bool:
    return _ib(0x4F32C0D5A90A9B40)

def SET_FLY_CAM_HORIZONTAL_RESPONSE(cam: int, p1: float, p2: float, p3: float) -> None:
    _iv(0x503F5920162365B2, cam, p1, p2, p3)

def SET_GAMEPLAY_HINT_FOV(FOV: float) -> None:
    _iv(0x513403FB9C56211F, FOV)

def SET_CINEMATIC_BUTTON_ACTIVE(p0: bool) -> None:
    _iv(0x51669F7D1FB53D9F, p0)

def GET_RENDERING_CAM() -> int:
    return _ii(0x5234F9F10919EABA)

def POINT_CAM_AT_ENTITY(cam: int, entity: int, p2: float, p3: float, p4: float, p5: bool) -> None:
    _iv(0x5640BFF86B16E8DC, cam, entity, p2, p3, p4, p5)

def DISABLE_FIRST_PERSON_FLASH_EFFECT_THIS_UPDATE() -> None:
    _iv(0x59424BD75174C9B1)

def DISABLE_NEAR_CLIP_SCAN_THIS_UPDATE() -> None:
    _iv(0x5A43C76F7FC7BA5F)

def SET_FOLLOW_PED_CAM_VIEW_MODE(viewMode: int) -> None:
    _iv(0x5A4F9EDF1673F704, viewMode)

def IS_SCREEN_FADED_IN() -> bool:
    return _ib(0x5A859503B0C08678)

def GET_FINAL_RENDERED_CAM_ROT(rotationOrder: int) -> 'gta.Vector3':
    return _ivec(0x5B4E4C817FCC2DFB, rotationOrder)

def SET_FIRST_PERSON_FLASH_EFFECT_TYPE(p0: int) -> None:
    _iv(0x5C41E6BABC9E2112, p0)

def WAS_FLY_CAM_CONSTRAINED_ON_PREVIOUS_UDPATE(cam: int) -> bool:
    return _ib(0x5C48A1D6E3B33179, cam)

def IS_SCREEN_FADING_IN() -> bool:
    return _ib(0x5C544BC6C57AC575)

def SET_FOLLOW_VEHICLE_CAM_SEAT_THIS_UPDATE(seatIndex: int) -> None:
    _iv(0x5C90CAB09951A12F, seatIndex)

def SET_GAMEPLAY_HINT_CAMERA_RELATIVE_SIDE_OFFSET(xOffset: float) -> None:
    _iv(0x5D7B620DAE436138, xOffset)

def TRIGGER_VEHICLE_PART_BROKEN_CAMERA_SHAKE(vehicle: int, p1: int, p2: float) -> None:
    _iv(0x5D96CFB59DA076A0, vehicle, p1, p2)

def IS_FIRST_PERSON_AIM_CAM_ACTIVE() -> bool:
    return _ib(0x5E346D934122613F)

def CREATE_CAMERA(camHash: int, p1: bool) -> int:
    return _ii(0x5E3CF89C6BCCA67D, camHash, p1)

def SET_CAM_DOF_STRENGTH(cam: int, dofStrength: float) -> None:
    _iv(0x5EE29B4D7D5DF897, cam, dofStrength)

def GET_FINAL_RENDERED_REMOTE_PLAYER_CAM_FOV(player: int) -> float:
    return _if(0x5F35F6732C3FBBA0, player)

def ADD_CAM_SPLINE_NODE_USING_GAMEPLAY_FRAME(cam: int, length: int, p2: int) -> None:
    _iv(0x609278246A29CA34, cam, length, p2)

def ATTACH_CAM_TO_PED_BONE(cam: int, ped: int, boneIndex: int, x: float, y: float, z: float, heading: bool) -> None:
    _iv(0x61A3DBA14AB7F411, cam, ped, boneIndex, x, y, z, heading)

def CAMERA_PREVENT_COLLISION_SETTINGS_FOR_TRIPLEHEAD_IN_INTERIORS_THIS_UPDATE() -> None:
    _iv(0x62374889A4D59F72)

def DISABLE_CINEMATIC_VEHICLE_IDLE_MODE_THIS_UPDATE() -> None:
    _iv(0x62ECFCFDEE7885D6)

def USE_VEHICLE_CAM_STUNT_SETTINGS_THIS_UPDATE() -> None:
    _iv(0x6493CF69859B116A)

def GET_GAMEPLAY_CAM_FOV() -> float:
    return _if(0x65019750A0324133)

def SET_CAM_CONTROLS_MINI_MAP_HEADING(cam: int, toggle: bool) -> None:
    _iv(0x661B5C8654ADD825, cam, toggle)

def POINT_CAM_AT_PED_BONE(cam: int, ped: int, boneIndex: int, x: float, y: float, z: float, p6: bool) -> None:
    _iv(0x68B2B5F33BA63C41, cam, ped, boneIndex, x, y, z, p6)

def IS_AIM_CAM_ACTIVE() -> bool:
    return _ib(0x68EDDA28A5976D07)

def SHAKE_CAM(cam: int, type: str, amplitude: float) -> None:
    _iv(0x6A25241C340D3822, cam, type, amplitude)

def CREATE_CAMERA_WITH_PARAMS(camHash: int, posX: float, posY: float, posZ: float, rotX: float, rotY: float, rotZ: float, fov: float, p8: bool, p9: int) -> int:
    return _ii(0x6ABFA3E16460F22D, camHash, posX, posY, posZ, rotX, rotY, rotZ, fov, p8, p9)

def IS_CAM_SHAKING(cam: int) -> bool:
    return _ib(0x6B24BFE83A2BE47B, cam)

def SET_GAMEPLAY_CAM_RELATIVE_PITCH(angle: float, scalingFactor: float) -> None:
    _iv(0x6D0858B8EDFD2B7D, angle, scalingFactor)

def SET_CAM_MOTION_BLUR_STRENGTH(cam: int, strength: float) -> None:
    _iv(0x6F0F77FBA9A8F2E6, cam, strength)

def IS_INTERPOLATING_TO_SCRIPT_CAMS() -> bool:
    return _ib(0x705A276EBFF3133D)

def SET_FIRST_PERSON_AIM_CAM_ZOOM_FACTOR(zoomFactor: float) -> None:
    _iv(0x70894BD0915C5BCA, zoomFactor)

def IS_GAMEPLAY_CAM_LOOKING_BEHIND() -> bool:
    return _ib(0x70FDA869F3317EA9)

def RESET_GAMEPLAY_CAM_FULL_ATTACH_PARENT_TRANSFORM_TIMER() -> None:
    _iv(0x7295C203DD659DFE)

def SET_USE_HI_DOF_ON_SYNCED_SCENE_THIS_UPDATE() -> None:
    _iv(0x731A880555DA3647)

def CREATE_CINEMATIC_SHOT(p0: int, time: int, p2: bool, entity: int) -> None:
    _iv(0x741B0129D4560F31, p0, time, p2, entity)

def GET_GAMEPLAY_CAM_RELATIVE_HEADING() -> float:
    return _if(0x743607648ADD4587)

def IS_AIM_CAM_ACTIVE_IN_ACCURATE_MODE() -> bool:
    return _ib(0x74BD83EA840F6BC9)

def SET_FIRST_PERSON_SHOOTER_CAMERA_PITCH(pitch: float) -> None:
    _iv(0x759E13EBC1C15C5A, pitch)

def STOP_CINEMATIC_SHOT(p0: int) -> None:
    _iv(0x7660C6E75D3A078E, p0)

def GET_DEBUG_CAM() -> int:
    return _ii(0x77C3CEC46BE286F6)

def IS_SCREEN_FADING_OUT() -> bool:
    return _ib(0x797AC7CB535BA28F)

def SET_TABLE_GAMES_CAMERA_THIS_UPDATE(hash: int) -> bool:
    return _ib(0x79C0E43EB9B944E2, hash)

def IGNORE_MENU_PREFERENCE_FOR_BONNET_CAMERA_THIS_UPDATE() -> None:
    _iv(0x7B8A361C1813FBEF)

def SET_CAM_SPLINE_NODE_EXTRA_FLAGS(cam: int, p1: int, flags: int) -> None:
    _iv(0x7BF1A54AE67AC070, cam, p1, flags)

def SET_CAM_DOF_SHOULD_KEEP_LOOK_AT_TARGET_IN_FOCUS(camera: int, state: bool) -> None:
    _iv(0x7CF3AF51DCFE4108, camera, state)

def GET_CAM_ROT(cam: int, rotationOrder: int) -> 'gta.Vector3':
    return _ivec(0x7D304C1C955E3E12, cam, rotationOrder)

def OVERRIDE_CAM_SPLINE_MOTION_BLUR(cam: int, p1: int, p2: float, p3: float) -> None:
    _iv(0x7DCF7C708D292D55, cam, p1, p2, p3)

def SET_CAM_DOF_FNUMBER_OF_LENS(camera: int, p1: float) -> None:
    _iv(0x7DD234D6F3914C5B, camera, p1)

def GET_FIRST_PERSON_AIM_CAM_ZOOM_FACTOR() -> float:
    return _if(0x7EC52CC40597D170)

def SET_CAM_DEATH_FAIL_EFFECT_STATE(p0: int) -> None:
    _iv(0x80C8B1846639BB19, p0)

def GET_FINAL_RENDERED_CAM_FOV() -> float:
    return _if(0x80EC114669DAEFF4)

def GET_GAMEPLAY_CAM_ROT(rotationOrder: int) -> 'gta.Vector3':
    return _ivec(0x837765A25378F0BB, rotationOrder)

def SET_CAM_SPLINE_NODE_EASE(cam: int, easingFunction: int, p2: int, p3: float) -> None:
    _iv(0x83B8201ED82A9A2D, cam, easingFunction, p2, p3)

def SET_GAMEPLAY_OBJECT_HINT(object: int, xOffset: float, yOffset: float, zOffset: float, p4: bool, time: int, easeInTime: int, easeOutTime: int) -> None:
    _iv(0x83E87508A2CA2AC6, object, xOffset, yOffset, zOffset, p4, time, easeInTime, easeOutTime)

def SET_CAM_ROT(cam: int, rotX: float, rotY: float, rotZ: float, rotationOrder: int) -> None:
    _iv(0x85973643155D0B07, cam, rotX, rotY, rotZ, rotationOrder)

def ADD_CAM_SPLINE_NODE(camera: int, x: float, y: float, z: float, xRot: float, yRot: float, zRot: float, length: int, smoothingStyle: int, rotationOrder: int) -> None:
    _iv(0x8609C75EC438FB3B, camera, x, y, z, xRot, yRot, zRot, length, smoothingStyle, rotationOrder)

def DESTROY_CAM(cam: int, bScriptHostCam: bool) -> None:
    _iv(0x865908C81A2C22E9, cam, bScriptHostCam)

def DO_SCREEN_FADE_OUT(duration: int) -> None:
    _iv(0x891B5B39AC6302AF, duration)

def GET_FOCUS_PED_ON_SCREEN(p0: float, p1: int, p2: float, p3: float, p4: float, p5: float, p6: float, p7: int, p8: int) -> int:
    return _ii(0x89215EC747DF244A, p0, p1, p2, p3, p4, p5, p6, p7, p8)

def SET_GAMEPLAY_CAM_FOLLOW_PED_THIS_UPDATE(ped: int) -> None:
    _iv(0x8BBACBF51DA047A8, ped)

def REPLAY_GET_MAX_DISTANCE_ALLOWED_FROM_PLAYER() -> float:
    return _if(0x8BFCEB5EA1B161B6)

def SET_CAM_AFFECTS_AIMING(cam: int, toggle: bool) -> None:
    _iv(0x8C1DC7770C51DC8D, cam, toggle)

def GET_FOLLOW_PED_CAM_VIEW_MODE() -> int:
    return _ii(0x8D4D46230B2C353A)

def ATTACH_CAM_TO_VEHICLE_BONE(cam: int, vehicle: int, boneIndex: int, relativeRotation: bool, rotX: float, rotY: float, rotZ: float, offsetX: float, offsetY: float, offsetZ: float, fixedDirection: bool) -> None:
    _iv(0x8DB3F12A02CAEF72, cam, vehicle, boneIndex, relativeRotation, rotX, rotY, rotZ, offsetX, offsetY, offsetZ, fixedDirection)

def DESTROY_ALL_CAMS(bScriptHostCam: bool) -> None:
    _iv(0x8E5FB15663F79120, bScriptHostCam)

def SET_THIRD_PERSON_CAM_RELATIVE_HEADING_LIMITS_THIS_UPDATE(minimum: float, maximum: float) -> None:
    _iv(0x8F993D26E0CA5E8E, minimum, maximum)

def SET_FOLLOW_VEHICLE_CAM_HIGH_ANGLE_MODE_THIS_UPDATE(p0: bool) -> None:
    _iv(0x91EF6EE6419E5B97, p0)

def GET_FINAL_RENDERED_CAM_FAR_DOF() -> float:
    return _if(0x9780F32BCAF72431)

def PLAY_CAM_ANIM(cam: int, animName: str, animDictionary: str, x: float, y: float, z: float, xRot: float, yRot: float, zRot: float, p9: bool, p10: int) -> bool:
    return _ib(0x9A2D0FB2E7852392, cam, animName, animDictionary, x, y, z, xRot, yRot, zRot, p9, p10)

def SET_FOLLOW_VEHICLE_CAM_HIGH_ANGLE_MODE_EVERY_UPDATE(p0: bool, p1: bool) -> None:
    _iv(0x9DFE13ECDC1EC196, p0, p1)

def INVALIDATE_CINEMATIC_VEHICLE_IDLE_MODE() -> None:
    _iv(0x9E4CFFF989258472)

def BLOCK_FIRST_PERSON_ORIENTATION_RESET_THIS_UPDATE() -> None:
    _iv(0x9F97DA93681F87EA)

def SET_CAM_ACTIVE_WITH_INTERP(camTo: int, camFrom: int, duration: int, easeLocation: int, easeRotation: int) -> None:
    _iv(0x9FBDA379383A52A4, camTo, camFrom, duration, easeLocation, easeRotation)

def GET_FINAL_RENDERED_CAM_NEAR_DOF() -> float:
    return _if(0xA03502FC581F7D9B)

def GET_CAM_ANIM_CURRENT_PHASE(cam: int) -> float:
    return _if(0xA10B2DB49E92A6B0, cam)

def SET_USE_HI_DOF() -> None:
    _iv(0xA13B0222F3D94A94)

def GET_FINAL_RENDERED_CAM_COORD() -> 'gta.Vector3':
    return _ivec(0xA200EB1EE790F448)

def SET_GAMEPLAY_VEHICLE_HINT(vehicle: int, offsetX: float, offsetY: float, offsetZ: float, p4: bool, time: int, easeInTime: int, easeOutTime: int) -> None:
    _iv(0xA2297E18F3E71C2E, vehicle, offsetX, offsetY, offsetZ, p4, time, easeInTime, easeOutTime)

def ANIMATED_SHAKE_CAM(cam: int, p1: str, p2: str, p3: str, amplitude: float) -> None:
    _iv(0xA2746EEAE3E577CD, cam, p1, p2, p3, amplitude)

def SET_CAM_IS_INSIDE_VEHICLE(cam: int, toggle: bool) -> None:
    _iv(0xA2767257A320FC82, cam, toggle)

def DETACH_CAM(cam: int) -> None:
    _iv(0xA2FABBE87F4BAD82, cam)

def FORCE_CINEMATIC_RENDERING_THIS_UPDATE(toggle: bool) -> None:
    _iv(0xA41BCD7213805AAC, toggle)

def GET_FOLLOW_VEHICLE_CAM_VIEW_MODE() -> int:
    return _ii(0xA4FF579AC0E3AAAE)

def SET_THIRD_PERSON_CAM_RELATIVE_PITCH_LIMITS_THIS_UPDATE(minimum: float, maximum: float) -> None:
    _iv(0xA516C198B7DCA1E1, minimum, maximum)

def SET_CAM_SPLINE_NODE_VELOCITY_SCALE(cam: int, p1: int, scale: float) -> None:
    _iv(0xA6385DEB180F319F, cam, p1, scale)

def BYPASS_CAMERA_COLLISION_BUOYANCY_TEST_THIS_UPDATE() -> None:
    _iv(0xA7092AFE81944852)

def DOES_CAM_EXIST(cam: int) -> bool:
    return _ib(0xA7A932170592B50E, cam)

def SET_GAMEPLAY_CAM_SHAKE_AMPLITUDE(amplitude: float) -> None:
    _iv(0xA87E00932DB4D85D, amplitude)

def FORCE_CAM_FAR_CLIP(cam: int, p1: float) -> None:
    _iv(0xAABD62873FFB1A33, cam, p1)

def SET_FOLLOW_VEHICLE_CAM_VIEW_MODE(viewMode: int) -> None:
    _iv(0xAC253D7842768F48, viewMode)

def DISABLE_CINEMATIC_BONNET_CAMERA_THIS_UPDATE() -> None:
    _iv(0xADFF1B2A555F5FBA)

def SET_CAM_FAR_CLIP(cam: int, farClip: float) -> None:
    _iv(0xAE306F2A904BF86E, cam, farClip)

def DISABLE_FIRST_PERSON_CAMERA_WATER_CLIPPING_TEST_THIS_UPDATE() -> None:
    _iv(0xB1381B97F70C7B30)

def SET_CAM_FOV(cam: int, fieldOfView: float) -> None:
    _iv(0xB13C14F66A00D047, cam, fieldOfView)

def IS_CINEMATIC_CAM_RENDERING() -> bool:
    return _ib(0xB15162CB5826E9E8)

def IS_SCREEN_FADED_OUT() -> bool:
    return _ib(0xB16FCE9DDC7BA182)

def GET_CAM_SPLINE_NODE_INDEX(cam: int) -> int:
    return _ii(0xB22B17DF858716A6, cam)

def SET_GAMEPLAY_CAM_RELATIVE_HEADING(heading: float) -> None:
    _iv(0xB4EC2312F4E5B1F1, heading)

def CREATE_CAM_WITH_PARAMS(camName: str, posX: float, posY: float, posZ: float, rotX: float, rotY: float, rotZ: float, fov: float, p8: bool, p9: int) -> int:
    return _ii(0xB51194800B257161, camName, posX, posY, posZ, rotX, rotY, rotZ, fov, p8, p9)

def GET_CAM_SPLINE_PHASE(cam: int) -> float:
    return _if(0xB5349E36C546509A, cam)

def GET_CAM_FAR_CLIP(cam: int) -> float:
    return _if(0xB60A9CFEB21CA6AA, cam)

def GET_CAM_COORD(cam: int) -> 'gta.Vector3':
    return _ivec(0xBAC038F7459AE5AE, cam)

def IS_CINEMATIC_CAM_SHAKING() -> bool:
    return _ib(0xBBC08F6B4CB8FF0A)

def _GET_THIRD_PERSON_CAM_MIN_ORBIT_DISTANCE_SPRING() -> float:
    return _if(0xBC456FB703431785)

def SET_FIRST_PERSON_AIM_CAM_RELATIVE_PITCH_LIMITS_THIS_UPDATE(p0: float, p1: float) -> None:
    _iv(0xBCFC632DB7673BF0, p0, p1)

def STOP_CAM_SHAKING(cam: int, p1: bool) -> None:
    _iv(0xBDECF64367884AC3, cam, p1)

def IS_CODE_GAMEPLAY_HINT_ACTIVE() -> bool:
    return _ib(0xBF72910D0F26F025)

def SET_CAM_PARAMS(cam: int, posX: float, posY: float, posZ: float, rotX: float, rotY: float, rotZ: float, fieldOfView: float, p8: int, p9: int, p10: int, p11: int) -> None:
    _iv(0xBFD8727AEA3CCEBA, cam, posX, posY, posZ, rotX, rotY, rotZ, fieldOfView, p8, p9, p10, p11)

def GET_CAM_NEAR_DOF(cam: int) -> float:
    return _if(0xC2612D223D915A1C, cam)

def ANIMATED_SHAKE_SCRIPT_GLOBAL(p0: str, p1: str, p2: str, p3: float) -> None:
    _iv(0xC2EAE3FB8CDBED31, p0, p1, p2, p3)

def GET_CAM_FOV(cam: int) -> float:
    return _if(0xC3330A45CCCDB26A, cam)

def SET_CAM_DOF_MAX_NEAR_IN_FOCUS_DISTANCE(camera: int, p1: float) -> None:
    _iv(0xC3654A441402562D, camera, p1)

def CREATE_CAM(camName: str, p1: bool) -> int:
    return _ii(0xC3981DCE61D9E13F, camName, p1)

def GET_CAM_NEAR_CLIP(cam: int) -> float:
    return _if(0xC520A34DAFBF24B1, cam)

def SET_CAM_DOF_FOCUS_DISTANCE_BIAS(camera: int, p1: float) -> None:
    _iv(0xC669EEA5D031B7DE, camera, p1)

def IS_FOLLOW_PED_CAM_ACTIVE() -> bool:
    return _ib(0xC6D3D26810C8E0F9)

def SET_CINEMATIC_CAM_SHAKE_AMPLITUDE(p0: float) -> None:
    _iv(0xC724C701C30B2FE7, p0)

def SET_CAM_NEAR_CLIP(cam: int, nearClip: float) -> None:
    _iv(0xC7848EFCCC545182, cam, nearClip)

def STOP_RENDERING_SCRIPT_CAMS_USING_CATCH_UP(render: bool, p1: float, p2: int, p3: int) -> None:
    _iv(0xC819F3CBB62BF692, render, p1, p2, p3)

def SET_FOLLOW_PED_CAM_LADDER_ALIGN_THIS_UPDATE() -> None:
    _iv(0xC8391C309684595A)

def SET_FLY_CAM_VERTICAL_CONTROLS_THIS_UPDATE(cam: int) -> None:
    _iv(0xC8B5C4A79CC18B94, cam)

def IS_CAM_PLAYING_ANIM(cam: int, animName: str, animDictionary: str) -> bool:
    return _ib(0xC90621D8A0CEECF2, cam, animName, animDictionary)

def IS_SCRIPT_GLOBAL_SHAKING() -> bool:
    return _ib(0xC912AF078AF19212)

def SET_FLY_CAM_COORD_AND_CONSTRAIN(cam: int, x: float, y: float, z: float) -> None:
    _iv(0xC91C6C55199308CA, cam, x, y, z)

def SET_GAMEPLAY_HINT_CAMERA_RELATIVE_VERTICAL_OFFSET(yOffset: float) -> None:
    _iv(0xC92717EF615B6704, yOffset)

def IS_CINEMATIC_IDLE_CAM_RENDERING() -> bool:
    return _ib(0xCA9D2AA3E326D720)

def IS_FOLLOW_VEHICLE_CAM_ACTIVE() -> bool:
    return _ib(0xCBBDE6D335D6D496)

def IS_CINEMATIC_SHOT_ACTIVE(p0: int) -> bool:
    return _ib(0xCC9F3371A7C28BC9, p0)

def STOP_GAMEPLAY_HINT_BEING_CANCELLED_THIS_UPDATE(p0: bool) -> None:
    _iv(0xCCD078C2665D2973, p0)

def SET_FIRST_PERSON_AIM_CAM_ZOOM_FACTOR_LIMITS_THIS_UPDATE(p0: float, p1: float) -> None:
    _iv(0xCED08CBE8EBB97C7, p0, p1)

def GET_FINAL_RENDERED_CAM_NEAR_CLIP() -> float:
    return _if(0xD0082607100D7193)

def SET_CAM_SPLINE_SMOOTHING_STYLE(cam: int, smoothingStyle: int) -> None:
    _iv(0xD1B0F412F109EA5D, cam, smoothingStyle)

def SET_GAMEPLAY_HINT_BASE_ORBIT_PITCH_OFFSET(value: float) -> None:
    _iv(0xD1F8363DFAD03848, value)

def _GET_THIRD_PERSON_CAM_MAX_ORBIT_DISTANCE_SPRING() -> float:
    return _if(0xD4592A16D36673ED)

def DO_SCREEN_FADE_IN(duration: int) -> None:
    _iv(0xD4E8E24955024033, duration)

def SET_GAMEPLAY_COORD_HINT(x: float, y: float, z: float, duration: int, blendOutDuration: int, blendInDuration: int, p6: int) -> None:
    _iv(0xD51ADCD2D8BC0FB3, x, y, z, duration, blendOutDuration, blendInDuration, p6)

def IS_BONNET_CINEMATIC_CAM_RENDERING() -> bool:
    return _ib(0xD7360051C885628B)

def SET_CAM_SHAKE_AMPLITUDE(cam: int, amplitude: float) -> None:
    _iv(0xD93DB43B82BC0D00, cam, amplitude)

def GET_CAM_SPLINE_NODE_PHASE(cam: int) -> float:
    return _if(0xD9D0E694C8282C96, cam)

def BYPASS_CUTSCENE_CAM_RENDERING_THIS_UPDATE() -> None:
    _iv(0xDB629FFD9285FA06)

def SET_GAMEPLAY_CAM_ALTITUDE_FOV_SCALING_STATE(p0: bool) -> None:
    _iv(0xDB90C6CCA48940F1, p0)

def SET_CINEMATIC_NEWS_CHANNEL_ACTIVE_THIS_UPDATE() -> None:
    _iv(0xDC9DA9E8789F5246)

def SET_WIDESCREEN_BORDERS(p0: bool, p1: int) -> None:
    _iv(0xDCD4EA924F42D01A, p0, p1)

def SHAKE_CINEMATIC_CAM(shakeType: str, amount: float) -> None:
    _iv(0xDCE214D9ED58F3CF, shakeType, amount)

def SET_CINEMATIC_MODE_ACTIVE(toggle: bool) -> None:
    _iv(0xDCF0754AC3D6FD4E, toggle)

def SET_FOLLOW_CAM_IGNORE_ATTACH_PARENT_MOVEMENT_THIS_UPDATE() -> None:
    _iv(0xDD79DF9F4D26E1C9)

def _INTERPOLATE_CAM_WITH_PARAMS(camera: int, camPosX: float, camPosY: float, camPosZ: float, camRotX: float, camRotY: float, camRotZ: float, fov: float, duration: int, posCurveType: int, rotCurveType: int, rotOrder: int, fovCurveType: int) -> None:
    _iv(0xDDA77EE33C005AAF, camera, camPosX, camPosY, camPosZ, camRotX, camRotY, camRotZ, fov, duration, posCurveType, rotCurveType, rotOrder, fovCurveType)

def DISABLE_ON_FOOT_FIRST_PERSON_VIEW_THIS_UPDATE() -> None:
    _iv(0xDE2EF5DA284CC8DF)

def SET_THIRD_PERSON_CAM_ORBIT_DISTANCE_LIMITS_THIS_UPDATE(p0: float, distance: float) -> None:
    _iv(0xDF2E1F7742402E81, p0, distance)

def IS_CAM_ACTIVE(cam: int) -> bool:
    return _ib(0xDFB2B516207D3534, cam)

def GET_FINAL_RENDERED_CAM_FAR_CLIP() -> float:
    return _if(0xDFC8CBC606FDB0FC)

def SET_CAM_DOF_OVERRIDDEN_FOCUS_DISTANCE_BLEND_LEVEL(p0: int, p1: float) -> None:
    _iv(0xE111A7C0D200CBC5, p0, p1)

def PLAY_SYNCHRONIZED_CAM_ANIM(p0: int, p1: int, animName: str, animDictionary: str) -> bool:
    return _ib(0xE32EFE9AB4A9AA0C, p0, p1, animName, animDictionary)

def IS_SPHERE_VISIBLE(x: float, y: float, z: float, radius: float) -> bool:
    return _ib(0xE33D59DA70B58FDF, x, y, z, radius)

def SET_GAMEPLAY_HINT_CAMERA_BLEND_TO_FOLLOW_PED_MEDIUM_VIEW_MODE(toggle: bool) -> None:
    _iv(0xE3433EADAAF7EE40, toggle)

def IS_GAMEPLAY_HINT_ACTIVE() -> bool:
    return _ib(0xE520FF1AD2785B40)

def SET_FLY_CAM_VERTICAL_RESPONSE(cam: int, p1: float, p2: float, p3: float) -> None:
    _iv(0xE827B9382CFB41BA, cam, p1, p2, p3)

def SET_IN_VEHICLE_CAM_STATE_THIS_UPDATE(p0: int, p1: int) -> None:
    _iv(0xE9EA16D6E54CDCA4, p0, p1)

def DISABLE_GAMEPLAY_CAM_ALTITUDE_FOV_SCALING_THIS_UPDATE() -> None:
    _iv(0xEA7F0AD7E9BA676F)

def IS_ALLOWED_INDEPENDENT_CAMERA_MODES() -> bool:
    return _ib(0xEAF0FA793D05C592)

def SET_CAM_FAR_DOF(cam: int, farDOF: float) -> None:
    _iv(0xEDD91296CD01AEE0, cam, farDOF)

def GET_CAM_VIEW_MODE_FOR_CONTEXT(context: int) -> int:
    return _ii(0xEE778F8C7E1142E2, context)

def GET_FOLLOW_VEHICLE_CAM_ZOOM_LEVEL() -> int:
    return _ii(0xEE82280AB767B690)

def STOP_CAM_POINTING(cam: int) -> None:
    _iv(0xF33AB75780BA57DE, cam)

def STOP_GAMEPLAY_HINT(p0: bool) -> None:
    _iv(0xF46C581C61718916, p0)

def SHAKE_SCRIPT_GLOBAL(p0: str, p1: float) -> None:
    _iv(0xF4C8CF9E353AFECA, p0, p1)

def INVALIDATE_IDLE_CAM() -> None:
    _iv(0xF4F2C0D4EE209E20)

def SET_CAM_DOF_OVERRIDDEN_FOCUS_DISTANCE(camera: int, p1: float) -> None:
    _iv(0xF55E4046F6F831DC, camera, p1)

def IS_CINEMATIC_CAM_INPUT_ACTIVE() -> bool:
    return _ib(0xF5F1E89A970B7796)

def POINT_CAM_AT_COORD(cam: int, x: float, y: float, z: float) -> None:
    _iv(0xF75497BB865F0803, cam, x, y, z)

def SET_GAMEPLAY_HINT_FOLLOW_DISTANCE_SCALAR(value: float) -> None:
    _iv(0xF8BDBF3D573049A1, value)

def SET_FLY_CAM_MAX_HEIGHT(cam: int, height: float) -> None:
    _iv(0xF9D02130ECDD1D77, cam, height)

def SET_GAMEPLAY_CAM_ENTITY_TO_LIMIT_FOCUS_OVER_BOUNDING_SPHERE_THIS_UPDATE(entity: int) -> None:
    _iv(0xFD3151CD37EA2245, entity)

def SHAKE_GAMEPLAY_CAM(shakeName: str, intensity: float) -> None:
    _iv(0xFD55E49555E017CF, shakeName, intensity)

def ATTACH_CAM_TO_ENTITY(cam: int, entity: int, xOffset: float, yOffset: float, zOffset: float, isRelative: bool) -> None:
    _iv(0xFEDB7D269E8C60E3, cam, entity, xOffset, yOffset, zOffset, isRelative)
