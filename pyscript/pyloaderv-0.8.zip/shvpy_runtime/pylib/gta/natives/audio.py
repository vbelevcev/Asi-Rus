"""Auto-generated raw native bindings for namespace AUDIO.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_str as _is


def START_AUDIO_SCENE(scene: str) -> bool:
    return _ib(0x013A80FC08F6E4F2, scene)

def UNREQUEST_TENNIS_BANKS() -> None:
    _iv(0x0150B6FF25A9E2E5)

def SET_VEHICLE_AUDIO_BODY_DAMAGE_FACTOR(vehicle: int, intensity: float) -> None:
    _iv(0x01BB4D577D38BD9E, vehicle, intensity)

def IS_AMBIENT_ZONE_ENABLED(ambientZone: str) -> bool:
    return _ib(0x01E2817A479A7F9B, ambientZone)

def GET_VEHICLE_DEFAULT_HORN(vehicle: int) -> int:
    return _ii(0x02165D55000219AC, vehicle)

def PREPARE_SYNCHRONIZED_AUDIO_EVENT_FOR_SCENE(sceneID: int, audioEvent: str) -> bool:
    return _ib(0x029FE7CD1B7E2E75, sceneID, audioEvent)

def SET_RADIO_POSITION_AUDIO_MUTE(p0: bool) -> None:
    _iv(0x02E93C796ABD3A97, p0)

def UNLOCK_RADIO_STATION_TRACK_LIST(radioStation: str, trackListName: str) -> None:
    _iv(0x031ACB6ABA18C729, radioStation, trackListName)

def CAN_VEHICLE_RECEIVE_CB_RADIO(vehicle: int) -> bool:
    return _ib(0x032A116663A4D5AC, vehicle)

def SET_VEHICLE_HORN_SOUND_INDEX(vehicle: int, value: int) -> None:
    _iv(0x0350E7E17BA767D0, vehicle, value)

def START_ALARM(alarmName: str, p2: bool) -> None:
    _iv(0x0355EF116C4C97B2, alarmName, p2)

def SET_PORTAL_SETTINGS_OVERRIDE(p0: str, p1: str) -> None:
    _iv(0x044DBAD7A7FA2BE5, p0, p1)

def IS_PED_IN_CURRENT_CONVERSATION(ped: int) -> bool:
    return _ib(0x049E937F18F4020C, ped)

def IS_RADIO_FADED_OUT() -> bool:
    return _ib(0x0626A247D2405330)

def FORCE_PED_PANIC_WALLA() -> None:
    _iv(0x062D5EAD4DA2FA6A)

def SET_PED_FOOTSTEPS_EVENTS_ENABLED(ped: int, toggle: bool) -> None:
    _iv(0x0653B735BFBDFE87, ped, toggle)

def SET_SCRIPT_UPDATE_DOOR_AUDIO(doorHash: int, toggle: bool) -> None:
    _iv(0x06C0023BED16DD6B, doorHash, toggle)

def SET_CONVERSATION_AUDIO_CONTROLLED_BY_ANIM(p0: bool) -> None:
    _iv(0x0B568201DD99F0EB, p0)

def SET_PED_VOICE_GROUP_FROM_RACE_TO_PVG(ped: int, voiceGroupHash: int) -> None:
    _iv(0x0BABC1345ABBFB16, ped, voiceGroupHash)

def IS_VEHICLE_RADIO_ON(vehicle: int) -> bool:
    return _ib(0x0BE4BE946463F917, vehicle)

def RELEASE_MISSION_AUDIO_BANK() -> None:
    _iv(0x0EC92A1BF0857187)

def DOES_PLAYER_VEH_HAVE_RADIO() -> bool:
    return _ib(0x109697E2FFBAC8A1)

def SET_MOBILE_RADIO_ENABLED_DURING_GAMEPLAY(toggle: bool) -> None:
    _iv(0x1098355A16064BB3, toggle)

def UNHINT_NAMED_SCRIPT_AUDIO_BANK(audioBank: str) -> None:
    _iv(0x11579D940949C49E, audioBank)

def CLEAR_AMBIENT_ZONE_LIST_STATE(ambientZone: str, p1: bool) -> None:
    _iv(0x120C48C614909FA4, ambientZone, p1)

def SET_AUDIO_SPECIAL_EFFECT_MODE(mode: int) -> None:
    _iv(0x12561FCBB62D5B9C, mode)

def OVERRIDE_TREVOR_RAGE(voiceEffect: str) -> None:
    _iv(0x13AD665062541A7E, voiceEffect)

def SET_PED_WALLA_DENSITY(p0: float, p1: float) -> None:
    _iv(0x149AEE66F0CB3A99, p0, p1)

def ADD_ENTITY_TO_AUDIO_MIX_GROUP(entity: int, groupName: str, p2: float) -> None:
    _iv(0x153973AB99FE8980, entity, groupName, p2)

def SET_GLOBAL_RADIO_SIGNAL_LEVEL(p0: int) -> None:
    _iv(0x159B7318403A1CD8, p0)

def CLEAR_CUSTOM_RADIO_TRACK_LIST(radioStation: str) -> None:
    _iv(0x1654F24A88A8E3FE, radioStation)

def IS_SCRIPTED_CONVERSATION_ONGOING() -> bool:
    return _ib(0x16754C556D2EDE3D)

def REMOVE_ENTITY_FROM_AUDIO_MIX_GROUP(entity: int, p1: float) -> None:
    _iv(0x18EB48CFC41F2EA0, entity, p1)

def IS_MISSION_COMPLETE_PLAYING() -> bool:
    return _ib(0x19A30C23F5827F8A)

def UNHINT_AMBIENT_AUDIO_BANK() -> None:
    _iv(0x19AF7ED9B9D23058)

def SET_USER_RADIO_CONTROL_ENABLED(toggle: bool) -> None:
    _iv(0x19F21E63AE6EAE4E, toggle)

def SET_PED_RACE_AND_VOICE_GROUP(ped: int, p1: int, voiceGroup: int) -> None:
    _iv(0x1B7ABE26CBCBF8C7, ped, p1, voiceGroup)

def BLIP_SIREN(vehicle: int) -> None:
    _iv(0x1B9025BDA76822B6, vehicle)

def SET_VEH_RADIO_STATION(vehicle: int, radioStation: str) -> None:
    _iv(0x1B9C0099CB942AC6, vehicle, radioStation)

def ENABLE_VEHICLE_FANBELT_DAMAGE(vehicle: int, toggle: bool) -> None:
    _iv(0x1C073274E065C6D2, vehicle, toggle)

def SET_AMBIENT_ZONE_STATE_PERSISTENT(ambientZone: str, p1: bool, p2: bool) -> None:
    _iv(0x1D6650420CEC9D3B, ambientZone, p1, p2)

def PREPARE_MUSIC_EVENT(eventName: str) -> bool:
    return _ib(0x1E5185B72EF5158A, eventName)

def IS_PED_RINGTONE_PLAYING(ped: int) -> bool:
    return _ib(0x1E8E5E20937E3137, ped)

def LOAD_STREAM(streamName: str, soundSet: str) -> bool:
    return _ib(0x1F1F957154EC51DF, streamName, soundSet)

def SET_SIREN_WITH_NO_DRIVER(vehicle: int, toggle: bool) -> None:
    _iv(0x1FEF0683B96EBCF2, vehicle, toggle)

def PLAY_STREAM_FROM_POSITION(x: float, y: float, z: float) -> None:
    _iv(0x21442F412E8DE56B, x, y, z)

def CLEAR_AMBIENT_ZONE_STATE(zoneName: str, p1: bool) -> None:
    _iv(0x218DD44AAAC964FF, zoneName, p1)

def IS_ALARM_PLAYING(alarmName: str) -> bool:
    return _ib(0x226435CB96CCFC8C, alarmName)

def START_PRELOADED_CONVERSATION() -> None:
    _iv(0x23641AFE870AF385)

def START_SCRIPT_PHONE_CONVERSATION(p0: bool, p1: bool) -> None:
    _iv(0x252E5F915EABB675, p0, p1)

def SET_PED_CLOTH_EVENTS_ENABLED(ped: int, toggle: bool) -> None:
    _iv(0x29DA3CA8D8B2692D, ped, toggle)

def UNBLOCK_SPEECH_CONTEXT_GROUP(p0: str) -> None:
    _iv(0x2ACABED337622DF2, p0)

def IS_RADIO_STATION_FAVOURITED(radioStation: str) -> bool:
    return _ib(0x2B1784DB08AFEA79, radioStation)

def ENABLE_VEHICLE_EXHAUST_POPS(vehicle: int, toggle: bool) -> None:
    _iv(0x2BE4BC731D039D5A, vehicle, toggle)

def SET_RADIO_FRONTEND_FADE_TIME(fadeTime: float) -> None:
    _iv(0x2C96CDB04FCA358E, fadeTime)

def SET_RADIO_TRACK_WITH_START_OFFSET(radioStationName: str, mixName: str, p2: int) -> None:
    _iv(0x2CB0075110BE1E56, radioStationName, mixName, p2)

def AUDIO_IS_SCRIPTED_MUSIC_PLAYING() -> bool:
    return _ib(0x2DD39BF3E2F9C47F)

def GET_NETWORK_ID_FROM_SOUND_ID(soundId: int) -> int:
    return _ii(0x2DE3F0A134FFBC0D, soundId)

def STOP_ALL_ALARMS(stop: bool) -> None:
    _iv(0x2F794A877ADD4C92, stop)

def REQUEST_SCRIPT_AUDIO_BANK(audioBank: str, p1: bool, p2: int) -> bool:
    return _ib(0x2F844A8B08D76685, audioBank, p1, p2)

def SET_VARIABLE_ON_STREAM(variable: str, p1: float) -> None:
    _iv(0x2F9D3834AEB9EF79, variable, p1)

def IS_ANY_POSITIONAL_SPEECH_PLAYING() -> bool:
    return _ib(0x30CA2EF91D15ADF8)

def SET_POSITION_FOR_NULL_CONV_PED(p0: int, p1: float, p2: float, p3: float) -> None:
    _iv(0x33E3C6C6F2F0B506, p0, p1, p2, p3)

def FREEZE_RADIO_STATION(radioStation: str) -> None:
    _iv(0x344F393B027E38C3, radioStation)

def GET_CURRENT_TRACK_SOUND_NAME(radioStationName: str) -> int:
    return _ii(0x34D66BC058019CE0, radioStationName)

def PLAY_PED_AMBIENT_SPEECH_WITH_VOICE_NATIVE(ped: int, speechName: str, voiceName: str, speechParam: str, p4: bool) -> None:
    _iv(0x3523634255FC3318, ped, speechName, voiceName, speechParam, p4)

def RELEASE_SOUND_ID(soundId: int) -> None:
    _iv(0x353FC880830B88FA, soundId)

def SET_AGGRESSIVE_HORNS(toggle: bool) -> None:
    _iv(0x395BF71085D1B1D9, toggle)

def SET_STATIC_EMITTER_ENABLED(emitterName: str, toggle: bool) -> None:
    _iv(0x399D2D3B33F1B8EB, emitterName, toggle)

def GET_MUSIC_VOL_SLIDER() -> int:
    return _ii(0x3A48AB4445D499BE)

def PLAY_VEHICLE_DOOR_OPEN_SOUND(vehicle: int, doorId: int) -> None:
    _iv(0x3A539D52857EA82D, vehicle, doorId)

def PRELOAD_SCRIPT_CONVERSATION(p0: bool, p1: bool, p2: bool, p3: bool) -> None:
    _iv(0x3B3CAD6166916D87, p0, p1, p2, p3)

def SET_CUTSCENE_AUDIO_OVERRIDE(name: str) -> None:
    _iv(0x3B4BF5F0859204D9, name)

def SET_VEHICLE_RADIO_ENABLED(vehicle: int, toggle: bool) -> None:
    _iv(0x3B988190C0AA6C0B, vehicle, toggle)

def SET_GPS_ACTIVE(active: bool) -> None:
    _iv(0x3BD3F52BA9B1E4E8, active)

def OVERRIDE_VEH_HORN(vehicle: int, override: bool, hornHash: int) -> None:
    _iv(0x3CDC1E622CCE0356, vehicle, override, hornHash)

def SET_VEH_HAS_NORMAL_RADIO(vehicle: int) -> None:
    _iv(0x3E45765F3FBB582F, vehicle)

def GET_CURRENT_TRACK_PLAY_TIME(radioStationName: str) -> int:
    return _ii(0x3E65CDE5215832C1, radioStationName)

def HINT_MISSION_AUDIO_BANK(audioBank: str, p1: bool, p2: int) -> bool:
    return _ib(0x40763EA7B9B783E7, audioBank, p1, p2)

def SET_PED_VOICE_FULL(ped: int) -> None:
    _iv(0x40CF0D12D142A9E8, ped)

def GET_SOUND_ID() -> int:
    return _ii(0x430386FE9BF80B45)

def SET_SIREN_CAN_BE_CONTROLLED_BY_AUDIO(vehicle: int, p1: bool) -> None:
    _iv(0x43FA0DFC5DF87815, vehicle, p1)

def LOCK_RADIO_STATION(radioStationName: str, toggle: bool) -> None:
    _iv(0x477D9DB48F889591, radioStationName, toggle)

def UPDATE_UNLOCKABLE_DJ_RADIO_TRACKS(enableMixes: bool) -> None:
    _iv(0x47AED84213A47510, enableMixes)

def GET_CURRENT_SCRIPTED_CONVERSATION_LINE() -> int:
    return _ii(0x480357EE890C295A)

def DOES_CONTEXT_EXIST_FOR_THIS_PED(ped: int, speechName: str, p2: bool) -> bool:
    return _ib(0x49B99BF3FDA89A7A, ped, speechName, p2)

def SET_VEHICLE_BOOST_ACTIVE(vehicle: int, toggle: bool) -> None:
    _iv(0x4A04DE7CAB2739A1, vehicle, toggle)

def REQUEST_TENNIS_BANKS(ped: int) -> None:
    _iv(0x4ADA3F19BE4A6047, ped)

def SET_RADIO_STATION_AS_FAVOURITE(radioStation: str, toggle: bool) -> None:
    _iv(0x4CAFEBFA21EC188D, radioStation, toggle)

def FORCE_MUSIC_TRACK_LIST(radioStation: str, trackListName: str, milliseconds: int) -> None:
    _iv(0x4E0AF9114608257C, radioStation, trackListName, milliseconds)

def SET_CUSTOM_RADIO_TRACK_LIST(radioStation: str, trackListName: str, p2: bool) -> None:
    _iv(0x4E404A9361F75BB2, radioStation, trackListName, p2)

def GET_STREAM_PLAY_TIME() -> int:
    return _ii(0x4E72BBDBCA58A3DB)

def FORCE_USE_AUDIO_GAME_OBJECT(vehicle: int, audioName: str) -> None:
    _iv(0x4F0C413926060B38, vehicle, audioName)

def GET_AUDIBLE_MUSIC_TRACK_TEXT_ID() -> int:
    return _ii(0x50B196FC9ED6545B)

def HAS_LOADED_MP_DATA_SET() -> bool:
    return _ib(0x544810ED9DB6BBE6)

def DISTANT_COP_CAR_SIRENS(value: bool) -> None:
    _iv(0x552369F549563AD5, value)

def SET_NEXT_RADIO_TRACK(radioName: str, radioTrack: str, p2: str, p3: str) -> None:
    _iv(0x55ECF4D13D9903B0, radioName, radioTrack, p2, p3)

def SET_VEHICLE_CONVERSATIONS_PERSIST(p0: bool, p1: bool) -> None:
    _iv(0x58BB377BEC7CD5F4, p0, p1)

def PLAY_STREAM_FRONTEND() -> None:
    _iv(0x58FCE43488F9F5F4)

def LOAD_STREAM_WITH_START_OFFSET(streamName: str, startOffset: int, soundSet: str) -> bool:
    return _ib(0x59C16B79F53B3712, streamName, startOffset, soundSet)

def SET_VEHICLE_AUDIO_ENGINE_DAMAGE_FACTOR(vehicle: int, damageFactor: float) -> None:
    _iv(0x59E7B488451F4D3A, vehicle, damageFactor)

def CANCEL_MUSIC_EVENT(eventName: str) -> bool:
    return _ib(0x5B17A90291133DA5, eventName)

def HAS_LOADED_SP_DATA_SET() -> bool:
    return _ib(0x5B50ABB1FE3746F4)

def PLAY_SOUND_FROM_ENTITY_HASH(soundId: int, model: int, entity: int, soundSetHash: int, p4: int, p5: int) -> None:
    _iv(0x5B9853296731E88D, soundId, model, entity, soundSetHash, p4, p5)

def REFRESH_CLOSEST_OCEAN_SHORELINE() -> None:
    _iv(0x5D2BFAAB8D956E0E)

def IS_VEHICLE_AUDIBLY_DAMAGED(vehicle: int) -> bool:
    return _ib(0x5DB8010EE71FDEF2, vehicle)

def GET_AMBIENT_VOICE_NAME_HASH(ped: int) -> int:
    return _ii(0x5E203DA2BA15D436, ped)

def IS_PLAYER_VEH_RADIO_ENABLE() -> bool:
    return _ib(0x5F43D83FD6738741)

def PRELOAD_SCRIPT_PHONE_CONVERSATION(p0: bool, p1: bool) -> None:
    _iv(0x6004BCB0E226AAEA, p0, p1)

def SET_CONVERSATION_AUDIO_PLACEHOLDER(p0: bool) -> None:
    _iv(0x61631F5DF50D1C34, p0)

def PLAY_VEHICLE_DOOR_CLOSE_SOUND(vehicle: int, doorId: int) -> None:
    _iv(0x62A456AA4769EF34, vehicle, doorId)

def LINK_STATIC_EMITTER_TO_ENTITY(emitterName: str, entity: int) -> None:
    _iv(0x651D3228960D08AF, emitterName, entity)

def RELEASE_AMBIENT_AUDIO_BANK() -> None:
    _iv(0x65475A218FFAA93D)

def TRIGGER_SIREN_AUDIO(vehicle: int) -> None:
    _iv(0x66C3FB05206041BA, vehicle)

def IS_MISSION_NEWS_STORY_UNLOCKED(newsStory: int) -> bool:
    return _ib(0x66E49BF55B4B1874, newsStory)

def PLAY_SOUND_FRONTEND(soundId: int, audioName: str, audioRef: str, p3: bool) -> None:
    _iv(0x67C540AA08E4A6F5, soundId, audioName, audioRef, p3)

def START_SCRIPT_CONVERSATION(p0: bool, p1: bool, p2: bool, p3: bool) -> None:
    _iv(0x6B17C62C9635D2DC, p0, p1, p2, p3)

def STOP_PED_RINGTONE(ped: int) -> None:
    _iv(0x6C5AE23EFA885092, ped)

def SET_AMBIENT_VOICE_NAME(ped: int, name: str) -> None:
    _iv(0x6C8065A3B780185B, ped, name)

def IS_GAME_IN_CONTROL_OF_MUSIC() -> bool:
    return _ib(0x6D28DC1671E334FD)

def SKIP_RADIO_FORWARD() -> None:
    _iv(0x6DDBBDD98E2E9C25)

def IS_MISSION_COMPLETE_READY_FOR_UI() -> bool:
    return _ib(0x6F259F82D873B8B8)

def SET_PLAYER_VEHICLE_ALARM_AUDIO_ACTIVE(vehicle: int, toggle: bool) -> None:
    _iv(0x6FDDAD856E36988A, vehicle, toggle)

def TRIGGER_MUSIC_EVENT(eventName: str) -> bool:
    return _ib(0x706D57B0F50DA710, eventName)

def SCRIPT_OVERRIDES_WIND_ELEVATION(p0: bool, p1: int) -> None:
    _iv(0x70B8EC8FC108A634, p0, p1)

def IS_ANY_SPEECH_PLAYING(ped: int) -> bool:
    return _ib(0x729072355FA39EC9, ped)

def SET_VARIABLE_ON_UNDER_WATER_STREAM(variableName: str, value: float) -> None:
    _iv(0x733ADF241531E5C2, variableName, value)

def REQUEST_MISSION_AUDIO_BANK(audioBank: str, p1: bool, p2: int) -> bool:
    return _ib(0x7345BDD95E62E0F2, audioBank, p1, p2)

def IS_MOBILE_PHONE_CALL_ONGOING() -> bool:
    return _ib(0x7497D2CE2C30D24C)

def GET_SOUND_ID_FROM_NETWORK_ID(netId: int) -> int:
    return _ii(0x75262FD12D0A1C84, netId)

def OVERRIDE_MICROPHONE_SETTINGS(hash: int, toggle: bool) -> None:
    _iv(0x75773E11BA459E90, hash, toggle)

def SET_HORN_ENABLED(vehicle: int, toggle: bool) -> None:
    _iv(0x76D683C108594D0E, vehicle, toggle)

def SET_RADIO_STATION_MUSIC_ONLY(radioStation: str, toggle: bool) -> None:
    _iv(0x774BD811F656A122, radioStation, toggle)

def RELEASE_NAMED_SCRIPT_AUDIO_BANK(audioBank: str) -> None:
    _iv(0x77ED170667F50170, audioBank)

def RELEASE_SCRIPT_AUDIO_BANK() -> None:
    _iv(0x7A2D8AD0A9EB9C3F)

def STOP_CURRENT_PLAYING_SPEECH(ped: int) -> None:
    _iv(0x7A73D05A607734C7, ped)

def SET_PED_VOICE_GROUP(ped: int, voiceGroupHash: int) -> None:
    _iv(0x7CDC8C3B89F661B3, ped, voiceGroupHash)

def UPDATE_SOUND_COORD(soundId: int, x: float, y: float, z: float) -> None:
    _iv(0x7EC3C679D0E7E46B, soundId, x, y, z)

def PLAY_SOUND(soundId: int, audioName: str, audioRef: str, p3: bool, p4: int, p5: bool) -> None:
    _iv(0x7FF4944CC209192D, soundId, audioName, audioRef, p3, p4, p5)

def STOP_CUTSCENE_AUDIO() -> None:
    _iv(0x806058BBDC136E06)

def AUDIO_IS_MUSIC_PLAYING() -> bool:
    return _ib(0x845FFC3A4FEEFA3E)

def PAUSE_SCRIPTED_CONVERSATION(p0: bool) -> None:
    _iv(0x8530AD776CD72B12, p0)

def SET_INITIAL_PLAYER_STATION(radioStation: str) -> None:
    _iv(0x88795F13FACDA88D, radioStation)

def PLAY_STREAM_FROM_PED(ped: int) -> None:
    _iv(0x89049DD63C08B5D1, ped)

def SET_ENTITY_FOR_NULL_CONV_PED(p0: int, entity: int) -> None:
    _iv(0x892B6AB8F33606F5, p0, entity)

def INTERRUPT_CONVERSATION_AND_PAUSE(ped: int, p1: str, speaker: str) -> None:
    _iv(0x8A694D7A68F8DC38, ped, p1, speaker)

def PLAY_SYNCHRONIZED_AUDIO_EVENT(sceneID: int) -> bool:
    return _ib(0x8B2FD4560E55DD2D, sceneID)

def SET_PED_INTERIOR_WALLA_DENSITY(p0: float, p1: float) -> None:
    _iv(0x8BF907833BE275DE, p0, p1)

def FIND_RADIO_STATION_INDEX(stationNameHash: int) -> int:
    return _ii(0x8D67489793FF428B, stationNameHash)

def PLAY_SOUND_FROM_COORD(soundId: int, audioName: str, x: float, y: float, z: float, audioRef: str, isNetwork: bool, range: int, p8: bool) -> None:
    _iv(0x8D8686B622B88120, soundId, audioName, x, y, z, audioRef, isNetwork, range, p8)

def PLAY_PED_AMBIENT_SPEECH_NATIVE(ped: int, speechName: str, speechParam: str, p3: int) -> None:
    _iv(0x8E04FEDD28D42462, ped, speechName, speechParam, p3)

def REMOVE_INDIVIDUAL_PORTAL_SETTINGS_OVERRIDE(interiorNameHash: int, roomIndex: int, doorIndex: int) -> None:
    _iv(0x8EF105736194F80C, interiorNameHash, roomIndex, doorIndex)

def HINT_AMBIENT_AUDIO_BANK(audioBank: str, p1: bool, p2: int) -> bool:
    return _ib(0x8F8C0E370AE62F5C, audioBank, p1, p2)

def IS_AMBIENT_SPEECH_PLAYING(ped: int) -> bool:
    return _ib(0x9072C8B49907BFAD, ped)

def STOP_SYNCHRONIZED_AUDIO_EVENT(sceneID: int) -> bool:
    return _ib(0x92D6A88E64A94430, sceneID)

def IS_AMBIENT_SPEECH_DISABLED(ped: int) -> bool:
    return _ib(0x932C2D096A2C3FFF, ped)

def INIT_SYNCH_SCENE_AUDIO_WITH_ENTITY(audioEvent: str, entity: int) -> None:
    _iv(0x950A154B8DAB6185, audioEvent, entity)

def SET_PED_IS_DRUNK(ped: int, toggle: bool) -> None:
    _iv(0x95D2D383D5396B8A, ped, toggle)

def ADD_PED_TO_CONVERSATION(index: int, ped: int, p2: str) -> None:
    _iv(0x95D9F4BC443956E7, index, ped, p2)

def SKIP_TO_NEXT_SCRIPTED_CONVERSATION_LINE() -> None:
    _iv(0x9663FE6B7A61EB00)

def SET_AMBIENT_ZONE_LIST_STATE(ambientZone: str, p1: bool, p2: bool) -> None:
    _iv(0x9748FA4DE50CCE3E, ambientZone, p1, p2)

def SET_VEHICLE_FORCE_REVERSE_WARNING(p0: int, p1: int) -> None:
    _iv(0x97FFB4ADEED08066, p0, p1)

def SET_AMBIENT_VOICE_NAME_HASH(ped: int, hash: int) -> None:
    _iv(0x9A53DED9921DE990, ped, hash)

def UNHINT_SCRIPT_AUDIO_BANK() -> None:
    _iv(0x9AC92EED5E4793AB)

def RESTART_SCRIPTED_CONVERSATION() -> None:
    _iv(0x9AEB285D1818C9AC)

def SET_VEHICLE_CONVERSATIONS_PERSIST_NEW(p0: bool, p1: bool, p2: bool) -> None:
    _iv(0x9BD7BD55E4533183, p0, p1, p2)

def SET_HORN_PERMANENTLY_ON(vehicle: int) -> None:
    _iv(0x9C11908013EA4715, vehicle)

def SET_HORN_PERMANENTLY_ON_TIME(vehicle: int, time: float) -> None:
    _iv(0x9D3AF56E94C9AE98, vehicle, time)

def STOP_PED_SPEAKING(ped: int, shaking: bool) -> None:
    _iv(0x9D64D7405520E3D3, ped, shaking)

def IS_HORN_ACTIVE(vehicle: int) -> bool:
    return _ib(0x9D6BFC12B05C6121, vehicle)

def PREPARE_ALARM(alarmName: str) -> bool:
    return _ib(0x9D74AE343DB65533, alarmName)

def INTERRUPT_CONVERSATION(ped: int, voiceline: str, speaker: str) -> None:
    _iv(0xA018A12E5C5C2FA6, ped, voiceline, speaker)

def IS_MUSIC_ONESHOT_PLAYING() -> bool:
    return _ib(0xA097AB275061FB21)

def IS_RADIO_RETUNING() -> bool:
    return _ib(0xA151A7394A214E65)

def STOP_ALARM(alarmName: str, toggle: bool) -> None:
    _iv(0xA1CADDCD98415A41, alarmName, toggle)

def STOP_SOUND(soundId: int) -> None:
    _iv(0xA3B0C41BA5CC0BB5, soundId)

def STOP_STREAM() -> None:
    _iv(0xA4718A1419D18151)

def SET_PED_GENDER(ped: int, p1: bool) -> None:
    _iv(0xA5342D390CDA41D6, ped, p1)

def GET_PLAYER_RADIO_STATION_GENRE() -> int:
    return _ii(0xA571991A7FE6CCEB)

def SET_AUDIO_SCRIPT_CLEANUP_TIME(time: int) -> None:
    _iv(0xA5F377B175A699C5, time)

def SET_RADIO_TO_STATION_INDEX(radioStation: int) -> None:
    _iv(0xA619B168B8A8570F, radioStation)

def UNREGISTER_SCRIPT_WITH_AUDIO() -> None:
    _iv(0xA8638BE228D4751A)

def BLOCK_SPEECH_CONTEXT_GROUP(p0: str, p1: int) -> None:
    _iv(0xA8A7D434AFB4B97B, p0, p1)

def DISABLE_PED_PAIN_AUDIO(ped: int, toggle: bool) -> None:
    _iv(0xA9A41C1E940FB0E8, ped, toggle)

def GET_VARIATION_CHOSEN_FOR_SCRIPTED_LINE(p0: int) -> int:
    return _ii(0xAA19F5572C38B564, p0)

def STOP_PED_SPEAKING_SYNCED(ped: int, p1: bool) -> None:
    _iv(0xAB6781A5F3101470, ped, p1)

def GET_VEHICLE_DEFAULT_HORN_IGNORE_MODS(vehicle: int) -> int:
    return _ii(0xACB5DCCA1EC76840, vehicle)

def SET_EMITTER_RADIO_STATION(emitterName: str, radioStation: str, p2: int) -> None:
    _iv(0xACF57305B12AF907, emitterName, radioStation, p2)

def SET_VARIABLE_ON_SOUND(soundId: int, variable: str, p2: float) -> None:
    _iv(0xAD6B3148A78AE9B6, soundId, variable, p2)

def PLAY_MISSION_COMPLETE_AUDIO(audioName: str) -> None:
    _iv(0xB138AAB8A70D3C69, audioName)

def UNLOCK_MISSION_NEWS_STORY(newsStory: int) -> None:
    _iv(0xB165AB7C248B2DC1, newsStory)

def GET_RADIO_STATION_NAME(radioStation: int) -> str:
    return _is(0xB28ECA15046CA8B9, radioStation)

def CLEAR_ALL_BROKEN_GLASS() -> None:
    _iv(0xB32209EFFDC04913)

def IS_MOBILE_PHONE_RADIO_ACTIVE() -> bool:
    return _ib(0xB35CE999E8EF317E)

def SET_RADIO_TRACK(radioStation: str, radioTrack: str) -> None:
    _iv(0xB39786F201FEE30B, radioStation, radioTrack)

def REMOVE_PORTAL_SETTINGS_OVERRIDE(p0: str) -> None:
    _iv(0xB4BBFD9CD8B3922B, p0)

def CANCEL_ALL_POLICE_REPORTS() -> None:
    _iv(0xB4F90FAF7670B16F)

def SET_NO_DUCKING_FOR_CONVERSATION(p0: bool) -> None:
    _iv(0xB542DE8C3D1CB210, p0)

def IS_AUDIO_SCENE_ACTIVE(scene: str) -> bool:
    return _ib(0xB65B60556E2A9225, scene)

def SET_MICROPHONE_POSITION(toggle: bool, x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, x3: float, y3: float, z3: float) -> None:
    _iv(0xB6AE90EDDE95C762, toggle, x1, y1, z1, x2, y2, z2, x3, y3, z3)

def PLAY_STREAM_FROM_VEHICLE(vehicle: int) -> None:
    _iv(0xB70374A758007DFA, vehicle)

def ENABLE_STUNT_JUMP_AUDIO() -> None:
    _iv(0xB81CF134AEB56FFB)

def STOP_CURRENT_PLAYING_AMBIENT_SPEECH(ped: int) -> None:
    _iv(0xB8BEC0CA6F0EDB0F, ped)

def SET_AUDIO_FLAG(flagName: str, toggle: bool) -> None:
    _iv(0xB9EFD5C25018725A, flagName, toggle)

def STOP_AUDIO_SCENES() -> None:
    _iv(0xBAC7FC81A75EC1A1)

def SET_VEHICLE_RADIO_LOUD(vehicle: int, toggle: bool) -> None:
    _iv(0xBB6F1CAEC68B0BCE, vehicle, toggle)

def PLAY_PAIN(ped: int, painID: int, p1: int, p3: int) -> None:
    _iv(0xBC9AE166038A5CEC, ped, painID, p1, p3)

def SET_VARIABLE_ON_SYNCH_SCENE_AUDIO(variableName: str, value: float) -> None:
    _iv(0xBCC29F935ED07688, variableName, value)

def SET_AMBIENT_ZONE_STATE(zoneName: str, p1: bool, p2: bool) -> None:
    _iv(0xBDA07E5950085E46, zoneName, p1, p2)

def SET_SKIP_MINIGUN_SPIN_UP_AUDIO(p0: bool) -> None:
    _iv(0xBEF34B1D9624D5DD, p0)

def _ENABLE_DRAG_RACE_STATIONARY_WARNING_SOUNDS(vehicle: int, enable: bool) -> None:
    _iv(0xBEFB80290414FD4F, vehicle, enable)

def SET_MOBILE_PHONE_RADIO_STATE(state: bool) -> None:
    _iv(0xBF286C554784F3DF, state)

def USE_FOOTSTEP_SCRIPT_SWEETENERS(ped: int, p1: bool, hash: int) -> None:
    _iv(0xBF4DC1784BE94DFA, ped, p1, hash)

def ENABLE_STALL_WARNING_SOUNDS(vehicle: int, toggle: bool) -> None:
    _iv(0xC15907D667F7CFB2, vehicle, toggle)

def SET_VEH_FORCED_RADIO_THIS_FRAME(vehicle: int) -> None:
    _iv(0xC1805D05E6D4FE10, vehicle)

def SET_RADIO_AUTO_UNFREEZE(toggle: bool) -> None:
    _iv(0xC1AA9F53CE982990, toggle)

def IS_ANIMAL_VOCALIZATION_PLAYING(pedHandle: int) -> bool:
    return _ib(0xC265DF9FB44A9FBD, pedHandle)

def ADD_LINE_TO_CONVERSATION(index: int, p1: str, p2: str, p3: int, p4: int, p5: bool, p6: bool, p7: bool, p8: bool, p9: int, p10: bool, p11: bool, p12: bool) -> None:
    _iv(0xC5EF963405593646, index, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12)

def GET_NEXT_AUDIBLE_BEAT(out1: int, out2: int, out3: int) -> bool:
    return _ib(0xC64A06D939F826F5, out1, out2, out3)

def PLAY_PED_AMBIENT_SPEECH_AND_CLONE_NATIVE(ped: int, speechName: str, speechParam: str, p3: int) -> None:
    _iv(0xC6941B4A3A8FBBB9, ped, speechName, speechParam, p3)

def SET_RADIO_TO_STATION_NAME(stationName: str) -> None:
    _iv(0xC69EDA28699D5107, stationName)

def REGISTER_SCRIPT_WITH_AUDIO(p0: int) -> None:
    _iv(0xC6ED9D5092438D91, p0)

def PREPARE_SYNCHRONIZED_AUDIO_EVENT(audioEvent: str, p1: int) -> bool:
    return _ib(0xC7ABCACA4985A766, audioEvent, p1)

def IS_MOBILE_INTERFERENCE_ACTIVE() -> bool:
    return _ib(0xC8B1B2425604CDD0)

def INIT_SYNCH_SCENE_AUDIO_WITH_POSITION(audioEvent: str, x: float, y: float, z: float) -> None:
    _iv(0xC8EDE9BDBCCBA6D4, audioEvent, x, y, z)

def SET_INDIVIDUAL_PORTAL_SETTINGS_OVERRIDE(interiorNameHash: int, roomIndex: int, doorIndex: int, newPortalSettingsName: str) -> None:
    _iv(0xC9D623C5A3D8FD5D, interiorNameHash, roomIndex, doorIndex, newPortalSettingsName)

def PRELOAD_VEHICLE_AUDIO_BANK(vehicleModel: int) -> None:
    _iv(0xCA4CEA6AE0000A7E, vehicleModel)

def PLAY_DEFERRED_SOUND_FRONTEND(soundName: str, soundsetName: str) -> None:
    _iv(0xCADA5A0D0702381E, soundName, soundsetName)

def SET_ANIMAL_MOOD(animal: int, mood: int) -> None:
    _iv(0xCC97B29285B1DC3B, animal, mood)

def IS_SCRIPTED_SPEECH_PLAYING(p0: int) -> bool:
    return _ib(0xCC9AA18DCC7084F4, p0)

def PLAY_END_CREDITS_MUSIC(play: bool) -> None:
    _iv(0xCD536C4D33DCC900, play)

def RELEASE_WEAPON_AUDIO() -> None:
    _iv(0xCE4AC0439F607045)

def ACTIVATE_AUDIO_SLOWMO_MODE(mode: str) -> None:
    _iv(0xD01005D2BA2EB778, mode)

def IS_STREAM_PLAYING() -> bool:
    return _ib(0xD11FA52EB849D978)

def CREATE_NEW_SCRIPTED_CONVERSATION() -> None:
    _iv(0xD2C91A0B572AAE56)

def OVERRIDE_PLAYER_GROUND_MATERIAL(hash: int, toggle: bool) -> None:
    _iv(0xD2CC78CD3D0B50F9, hash, toggle)

def RESET_VEHICLE_STARTUP_REV_SOUND(vehicle: int) -> None:
    _iv(0xD2DCCD8E16E20997, vehicle)

def GET_VEHICLE_HORN_SOUND_INDEX(vehicle: int) -> int:
    return _ii(0xD53F3A29BCE2580E, vehicle)

def FREEZE_MICROPHONE() -> None:
    _iv(0xD57AAAE0E2214D11)

def STOP_SCRIPTED_CONVERSATION(p0: bool) -> int:
    return _ii(0xD79DEEFB53455EBA, p0)

def SET_POSITIONED_PLAYER_VEHICLE_RADIO_EMITTER_ENABLED(p0: int) -> None:
    _iv(0xDA07819E452FFE8F, p0)

def GET_CURRENT_TV_SHOW_PLAY_TIME() -> int:
    return _ii(0xDD3AA743AB7D4D75)

def SET_RADIO_RETUNE_DOWN() -> None:
    _iv(0xDD6BCF9E94425DF9)

def DEACTIVATE_AUDIO_SLOWMO_MODE(mode: str) -> None:
    _iv(0xDDC635D5B3262C56, mode)

def IS_SCRIPTED_CONVERSATION_LOADED() -> bool:
    return _ib(0xDF0D54BE7A776737)

def STOP_AUDIO_SCENE(scene: str) -> None:
    _iv(0xDFE8422B3B94E688, scene)

def PLAY_POLICE_REPORT(name: str, p1: float) -> int:
    return _ii(0xDFEBD56D9BD1EB16, name, p1)

def STOP_SMOKE_GRENADE_EXPLOSION_SOUNDS() -> None:
    _iv(0xE4E6DD5566D28C82)

def SET_AUDIO_VEHICLE_PRIORITY(vehicle: int, p1: int) -> None:
    _iv(0xE5564483E407F914, vehicle, p1)

def PLAY_SOUND_FROM_ENTITY(soundId: int, audioName: str, entity: int, audioRef: str, isNetwork: bool, p5: int) -> None:
    _iv(0xE65F427EB70AB1ED, soundId, audioName, entity, audioRef, isNetwork, p5)

def GET_IS_PRELOADED_CONVERSATION_READY() -> bool:
    return _ib(0xE73364DB90778FFA)

def RESET_TREVOR_RAGE() -> None:
    _iv(0xE78503B10C4314E0)

def GET_MUSIC_PLAYTIME() -> int:
    return _ii(0xE7A0D23DC414507B)

def GET_PLAYER_RADIO_STATION_INDEX() -> int:
    return _ii(0xE8AF77C4C06ADC93)

def SET_PLAYER_ANGRY(ped: int, toggle: bool) -> None:
    _iv(0xEA241BB04110F091, ped, toggle)

def _FORCE_VEHICLE_ENGINE_SYNTH(vehicle: int, force: bool) -> None:
    _iv(0xEB7D0E1FCC8FE17A, vehicle, force)

def PLAY_STREAM_FROM_OBJECT(object: int) -> None:
    _iv(0xEBAA9B64D76356FD, object)

def PLAY_AMBIENT_SPEECH_FROM_POSITION_NATIVE(speechName: str, voiceName: str, x: float, y: float, z: float, speechParam: str) -> None:
    _iv(0xED640017ED337E45, speechName, voiceName, x, y, z, speechParam)

def PLAY_ANIMAL_VOCALIZATION(pedHandle: int, p1: int, speechName: str) -> None:
    _iv(0xEE066C7006C49C0A, pedHandle, p1, speechName)

def SET_AUDIO_SCENE_VARIABLE(scene: str, variable: str, value: float) -> None:
    _iv(0xEF21A9EF089A2668, scene, variable, value)

def BLOCK_DEATH_JINGLE(toggle: bool) -> None:
    _iv(0xF154B8D1775B2DEC, toggle)

def GET_NUM_UNLOCKED_RADIO_STATIONS() -> int:
    return _ii(0xF1620ECB50E01DE7)

def SET_VEHICLE_STARTUP_REV_SOUND(vehicle: int, p1: str, p2: str) -> None:
    _iv(0xF1F8157B8C3F171C, vehicle, p1, p2)

def OVERRIDE_UNDERWATER_STREAM(p0: str, p1: bool) -> None:
    _iv(0xF2A9CDABCEA04BD6, p0, p1)

def SET_VEHICLE_MISSILE_WARNING_ENABLED(vehicle: int, toggle: bool) -> None:
    _iv(0xF3365489E0DD50F9, vehicle, toggle)

def SET_AMBIENT_ZONE_LIST_STATE_PERSISTENT(ambientZone: str, p1: bool, p2: bool) -> None:
    _iv(0xF3638DAE8C4045E1, ambientZone, p1, p2)

def RESET_PED_AUDIO_FLAGS(ped: int) -> None:
    _iv(0xF54BB7B61036F335, ped)

def SET_SIREN_BYPASS_MP_DRIVER_CHECK(vehicle: int, toggle: bool) -> None:
    _iv(0xF584CF8529B51434, vehicle, toggle)

def GET_PLAYER_RADIO_STATION_NAME() -> str:
    return _is(0xF6D733C32076AD03)

def SET_FRONTEND_RADIO_ACTIVE(active: bool) -> None:
    _iv(0xF7F26C6E9CC9EBB8, active)

def BLOCK_ALL_SPEECH_FROM_PED(ped: int, p1: bool, p2: bool) -> None:
    _iv(0xF8AD2EED7C47E8FE, ped, p1, p2)

def PLAY_PED_RINGTONE(ringtoneName: str, ped: int, p2: bool) -> None:
    _iv(0xF9E56683CA8E11A5, ringtoneName, ped, p2)

def USE_SIREN_AS_HORN(vehicle: int, toggle: bool) -> None:
    _iv(0xFA932DE350266EF8, vehicle, toggle)

def HINT_SCRIPT_AUDIO_BANK(audioBank: str, p1: bool, p2: int) -> bool:
    return _ib(0xFB380A29641EC31A, audioBank, p1, p2)

def RECORD_BROKEN_GLASS(x: float, y: float, z: float, radius: float) -> None:
    _iv(0xFBE20329593DEC9D, x, y, z, radius)

def UNFREEZE_RADIO_STATION(radioStation: str) -> None:
    _iv(0xFC00454CF60B91DD, radioStation)

def HAS_SOUND_FINISHED(soundId: int) -> bool:
    return _ib(0xFCBDCE714A7C88E5, soundId)

def REQUEST_AMBIENT_AUDIO_BANK(audioBank: str, p1: bool, p2: int) -> bool:
    return _ib(0xFE02FFBED8CA9D99, audioBank, p1, p2)

def SET_RADIO_RETUNE_UP() -> None:
    _iv(0xFF266D1D0EB1195D)

def LOCK_RADIO_STATION_TRACK_LIST(radioStation: str, trackListName: str) -> None:
    _iv(0xFF5E5EA2DCEEACF3, radioStation, trackListName)
