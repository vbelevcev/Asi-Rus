"""Auto-generated raw native bindings for namespace PAD.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_str as _is


def GET_CONTROL_INSTRUCTIONAL_BUTTONS_STRING(control: int, action: int, allowXOSwap: bool) -> str:
    return _is(0x0499D7B09FC9B407, control, action, allowXOSwap)

def GET_IS_USING_ALTERNATE_DRIVEBY() -> bool:
    return _ib(0x0F70731BACCFBB96)

def GET_DISABLED_CONTROL_NORMAL(control: int, action: int) -> float:
    return _if(0x11E65974A982637C, control, action)

def IS_USING_CURSOR(control: int) -> bool:
    return _ib(0x13337B38DB572509, control)

def SET_CONTROL_TRIGGER_SHAKE(control: int, leftDuration: int, leftFrequency: int, rightDuration: int, rightFrequency: int) -> None:
    _iv(0x14D29BB12D47F68C, control, leftDuration, leftFrequency, rightDuration, rightFrequency)

def _GET_GAMEPAD_TYPE() -> int:
    return _ii(0x18E474F40EF05F10)

def IS_CONTROL_ENABLED(control: int, action: int) -> bool:
    return _ib(0x1CEA6BFDF248E5D9, control, action)

def IS_USING_REMOTE_PLAY(control: int) -> bool:
    return _ib(0x23F09EADC01449D6, control)

def GET_IS_USING_ALTERNATE_HANDBRAKE() -> bool:
    return _ib(0x25AAA32BDC98F2A3)

def IS_DISABLED_CONTROL_JUST_RELEASED(control: int, action: int) -> bool:
    return _ib(0x305C8DCD79DA8B0F, control, action)

def ENABLE_CONTROL_ACTION(control: int, action: int, enableRelatedActions: bool) -> None:
    _iv(0x351220255D64C155, control, action, enableRelatedActions)

def STOP_CONTROL_SHAKE(control: int) -> None:
    _iv(0x38C16A305E8CDC8D, control)

def INIT_PC_SCRIPTED_CONTROLS(schemeName: str) -> bool:
    return _ib(0x3D42B92563939375, schemeName)

def SWITCH_PC_SCRIPTED_CONTROLS(schemeName: str) -> bool:
    return _ib(0x4683149ED1DDE7A1, schemeName)

def SET_CONTROL_SHAKE(control: int, duration: int, frequency: int) -> None:
    _iv(0x48B3886C1358D0D5, control, duration, frequency)

def GET_DISABLED_CONTROL_UNBOUND_NORMAL(control: int, action: int) -> float:
    return _if(0x4F8A26A890FD62FB, control, action)

def IS_CONTROL_JUST_RELEASED(control: int, action: int) -> bool:
    return _ib(0x50F940259D3841E6, control, action)

def IS_CONTROL_JUST_PRESSED(control: int, action: int) -> bool:
    return _ib(0x580417101DDB492F, control, action)

def GET_LOCAL_PLAYER_GAMEPAD_AIM_STATE() -> int:
    return _ii(0x59B9A7AF4C95133C)

def SET_USE_ADJUSTED_MOUSE_COORDS(toggle: bool) -> None:
    _iv(0x5B73C77D9EB66E24, toggle)

def GET_CONTROL_UNBOUND_NORMAL(control: int, action: int) -> float:
    return _if(0x5B84D09CEC5209C5, control, action)

def DISABLE_ALL_CONTROL_ACTIONS(control: int) -> None:
    _iv(0x5F4B6931816E599B, control)

def SHUTDOWN_PC_SCRIPTED_CONTROLS() -> None:
    _iv(0x643ED62D5EA3BEBD)

def IS_CONTROL_RELEASED(control: int, action: int) -> bool:
    return _ib(0x648EE3E7F38877DD, control, action)

def HAVE_CONTROLS_CHANGED(control: int) -> bool:
    return _ib(0x6CD79468A1E595C6, control)

def IS_LOOK_INVERTED() -> bool:
    return _ib(0x77B612531280010D)

def SET_PLAYERPAD_SHAKES_WHEN_CONTROLLER_DISABLED(toggle: bool) -> None:
    _iv(0x798FDEB5B1575088, toggle)

def ALLOW_ALTERNATIVE_SCRIPT_CONTROLS_LAYOUT(control: int) -> None:
    _iv(0x7F4724035FDCA1DD, control)

def GET_CONTROL_GROUP_INSTRUCTIONAL_BUTTONS_STRING(control: int, controlGroup: int, allowXOSwap: bool) -> str:
    return _is(0x80C2FD58D720C801, control, controlGroup, allowXOSwap)

def SET_CONTROL_LIGHT_EFFECT_COLOR(control: int, red: int, green: int, blue: int) -> None:
    _iv(0x8290252FFF36ACB5, control, red, green, blue)

def IS_DISABLED_CONTROL_JUST_PRESSED(control: int, action: int) -> bool:
    return _ib(0x91AEF906BCA88877, control, action)

def CLEAR_CONTROL_SHAKE_SUPPRESSED_ID(control: int) -> None:
    _iv(0xA0CEFCEA390AAB9B, control)

def IS_USING_KEYBOARD_AND_MOUSE(control: int) -> bool:
    return _ib(0xA571D46727E2B718, control)

def ENABLE_ALL_CONTROL_ACTIONS(control: int) -> None:
    _iv(0xA5FFE9B05F199DE7, control)

def GET_LOCAL_PLAYER_AIM_STATE() -> int:
    return _ii(0xBB41AFBBBC0A0287)

def CLEAR_CONTROL_LIGHT_EFFECT(control: int) -> None:
    _iv(0xCB0360EFEFB2580D, control)

def GET_CONTROL_HOW_LONG_AGO(control: int) -> int:
    return _ii(0xD7D22F5592AED8BA, control)

def GET_CONTROL_VALUE(control: int, action: int) -> int:
    return _ii(0xD95E79E8686D2C27, control, action)

def IS_MOUSE_LOOK_INVERTED() -> bool:
    return _ib(0xE1615EC03B3BB4FD)

def IS_DISABLED_CONTROL_PRESSED(control: int, action: int) -> bool:
    return _ib(0xE2587F8CBBD87B1D, control, action)

def SET_CONTROL_VALUE_NEXT_FRAME(control: int, action: int, value: float) -> bool:
    return _ib(0xE8A25867FBA3B05E, control, action, value)

def _IS_CONTROL_HELD_DOWN(control: int, action: int, duration: int) -> bool:
    return _ib(0xE9CB8C56E90D5079, control, action, duration)

def GET_CONTROL_NORMAL(control: int, action: int) -> float:
    return _if(0xEC3C9B8D5327B563, control, action)

def SET_INPUT_EXCLUSIVE(control: int, action: int) -> None:
    _iv(0xEDE476E5EE29EDB1, control, action)

def SET_CONTROL_SHAKE_SUPPRESSED_ID(control: int, uniqueId: int) -> None:
    _iv(0xF239400E16C23E08, control, uniqueId)

def IS_CONTROL_PRESSED(control: int, action: int) -> bool:
    return _ib(0xF3A21BCD95725A4A, control, action)

def IS_DISABLED_CONTROL_RELEASED(control: int, action: int) -> bool:
    return _ib(0xFB6C4072E9A32E92, control, action)

def SET_CURSOR_POSITION(x: float, y: float) -> bool:
    return _ib(0xFC695459D4D0E219, x, y)

def GET_ALLOW_MOVEMENT_WHILE_ZOOMED() -> bool:
    return _ib(0xFC859E2374407556)

def DISABLE_CONTROL_ACTION(control: int, action: int, disableRelatedActions: bool) -> None:
    _iv(0xFE99B66D079CF6BC, control, action, disableRelatedActions)
