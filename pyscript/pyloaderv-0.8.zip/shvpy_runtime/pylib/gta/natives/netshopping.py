"""Auto-generated raw native bindings for namespace NETSHOPPING.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_bool as _ib, _invoke_int as _ii


def NET_GAMESERVER_RETRIEVE_INIT_SESSION_STATUS(p0: int) -> bool:
    return _ib(0x0395CB47B022E62C, p0)

def NET_GAMESERVER_DELETE_CHARACTER_GET_STATUS() -> int:
    return _ii(0x0A6D923DFFC9BD89)

def NET_GAMESERVER_DELETE_SET_TELEMETRY_NONCE_SEED() -> bool:
    return _ib(0x112CEF1615A1139F)

def NET_GAMESERVER_RETRIEVE_START_SESSION_STATUS(p0: int) -> bool:
    return _ib(0x170910093218C8B9, p0)

def NET_GAMESERVER_TRANSFER_BANK_TO_WALLET_GET_STATUS() -> int:
    return _ii(0x23789E777D14CE44)

def NET_GAMESERVER_CATALOG_ITEM_KEY_IS_VALID(hash: int) -> bool:
    return _ib(0x247F0F73A182EA0B, hash)

def NET_GAMESERVER_BASKET_START(transactionId: int, categoryHash: int, actionHash: int, flags: int) -> bool:
    return _ib(0x279F08B1A4B29B7E, transactionId, categoryHash, actionHash, flags)

def NET_GAMESERVER_BASKET_IS_FULL() -> bool:
    return _ib(0x27F76CC6C55AD30E)

def NET_GAMESERVER_IS_CATALOG_CURRENT() -> bool:
    return _ib(0x2B949A1E6AEC8F6A)

def NET_GAMESERVER_SESSION_APPLY_RECEIVED_DATA(charSlot: int) -> bool:
    return _ib(0x2F41D51BA3BCD1F1, charSlot)

def NET_GAMESERVER_TRANSFER_WALLET_TO_BANK_GET_STATUS() -> int:
    return _ii(0x350AA5EBC03D3BD2)

def NET_GAMESERVER_REFRESH_SERVER_CATALOG() -> bool:
    return _ib(0x357B152EF96C30B6)

def NET_GAMESERVER_START_SESSION_RESTART(inventory: bool, playerbalance: bool) -> bool:
    return _ib(0x35A1B3E1D1315CFA, inventory, playerbalance)

def NET_GAMESERVER_CHECKOUT_START(transactionId: int) -> bool:
    return _ib(0x39BE7CEA8D9CC8E6, transactionId)

def NET_GAMESERVER_CATALOG_IS_VALID() -> bool:
    return _ib(0x3C4487461E9B0DCB)

def NET_GAMESERVER_BEGIN_SERVICE(transactionId: int, categoryHash: int, itemHash: int, actionTypeHash: int, value: int, flags: int) -> bool:
    return _ib(0x3C5FD37B5499582E, transactionId, categoryHash, itemHash, actionTypeHash, value, flags)

def NET_GAMESERVER_TRANSFER_CASH_SET_TELEMETRY_NONCE_SEED() -> bool:
    return _ib(0x498C1E05CE5F7877)

def NET_GAMESERVER_CHECKOUT_PENDING(transactionId: int) -> bool:
    return _ib(0x4B64CD6D18474126, transactionId)

def NET_GAMESERVER_DELETE_CHARACTER(slot: int, transfer: bool, reason: int) -> bool:
    return _ib(0x51F1A8E48C3D2F6D, slot, transfer, reason)

def NET_GAMESERVER_TRANSACTION_IN_PROGRESS() -> bool:
    return _ib(0x613F125BA3BD2EB9)

def NET_GAMESERVER_START_SESSION_PENDING() -> bool:
    return _ib(0x72EB7BA9B69BF6AB)

def NET_GAMESERVER_CLEAR_SESSION(p0: int) -> bool:
    return _ib(0x74A0FD0688F1EE45, p0)

def NET_GAMESERVER_USE_SERVER_TRANSACTIONS() -> bool:
    return _ib(0x7D2708796355B20B)

def NET_GAMESERVER_IS_SESSION_REFRESH_PENDING() -> bool:
    return _ib(0x810E8431C0614BF9)

def NET_GAMESERVER_GET_CATALOG_CLOUD_CRC() -> int:
    return _ii(0x85F6C9ABA1DE2BCF)

def NET_GAMESERVER_GET_SESSION_STATE_AND_STATUS(p0: int, p1: int) -> bool:
    return _ib(0x897433D292B44130, p0, p1)

def NET_GAMESERVER_SET_TELEMETRY_NONCE_SEED(p0: int) -> bool:
    return _ib(0x9507D4271988E1AE, p0)

def NET_GAMESERVER_START_SESSION(charSlot: int) -> bool:
    return _ib(0xA135AC892A58FC07, charSlot)

def NET_GAMESERVER_BASKET_IS_ACTIVE() -> bool:
    return _ib(0xA65568121DF2EA26)

def NET_GAMESERVER_IS_SESSION_VALID(charSlot: int) -> bool:
    return _ib(0xB24F0944DA203D9E, charSlot)

def NET_GAMESERVER_CATALOG_ITEM_IS_VALID(name: str) -> bool:
    return _ib(0xBD4D7EAF8A30F637, name)

def NET_GAMESERVER_RETRIEVE_SESSION_ERROR_CODE(p0: int) -> bool:
    return _ib(0xC13C38E47EA5DF31, p0)

def NET_GAMESERVER_GET_PRICE(itemHash: int, categoryHash: int, p2: bool) -> int:
    return _ii(0xC27009422FCCA88D, itemHash, categoryHash, p2)

def NET_GAMESERVER_TRANSFER_WALLET_TO_BANK(charSlot: int, amount: int) -> bool:
    return _ib(0xC2F7FE5309181C7D, charSlot, amount)

def NET_GAMESERVER_RETRIEVE_CATALOG_REFRESH_STATUS(state: int) -> bool:
    return _ib(0xCF38DAFBB49EDE5E, state)

def NET_GAMESERVER_TRANSFER_BANK_TO_WALLET(charSlot: int, amount: int) -> bool:
    return _ib(0xD47A2C1BA117471D, charSlot, amount)

def NET_GAMESERVER_BASKET_APPLY_SERVER_DATA(p0: int, p1: int) -> bool:
    return _ib(0xE1A0450ED46A7812, p0, p1)

def NET_GAMESERVER_END_SERVICE(transactionId: int) -> bool:
    return _ib(0xE2A99A9B524BEFFF, transactionId)

def NET_GAMESERVER_INIT_SESSION() -> bool:
    return _ib(0xE3E5A7C64CA2C6ED)

def NET_GAMESERVER_BASKET_ADD_ITEM(itemData: int, quantity: int) -> bool:
    return _ib(0xF30980718C8ED876, itemData, quantity)

def NET_GAMESERVER_BASKET_END() -> bool:
    return _ib(0xFA336E7F40C0A0D0)
