"""Auto-generated raw native bindings for namespace GRAPHICS.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_str as _is, _invoke_vector3 as _ivec


def CREATE_CHECKPOINT(type: int, posX1: float, posY1: float, posZ1: float, posX2: float, posY2: float, posZ2: float, diameter: float, red: int, green: int, blue: int, alpha: int, reserved: int) -> int:
    return _ii(0x0134F0835AB6BFCB, type, posX1, posY1, posZ1, posX2, posY2, posZ2, diameter, red, green, blue, alpha, reserved)

def HAS_STREAMED_TEXTURE_DICT_LOADED(textureDict: str) -> bool:
    return _ib(0x0145F696AAAAD2E4, textureDict)

def PROCGRASS_DISABLE_AMBSCALESCAN() -> None:
    _iv(0x0218BA067D249DEA)

def DISABLE_SCUFF_DECALS(toggle: bool) -> None:
    _iv(0x02369D5C8A51FDCF, toggle)

def CASCADE_SHADOWS_SET_DYNAMIC_DEPTH_VALUE(p0: float) -> None:
    _iv(0x02AC28F3A01FA04A, p0)

def START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_BONE(effectName: str, entity: int, offsetX: float, offsetY: float, offsetZ: float, rotX: float, rotY: float, rotZ: float, boneIndex: int, scale: float, axisX: bool, axisY: bool, axisZ: bool) -> bool:
    return _ib(0x02B1F2A72E0F5325, effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, boneIndex, scale, axisX, axisY, axisZ)

def RENDER_SHADOWED_LIGHTS_WITH_NO_SHADOWS(p0: bool) -> None:
    _iv(0x03300B57FCAC6DDB, p0)

def CASCADE_SHADOWS_INIT_SESSION() -> None:
    _iv(0x03FC694AE06C5A20)

def RELEASE_BINK_MOVIE(binkMovie: int) -> None:
    _iv(0x04D950EEFA4EED8C, binkMovie)

def DOES_VEHICLE_HAVE_CREW_EMBLEM(vehicle: int, p1: int) -> bool:
    return _ib(0x060D935D3981A275, vehicle, p1)

def ANIMPOSTFX_STOP(effectName: str) -> None:
    _iv(0x068E835A1D0DC0E3, effectName)

def GOLF_TRAIL_SET_FACING(p0: bool) -> None:
    _iv(0x06F761EA47C1D3ED, p0)

def DRAW_DEBUG_BOX(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, r: int, g: int, b: int, alpha: int) -> None:
    _iv(0x083A2CA4F2E573BD, x1, y1, z1, x2, y2, z2, r, g, b, alpha)

def END_PETROL_TRAIL_DECALS() -> None:
    _iv(0x0A123435A26C36CD)

def FREE_MEMORY_FOR_MISSION_CREATOR_PHOTO() -> None:
    _iv(0x0A46AF8A78DC5E0A)

def SET_FLASH(p0: float, p1: float, fadeIn: float, duration: float, fadeOut: float) -> None:
    _iv(0x0AB84296FED9CFC6, p0, p1, fadeIn, duration, fadeOut)

def IS_TVSHOW_CURRENTLY_PLAYING(videoCliphash: int) -> bool:
    return _ib(0x0AD973CA1E077B60, videoCliphash)

def CASCADE_SHADOWS_ENABLE_FREEZER(p0: bool) -> None:
    _iv(0x0AE73D8DF3A762B2, p0)

def GET_STATUS_OF_SAVE_HIGH_QUALITY_PHOTO() -> int:
    return _ii(0x0C0C4E81E1AC60A0)

def HAS_SCALEFORM_MOVIE_FILENAME_LOADED(scaleformName: str) -> bool:
    return _ib(0x0C1C5D756FB5F337, scaleformName)

def SEETHROUGH_SET_MAX_THICKNESS(thickness: float) -> None:
    _iv(0x0C8FAC83902A62DF, thickness)

def SET_BINK_MOVIE_TIME(binkMovie: int, progress: float) -> None:
    _iv(0x0CB6B3446855B57A, binkMovie, progress)

def START_PARTICLE_FX_NON_LOOPED_ON_ENTITY(effectName: str, entity: int, offsetX: float, offsetY: float, offsetZ: float, rotX: float, rotY: float, rotZ: float, scale: float, axisX: bool, axisY: bool, axisZ: bool) -> bool:
    return _ib(0x0D53A3B8DA0809D2, effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, scale, axisX, axisY, axisZ)

def GET_STATUS_OF_TAKE_HIGH_QUALITY_PHOTO() -> int:
    return _ii(0x0D6CA79EEEBD8CA3)

def DRAW_SCALEFORM_MOVIE_FULLSCREEN(scaleform: int, red: int, green: int, blue: int, alpha: int, p5: int) -> None:
    _iv(0x0DF606929C105BE1, scaleform, red, green, blue, alpha, p5)

def DISABLE_COMPOSITE_SHOTGUN_DECALS(toggle: bool) -> None:
    _iv(0x0E4299C549F0D1F1, toggle)

def START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE(effectName: str, ped: int, offsetX: float, offsetY: float, offsetZ: float, rotX: float, rotY: float, rotZ: float, boneIndex: int, scale: float, axisX: bool, axisY: bool, axisZ: bool) -> bool:
    return _ib(0x0E7E72961BA18619, effectName, ped, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, boneIndex, scale, axisX, axisY, axisZ)

def CLEAR_TIMECYCLE_MODIFIER() -> None:
    _iv(0x0F07E7745A236711)

def DRAW_LOW_QUALITY_PHOTO_TO_PHONE(p0: bool, p1: bool) -> None:
    _iv(0x1072F115DAB0717E, p0, p1)

def SEETHROUGH_SET_COLOR_NEAR(red: int, green: int, blue: int) -> None:
    _iv(0x1086127B3A63505E, red, green, blue)

def UI3DSCENE_MAKE_PUSHED_PRESET_PERSISTENT(toggle: bool) -> None:
    _iv(0x108BE26959A9D9BB, toggle)

def SET_TV_AUDIO_FRONTEND(toggle: bool) -> None:
    _iv(0x113D2C5DC57E1774, toggle)

def REQUEST_SCALEFORM_MOVIE(scaleformName: str) -> int:
    return _ii(0x11FE353CF9733E6F, scaleformName)

def SET_ARTIFICIAL_LIGHTS_STATE(state: bool) -> None:
    _iv(0x1268615ACE24D504, state)

def ADD_OIL_DECAL(x: float, y: float, z: float, groundLvl: float, width: float, transparency: float) -> int:
    return _ii(0x126D7F89FE859A5E, x, y, z, groundLvl, width, transparency)

def GOLF_TRAIL_SET_COLOUR(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int, p7: int, p8: int, p9: int, p10: int, p11: int) -> None:
    _iv(0x12995F2E53FFA601, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11)

def PROCGRASS_ENABLE_AMBSCALESCAN() -> None:
    _iv(0x14FC5833464340A8)

def CLEAR_ALL_TCMODIFIER_OVERRIDES(p0: str) -> None:
    _iv(0x15E33297C3E8DC60, p0)

def OVERRIDE_INTERIOR_SMOKE_LEVEL(level: float) -> None:
    _iv(0x1600FD8CF72EBC12, level)

def DISABLE_PROCOBJ_CREATION() -> None:
    _iv(0x1612C45F9E3E0D44)

def SEETHROUGH_SET_HIGHLIGHT_NOISE(noise: float) -> None:
    _iv(0x1636D7FC127B10D2, noise)

def SET_TRACKED_POINT_INFO(point: int, x: float, y: float, z: float, radius: float) -> None:
    _iv(0x164ECBB3CF750CB0, point, x, y, z, radius)

def GET_STATUS_OF_LOAD_MISSION_CREATOR_PHOTO(p0: int) -> int:
    return _ii(0x1670F8D05056F257, p0)

def REGISTER_POSTFX_BULLET_IMPACT(weaponWorldPosX: float, weaponWorldPosY: float, weaponWorldPosZ: float, intensity: float) -> None:
    _iv(0x170911F37F646F29, weaponWorldPosX, weaponWorldPosY, weaponWorldPosZ, intensity)

def SET_DEBUG_LINES_AND_SPHERES_DRAWING_ACTIVE(enabled: bool) -> None:
    _iv(0x175B6BFC15CDD0C5, enabled)

def SET_NIGHTVISION(toggle: bool) -> None:
    _iv(0x18F621F7A5B1F85D, toggle)

def SEETHROUGH_SET_HILIGHT_INTENSITY(intensity: float) -> None:
    _iv(0x19E50EB6E33E1D28, intensity)

def ADD_TCMODIFIER_OVERRIDE(modifierName1: str, modifierName2: str) -> None:
    _iv(0x1A8E2C8B9CF4549C, modifierName1, modifierName2)

def START_PARTICLE_FX_LOOPED_ON_ENTITY(effectName: str, entity: int, xOffset: float, yOffset: float, zOffset: float, xRot: float, yRot: float, zRot: float, scale: float, xAxis: bool, yAxis: bool, zAxis: bool) -> int:
    return _ii(0x1AE42C1660FD6517, effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis)

def SET_TAKEN_PHOTO_IS_MUGSHOT(toggle: bool) -> None:
    _iv(0x1BBC135A4D25EDDE, toggle)

def TERRAINGRID_SET_PARAMS(x: float, y: float, z: float, forwardX: float, forwardY: float, forwardZ: float, sizeX: float, sizeY: float, sizeZ: float, gridScale: float, glowIntensity: float, normalHeight: float, heightDiff: float) -> None:
    _iv(0x1C4FC5752BCD8E48, x, y, z, forwardX, forwardY, forwardZ, sizeX, sizeY, sizeZ, gridScale, glowIntensity, normalHeight, heightDiff)

def SET_TRANSITION_OUT_OF_TIMECYCLE_MODIFIER(strength: float) -> None:
    _iv(0x1CBA05AE7BD7EE05, strength)

def DRAW_SCALEFORM_MOVIE_3D_SOLID(scaleform: int, posX: float, posY: float, posZ: float, rotX: float, rotY: float, rotZ: float, p7: float, p8: float, p9: float, scaleX: float, scaleY: float, scaleZ: float, rotationOrder: int) -> None:
    _iv(0x1CE592FDC749D6F5, scaleform, posX, posY, posZ, rotX, rotY, rotZ, p7, p8, p9, scaleX, scaleY, scaleZ, rotationOrder)

def SET_SCALEFORM_MOVIE_AS_NO_LONGER_NEEDED(scaleformHandle: int) -> None:
    _iv(0x1D132D614DD86811, scaleformHandle)

def SET_ENTITY_ICON_COLOR(entity: int, red: int, green: int, blue: int, alpha: int) -> None:
    _iv(0x1D5F595CCAE2E238, entity, red, green, blue, alpha)

def BEGIN_TAKE_MISSION_CREATOR_PHOTO() -> bool:
    return _ib(0x1DD2139A9A20DCE8)

def SET_PARTICLE_FX_NON_LOOPED_EMITTER_SIZE(p0: float, p1: float, scale: float) -> None:
    _iv(0x1E2E01C00837D26E, p0, p1, scale)

def IS_PLAYLIST_ON_CHANNEL(tvChannel: int, p1: int) -> bool:
    return _ib(0x1F710BFF7DAE6261, tvChannel, p1)

def GET_TV_VOLUME() -> float:
    return _if(0x2170813D3DD8661B)

def SET_TV_CHANNEL_PLAYLIST_AT_HOUR(tvChannel: int, playlistName: str, hour: int) -> None:
    _iv(0x2201C576FACAEBE8, tvChannel, playlistName, hour)

def GET_USINGNIGHTVISION() -> bool:
    return _ib(0x2202A3F42C8E5F79)

def ANIMPOSTFX_PLAY(effectName: str, duration: int, looped: bool) -> None:
    _iv(0x2206BF9A37B7F724, effectName, duration, looped)

def DONT_RENDER_IN_GAME_UI(p0: bool) -> None:
    _iv(0x22A249A53034450A, p0)

def SET_BACKFACECULLING(toggle: bool) -> None:
    _iv(0x23BA6B0C2AD7B0D3, toggle)

def GOLF_TRAIL_SET_RADIUS(p0: float, p1: float, p2: float) -> None:
    _iv(0x2485D34E50A22E84, p0, p1, p2)

def START_PARTICLE_FX_NON_LOOPED_AT_COORD(effectName: str, xPos: float, yPos: float, zPos: float, xRot: float, yRot: float, zRot: float, scale: float, xAxis: bool, yAxis: bool, zAxis: bool) -> bool:
    return _ib(0x25129531F77B9ED3, effectName, xPos, yPos, zPos, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis)

def CASCADE_SHADOWS_SET_BOUND_POSITION(p0: int) -> None:
    _iv(0x259BA6D4E6F808F1, p0)

def CASCADE_SHADOWS_SET_SCREEN_SIZE_CHECK_ENABLED(p0: bool) -> None:
    _iv(0x25FC3E33A31AD0C9, p0)

def SET_PARTICLE_FX_NON_LOOPED_COLOUR(r: float, g: float, b: float) -> None:
    _iv(0x26143A59EF48B262, r, g, b)

def SET_CHECKPOINT_CYLINDER_HEIGHT(checkpoint: int, nearHeight: float, farHeight: float, radius: float) -> None:
    _iv(0x2707AAE9D9297D89, checkpoint, nearHeight, farHeight, radius)

def CASCADE_SHADOWS_CLEAR_SHADOW_SAMPLE_TYPE() -> None:
    _iv(0x27CB772218215325)

def SET_DISABLE_PETROL_DECALS_RECYCLING_THIS_FRAME() -> None:
    _iv(0x27CFB1B1E078CB2D)

def SET_PARTICLE_FX_BULLET_IMPACT_SCALE(scale: float) -> None:
    _iv(0x27E32866E9A5C416, scale)

def PHONEPHOTOEDITOR_SET_FRAME_TXD(textureDict: str, p1: bool) -> bool:
    return _ib(0x27FEB5254759CDE3, textureDict, p1)

def DRAW_MARKER(type: int, posX: float, posY: float, posZ: float, dirX: float, dirY: float, dirZ: float, rotX: float, rotY: float, rotZ: float, scaleX: float, scaleY: float, scaleZ: float, red: int, green: int, blue: int, alpha: int, bobUpAndDown: bool, faceCamera: bool, p19: int, rotate: bool, textureDict: str, textureName: str, drawOnEnts: bool) -> None:
    _iv(0x28477EC23D892089, type, posX, posY, posZ, dirX, dirY, dirZ, rotX, rotY, rotZ, scaleX, scaleY, scaleZ, red, green, blue, alpha, bobUpAndDown, faceCamera, p19, rotate, textureDict, textureName, drawOnEnts)

def DRAW_TEXTURED_POLY(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, x3: float, y3: float, z3: float, red: int, green: int, blue: int, alpha: int, textureDict: str, textureName: str, u1: float, v1: float, w1: float, u2: float, v2: float, w2: float, u3: float, v3: float, w3: float) -> None:
    _iv(0x29280002282F1928, x1, y1, z1, x2, y2, z2, x3, y3, z3, red, green, blue, alpha, textureDict, textureName, u1, v1, w1, u2, v2, w2, u3, v3, w3)

def SET_TV_VOLUME(volume: float) -> None:
    _iv(0x2982BF73F66E9DDC, volume)

def CLEAR_PARTICLE_FX_SHOOTOUT_BOAT() -> None:
    _iv(0x2A251AA48B2B46DB)

def OVERRIDE_INTERIOR_SMOKE_NAME(name: str) -> None:
    _iv(0x2A2A52824DB96700, name)

def QUEUE_OPERATION_TO_CREATE_SORTED_LIST_OF_PHOTOS(p0: int) -> bool:
    return _ib(0x2A893980E96B659A, p0)

def SET_PARTICLE_FX_SLIPSTREAM_LODRANGE_SCALE(scale: float) -> None:
    _iv(0x2B40A97646381508, scale)

def DRAW_SPRITE_NAMED_RENDERTARGET(textureDict: str, textureName: str, screenX: float, screenY: float, width: float, height: float, heading: float, red: int, green: int, blue: int, alpha: int, p11: int) -> None:
    _iv(0x2BC54A8188768488, textureDict, textureName, screenX, screenY, width, height, heading, red, green, blue, alpha, p11)

def DISABLE_MOON_CYCLE_OVERRIDE() -> None:
    _iv(0x2BF72AD5B41AA739)

def ENABLE_MOON_CYCLE_OVERRIDE(strength: float) -> None:
    _iv(0x2C328AF17210F009, strength)

def PROCGRASS_IS_CULLSPHERE_ENABLED(handle: int) -> bool:
    return _ib(0x2C42340F916C5930, handle)

def SET_TIMECYCLE_MODIFIER(modifierName: str) -> None:
    _iv(0x2C933ABF17A1DF41, modifierName)

def DRAW_SPRITE_ARX(textureDict: str, textureName: str, x: float, y: float, width: float, height: float, p6: float, red: int, green: int, blue: int, alpha: int, p11: int, p12: int) -> None:
    _iv(0x2D3B147AFAD49DE0, textureDict, textureName, x, y, width, height, p6, red, green, blue, alpha, p11, p12)

def GET_SCALEFORM_MOVIE_METHOD_RETURN_VALUE_INT(methodReturn: int) -> int:
    return _ii(0x2DE7EFA66B906036, methodReturn)

def GET_IS_PETROL_DECAL_IN_RANGE(xCoord: float, yCoord: float, zCoord: float, radius: float) -> bool:
    return _ib(0x2F09F7976C512404, xCoord, yCoord, zCoord, radius)

def IS_ACTIVE_SCALEFORM_MOVIE_DELETING(val: int) -> bool:
    return _ib(0x2FCB133CA50A49EB, val)

def _SET_SCALEFORM_MOVIE_NAMED_AS_NO_LONGER_NEEDED(scaleformHandle: int, scaleformName: str) -> None:
    _iv(0x2FDFB1B04C76E9C3, scaleformHandle, scaleformName)

def GRASSBATCH_DISABLE_FLATTENING() -> None:
    _iv(0x302C91AB2D477F7E)

def GET_CURRENT_TV_CLIP_NAMEHASH() -> int:
    return _ii(0x30432A0118736E00)

def GET_IS_WIDESCREEN() -> bool:
    return _ib(0x30CF4BDA4FCB1905)

def GOLF_TRAIL_SET_PATH(p0: float, p1: float, p2: float, p3: float, p4: float, p5: float, p6: float, p7: float, p8: bool) -> None:
    _iv(0x312342E1A4874F3F, p0, p1, p2, p3, p4, p5, p6, p7, p8)

def GET_DECAL_WASH_LEVEL(decal: int) -> float:
    return _if(0x323F647679A09103, decal)

def SET_SCALEFORM_MOVIE_TO_USE_LARGE_RT(scaleformHandle: int, toggle: bool) -> None:
    _iv(0x32F34FF7F617643B, scaleformHandle, toggle)

def SET_BINK_MOVIE(name: str) -> int:
    return _ii(0x338D9F609FD632DB, name)

def FREE_MEMORY_FOR_MISSION_CREATOR_PHOTO_PREVIEW() -> None:
    _iv(0x346EF3ECAAAB149E)

def GET_MAXIMUM_NUMBER_OF_PHOTOS() -> int:
    return _ii(0x34D23450F028B0BF)

def GET_SCREEN_COORD_FROM_WORLD_COORD(worldX: float, worldY: float, worldZ: float, screenX: int, screenY: int) -> bool:
    return _ib(0x34E82F05DF2974F5, worldX, worldY, worldZ, screenX, screenY)

def GET_TEXTURE_RESOLUTION(textureDict: str, textureName: str) -> 'gta.Vector3':
    return _ivec(0x35736EE65BD00C11, textureDict, textureName)

def GET_REQUESTINGNIGHTVISION() -> bool:
    return _ib(0x35FB78DC42B7BD21)

def END_TEXT_COMMAND_SCALEFORM_STRING() -> None:
    _iv(0x362E2D3FE93A9959)

def DISABLE_OCCLUSION_THIS_FRAME() -> None:
    _iv(0x3669F1B198DCAA4F)

def ANIMPOSTFX_IS_RUNNING(effectName: str) -> bool:
    return _ib(0x36AD3E690DA5ACEB, effectName)

def CASCADE_SHADOWS_SET_SPLIT_Z_EXP_WEIGHT(p0: float) -> None:
    _iv(0x36F6626459D91457, p0)

def DRAW_DEBUG_TEXT(text: str, x: float, y: float, z: float, red: int, green: int, blue: int, alpha: int) -> None:
    _iv(0x3903E216620488E8, text, x, y, z, red, green, blue, alpha)

def GET_LIGHT_OVERRIDE_MAX_INTENSITY_SCALE() -> float:
    return _if(0x393BD2275CEB7793)

def DRAW_RECT(x: float, y: float, width: float, height: float, r: int, g: int, b: int, a: int, p8: bool) -> None:
    _iv(0x3A618A217E5154F0, x, y, width, height, r, g, b, a, p8)

def SET_TRANSITION_TIMECYCLE_MODIFIER(modifierName: str, transition: float) -> None:
    _iv(0x3BCF567485E1971C, modifierName, transition)

def SET_CHECKPOINT_DIRECTION(checkpoint: int, posX: float, posY: float, posZ: float) -> None:
    _iv(0x3C788E7F6438754D, checkpoint, posX, posY, posZ)

def POP_TIMECYCLE_MODIFIER() -> None:
    _iv(0x3C8938D7D872211E)

def SAVE_HIGH_QUALITY_PHOTO(unused: int) -> bool:
    return _ib(0x3DEC726C25A11BAC, unused)

def GET_LOAD_HIGH_QUALITY_PHOTO_STATUS(p0: int) -> int:
    return _ii(0x40AFB081F8ADD4EE, p0)

def _SET_PARTICLE_FX_LOOPED_CAMERA_BIAS(ptfxHandle: int, p1: float) -> None:
    _iv(0x4100BF0346A8D2C3, ptfxHandle, p1)

def ADD_VEHICLE_CREW_EMBLEM(vehicle: int, ped: int, boneIndex: int, x1: float, x2: float, x3: float, y1: float, y2: float, y3: float, z1: float, z2: float, z3: float, scale: float, p13: int, alpha: int) -> bool:
    return _ib(0x428BDCB9DA58DA53, vehicle, ped, boneIndex, x1, x2, x3, y1, y2, y3, z1, z2, z3, scale, p13, alpha)

def SEETHROUGH_GET_MAX_THICKNESS() -> float:
    return _if(0x43DBAE39626CE83F)

def OVERRIDE_NIGHTVISION_LIGHT_RANGE(p0: float) -> None:
    _iv(0x43FA7CBE20DAB219, p0)

def SET_CHECKPOINT_INSIDE_CYLINDER_SCALE(checkpoint: int, scale: float) -> None:
    _iv(0x44621483FF966526, checkpoint, scale)

def GET_USINGSEETHROUGH() -> bool:
    return _ib(0x44B80ABAB9D80BD3)

def GET_TIMECYCLE_TRANSITION_MODIFIER_INDEX() -> int:
    return _ii(0x459FD2C8D0AB78BC)

def SET_DECAL_BULLET_IMPACT_RANGE_SCALE(p0: float) -> None:
    _iv(0x46D1A61A21F566FC, p0)

def GET_CURRENT_NUMBER_OF_CLOUD_PHOTOS() -> int:
    return _ii(0x473151EBC762C6DA)

def LOAD_MISSION_CREATOR_PHOTO(p0: int, p1: int, p2: int, p3: int) -> bool:
    return _ib(0x4862437A486F91B0, p0, p1, p2, p3)

def CLEAR_STATUS_OF_SORTED_LIST_OPERATION() -> None:
    _iv(0x4AF92ACD3141D96C)

def SET_CHECKPOINT_INSIDE_CYLINDER_HEIGHT_SCALE(checkpoint: int, scale: float) -> None:
    _iv(0x4B5B4DA5D79F1943, checkpoint, scale)

def SET_DISABLE_DECAL_RENDERING_THIS_FRAME() -> None:
    _iv(0x4B5CFC83122DF602)

def USE_SNOW_WHEEL_VFX_WHEN_UNSHELTERED(toggle: bool) -> None:
    _iv(0x4CC7F0FEA5283FE0, toggle)

def ADD_PETROL_DECAL(x: float, y: float, z: float, groundLvl: float, width: float, transparency: float) -> int:
    return _ii(0x4F5212C7AD880DF8, x, y, z, groundLvl, width, transparency)

def SET_EXTRA_TCMODIFIER(modifierName: str) -> None:
    _iv(0x5096FD9CCB49056D, modifierName)

def CALL_SCALEFORM_MOVIE_METHOD_WITH_STRING(scaleform: int, methodName: str, param1: str, param2: str, param3: str, param4: str, param5: str) -> None:
    _iv(0x51BC1ED3CC44E8F7, scaleform, methodName, param1, param2, param3, param4, param5)

def DRAW_SCALEFORM_MOVIE(scaleformHandle: int, x: float, y: float, width: float, height: float, red: int, green: int, blue: int, alpha: int, p9: int) -> None:
    _iv(0x54972ADAF0294A93, scaleformHandle, x, y, width, height, red, green, blue, alpha, p9)

def SET_PARTICLE_FX_BANG_SCRAPE_LODRANGE_SCALE(p0: float) -> None:
    _iv(0x54E22EA2C1956A8D, p0)

def PUSH_TIMECYCLE_MODIFIER() -> None:
    _iv(0x58F735290861E6B4)

def GET_STATUS_OF_CREATE_MISSION_CREATOR_PHOTO_PREVIEW() -> int:
    return _ii(0x5B0316762AFD4A64)

def WASH_DECALS_FROM_VEHICLE(vehicle: int, p1: float) -> None:
    _iv(0x5B712761429DBC14, vehicle, p1)

def DRAW_SHADOWED_SPOT_LIGHT(posX: float, posY: float, posZ: float, dirX: float, dirY: float, dirZ: float, colorR: int, colorG: int, colorB: int, distance: float, brightness: float, roundness: float, radius: float, falloff: float, shadowId: int) -> None:
    _iv(0x5BCA583A583194DB, posX, posY, posZ, dirX, dirY, dirZ, colorR, colorG, colorB, distance, brightness, roundness, radius, falloff, shadowId)

def GET_SCREENBLUR_FADE_CURRENT_TIME() -> float:
    return _if(0x5CCABFFCA31DDE33)

def TERRAINGRID_SET_COLOURS(lowR: int, lowG: int, lowB: int, lowAlpha: int, r: int, g: int, b: int, alpha: int, highR: int, highG: int, highB: int, highAlpha: int) -> None:
    _iv(0x5CE62918F8D703C7, lowR, lowG, lowB, lowAlpha, r, g, b, alpha, highR, highG, highB, highAlpha)

def REMOVE_DECALS_IN_RANGE(x: float, y: float, z: float, range: float) -> None:
    _iv(0x5D6B2D4830A67C62, x, y, z, range)

def SET_SKIDMARK_RANGE_SCALE(scale: float) -> None:
    _iv(0x5DBF05DB5926D089, scale)

def ENABLE_PROCOBJ_CREATION() -> None:
    _iv(0x5DEBD9C4DC995692)

def DOES_LATEST_BRIEF_STRING_EXIST(p0: int) -> bool:
    return _ib(0x5E657EF1099EDD65, p0)

def CASCADE_SHADOWS_SET_ENTITY_TRACKER_SCALE(p0: float) -> None:
    _iv(0x5E9DAF5A20F15908, p0)

def SET_PARTICLE_FX_LOOPED_EVOLUTION(ptfxHandle: int, propertyName: str, amount: float, noNetwork: bool) -> None:
    _iv(0x5F0C4B5B1C393BE2, ptfxHandle, propertyName, amount, noNetwork)

def CASCADE_SHADOWS_SET_CASCADE_BOUNDS_SCALE(p0: float) -> None:
    _iv(0x5F0F3F56635809EF, p0)

def DISABLE_DOWNWASH_PTFX(toggle: bool) -> None:
    _iv(0x5F6DF3D92271E8A1, toggle)

def SET_CHECKPOINT_DECAL_ROT_ALIGNED_TO_CAMERA_ROT(checkpoint: int) -> None:
    _iv(0x615D3925E87A3B26, checkpoint)

def SET_SCRIPT_GFX_DRAW_ORDER(drawOrder: int) -> None:
    _iv(0x61BB1D9B3A95D802, drawOrder)

def REMOVE_GRASS_CULL_SPHERE(handle: int) -> None:
    _iv(0x61F95E5BB3E0A8C6, handle)

def STOP_BINK_MOVIE(binkMovie: int) -> None:
    _iv(0x63606A61DE68898A, binkMovie)

def PROCGRASS_DISABLE_CULLSPHERE(handle: int) -> None:
    _iv(0x649C97D52332341A, handle)

def REQUEST_SCALEFORM_MOVIE_WITH_IGNORE_SUPER_WIDESCREEN(scaleformName: str) -> int:
    return _ii(0x65E7E78842E74CDB, scaleformName)

def SET_BINK_SHOULD_SKIP(binkMovie: int, bShouldSkip: bool) -> None:
    _iv(0x6805D58CAA427B72, binkMovie, bShouldSkip)

def FREE_MEMORY_FOR_LOW_QUALITY_PHOTO() -> None:
    _iv(0x6A12D88881435DCA)

def SET_FORCE_MOTIONBLUR(toggle: bool) -> None:
    _iv(0x6A51F78772175A51, toggle)

def DRAW_LINE(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, red: int, green: int, blue: int, alpha: int) -> None:
    _iv(0x6B7256074AE34680, x1, y1, z1, x2, y2, z2, red, green, blue, alpha)

def USE_PARTICLE_FX_ASSET(name: str) -> None:
    _iv(0x6C38AF3693A69A91, name)

def SET_SCALEFORM_MOVIE_TO_USE_SYSTEM_TIME(scaleform: int, toggle: bool) -> None:
    _iv(0x6D8EB211944DCE08, scaleform, toggle)

def GRASSBATCH_ENABLE_FLATTENING_IN_SPHERE(x: float, y: float, z: float, radius: float, p4: float, p5: float, p6: float) -> None:
    _iv(0x6D955F6A9E0295B1, x, y, z, radius, p4, p5, p6)

def GET_SCRIPT_GFX_ALIGN_POSITION(x: float, y: float, calculatedX: int, calculatedY: int) -> None:
    _iv(0x6DD8F5AA635EB4B2, x, y, calculatedX, calculatedY)

def CASCADE_SHADOWS_SET_AIRCRAFT_MODE(p0: bool) -> None:
    _iv(0x6DDBF9DFFC4AC080, p0)

def _FORCE_GROUND_SNOW_PASS(toggle: bool) -> None:
    _iv(0x6E9EF3A33C8899F8, toggle)

def START_NETWORKED_PARTICLE_FX_LOOPED_ON_ENTITY(effectName: str, entity: int, xOffset: float, yOffset: float, zOffset: float, xRot: float, yRot: float, zRot: float, scale: float, xAxis: bool, yAxis: bool, zAxis: bool, r: float, g: float, b: float, a: float) -> int:
    return _ii(0x6F60E89A7B64EE1D, effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis, r, g, b, a)

def SEETHROUGH_RESET() -> None:
    _iv(0x70A64C0234EF522C)

def PLAY_BINK_MOVIE(binkMovie: int) -> None:
    _iv(0x70D2CC8A542A973C, binkMovie)

def DRAW_BINK_MOVIE(binkMovie: int, p1: float, p2: float, p3: float, p4: float, p5: float, r: int, g: int, b: int, a: int) -> None:
    _iv(0x7118E83EEB9F7238, binkMovie, p1, p2, p3, p4, p5, r, g, b, a)

def SET_CHECKPOINT_RGBA(checkpoint: int, red: int, green: int, blue: int, alpha: int) -> None:
    _iv(0x7167371E8AD747F7, checkpoint, red, green, blue, alpha)

def SET_PARTICLE_FX_LOOPED_ALPHA(ptfxHandle: int, alpha: float) -> None:
    _iv(0x726845132380142E, ptfxHandle, alpha)

def DRAW_TEXTURED_POLY_WITH_THREE_COLOURS(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, x3: float, y3: float, z3: float, red1: float, green1: float, blue1: float, alpha1: int, red2: float, green2: float, blue2: float, alpha2: int, red3: float, green3: float, blue3: float, alpha3: int, textureDict: str, textureName: str, u1: float, v1: float, w1: float, u2: float, v2: float, w2: float, u3: float, v3: float, w3: float) -> None:
    _iv(0x736D7AA1B750856B, x1, y1, z1, x2, y2, z2, x3, y3, z3, red1, green1, blue1, alpha1, red2, green2, blue2, alpha2, red3, green3, blue3, alpha3, textureDict, textureName, u1, v1, w1, u2, v2, w2, u3, v3, w3)

def DRAW_DEBUG_CROSS(x: float, y: float, z: float, size: float, red: int, green: int, blue: int, alpha: int) -> None:
    _iv(0x73B1189623049839, x, y, z, size, red, green, blue, alpha)

def DOES_PARTICLE_FX_LOOPED_EXIST(ptfxHandle: int) -> bool:
    return _ib(0x74AFEF0D2E1E409B, ptfxHandle)

def ENABLE_MOVIE_KEYFRAME_WAIT(toggle: bool) -> None:
    _iv(0x74C180030FDE4B69, toggle)

def BEGIN_CREATE_LOW_QUALITY_COPY_OF_PHOTO(p0: int) -> bool:
    return _ib(0x759650634F07B6B4, p0)

def IS_SCALEFORM_MOVIE_METHOD_RETURN_VALUE_READY(methodReturn: int) -> bool:
    return _ib(0x768FF8961BA904D6, methodReturn)

def SET_PARTICLE_FX_NON_LOOPED_ALPHA(alpha: float) -> None:
    _iv(0x77168D722C58B2FC, alpha)

def SCALEFORM_MOVIE_METHOD_ADD_PARAM_LITERAL_STRING(string: str) -> None:
    _iv(0x77FE3402004CD1B0, string)

def DRAW_MARKER_SPHERE(x: float, y: float, z: float, radius: float, red: int, green: int, blue: int, alpha: float) -> None:
    _iv(0x799017F9E3B10112, x, y, z, radius, red, green, blue, alpha)

def UI3DSCENE_CLEAR_PATCHED_DATA() -> None:
    _iv(0x7A42B2E236E71415)

def PHONEPHOTOEDITOR_TOGGLE(p0: bool) -> bool:
    return _ib(0x7AC24EAB6D74118D, p0)

def IS_SCREENBLUR_FADE_RUNNING() -> bool:
    return _ib(0x7B226C785A52A0A9)

def SET_SEETHROUGH(toggle: bool) -> None:
    _iv(0x7E08924259E08CE0, toggle)

def SET_PARTICLE_FX_LOOPED_COLOUR(ptfxHandle: int, r: float, g: float, b: float, p4: bool) -> None:
    _iv(0x7F8F65877F88783B, ptfxHandle, r, g, b, p4)

def BEGIN_CREATE_MISSION_CREATOR_PHOTO_PREVIEW() -> bool:
    return _ib(0x7FA5D82B8F58EC06)

def DRAW_DEBUG_LINE(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, r: int, g: int, b: int, alpha: int) -> None:
    _iv(0x7FDFADE676AA3CB0, x1, y1, z1, x2, y2, z2, r, g, b, alpha)

def BEGIN_TEXT_COMMAND_SCALEFORM_STRING(componentType: str) -> None:
    _iv(0x80338406F3475E55, componentType)

def CASCADE_SHADOWS_ENABLE_ENTITY_TRACKER(toggle: bool) -> None:
    _iv(0x80ECBC0C856D3B0B, toggle)

def FORCE_EXPOSURE_READBACK(toggle: bool) -> None:
    _iv(0x814AF7DCAACC597B, toggle)

def HAS_SCALEFORM_CONTAINER_MOVIE_LOADED_INTO_PARENT(scaleformHandle: int) -> bool:
    return _ib(0x8217150E1217EBFD, scaleformHandle)

def ABORT_VEHICLE_CREW_EMBLEM_REQUEST(p0: int) -> bool:
    return _ib(0x82ACC484FFA3B05F, p0)

def SET_TIMECYCLE_MODIFIER_STRENGTH(strength: float) -> None:
    _iv(0x82E7FFCD5B2326B3, strength)

def ATTACH_TV_AUDIO_TO_ENTITY(entity: int) -> None:
    _iv(0x845BAD77CC770633, entity)

def MOVE_VEHICLE_DECALS(p0: int, p1: int) -> None:
    _iv(0x84C8D7C2D30D3280, p0, p1)

def GET_IS_HIDEF() -> bool:
    return _ib(0x84ED31191CC5D2C9)

def GRAB_PAUSEMENU_OWNERSHIP() -> None:
    _iv(0x851CD923176EBA7C)

def HAS_SCALEFORM_MOVIE_LOADED(scaleformHandle: int) -> bool:
    return _ib(0x85F01B8D5B90570E, scaleformHandle)

def IS_SCALEFORM_MOVIE_DELETING(val: int) -> bool:
    return _ib(0x86255B1FC929E33E, val)

def GET_ACTUAL_SCREEN_RESOLUTION(x: int, y: int) -> None:
    _iv(0x873C9F3104101DD3, x, y)

def ENABLE_MOVIE_SUBTITLES(toggle: bool) -> None:
    _iv(0x873FA65C778AD970, toggle)

def DRAW_SCALEFORM_MOVIE_3D(scaleform: int, posX: float, posY: float, posZ: float, rotX: float, rotY: float, rotZ: float, p7: float, p8: float, p9: float, scaleX: float, scaleY: float, scaleZ: float, rotationOrder: int) -> None:
    _iv(0x87D51D72255D4E78, scaleform, posX, posY, posZ, rotX, rotY, rotZ, p7, p8, p9, scaleX, scaleY, scaleZ, rotationOrder)

def GET_SCREEN_RESOLUTION(x: int, y: int) -> None:
    _iv(0x888D57E407E63624, x, y)

def RESET_PARTICLE_FX_OVERRIDE(name: str) -> None:
    _iv(0x89C8553DD3274AAE, name)

def PATCH_DECAL_DIFFUSE_MAP(decalType: int, textureDict: str, textureName: str) -> None:
    _iv(0x8A35C742130C6080, decalType, textureDict, textureName)

def SET_PARTICLE_FX_FORCE_VEHICLE_INTERIOR(toggle: bool) -> None:
    _iv(0x8CDE909A0370BB3A, toggle)

def GET_BINK_MOVIE_TIME(binkMovie: int) -> float:
    return _if(0x8E17DDD6B9D5BF29, binkMovie)

def STOP_PARTICLE_FX_LOOPED(ptfxHandle: int, p1: bool) -> None:
    _iv(0x8F75998877616996, ptfxHandle, p1)

def SET_PARTICLE_FX_BLOOD_SCALE(p0: int) -> None:
    _iv(0x908311265D42A820, p0)

def GET_STATUS_OF_TAKE_MISSION_CREATOR_PHOTO() -> int:
    return _ii(0x90A78ECAA4E78453)

def CLEAR_EXTRA_TCMODIFIER() -> None:
    _iv(0x92CCC17A7A2285DA)

def REQUEST_SCALEFORM_SCRIPT_HUD_MOVIE(hudComponent: int) -> None:
    _iv(0x9304881D6F6537EA, hudComponent)

def SET_PARTICLE_FX_FOOT_LODRANGE_SCALE(p0: float) -> None:
    _iv(0x949F397A288B28B3, p0)

def DRAW_SPRITE_ARX_WITH_UV(textureDict: str, textureName: str, x: float, y: float, width: float, height: float, u1: float, v1: float, u2: float, v2: float, heading: float, red: int, green: int, blue: int, alpha: int, p15: int) -> None:
    _iv(0x95812F9B26074726, textureDict, textureName, x, y, width, height, u1, v1, u2, v2, heading, red, green, blue, alpha, p15)

def OVERRIDE_PED_CREW_LOGO_TEXTURE(ped: int, txd: str, txn: str) -> bool:
    return _ib(0x95EB5E34F821BABE, ped, txd, txn)

def SET_LIGHT_OVERRIDE_MAX_INTENSITY_SCALE(p0: int) -> None:
    _iv(0x9641588DAB93B4B5, p0)

def ADD_PETROL_TRAIL_DECAL_INFO(x: float, y: float, z: float, p3: float) -> None:
    _iv(0x967278682CB6967A, x, y, z, p3)

def SET_PARTICLE_FX_SHOOTOUT_BOAT(p0: int) -> None:
    _iv(0x96EF97DAEB89BEF5, p0)

def _HAS_SCALEFORM_MOVIE_NAMED_LOADED(scaleformHandle: int, scaleformName: str) -> bool:
    return _ib(0x9743BCCF7CD6E1F6, scaleformHandle, scaleformName)

def BEGIN_SCALEFORM_SCRIPT_HUD_MOVIE_METHOD(hudComponent: int, methodName: str) -> bool:
    return _ib(0x98C494FD5BDFBFD5, hudComponent, methodName)

def UI3DSCENE_ASSIGN_PED_TO_SLOT(presetName: str, ped: int, slot: int, posX: float, posY: float, posZ: float) -> bool:
    return _ib(0x98C4FE6EC34154CA, presetName, ped, slot, posX, posY, posZ)

def GET_IS_TIMECYCLE_TRANSITIONING_OUT() -> bool:
    return _ib(0x98D18905BF723B99)

def REQUEST_EARLY_LIGHT_CHECK() -> None:
    _iv(0x98EDF76A7271E4F2)

def START_PETROL_TRAIL_DECALS(p0: float) -> None:
    _iv(0x99AC7F0D8B9C893D, p0)

def FORCE_POSTFX_BULLET_IMPACTS_AFTER_HUD(p0: bool) -> None:
    _iv(0x9B079E5221D984D3, p0)

def QUERY_MOVIE_MESH_SET_STATE(p0: int) -> int:
    return _ii(0x9B6E70C5CEEF4EEB, p0)

def WASH_DECALS_IN_RANGE(x: float, y: float, z: float, range: float, p4: float) -> None:
    _iv(0x9C30613D50A6ADEF, x, y, z, range, p4)

def ADD_ENTITY_ICON(entity: int, icon: str) -> int:
    return _ii(0x9CD43EEE12BF4DD0, entity, icon)

def GOLF_TRAIL_SET_SHADER_PARAMS(p0: float, p1: float, p2: float, p3: float, p4: float) -> None:
    _iv(0x9CFDD90B2B844BF7, p0, p1, p2, p3, p4)

def SEETHROUGH_SET_FADE_ENDDISTANCE(distance: float) -> None:
    _iv(0x9D75795B9DC6EBBF, distance)

def ENABLE_ALIEN_BLOOD_VFX(toggle: bool) -> None:
    _iv(0x9DCE1F0F78260875, toggle)

def TRIGGER_SCREENBLUR_FADE_IN(transitionTime: float) -> bool:
    return _ib(0xA328A24AAA6B7FDC, transitionTime)

def _FORCE_ALLOW_SNOW_FOOT_VFX_ON_ICE(toggle: bool) -> None:
    _iv(0xA342A3763B3AFB6C, toggle)

def TERRAINGRID_ACTIVATE(toggle: bool) -> None:
    _iv(0xA356990E161C9E65, toggle)

def DRAW_DEBUG_TEXT_2D(text: str, x: float, y: float, z: float, red: int, green: int, blue: int, alpha: int) -> None:
    _iv(0xA3BB2E9555C05A8F, text, x, y, z, red, green, blue, alpha)

def START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE(effectName: str, ped: int, offsetX: float, offsetY: float, offsetZ: float, rotX: float, rotY: float, rotZ: float, boneIndex: int, scale: float, axisX: bool, axisY: bool, axisZ: bool) -> bool:
    return _ib(0xA41B6A43642AC2CF, effectName, ped, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, boneIndex, scale, axisX, axisY, axisZ)

def REGISTER_NOIR_LENS_EFFECT() -> None:
    _iv(0xA44FF770DFBC5DAE)

def GOLF_TRAIL_GET_VISUAL_CONTROL_POINT(p0: int) -> 'gta.Vector3':
    return _ivec(0xA4664972A9B8F8BA, p0)

def SET_WEATHER_PTFX_USE_OVERRIDE_SETTINGS(p0: bool) -> None:
    _iv(0xA46B73FAA3460AE1, p0)

def GOLF_TRAIL_GET_MAX_HEIGHT() -> float:
    return _if(0xA4819F5E23E2FFAD)

def GOLF_TRAIL_SET_ENABLED(toggle: bool) -> None:
    _iv(0xA51C4B86B71652AE, toggle)

def BEGIN_TAKE_HIGH_QUALITY_PHOTO() -> bool:
    return _ib(0xA67C35C56EB1BD9D)

def REMOVE_DECALS_FROM_OBJECT_FACING(obj: int, x: float, y: float, z: float) -> None:
    _iv(0xA6F6F70FDC6D144C, obj, x, y, z)

def SEETHROUGH_SET_FADE_STARTDISTANCE(distance: float) -> None:
    _iv(0xA78DE25577300BA1, distance)

def SET_DRAW_ORIGIN(x: float, y: float, z: float, p3: bool) -> None:
    _iv(0xAA0008F3BBB8F416, x, y, z, p3)

def DRAW_DEBUG_SPHERE(x: float, y: float, z: float, radius: float, red: int, green: int, blue: int, alpha: int) -> None:
    _iv(0xAAD68E1AB39DA632, x, y, z, radius, red, green, blue, alpha)

def GRASSBATCH_ENABLE_FLATTENING_EXT_IN_SPHERE(x: float, y: float, z: float, p3: int, p4: float, p5: float, p6: float, scale: float) -> None:
    _iv(0xAAE9BE70EC7C69AB, x, y, z, p3, p4, p5, p6, scale)

def BEGIN_SCALEFORM_MOVIE_METHOD_ON_FRONTEND(methodName: str) -> bool:
    return _ib(0xAB58C27C2E6123C6, methodName)

def DRAW_POLY(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, x3: float, y3: float, z3: float, red: int, green: int, blue: int, alpha: int) -> None:
    _iv(0xAC26716048436851, x1, y1, z1, x2, y2, z2, x3, y3, z3, red, green, blue, alpha)

def SET_PARTICLE_FX_CAM_INSIDE_NONPLAYER_VEHICLE(vehicle: int, p1: bool) -> None:
    _iv(0xACEE6F360FC1F6B6, vehicle, p1)

def SET_ON_ISLAND_X_FOR_TAKEN_PHOTO(p0: int) -> None:
    _iv(0xADD6627C4D325458, p0)

def END_TEXT_COMMAND_UNPARSED_SCALEFORM_STRING() -> None:
    _iv(0xAE4E8157D9ECF087)

def PROCGRASS_ENABLE_CULLSPHERE(handle: int, x: float, y: float, z: float, scale: float) -> None:
    _iv(0xAE51BC858F32BA66, handle, x, y, z, scale)

def USE_SNOW_FOOT_VFX_WHEN_UNSHELTERED(toggle: bool) -> None:
    _iv(0xAEEDAD1420C65CC0, toggle)

def SET_BINK_MOVIE_VOLUME(binkMovie: int, value: float) -> None:
    _iv(0xAFF33B1178172223, binkMovie, value)

def CASCADE_SHADOWS_SET_SHADOW_SAMPLE_TYPE(type: str) -> None:
    _iv(0xB11D94BC55F41932, type)

def GOLF_TRAIL_SET_FIXED_CONTROL_POINT(type: int, xPos: float, yPos: float, zPos: float, p4: float, red: int, green: int, blue: int, alpha: int) -> None:
    _iv(0xB1BB03742917A5D6, type, xPos, yPos, zPos, p4, red, green, blue, alpha)

def DESTROY_TRACKED_POINT(point: int) -> None:
    _iv(0xB25DC90BAD56CA42, point)

def GET_SCREEN_ASPECT_RATIO() -> float:
    return _if(0xB2EBE8CBC58B90E9)

def ADD_DECAL(decalType: int, posX: float, posY: float, posZ: float, p4: float, p5: float, p6: float, p7: float, p8: float, p9: float, width: float, height: float, rCoef: float, gCoef: float, bCoef: float, opacity: float, timeout: float, p17: bool, p18: bool, p19: bool) -> int:
    return _ii(0xB302244A1839BDAD, decalType, posX, posY, posZ, p4, p5, p6, p7, p8, p9, width, height, rCoef, gCoef, bCoef, opacity, timeout, p17, p18, p19)

def SET_MOTIONBLUR_MAX_VEL_SCALER(p0: float) -> None:
    _iv(0xB3C641F3630BF6DA, p0)

def SET_PARTICLE_FX_LOOPED_SCALE(ptfxHandle: int, scale: float) -> None:
    _iv(0xB44250AAA456492D, ptfxHandle, scale)

def ANIMPOSTFX_STOP_ALL() -> None:
    _iv(0xB4EDDC19532BFB85)

def SET_LOCK_ADAPTIVE_DOF_DISTANCE(p0: bool) -> None:
    _iv(0xB569F41F3E7E83A4, p0)

def LOAD_MOVIE_MESH_SET(movieMeshSetName: str) -> int:
    return _ii(0xB66064452270E8F1, movieMeshSetName)

def UNPATCH_DECAL_DIFFUSE_MAP(decalType: int) -> None:
    _iv(0xB7ED70C49521A61D, decalType)

def SET_PARTICLE_FX_NON_LOOPED_SCALE(scale: float) -> None:
    _iv(0xB7EF5850C39FABCA, scale)

def SET_SCRIPT_GFX_ALIGN(horizontalAlign: int, verticalAlign: int) -> None:
    _iv(0xB8A850F20A067EB6, horizontalAlign, verticalAlign)

def REMOVE_PARTICLE_FX_FROM_ENTITY(entity: int) -> None:
    _iv(0xB8FEAEEBCC127425, entity)

def BEGIN_SCALEFORM_MOVIE_METHOD_ON_FRONTEND_HEADER(methodName: str) -> bool:
    return _ib(0xB9449845F73F5E9C, methodName)

def SET_CHECKPOINT_RGBA2(checkpoint: int, red: int, green: int, blue: int, alpha: int) -> None:
    _iv(0xB9EA40907C680580, checkpoint, red, green, blue, alpha)

def FORCE_PARTICLE_FX_IN_VEHICLE_INTERIOR(p0: int, p1: int) -> None:
    _iv(0xBA0127DA25FD54C9, p0, p1)

def SET_PARTICLE_FX_FOOT_OVERRIDE_NAME(p0: str) -> None:
    _iv(0xBA3D194057C79A7B, p0)

def SET_HIDOF_OVERRIDE(p0: bool, p1: bool, nearplaneOut: float, nearplaneIn: float, farplaneOut: float, farplaneIn: float) -> None:
    _iv(0xBA3D65906822BED5, p0, p1, nearplaneOut, nearplaneIn, farplaneOut, farplaneIn)

def SCALEFORM_MOVIE_METHOD_ADD_PARAM_TEXTURE_NAME_STRING(string: str) -> None:
    _iv(0xBA7148484BD90365, string)

def SET_TV_CHANNEL(channel: int) -> None:
    _iv(0xBAABBB23EB6E484E, channel)

def GET_SAFE_ZONE_SIZE() -> float:
    return _if(0xBAF107B6BB2C97F0)

def GET_EXTRA_TCMODIFIER() -> int:
    return _ii(0xBB0527EC6341496D)

def SET_PARTICLE_FX_BULLET_IMPACT_LODRANGE_SCALE(p0: float) -> None:
    _iv(0xBB90E12CAC1DAB25, p0)

def SET_CURRENT_PLAYER_TCMODIFIER(modifierName: str) -> None:
    _iv(0xBBF327DED94E4DEB, modifierName)

def PHONEPHOTOEDITOR_IS_ACTIVE() -> bool:
    return _ib(0xBCEDB009461DA156)

def REQUEST_SCALEFORM_MOVIE_SKIP_RENDER_WHILE_PAUSED(scaleformName: str) -> int:
    return _ii(0xBD06C611BB9048C2, scaleformName)

def SET_PLAYER_TCMODIFIER_TRANSITION(value: float) -> None:
    _iv(0xBDEB86F4D5809204, value)

def SET_GRASS_CULL_SPHERE(p0: float, p1: float, p2: float, p3: float) -> int:
    return _ii(0xBE197EAA669238F4, p0, p1, p2, p3)

def SET_STREAMED_TEXTURE_DICT_AS_NO_LONGER_NEEDED(textureDict: str) -> None:
    _iv(0xBE2CACCF5A8AA805, textureDict)

def CLEAR_TV_CHANNEL_PLAYLIST(tvChannel: int) -> None:
    _iv(0xBEB3D46BB7F043C0, tvChannel)

def SET_NEXT_PLAYER_TCMODIFIER(modifierName: str) -> None:
    _iv(0xBF59707B3E5ED531, modifierName)

def GOLF_TRAIL_SET_FIXED_CONTROL_POINT_ENABLE(p0: bool) -> None:
    _iv(0xC0416B061F2B7E5E, p0)

def DISABLE_HDTEX_THIS_FRAME() -> None:
    _iv(0xC35A6D07C93802B2)

def SCALEFORM_MOVIE_METHOD_ADD_PARAM_INT(value: int) -> None:
    _iv(0xC3D0841A0CC546A6, value)

def REMOVE_PARTICLE_FX(ptfxHandle: int, p1: bool) -> None:
    _iv(0xC401503DFE8D53CF, ptfxHandle, p1)

def IS_TRACKED_POINT_VISIBLE(point: int) -> bool:
    return _ib(0xC45CCDAAC9221CA8, point)

def END_SCALEFORM_MOVIE_METHOD_RETURN_VALUE() -> int:
    return _ii(0xC50AA39A577AF886)

def REQUEST_SCALEFORM_MOVIE_INSTANCE(scaleformName: str) -> int:
    return _ii(0xC514489CFB8AF806, scaleformName)

def SCALEFORM_MOVIE_METHOD_ADD_PARAM_BOOL(value: bool) -> None:
    _iv(0xC58424BA936EB458, value)

def SET_DEPTHWRITING(toggle: bool) -> None:
    _iv(0xC5C8F970D4EDFF71, toggle)

def SET_SCRIPT_GFX_DRAW_BEHIND_PAUSEMENU(toggle: bool) -> None:
    _iv(0xC6372ECD45D73BCD, toggle)

def SET_PTFX_FORCE_VEHICLE_INTERIOR_FLAG(p0: int) -> None:
    _iv(0xC6730E0D14E50703, p0)

def END_SCALEFORM_MOVIE_METHOD() -> None:
    _iv(0xC6796A8FFA375E53)

def IS_DECAL_ALIVE(decal: int) -> bool:
    return _ib(0xC694D74949CAFD0C, decal)

def START_PARTICLE_FX_LOOPED_ON_ENTITY_BONE(effectName: str, entity: int, xOffset: float, yOffset: float, zOffset: float, xRot: float, yRot: float, zRot: float, boneIndex: int, scale: float, xAxis: bool, yAxis: bool, zAxis: bool) -> int:
    return _ii(0xC6EB449E33977F0B, effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, zAxis)

def START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_ENTITY(effectName: str, entity: int, offsetX: float, offsetY: float, offsetZ: float, rotX: float, rotY: float, rotZ: float, scale: float, axisX: bool, axisY: bool, axisZ: bool) -> bool:
    return _ib(0xC95EB1DB6E92113D, effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, scale, axisX, axisY, axisZ)

def FADE_UP_PED_LIGHT(p0: float) -> None:
    _iv(0xC9B18B4619F48F7B, p0)

def DISABLE_VEHICLE_DISTANTLIGHTS(toggle: bool) -> None:
    _iv(0xC9F98AC1884E73A2, toggle)

def WATER_REFLECTION_SET_SCRIPT_OBJECT_VISIBILITY(p0: int) -> None:
    _iv(0xCA465D9CC0D231BA, p0)

def SET_PARTICLE_FX_BULLET_TRACE_NO_ANGLE_REJECT(p0: bool) -> None:
    _iv(0xCA4AE345A153D573, p0)

def SET_NOISINESSOVERIDE(value: float) -> None:
    _iv(0xCB6A7C3BB17A0C67, value)

def GET_STATUS_OF_CREATE_LOW_QUALITY_COPY_OF_PHOTO(p0: int) -> int:
    return _ii(0xCB82A0BF0E3E3265, p0)

def REMOVE_DECALS_FROM_OBJECT(obj: int) -> None:
    _iv(0xCCF71CBDDF5B6CB9, obj)

def DRAW_SCALEFORM_MOVIE_FULLSCREEN_MASKED(scaleform1: int, scaleform2: int, red: int, green: int, blue: int, alpha: int) -> None:
    _iv(0xCF537FDE4FBD4CE5, scaleform1, scaleform2, red, green, blue, alpha)

def DISABLE_IN_WATER_PTFX(toggle: bool) -> None:
    _iv(0xCFD16F0DB5A3535C, toggle)

def CALL_SCALEFORM_MOVIE_METHOD_WITH_NUMBER(scaleform: int, methodName: str, param1: float, param2: float, param3: float, param4: float, param5: float) -> None:
    _iv(0xD0837058AE2E4BEE, scaleform, methodName, param1, param2, param3, param4, param5)

def DRAW_SPOT_LIGHT(posX: float, posY: float, posZ: float, dirX: float, dirY: float, dirZ: float, colorR: int, colorG: int, colorB: int, distance: float, brightness: float, hardness: float, radius: float, falloff: float) -> None:
    _iv(0xD0F64B265C8C8B33, posX, posY, posZ, dirX, dirY, dirZ, colorR, colorG, colorB, distance, brightness, hardness, radius, falloff)

def SET_TV_PLAYER_WATCHING_THIS_FRAME(p0: int) -> None:
    _iv(0xD1C55B110E4DF534, p0)

def PASS_KEYBOARD_INPUT_TO_SCALEFORM(scaleformHandle: int) -> bool:
    return _ib(0xD1C7CB175E012964, scaleformHandle)

def ANIMPOSTFX_STOP_AND_FLUSH_REQUESTS(effectName: str) -> None:
    _iv(0xD2209BE128B5418C, effectName)

def REMOVE_VEHICLE_CREW_EMBLEM(vehicle: int, p1: int) -> None:
    _iv(0xD2300034310557E4, vehicle, p1)

def CASCADE_SHADOWS_SET_CASCADE_BOUNDS(p0: int, p1: bool, p2: float, p3: float, p4: float, p5: float, p6: bool, p7: float) -> None:
    _iv(0xD2936CAB8B58FCBD, p0, p1, p2, p3, p4, p5, p6, p7)

def CASCADE_SHADOWS_SET_DYNAMIC_DEPTH_MODE(p0: bool) -> None:
    _iv(0xD39D13C9FEBF0511, p0)

def UI3DSCENE_IS_AVAILABLE() -> bool:
    return _ib(0xD3A10FC7FD8D98CD)

def DRAW_BOX(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, red: int, green: int, blue: int, alpha: int) -> None:
    _iv(0xD3A9971CADAC7252, x1, y1, z1, x2, y2, z2, red, green, blue, alpha)

def SCALEFORM_MOVIE_METHOD_ADD_PARAM_FLOAT(value: float) -> None:
    _iv(0xD69736AAE04DB51A, value)

def PRESET_INTERIOR_AMBIENT_CACHE(timecycleModifierName: str) -> None:
    _iv(0xD7021272EB0A451E, timecycleModifierName)

def FADE_DECALS_IN_RANGE(x: float, y: float, z: float, p3: float, p4: float) -> None:
    _iv(0xD77EDADB0420E6E0, x, y, z, p3, p4)

def SEETHROUGH_SET_HEATSCALE(index: int, heatScale: float) -> None:
    _iv(0xD7D0B00177485411, index, heatScale)

def FREE_MEMORY_FOR_HIGH_QUALITY_PHOTO() -> None:
    _iv(0xD801CC02177FA3F1)

def GET_SCALEFORM_MOVIE_METHOD_RETURN_VALUE_BOOL(methodReturn: int) -> bool:
    return _ib(0xD80A80346A45D761, methodReturn)

def ENABLE_CLOWN_BLOOD_VFX(toggle: bool) -> None:
    _iv(0xD821490579791273, toggle)

def DRAW_DEBUG_LINE_WITH_TWO_COLOURS(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, r1: int, g1: int, b1: int, r2: int, g2: int, b2: int, alpha1: int, alpha2: int) -> None:
    _iv(0xD8B9A8AC5608FF94, x1, y1, z1, x2, y2, z2, r1, g1, b1, r2, g2, b2, alpha1, alpha2)

def SET_DISABLE_PETROL_DECALS_IGNITING_THIS_FRAME() -> None:
    _iv(0xD9454B5752C857DC)

def SET_CHECKPOINT_FORCE_DIRECTION(checkpoint: int) -> None:
    _iv(0xDB1EA9411C8911EC, checkpoint)

def GOLF_TRAIL_SET_TESSELLATION(p0: int, p1: int) -> None:
    _iv(0xDBAA5EC848BA2D46, p0, p1)

def FORCE_RENDER_IN_GAME_UI(toggle: bool) -> None:
    _iv(0xDC459CFA0CCE245B, toggle)

def GET_MAXIMUM_NUMBER_OF_CLOUD_PHOTOS() -> int:
    return _ii(0xDC54A7AF8B3A14EF)

def SET_PARTICLE_FX_LOOPED_FAR_CLIP_DIST(ptfxHandle: int, range: float) -> None:
    _iv(0xDCB194B85EF7B541, ptfxHandle, range)

def REMOVE_PARTICLE_FX_IN_RANGE(X: float, Y: float, Z: float, radius: float) -> None:
    _iv(0xDD19FA1C6D657305, X, Y, Z, radius)

def START_NETWORKED_PARTICLE_FX_LOOPED_ON_ENTITY_BONE(effectName: str, entity: int, xOffset: float, yOffset: float, zOffset: float, xRot: float, yRot: float, zRot: float, boneIndex: int, scale: float, xAxis: bool, yAxis: bool, zAxis: bool, r: float, g: float, b: float, a: float) -> int:
    return _ii(0xDDE23F30CC5A0F03, effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, zAxis, r, g, b, a)

def DISABLE_SCREENBLUR_FADE() -> None:
    _iv(0xDE81239437E8C5A8)

def UPDATE_LIGHTS_ON_ENTITY(entity: int) -> None:
    _iv(0xDEADC0DEDEADC0DE, entity)

def _START_VEHICLE_PARTICLE_FX_LOOPED(vehicle: int, effectName: str, frontBack: bool, leftRight: bool, localOnly: bool) -> int:
    return _ii(0xDF269BE2909E181A, vehicle, effectName, frontBack, leftRight, localOnly)

def HAS_SCALEFORM_SCRIPT_HUD_MOVIE_LOADED(hudComponent: int) -> bool:
    return _ib(0xDF6E5987D2B4D140, hudComponent)

def REQUEST_STREAMED_TEXTURE_DICT(textureDict: str, p1: bool) -> None:
    _iv(0xDFA2EF8E04127DD5, textureDict, p1)

def TOGGLE_PAUSED_RENDERPHASES(toggle: bool) -> None:
    _iv(0xDFC252D8A3E15AB7, toggle)

def SET_ENTITY_ICON_VISIBILITY(entity: int, toggle: bool) -> None:
    _iv(0xE0E8BEECCA96BA31, entity, toggle)

def START_PARTICLE_FX_LOOPED_AT_COORD(effectName: str, x: float, y: float, z: float, xRot: float, yRot: float, zRot: float, scale: float, xAxis: bool, yAxis: bool, zAxis: bool, p11: bool) -> int:
    return _ii(0xE184F4F0DC5910E7, effectName, x, y, z, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis, p11)

def RESET_PAUSED_RENDERPHASES() -> None:
    _iv(0xE1C8709406F2C41C)

def GET_SCALEFORM_MOVIE_METHOD_RETURN_VALUE_STRING(methodReturn: int) -> str:
    return _is(0xE1E258829A885245, methodReturn)

def SET_DISTANCE_BLUR_STRENGTH_OVERRIDE(p0: float) -> None:
    _iv(0xE2892E7E55D7073A, p0)

def SET_ARTIFICIAL_VEHICLE_LIGHTS_STATE(toggle: bool) -> None:
    _iv(0xE2B187C0939B3D32, toggle)

def CREATE_TRACKED_POINT() -> int:
    return _ii(0xE2C9439ED45DEA60)

def ANIMPOSTFX_GET_CURRENT_TIME(effectName: str) -> float:
    return _if(0xE35B38A27E8E7179, effectName)

def RESET_SCRIPT_GFX_ALIGN() -> None:
    _iv(0xE3A3DB414A373DAB)

def RESET_ADAPTATION(p0: int) -> None:
    _iv(0xE3E2C1B4C59DBC77, p0)

def GET_MOTIONBLUR_MAX_VEL_SCALER() -> float:
    return _if(0xE59343E9E96529E7)

def TOGGLE_PLAYER_DAMAGE_OVERLAY(toggle: bool) -> None:
    _iv(0xE63D7C6EECECB66B, toggle)

def SET_SCALEFORM_MOVIE_TO_USE_SUPER_LARGE_RT(scaleformHandle: int, toggle: bool) -> None:
    _iv(0xE6A9F00D4240B519, scaleformHandle, toggle)

def SET_NOISEOVERIDE(toggle: bool) -> None:
    _iv(0xE787BF1C5CF823C9, toggle)

def DOES_THIS_PHOTO_SLOT_CONTAIN_A_VALID_PHOTO(p0: int) -> bool:
    return _ib(0xE791DF1F73ED2C8B, p0)

def DRAW_SPRITE(textureDict: str, textureName: str, screenX: float, screenY: float, width: float, height: float, heading: float, red: int, green: int, blue: int, alpha: int, p11: bool, p12: int) -> None:
    _iv(0xE7FFAE5EBF23D890, textureDict, textureName, screenX, screenY, width, height, heading, red, green, blue, alpha, p11, p12)

def DRAW_MARKER_EX(type: int, posX: float, posY: float, posZ: float, dirX: float, dirY: float, dirZ: float, rotX: float, rotY: float, rotZ: float, scaleX: float, scaleY: float, scaleZ: float, red: int, green: int, blue: int, alpha: int, bobUpAndDown: bool, faceCamera: bool, p19: int, rotate: bool, textureDict: str, textureName: str, drawOnEnts: bool, p24: bool, p25: bool) -> None:
    _iv(0xE82728F0DE75D13A, type, posX, posY, posZ, dirX, dirY, dirZ, rotX, rotY, rotZ, scaleX, scaleY, scaleZ, red, green, blue, alpha, bobUpAndDown, faceCamera, p19, rotate, textureDict, textureName, drawOnEnts, p24, p25)

def SCALEFORM_MOVIE_METHOD_ADD_PARAM_PLAYER_NAME_STRING(string: str) -> None:
    _iv(0xE83A3E3557A56640, string)

def REMOVE_DECALS_FROM_VEHICLE(vehicle: int) -> None:
    _iv(0xE91F1B65F2B48D57, vehicle)

def SET_PARTICLE_FX_OVERRIDE(oldAsset: str, newAsset: str) -> None:
    _iv(0xEA1E2D93F6F75ED9, oldAsset, newAsset)

def RELEASE_MOVIE_MESH_SET(movieMeshSet: int) -> None:
    _iv(0xEB119AA014E89183, movieMeshSet)

def GET_TOGGLE_PAUSED_RENDERPHASES_STATUS() -> bool:
    return _ib(0xEB3DAC2C86001E5E)

def SCALEFORM_MOVIE_METHOD_ADD_PARAM_LATEST_BRIEF_STRING(value: int) -> None:
    _iv(0xEC52C631A1831C03, value)

def LOAD_HIGH_QUALITY_PHOTO(p0: int) -> bool:
    return _ib(0xEC72C258667BE5EA, p0)

def REMOVE_DECAL(decal: int) -> None:
    _iv(0xED3F346429CCD659, decal)

def _SET_TV_CHANNEL_PLAYLIST_DIRTY(tvChannel: int, p1: bool) -> int:
    return _ii(0xEE831F15A8D0D94A, tvChannel, p1)

def SET_PARTICLE_FX_CAM_INSIDE_VEHICLE(p0: bool) -> None:
    _iv(0xEEC4047028426510, p0)

def SET_EXPOSURETWEAK(toggle: bool) -> None:
    _iv(0xEF398BEEE4EF45F9, toggle)

def CALL_SCALEFORM_MOVIE_METHOD_WITH_NUMBER_AND_STRING(scaleform: int, methodName: str, floatParam1: float, floatParam2: float, floatParam3: float, floatParam4: float, floatParam5: float, stringParam1: str, stringParam2: str, stringParam3: str, stringParam4: str, stringParam5: str) -> None:
    _iv(0xEF662D8D57E290B1, scaleform, methodName, floatParam1, floatParam2, floatParam3, floatParam4, floatParam5, stringParam1, stringParam2, stringParam3, stringParam4, stringParam5)

def ADJUST_NEXT_POS_SIZE_AS_NORMALIZED_16_9() -> None:
    _iv(0xEFABC7722293DA7C)

def TRIGGER_SCREENBLUR_FADE_OUT(transitionTime: float) -> bool:
    return _ib(0xEFACC8AEF94430D5, transitionTime)

def OVERRIDE_INTERIOR_SMOKE_END() -> None:
    _iv(0xEFB55E7C25D3B3BE)

def DISABLE_REGION_VFX(p0: int) -> None:
    _iv(0xEFD97FF47B745B8D, p0)

def GET_ASPECT_RATIO(b: bool) -> float:
    return _if(0xF1307EF624A80D87, b)

def UI3DSCENE_PUSH_PRESET(presetName: str) -> bool:
    return _ib(0xF1CEA8A4198D8E9A, presetName)

def START_PARTICLE_FX_LOOPED_ON_PED_BONE(effectName: str, ped: int, xOffset: float, yOffset: float, zOffset: float, xRot: float, yRot: float, zRot: float, boneIndex: int, scale: float, xAxis: bool, yAxis: bool, zAxis: bool) -> int:
    return _ii(0xF28DA9F38CD1787C, effectName, ped, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, zAxis)

def DRAW_LIGHT_WITH_RANGE(posX: float, posY: float, posZ: float, colorR: int, colorG: int, colorB: int, range: float, intensity: float) -> None:
    _iv(0xF2A1B2771A01DBD4, posX, posY, posZ, colorR, colorG, colorB, range, intensity)

def SET_ARENA_THEME_AND_VARIATION_FOR_TAKEN_PHOTO(p0: int, p1: int) -> None:
    _iv(0xF3F776ADA161E47D, p0, p1)

def REMOVE_SCALEFORM_SCRIPT_HUD_MOVIE(hudComponent: int) -> None:
    _iv(0xF44A5456AC3F4F97, hudComponent)

def DRAW_LIGHT_WITH_RANGEEX(x: float, y: float, z: float, r: int, g: int, b: int, range: float, intensity: float, shadow: float) -> None:
    _iv(0xF49E9A9716A04595, x, y, z, r, g, b, range, intensity, shadow)

def SET_CHECKPOINT_CLIPPLANE_WITH_POS_NORM(checkpoint: int, posX: float, posY: float, posZ: float, unkX: float, unkY: float, unkZ: float) -> None:
    _iv(0xF51D36185993515D, checkpoint, posX, posY, posZ, unkX, unkY, unkZ)

def START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD(effectName: str, xPos: float, yPos: float, zPos: float, xRot: float, yRot: float, zRot: float, scale: float, xAxis: bool, yAxis: bool, zAxis: bool, p11: bool) -> bool:
    return _ib(0xF56B8137DF10135D, effectName, xPos, yPos, zPos, xRot, yRot, zRot, scale, xAxis, yAxis, zAxis, p11)

def SET_SCRIPT_GFX_ALIGN_PARAMS(x: float, y: float, w: float, h: float) -> None:
    _iv(0xF5A2C681787E579D, x, y, w, h)

def GET_STATUS_OF_SORTED_LIST_OPERATION(p0: int) -> int:
    return _ii(0xF5BED327CEA362B1, p0)

def DELETE_CHECKPOINT(checkpoint: int) -> None:
    _iv(0xF5ED37F54CD4D52E, checkpoint)

def BEGIN_SCALEFORM_MOVIE_METHOD(scaleform: int, methodName: str) -> bool:
    return _ib(0xF6E48914C7A8694E, scaleform, methodName)

def SET_WEATHER_PTFX_OVERRIDE_CURR_LEVEL(p0: float) -> None:
    _iv(0xF78B803082D4386F, p0)

def SET_TV_CHANNEL_PLAYLIST(tvChannel: int, playlistName: str, restart: bool) -> None:
    _iv(0xF7B38B8305F1FE8B, tvChannel, playlistName, restart)

def SET_PARTICLE_FX_LOOPED_OFFSETS(ptfxHandle: int, x: float, y: float, z: float, rotX: float, rotY: float, rotZ: float) -> None:
    _iv(0xF7DDEBEC43483C43, ptfxHandle, x, y, z, rotX, rotY, rotZ)

def SET_BINK_MOVIE_AUDIO_FRONTEND(binkMovie: int, p1: bool) -> None:
    _iv(0xF816F2933752322D, binkMovie, p1)

def CALL_SCALEFORM_MOVIE_METHOD(scaleform: int, method: str) -> None:
    _iv(0xFBD96D87AC96D533, scaleform, method)

def GET_TV_CHANNEL() -> int:
    return _ii(0xFC1E275A90D39995)

def SET_CHECKPOINT_FORCE_OLD_ARROW_POINTING(checkpoint: int) -> None:
    _iv(0xFCF6788FC4860CD4, checkpoint)

def DRAW_TV_CHANNEL(xPos: float, yPos: float, xScale: float, yScale: float, rotation: float, red: int, green: int, blue: int, alpha: int) -> None:
    _iv(0xFDDC2B4ED3C69DF0, xPos, yPos, xScale, yScale, rotation, red, green, blue, alpha)

def GET_TIMECYCLE_MODIFIER_INDEX() -> int:
    return _ii(0xFDF3D97C674AFB66)

def GET_VEHICLE_CREW_EMBLEM_REQUEST_STATE(vehicle: int, p1: int) -> int:
    return _ii(0xFE26117A5841B2FF, vehicle, p1)

def SEETHROUGH_SET_NOISE_MAX(amount: float) -> None:
    _iv(0xFEBFBFDFB66039DE, amount)

def CLEAR_DRAW_ORIGIN() -> None:
    _iv(0xFF0B610F6BE0D7AF)

def SEETHROUGH_SET_NOISE_MIN(amount: float) -> None:
    _iv(0xFF5992E1C9E65D05, amount)
