"""Auto-generated raw native bindings for namespace WEAPON.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if


def GET_AMMO_IN_PED_WEAPON(ped: int, weaponhash: int) -> int:
    return _ii(0x015A522136D7F951, ped, weaponhash)

def GET_WEAPON_TIME_BETWEEN_SHOTS(weaponHash: int) -> float:
    return _if(0x065D2AACAD8CF7A4, weaponHash)

def SET_PED_CURRENT_WEAPON_VISIBLE(ped: int, visible: bool, deselectWeapon: bool, p3: bool, p4: bool) -> None:
    _iv(0x0725A4CCFDED9A70, ped, visible, deselectWeapon, p3, p4)

def GET_SELECTED_PED_WEAPON(ped: int) -> int:
    return _ii(0x0A6DB4965674D243, ped)

def REMOVE_AIR_DEFENCE_SPHERE(zoneId: int) -> bool:
    return _ib(0x0ABF535877897560, zoneId)

def IS_PED_WEAPON_COMPONENT_ACTIVE(ped: int, weaponHash: int, componentHash: int) -> bool:
    return _ib(0x0D78DE0572D3969E, ped, weaponHash, componentHash)

def GET_WEAPON_COMPONENT_TYPE_MODEL(componentHash: int) -> int:
    return _ii(0x0DB57B41EC1DB083, componentHash)

def CLEAR_PED_LAST_WEAPON_DAMAGE(ped: int) -> None:
    _iv(0x0E98F88A24C5F4B8, ped)

def GET_CURRENT_PED_VEHICLE_WEAPON(ped: int, weaponHash: int) -> bool:
    return _ib(0x1017582BCD3832DC, ped, weaponHash)

def SET_WEAPON_ANIMATION_OVERRIDE(ped: int, animStyle: int) -> None:
    _iv(0x1055AC3A667F09D9, ped, animStyle)

def _SET_WEAPON_PED_DAMAGE_MODIFIER(weapon: int, damageModifier: float) -> None:
    _iv(0x1091922715B68DF0, weapon, damageModifier)

def HAS_ENTITY_BEEN_DAMAGED_BY_WEAPON(entity: int, weaponHash: int, weaponType: int) -> bool:
    return _ib(0x131D401334815E94, entity, weaponHash, weaponType)

def SET_PED_AMMO(ped: int, weaponHash: int, ammo: int, p3: bool) -> None:
    _iv(0x14E56BC5B5DB6A19, ped, weaponHash, ammo, p3)

def SET_PED_INFINITE_AMMO_CLIP(ped: int, toggle: bool) -> None:
    _iv(0x183DADC6AA953186, ped, toggle)

def REMOVE_ALL_AIR_DEFENCE_SPHERES() -> None:
    _iv(0x1E45B34ADEBEE48E)

def REMOVE_WEAPON_COMPONENT_FROM_PED(ped: int, weaponHash: int, componentHash: int) -> None:
    _iv(0x1E8BE90C74FB4C09, ped, weaponHash, componentHash)

def SET_PED_DROPS_INVENTORY_WEAPON(ped: int, weaponHash: int, xOffset: float, yOffset: float, zOffset: float, ammoCount: int) -> None:
    _iv(0x208A1888007FC0E6, ped, weaponHash, xOffset, yOffset, zOffset, ammoCount)

def MAKE_PED_RELOAD(ped: int) -> bool:
    return _ib(0x20AE33F3AC9C0033, ped)

def ADD_PED_AMMO_BY_TYPE(ped: int, ammoTypeHash: int, ammo: int) -> None:
    _iv(0x2472622CE1F2D45F, ped, ammoTypeHash, ammo)

def SET_PED_STUN_GUN_FINITE_AMMO(p0: int, p1: int) -> None:
    _iv(0x24C024BA8379A70A, p0, p1)

def _GET_AMMO_IN_VEHICLE_WEAPON_CLIP(vehicle: int, seat: int, ammo: int) -> bool:
    return _ib(0x2857938C5D407AFA, vehicle, seat, ammo)

def GET_PED_WEAPON_TINT_INDEX(ped: int, weaponHash: int) -> int:
    return _ii(0x2B9EEDC07BD06B9F, ped, weaponHash)

def HAS_PED_BEEN_DAMAGED_BY_WEAPON(ped: int, weaponHash: int, weaponType: int) -> bool:
    return _ib(0x2D343D2219CD027A, ped, weaponHash, weaponType)

def GET_AMMO_IN_CLIP(ped: int, weaponHash: int, ammo: int) -> bool:
    return _ib(0x2E1202248937775C, ped, weaponHash, ammo)

def GET_WEAPON_DAMAGE(weaponHash: int, componentHash: int) -> float:
    return _if(0x3133B907D8B32053, weaponHash, componentHash)

def GIVE_WEAPON_COMPONENT_TO_WEAPON_OBJECT(weaponObject: int, componentHash: int) -> None:
    _iv(0x33E179436C0B31DB, weaponObject, componentHash)

def HAS_WEAPON_ASSET_LOADED(weaponHash: int) -> bool:
    return _ib(0x36E353271F0E90EE, weaponHash)

def GET_PED_AMMO_BY_TYPE(ped: int, ammoTypeHash: int) -> int:
    return _ii(0x39D22031557946C1, ped, ammoTypeHash)

def GET_CURRENT_PED_WEAPON(ped: int, weaponHash: int, p2: bool) -> bool:
    return _ib(0x3A87E44BB9A01D54, ped, weaponHash, p2)

def GET_CURRENT_PED_WEAPON_ENTITY_INDEX(ped: int, p1: int) -> int:
    return _ii(0x3B390A939AF0B5FC, ped, p1)

def GET_WEAPON_DAMAGE_TYPE(weaponHash: int) -> int:
    return _ii(0x3BE0BB12D25FB305, weaponHash)

def SET_PED_INFINITE_AMMO(ped: int, toggle: bool, weaponHash: int) -> None:
    _iv(0x3EDCB0505123623B, ped, toggle, weaponHash)

def GET_WEAPONTYPE_SLOT(weaponHash: int) -> int:
    return _ii(0x4215460B9B8B7FA0, weaponHash)

def FIRE_AIR_DEFENCE_SPHERE_WEAPON_AT_POSITION(zoneId: int, x: float, y: float, z: float) -> None:
    _iv(0x44F1012B69313374, zoneId, x, y, z)

def IS_PED_ARMED(ped: int, typeFlags: int) -> bool:
    return _ib(0x475768A975D5AD17, ped, typeFlags)

def SET_WEAPON_DAMAGE_MODIFIER(weaponHash: int, damageMultiplier: float) -> None:
    _iv(0x4757F00BC6323CFE, weaponHash, damageMultiplier)

def SET_PED_DROPS_WEAPONS_WHEN_DEAD(ped: int, toggle: bool) -> None:
    _iv(0x476AE72C1D19D1A8, ped, toggle)

def REQUEST_WEAPON_HIGH_DETAIL_MODEL(weaponObject: int) -> None:
    _iv(0x48164DBB970AC3F0, weaponObject)

def REMOVE_WEAPON_FROM_PED(ped: int, weaponHash: int) -> None:
    _iv(0x4899CB088EDF59B8, ped, weaponHash)

def SET_WEAPON_AOE_MODIFIER(weaponHash: int, multiplier: float) -> None:
    _iv(0x4AE5AC8B852D642C, weaponHash, multiplier)

def IS_FLASH_LIGHT_ON(ped: int) -> bool:
    return _ib(0x4B7620C47217126C, ped)

def GET_WEAPON_COMPONENT_VARIANT_EXTRA_MODEL(componentHash: int, extraComponentIndex: int) -> int:
    return _ii(0x4D1CB8DC40208A17, componentHash, extraComponentIndex)

def SET_PED_CYCLE_VEHICLE_WEAPONS_ONLY(ped: int) -> None:
    _iv(0x50276EF8172F5F12, ped)

def SET_PED_WEAPON_TINT_INDEX(ped: int, weaponHash: int, tintIndex: int) -> None:
    _iv(0x50969B9B89ED5738, ped, weaponHash, tintIndex)

def REQUEST_WEAPON_ASSET(weaponHash: int, p1: int, p2: int) -> None:
    _iv(0x5443438F033E29C3, weaponHash, p1, p2)

def GET_WEAPON_CLIP_SIZE(weaponHash: int) -> int:
    return _ii(0x583BE370B1EC6EB4, weaponHash)

def GET_MAX_AMMO_BY_TYPE(ped: int, ammoTypeHash: int, ammo: int) -> bool:
    return _ib(0x585847C5E4E11709, ped, ammoTypeHash, ammo)

def _TRIGGER_VEHICLE_WEAPON_RELOAD(vehicle: int, seat: int, ped: int) -> bool:
    return _ib(0x5B1513F27F279A44, vehicle, seat, ped)

def DOES_WEAPON_TAKE_WEAPON_COMPONENT(weaponHash: int, componentHash: int) -> bool:
    return _ib(0x5CEE3DF569CECAB0, weaponHash, componentHash)

def SET_WEAPON_OBJECT_COMPONENT_TINT_INDEX(weaponObject: int, camoComponentHash: int, colorIndex: int) -> None:
    _iv(0x5DA825A85D0EA6E6, weaponObject, camoComponentHash, colorIndex)

def GET_WEAPON_TINT_COUNT(weaponHash: int) -> int:
    return _ii(0x5DCF6C5CAB2E9BF7, weaponHash)

def SET_PED_AMMO_BY_TYPE(ped: int, ammoTypeHash: int, ammo: int) -> None:
    _iv(0x5FD1E1F011E76D7E, ped, ammoTypeHash, ammo)

def GET_WEAPON_COMPONENT_VARIANT_EXTRA_COUNT(componentHash: int) -> int:
    return _ii(0x6558AC7C17BFEF58, componentHash)

def IS_PED_CURRENT_WEAPON_SILENCED(ped: int) -> bool:
    return _ib(0x65F0C5AE05943EC7, ped)

def GIVE_LOADOUT_TO_PED(ped: int, loadoutHash: int) -> None:
    _iv(0x68F8BE6AF5CDF8A6, ped, loadoutHash)

def SET_PED_DROPS_WEAPON(ped: int) -> None:
    _iv(0x6B7513D9966FBEC0, ped)

def GET_PED_LAST_WEAPON_IMPACT_COORD(ped: int, coords: int) -> bool:
    return _ib(0x6C4D0409BA1A2BC2, ped, coords)

def HIDE_PED_WEAPON_FOR_SCRIPTED_CUTSCENE(ped: int, toggle: bool) -> None:
    _iv(0x6F6981D2253C208F, ped, toggle)

def HAS_VEHICLE_GOT_PROJECTILE_ATTACHED(driver: int, vehicle: int, weaponHash: int, p3: int) -> bool:
    return _ib(0x717C8481234E3B88, driver, vehicle, weaponHash, p3)

def SET_CURRENT_PED_VEHICLE_WEAPON(ped: int, weaponHash: int) -> bool:
    return _ib(0x75C55983C2C39DAA, ped, weaponHash)

def HAS_WEAPON_GOT_WEAPON_COMPONENT(weapon: int, componentHash: int) -> bool:
    return _ib(0x76A18844E743BF91, weapon, componentHash)

def ADD_AMMO_TO_PED(ped: int, weaponHash: int, ammo: int) -> None:
    _iv(0x78F0424C34306220, ped, weaponHash, ammo)

def GET_PED_AMMO_TYPE_FROM_WEAPON(ped: int, weaponHash: int) -> int:
    return _ii(0x7FEAD38B326B9F74, ped, weaponHash)

def _HAS_WEAPON_RELOADING_IN_VEHICLE(vehicle: int, seat: int) -> bool:
    return _ib(0x8062F07153F4446F, vehicle, seat)

def GET_MAX_RANGE_OF_CURRENT_PED_WEAPON(ped: int) -> float:
    return _if(0x814C9D19DFD69679, ped)

def SET_PED_CHANCE_OF_FIRING_BLANKS(ped: int, xBias: float, yBias: float) -> None:
    _iv(0x8378627201D5497D, ped, xBias, yBias)

def GET_LOCKON_DISTANCE_OF_CURRENT_PED_WEAPON(ped: int) -> float:
    return _if(0x840F03E9041E2C9C, ped)

def GET_BEST_PED_WEAPON(ped: int, p1: bool) -> int:
    return _ii(0x8483E98E8B888AE2, ped, p1)

def _SET_AMMO_IN_VEHICLE_WEAPON_CLIP(vehicle: int, seat: int, ammo: int) -> bool:
    return _ib(0x873906720EE842C3, vehicle, seat, ammo)

def REFILL_AMMO_INSTANTLY(ped: int) -> bool:
    return _ib(0x8C0D57EA686FAD87, ped)

def HAS_PED_GOT_WEAPON(ped: int, weaponHash: int, p2: bool) -> bool:
    return _ib(0x8DECB02F88F428BC, ped, weaponHash, p2)

def CREATE_AIR_DEFENCE_SPHERE(x: float, y: float, z: float, radius: float, p4: float, p5: float, p6: float, weaponHash: int) -> int:
    return _ii(0x91EF34584710BE99, x, y, z, radius, p4, p5, p6, weaponHash)

def IS_WEAPON_VALID(weaponHash: int) -> bool:
    return _ib(0x937C71165CF334B3, weaponHash)

def CREATE_WEAPON_OBJECT(weaponHash: int, ammoCount: int, x: float, y: float, z: float, showWorldModel: bool, scale: float, p7: int, p8: int, p9: int) -> int:
    return _ii(0x9541D3CF0D398F36, weaponHash, ammoCount, x, y, z, showWorldModel, scale, p7, p8, p9)

def SET_WEAPON_OBJECT_CAMO_INDEX(weaponObject: int, p1: int) -> None:
    _iv(0x977CA98939E82E4B, weaponObject, p1)

def SET_FLASH_LIGHT_ACTIVE_HISTORY(ped: int, toggle: bool) -> None:
    _iv(0x988DB6FE9B3AC000, ped, toggle)

def CREATE_AIR_DEFENCE_ANGLED_AREA(p0: float, p1: float, p2: float, p3: float, p4: float, p5: float, p6: float, p7: float, p8: float, radius: float, weaponHash: int) -> int:
    return _ii(0x9DA58CDBF6BDBC08, p0, p1, p2, p3, p4, p5, p6, p7, p8, radius, weaponHash)

def SET_PED_WEAPON_COMPONENT_TINT_INDEX(ped: int, weaponHash: int, camoComponentHash: int, colorIndex: int) -> None:
    _iv(0x9FE5633880ECD8ED, ped, weaponHash, camoComponentHash, colorIndex)

def GET_PED_WEAPON_CAMO_INDEX(ped: int, weaponHash: int) -> int:
    return _ii(0xA2C9AC24B4061285, ped, weaponHash)

def GET_MAX_AMMO_IN_CLIP(ped: int, weaponHash: int, p2: bool) -> int:
    return _ii(0xA38DCFFCEA8962FA, ped, weaponHash, p2)

def SET_PED_AMMO_TO_DROP(ped: int, p1: int) -> None:
    _iv(0xA4EFEF9440A5B0EF, ped, p1)

def REMOVE_WEAPON_ASSET(weaponHash: int) -> None:
    _iv(0xAA08EF13F341C8FC, weaponHash)

def CLEAR_ENTITY_LAST_WEAPON_DAMAGE(entity: int) -> None:
    _iv(0xAC678E40BE7C74D2, entity)

def SET_CURRENT_PED_WEAPON(ped: int, weaponHash: int, bForceInHand: bool) -> None:
    _iv(0xADF692B254977C0C, ped, weaponHash, bForceInHand)

def GIVE_WEAPON_OBJECT_TO_PED(weaponObject: int, ped: int) -> None:
    _iv(0xB1FA61371AF7C4B7, weaponObject, ped)

def GIVE_DELAYED_WEAPON_TO_PED(ped: int, weaponHash: int, ammoCount: int, bForceInHand: bool) -> None:
    _iv(0xB282DC6EBD803C75, ped, weaponHash, ammoCount, bForceInHand)

def GET_WEAPON_COMPONENT_HUD_STATS(componentHash: int, outData: int) -> bool:
    return _ib(0xB3CAF387AE12E9F8, componentHash, outData)

def GET_WEAPON_OBJECT_COMPONENT_TINT_INDEX(weaponObject: int, camoComponentHash: int) -> int:
    return _ii(0xB3EA4FEABF41464B, weaponObject, camoComponentHash)

def SET_CAN_PED_SELECT_INVENTORY_WEAPON(ped: int, weaponHash: int, toggle: bool) -> None:
    _iv(0xB4771B9AAF4E68E4, ped, weaponHash, toggle)

def SET_PED_SHOOT_ORDNANCE_WEAPON(ped: int, p1: float) -> int:
    return _ii(0xB4C8D77C80C0421E, ped, p1)

def IS_PED_WEAPON_READY_TO_SHOOT(ped: int) -> bool:
    return _ib(0xB80CA294F2F26749, ped)

def CAN_USE_WEAPON_ON_PARACHUTE(weaponHash: int) -> bool:
    return _ib(0xBC7BE5ABC0879F74, weaponHash)

def GIVE_WEAPON_TO_PED(ped: int, weaponHash: int, ammoCount: int, isHidden: bool, bForceInHand: bool) -> None:
    _iv(0xBF0FD6E56C964FCB, ped, weaponHash, ammoCount, isHidden, bForceInHand)

def GET_WEAPONTYPE_GROUP(weaponHash: int) -> int:
    return _ii(0xC3287EE3050FB74C, weaponHash)

def HAS_PED_GOT_WEAPON_COMPONENT(ped: int, weaponHash: int, componentHash: int) -> bool:
    return _ib(0xC593212475FAE340, ped, weaponHash, componentHash)

def ENABLE_LASER_SIGHT_RENDERING(toggle: bool) -> None:
    _iv(0xC8B46D7727D864AA, toggle)

def _GET_TIME_BEFORE_VEHICLE_WEAPON_RELOAD_FINISHES(vehicle: int, seat: int) -> int:
    return _ii(0xC8C6F4B1CDEB40EF, vehicle, seat)

def GET_WEAPON_OBJECT_FROM_PED(ped: int, p1: bool) -> int:
    return _ii(0xCAE1DC9A0E22A16D, ped, p1)

def GET_WEAPON_OBJECT_TINT_INDEX(weapon: int) -> int:
    return _ii(0xCD183314F7CD2E57, weapon)

def DOES_AIR_DEFENCE_SPHERE_EXIST(zoneId: int) -> bool:
    return _ib(0xCD79A550999D7D4F, zoneId)

def SET_FLASH_LIGHT_FADE_DISTANCE(distance: float) -> bool:
    return _ib(0xCEA66DAD478CD39B, distance)

def _GET_VEHICLE_WEAPON_RELOAD_TIME(vehicle: int, seat: int) -> float:
    return _if(0xD0AD348FFD7A6868, vehicle, seat)

def SET_PED_GADGET(ped: int, gadgetHash: int, p2: bool) -> None:
    _iv(0xD0D7B1E680ED4A1A, ped, gadgetHash, p2)

def GET_WEAPON_HUD_STATS(weaponHash: int, outData: int) -> bool:
    return _ib(0xD92C739EE34C9EBA, weaponHash, outData)

def GIVE_WEAPON_COMPONENT_TO_PED(ped: int, weaponHash: int, componentHash: int) -> None:
    _iv(0xD966D51AA5B28BB9, ped, weaponHash, componentHash)

def IS_AIR_DEFENCE_SPHERE_IN_AREA(x: float, y: float, z: float, radius: float, outZoneId: int) -> bool:
    return _ib(0xDAB963831DBFD3F4, x, y, z, radius, outZoneId)

def GET_MAX_AMMO(ped: int, weaponHash: int, ammo: int) -> bool:
    return _ib(0xDC16122C7A20C933, ped, weaponHash, ammo)

def SET_AMMO_IN_CLIP(ped: int, weaponHash: int, ammo: int) -> bool:
    return _ib(0xDCD2A934D65CB497, ped, weaponHash, ammo)

def SET_EQIPPED_WEAPON_START_SPINNING_AT_FULL_SPEED(ped: int) -> None:
    _iv(0xE4DCEC7FD5B739A5, ped)

def SET_PICKUP_AMMO_AMOUNT_SCALER(p0: float) -> None:
    _iv(0xE620FD3512A04F18, p0)

def SET_WEAPON_EFFECT_DURATION_MODIFIER(p0: int, p1: float) -> None:
    _iv(0xE6D2CEDD370FF98E, p0, p1)

def SET_PLAYER_TARGETTABLE_FOR_AIR_DEFENCE_SPHERE(player: int, zoneId: int, enable: bool) -> None:
    _iv(0xECDC202B25E5CF48, player, zoneId, enable)

def SET_CAN_PED_SELECT_ALL_WEAPONS(ped: int, toggle: bool) -> None:
    _iv(0xEFF296097FF1E509, ped, toggle)

def GET_PED_WEAPONTYPE_IN_SLOT(ped: int, weaponSlot: int) -> int:
    return _ii(0xEFFED78E9011134D, ped, weaponSlot)

def GET_PED_WEAPON_COMPONENT_TINT_INDEX(ped: int, weaponHash: int, camoComponentHash: int) -> int:
    return _ii(0xF0A60040BE558F2D, ped, weaponHash, camoComponentHash)

def REMOVE_ALL_PED_WEAPONS(ped: int, p1: bool) -> None:
    _iv(0xF25DF915FA38C5F3, ped, p1)

def GET_WEAPONTYPE_MODEL(weaponHash: int) -> int:
    return _ii(0xF46CDC33180FDA94, weaponHash)

def GET_PED_ORIGINAL_AMMO_TYPE_FROM_WEAPON(ped: int, weaponHash: int) -> int:
    return _ii(0xF489B44DD5AF4BD9, ped, weaponHash)

def GET_IS_PED_GADGET_EQUIPPED(ped: int, gadgetHash: int) -> bool:
    return _ib(0xF731332072F5156C, ped, gadgetHash)

def REMOVE_WEAPON_COMPONENT_FROM_WEAPON_OBJECT(object: int, componentHash: int) -> None:
    _iv(0xF7D82B0D66777611, object, componentHash)

def SET_WEAPON_OBJECT_TINT_INDEX(weapon: int, tintIndex: int) -> None:
    _iv(0xF827589017D4E4A9, weapon, tintIndex)

def EXPLODE_PROJECTILES(ped: int, weaponHash: int, p2: bool) -> None:
    _iv(0xFC4BD125DE7611E4, ped, weaponHash, p2)

def REMOVE_ALL_PROJECTILES_OF_TYPE(weaponHash: int, explode: bool) -> None:
    _iv(0xFC52E0F37E446528, weaponHash, explode)
