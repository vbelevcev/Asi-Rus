"""Auto-generated raw native bindings for namespace EXTRAMETADATA.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii


def GET_SHOP_PED_APPAREL_FORCED_PROP_COUNT(componentHash: int) -> int:
    return _ii(0x017568A8182D98A6, componentHash)

def GET_HASH_NAME_FOR_COMPONENT(entity: int, componentId: int, drawableVariant: int, textureVariant: int) -> int:
    return _ii(0x0368B3A838070348, entity, componentId, drawableVariant, textureVariant)

def IS_DLC_VEHICLE_MOD(hash: int) -> bool:
    return _ib(0x0564B9FF9631B82C, hash)

def GET_SHOP_PED_OUTFIT_LOCATE(p0: int) -> int:
    return _ii(0x073CA26B079F956E, p0)

def GET_TATTOO_SHOP_DLC_ITEM_INDEX(overlayHash: int, p1: int, character: int) -> int:
    return _ii(0x10144267DD22866C, overlayHash, p1, character)

def GET_SHOP_PED_OUTFIT_COMPONENT_VARIANT(outfitHash: int, variantIndex: int, outComponentVariant: int) -> bool:
    return _ib(0x19F2A026EDF0013F, outfitHash, variantIndex, outComponentVariant)

def INIT_SHOP_PED_COMPONENT(outComponent: int) -> None:
    _iv(0x1E8C308FD312C036, outComponent)

def GET_SHOP_PED_QUERY_COMPONENT(componentId: int, outComponent: int) -> None:
    _iv(0x249E310B2D920699, componentId, outComponent)

def GET_NUM_TATTOO_SHOP_DLC_ITEMS(character: int) -> int:
    return _ii(0x278F76C3B0A8F109, character)

def GET_DLC_WEAPON_DATA_SP(dlcWeaponIndex: int, outData: int) -> bool:
    return _ib(0x310836EE7129BA33, dlcWeaponIndex, outData)

def GET_DLC_WEAPON_COMPONENT_DATA_SP(dlcWeaponIndex: int, dlcWeapCompIndex: int, ComponentDataPtr: int) -> bool:
    return _ib(0x31D5E073B6F93CDC, dlcWeaponIndex, dlcWeapCompIndex, ComponentDataPtr)

def GET_DLC_VEHICLE_DATA(dlcVehicleIndex: int, outData: int) -> bool:
    return _ib(0x33468EDC08E371F6, dlcVehicleIndex, outData)

def DOES_SHOP_PED_APPAREL_HAVE_RESTRICTION_TAG(componentHash: int, restrictionTagHash: int, componentId: int) -> bool:
    return _ib(0x341DE7ED1D2A1BFD, componentHash, restrictionTagHash, componentId)

def REVERT_CONTENT_CHANGESET_GROUP_FOR_ALL(hash: int) -> None:
    _iv(0x3C1978285B036B25, hash)

def GET_NUM_DLC_WEAPON_COMPONENTS(dlcWeaponIndex: int) -> int:
    return _ii(0x405425358A7D61FE, dlcWeaponIndex)

def GET_NUM_DLC_WEAPONS_SP() -> int:
    return _ii(0x4160B65AE085B5A9)

def SETUP_SHOP_PED_APPAREL_QUERY(p0: int, p1: int, p2: int, p3: int) -> int:
    return _ii(0x50F457823CE6EB5F, p0, p1, p2, p3)

def GET_DLC_VEHICLE_FLAGS(dlcVehicleIndex: int) -> int:
    return _ii(0x5549EE11FA22FCF2, dlcVehicleIndex)

def GET_SHOP_PED_PROP(componentHash: int, outProp: int) -> None:
    _iv(0x5D5CAFF661DDF6FC, componentHash, outProp)

def GET_HASH_NAME_FOR_PROP(entity: int, componentId: int, propIndex: int, propTextureIndex: int) -> int:
    return _ii(0x5D6160275CAEC8DD, entity, componentId, propIndex, propTextureIndex)

def EXECUTE_CONTENT_CHANGESET_GROUP_FOR_ALL(hash: int) -> None:
    _iv(0x6BEDF5769AC2DC07, hash)

def GET_FORCED_COMPONENT(componentHash: int, forcedComponentIndex: int, nameHash: int, enumValue: int, componentType: int) -> None:
    _iv(0x6C93ED8C2F74859B, componentHash, forcedComponentIndex, nameHash, enumValue, componentType)

def GET_SHOP_PED_QUERY_PROP_INDEX(componentHash: int) -> int:
    return _ii(0x6CEBE002E58DEE97, componentHash)

def GET_DLC_WEAPON_COMPONENT_DATA(dlcWeaponIndex: int, dlcWeapCompIndex: int, ComponentDataPtr: int) -> bool:
    return _ib(0x6CF598A2957C2BF8, dlcWeaponIndex, dlcWeapCompIndex, ComponentDataPtr)

def GET_SHOP_PED_QUERY_OUTFIT(outfitIndex: int, outfit: int) -> None:
    _iv(0x6D793F03A631FE56, outfitIndex, outfit)

def GET_VARIANT_COMPONENT(componentHash: int, variantComponentIndex: int, nameHash: int, enumValue: int, componentType: int) -> None:
    _iv(0x6E11F282F11863B6, componentHash, variantComponentIndex, nameHash, enumValue, componentType)

def GET_SHOP_PED_COMPONENT(componentHash: int, outComponent: int) -> None:
    _iv(0x74C0E2A57EC66760, componentHash, outComponent)

def DOES_CURRENT_PED_COMPONENT_HAVE_RESTRICTION_TAG(ped: int, componentId: int, restrictionTagHash: int) -> bool:
    return _ib(0x7796B21B76221BC5, ped, componentId, restrictionTagHash)

def GET_DLC_WEAPON_DATA(dlcWeaponIndex: int, outData: int) -> bool:
    return _ib(0x79923CD21BECE14E, dlcWeaponIndex, outData)

def GET_SHOP_PED_QUERY_COMPONENT_INDEX(componentHash: int) -> int:
    return _ii(0x96E2929292A4DB77, componentHash)

def SETUP_SHOP_PED_APPAREL_QUERY_TU(character: int, p1: int, p2: int, p3: bool, p4: int, componentId: int) -> int:
    return _ii(0x9BDF59818B1E38C1, character, p1, p2, p3, p4, componentId)

def GET_NUM_DLC_VEHICLES() -> int:
    return _ii(0xA7A866D21CD2329B)

def GET_SHOP_PED_OUTFIT_PROP_VARIANT(outfitHash: int, variantIndex: int, outPropVariant: int) -> bool:
    return _ib(0xA9F9C2E0FDE11CBB, outfitHash, variantIndex, outPropVariant)

def GET_NUM_DLC_WEAPON_COMPONENTS_SP(dlcWeaponIndex: int) -> int:
    return _ii(0xAD2A7A6DFF55841B, dlcWeaponIndex)

def GET_SHOP_PED_OUTFIT(p0: int, p1: int) -> None:
    _iv(0xB7952076E444979D, p0, p1)

def GET_DLC_VEHICLE_MOD_LOCK_HASH(hash: int) -> int:
    return _ii(0xC098810437312FFF, hash)

def GET_SHOP_PED_APPAREL_VARIANT_COMPONENT_COUNT(componentHash: int) -> int:
    return _ii(0xC17AD0E5752BECDA, componentHash)

def GET_SHOP_PED_APPAREL_FORCED_COMPONENT_COUNT(componentHash: int) -> int:
    return _ii(0xC6B9DB42C04DD8C3, componentHash)

def GET_SHOP_PED_APPAREL_VARIANT_PROP_COUNT(propHash: int) -> int:
    return _ii(0xD40AAC51E8E4C663, propHash)

def IS_CONTENT_ITEM_LOCKED(itemHash: int) -> bool:
    return _ib(0xD4D7B033C3AA243C, itemHash)

def DOES_CURRENT_PED_PROP_HAVE_RESTRICTION_TAG(ped: int, componentId: int, restrictionTagHash: int) -> bool:
    return _ib(0xD726BAB4554DA580, ped, componentId, restrictionTagHash)

def GET_VARIANT_PROP(componentHash: int, variantPropIndex: int, nameHash: int, enumValue: int, anchorPoint: int) -> None:
    _iv(0xD81B7F27BC773E66, componentHash, variantPropIndex, nameHash, enumValue, anchorPoint)

def GET_SHOP_PED_QUERY_PROP(componentId: int, outProp: int) -> None:
    _iv(0xDE44A00999B2837D, componentId, outProp)

def GET_FORCED_PROP(componentHash: int, forcedPropIndex: int, nameHash: int, enumValue: int, anchorPoint: int) -> None:
    _iv(0xE1CA84EBF72E691D, componentHash, forcedPropIndex, nameHash, enumValue, anchorPoint)

def INIT_SHOP_PED_PROP(outProp: int) -> None:
    _iv(0xEB0A2B758F7B850F, outProp)

def GET_DLC_VEHICLE_MODEL(dlcVehicleIndex: int) -> int:
    return _ii(0xECC01B7C5763333C, dlcVehicleIndex)

def GET_NUM_DLC_WEAPONS() -> int:
    return _ii(0xEE47635F352DA367)

def SETUP_SHOP_PED_OUTFIT_QUERY(character: int, p1: bool) -> int:
    return _ii(0xF3FBE2D50A6A8C28, character, p1)

def GET_TATTOO_SHOP_DLC_ITEM_DATA(characterType: int, decorationIndex: int, outComponent: int) -> bool:
    return _ib(0xFF56381874F82086, characterType, decorationIndex, outComponent)
