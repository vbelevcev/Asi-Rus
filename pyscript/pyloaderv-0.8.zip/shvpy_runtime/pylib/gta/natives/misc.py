"""Auto-generated raw native bindings for namespace MISC.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_str as _is, _invoke_vector3 as _ivec


def DISPLAY_ONSCREEN_KEYBOARD(p0: int, windowTitle: str, p2: str, defaultText: str, defaultConcat1: str, defaultConcat2: str, defaultConcat3: str, maxInputLength: int) -> None:
    _iv(0x00DC833F2568DBF6, p0, windowTitle, p2, defaultText, defaultConcat1, defaultConcat2, defaultConcat3, maxInputLength)

def CLEAR_AREA_OF_VEHICLES(x: float, y: float, z: float, radius: float, p4: bool, p5: bool, p6: bool, p7: bool, p8: bool, p9: bool, p10: int) -> None:
    _iv(0x01C7B9B38428AEB6, x, y, z, radius, p4, p5, p6, p7, p8, p9, p10)

def SET_CLOUD_SETTINGS_OVERRIDE(p0: str) -> None:
    _iv(0x02DEAAC8F8EA7FE7, p0)

def GET_MODEL_DIMENSIONS(modelHash: int, minimum: int, maximum: int) -> None:
    _iv(0x03E8D3D5F549087A, modelHash, minimum, maximum)

def STOP_SAVE_ARRAY() -> None:
    _iv(0x04456F95153C6BE4)

def CLEAR_AREA_OF_COPS(x: float, y: float, z: float, radius: float, flags: int) -> None:
    _iv(0x04F8FC8FCF58F88D, x, y, z, radius, flags)

def CREATE_INCIDENT_WITH_ENTITY(dispatchService: int, ped: int, numUnits: int, radius: float, outIncidentID: int, p5: int, p6: int) -> bool:
    return _ib(0x05983472F0494E60, dispatchService, ped, numUnits, radius, outIncidentID, p5, p6)

def CLEAR_CODE_REQUESTED_AUTOSAVE() -> None:
    _iv(0x06462A961E94B67C)

def HAS_CHEAT_WITH_HASH_BEEN_ACTIVATED(hash: int, amount: int) -> bool:
    return _ib(0x071E2A839DE82D90, hash, amount)

def HAVE_CREDITS_REACHED_END() -> bool:
    return _ib(0x075F1D57402C93BA)

def CLEAR_AREA_OF_PROJECTILES(x: float, y: float, z: float, radius: float, flags: int) -> None:
    _iv(0x0A1CB9094635D1A6, x, y, z, radius, flags)

def IS_STEAM_VERSION() -> bool:
    return _ib(0x0A27B2B6282F7169)

def SCRIPT_RACE_INIT(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x0A60017F841A54F2, p0, p1, p2, p3)

def ARE_STRINGS_EQUAL(string1: str, string2: str) -> bool:
    return _ib(0x0C515FAB3FF9EA92, string1, string2)

def UPDATE_ONSCREEN_KEYBOARD() -> int:
    return _ii(0x0CF2B696BBF945AE)

def CLEAR_WEATHER_TYPE_NOW_PERSIST_NETWORK(milliseconds: int) -> None:
    _iv(0x0CF97F497FE7D048, milliseconds)

def REGISTER_ENUM_TO_SAVE(p0: int, name: str) -> None:
    _iv(0x10C2FA78D0E128A1, p0, name)

def OVERRIDE_SAVE_HOUSE(p0: bool, p1: float, p2: float, p3: float, p4: float, p5: bool, p6: float, p7: float) -> bool:
    return _ib(0x1162EA8AE9D24EEA, p0, p1, p2, p3, p4, p5, p6, p7)

def SET_OVERRIDE_WEATHEREX(weatherType: str, p1: bool) -> None:
    _iv(0x1178E104409FE58C, weatherType, p1)

def SET_FIRE_AMMO_THIS_FRAME(player: int) -> None:
    _iv(0x11879CDD803D30F4, player)

def PRELOAD_CLOUD_HAT(name: str) -> None:
    _iv(0x11B56FBBF7224868, name)

def CLEAR_ANGLED_AREA_OF_VEHICLES(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, width: float, p7: bool, p8: bool, p9: bool, p10: bool, p11: bool, p12: int, p13: int) -> None:
    _iv(0x11DB3500F042A8AA, x1, y1, z1, x2, y2, z2, width, p7, p8, p9, p10, p11, p12, p13)

def IS_POP_MULTIPLIER_AREA_NETWORKED(id: int) -> bool:
    return _ib(0x1312F4B242609CE3, id)

def DOES_POP_MULTIPLIER_AREA_EXIST(id: int) -> bool:
    return _ib(0x1327E2FE9746BAEE, id)

def IS_XBOX_PLATFORM() -> bool:
    return _ib(0x138679CA01E21F53)

def SET_FAKE_WANTED_LEVEL(fakeWantedLevel: int) -> None:
    _iv(0x1454F2448DE30163, fakeWantedLevel)

def HAS_ASYNC_INSTALL_FINISHED() -> bool:
    return _ib(0x14832BF2ABA53FC5)

def GET_FRAME_TIME() -> float:
    return _if(0x15C40837039FFAF7)

def DOES_POP_MULTIPLIER_SPHERE_EXIST(id: int) -> bool:
    return _ib(0x171BAFB3C60389F4, id)

def GET_TENNIS_SWING_ANIM_COMPLETE(ped: int) -> bool:
    return _ib(0x17DF68D720AA77F8, ped)

def GET_ANGLE_BETWEEN_2D_VECTORS(x1: float, y1: float, x2: float, y2: float) -> float:
    return _if(0x186FC4BE848E1C92, x1, y1, x2, y2)

def GET_TENNIS_SWING_ANIM_CAN_BE_INTERRUPTED(ped: int) -> bool:
    return _ib(0x19BFED045C647C49, ped)

def SET_MINIGAME_IN_PROGRESS(toggle: bool) -> None:
    _iv(0x19E00D7322C6F85B, toggle)

def IS_BULLET_IN_ANGLED_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, width: float, ownedByPlayer: bool) -> bool:
    return _ib(0x1A8B5F3C01E2B477, x1, y1, z1, x2, y2, z2, width, ownedByPlayer)

def ADD_STUNT_JUMP(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, x3: float, y3: float, z3: float, x4: float, y4: float, z4: float, camX: float, camY: float, camZ: float, p15: int, p16: int, p17: int) -> int:
    return _ii(0x1A992DA297A4630C, x1, y1, z1, x2, y2, z2, x3, y3, z3, x4, y4, z4, camX, camY, camZ, p15, p16, p17)

def CLEAR_REPLAY_STATS() -> None:
    _iv(0x1B1AB132A16FDA55)

def GET_BENCHMARK_PASS() -> int:
    return _ii(0x1B2366C3F2A5C8DF)

def SCRIPT_RACE_PLAYER_HIT_CHECKPOINT(player: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x1BB299305C3E8C13, player, p1, p2, p3)

def ACOS(p0: float) -> float:
    return _if(0x1D08B970013C34B6, p0)

def SET_TIME_SCALE(timeScale: float) -> None:
    _iv(0x1D408577D440E81E, timeScale)

def SET_FADE_OUT_AFTER_ARREST(toggle: bool) -> None:
    _iv(0x1E0B4DC0D990A4E7, toggle)

def COMPARE_STRINGS(str1: str, str2: str, matchCase: bool, maxLength: int) -> int:
    return _ii(0x1E34710ECD4AB0EB, str1, str2, matchCase, maxLength)

def SUPRESS_RANDOM_EVENT_THIS_FRAME(eventType: int, suppress: bool) -> None:
    _iv(0x1EAE0A6E978894A2, eventType, suppress)

def GET_WIND_DIRECTION() -> 'gta.Vector3':
    return _ivec(0x1F400FEF721170DA)

def ADD_HOSPITAL_RESTART(x: float, y: float, z: float, p3: float, p4: int) -> int:
    return _ii(0x1F464EF988465A81, x, y, z, p3, p4)

def SCRIPT_RACE_SHUTDOWN() -> None:
    _iv(0x1FF6BF9A63E5757F)

def GET_CLOUDS_ALPHA() -> float:
    return _if(0x20AC25E781AE4A84)

def HAS_CODE_REQUESTED_AUTOSAVE() -> bool:
    return _ib(0x2107A3773771186D)

def COPY_SCRIPT_STRUCT(dst: int, src: int, size: int) -> None:
    _iv(0x213AEB2B90CBA7AC, dst, src, size)

def GET_CLOSEST_POINT_ON_LINE(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, x3: float, y3: float, z3: float, clamp: bool) -> 'gta.Vector3':
    return _ivec(0x21C235BC64831E5A, x1, y1, z1, x2, y2, z2, x3, y3, z3, clamp)

def IGNORE_NEXT_RESTART(toggle: bool) -> None:
    _iv(0x21FFB63D8C615361, toggle)

def IS_STUNT_JUMP_MESSAGE_SHOWING() -> bool:
    return _ib(0x2272B0A1343129F4)

def DISABLE_SCREEN_DIMMING_THIS_FRAME() -> None:
    _iv(0x23227DF0B2115469)

def DISABLE_POLICE_RESTART(policeIndex: int, toggle: bool) -> None:
    _iv(0x23285DED6EBD7EA3, policeIndex, toggle)

def GET_CONTENT_TO_LOAD() -> str:
    return _is(0x24DA7D7667FD7B09)

def SET_RIOT_MODE_ENABLED(toggle: bool) -> None:
    _iv(0x2587A48BC88DFADF, toggle)

def REMOVE_DISPATCH_SPAWN_BLOCKING_AREA(p0: int) -> None:
    _iv(0x264AC28B01B353A5, p0)

def ENABLE_TENNIS_MODE(ped: int, toggle: bool, p2: bool) -> None:
    _iv(0x28A04B411933F8A6, ped, toggle, p2)

def SET_WEATHER_TYPE_NOW(weatherType: str) -> None:
    _iv(0x29B487C359E19889, weatherType)

def IS_MINIGAME_IN_PROGRESS() -> bool:
    return _ib(0x2B4A15E44DE0F478)

def GET_STATUS_OF_MISSION_REPEAT_SAVE() -> int:
    return _ii(0x2B5E102E4A42F2BF)

def GET_REPLAY_STAT_MISSION_TYPE() -> int:
    return _ii(0x2B626A0150E4D449)

def PAUSE_DEATH_ARREST_RESTART(toggle: bool) -> None:
    _iv(0x2C2B3493FBF51C71, toggle)

def ADD_DISPATCH_SPAWN_SPHERE_BLOCKING_AREA(x1: float, y1: float, x2: float, y2: float) -> int:
    return _ii(0x2D4259F1FEB81DA9, x1, y1, x2, y2)

def IS_PROJECTILE_TYPE_IN_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, type: int, ownedByPlayer: bool) -> bool:
    return _ib(0x2E0DC353342C4A6D, x1, y1, z1, x2, y2, z2, type, ownedByPlayer)

def IS_NEXT_WEATHER_TYPE(weatherType: str) -> bool:
    return _ib(0x2FAA3A30BEC0F25D, weatherType)

def GET_HEADING_FROM_VECTOR_2D(dx: float, dy: float) -> float:
    return _if(0x2FFB6B224F4B2926, dx, dy)

def ACTIVITY_FEED_ADD_SUBSTRING_TO_CAPTION(p0: str) -> None:
    _iv(0x31125FD509D9043F, p0)

def GET_RANDOM_FLOAT_IN_RANGE(startRange: float, endRange: float) -> float:
    return _if(0x313CE5879CEB6FCD, startRange, endRange)

def WATER_OVERRIDE_SET_OCEANNOISEMINAMPLITUDE(minAmplitude: float) -> None:
    _iv(0x31727907B2C43C55, minAmplitude)

def ADD_POP_MULTIPLIER_SPHERE(x: float, y: float, z: float, radius: float, pedMultiplier: float, vehicleMultiplier: float, p6: bool, p7: bool) -> int:
    return _ii(0x32C7A7E8C43A1F80, x, y, z, radius, pedMultiplier, vehicleMultiplier, p6, p7)

def CLEAR_OVERRIDE_WEATHER() -> None:
    _iv(0x338D2E3477711050)

def IS_PROJECTILE_TYPE_WITHIN_DISTANCE(x: float, y: float, z: float, projectileHash: int, radius: float, ownedByPlayer: bool) -> bool:
    return _ib(0x34318593248C8FB2, x, y, z, projectileHash, radius, ownedByPlayer)

def REGISTER_INT_TO_SAVE(p0: int, name: str) -> None:
    _iv(0x34C9EE5986258415, p0, name)

def SAVE_END_USER_BENCHMARK() -> None:
    _iv(0x37DEB0AA183FB6D8)

def IS_AREA_OCCUPIED_SLOW(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int, p7: int, p8: int, p9: int, p10: int, p11: int, p12: int) -> bool:
    return _ib(0x39455BF4F4F55186, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12)

def GET_STATUS_OF_MANUAL_SAVE() -> int:
    return _ii(0x397BAA01068BAA96)

def LANDING_SCREEN_STARTED_END_USER_BENCHMARK() -> bool:
    return _ib(0x3BBBD13E5041A79E)

def GET_COORDS_OF_PROJECTILE_TYPE_IN_ANGLED_AREA(vecAngledAreaPoint1X: float, vecAngledAreaPoint1Y: float, vecAngledAreaPoint1Z: float, vecAngledAreaPoint2X: float, vecAngledAreaPoint2Y: float, vecAngledAreaPoint2Z: float, distanceOfOppositeFace: float, weaponType: int, positionOut: int, bIsPlayer: bool) -> bool:
    return _ib(0x3DA8C28346B62CED, vecAngledAreaPoint1X, vecAngledAreaPoint1Y, vecAngledAreaPoint1Z, vecAngledAreaPoint2X, vecAngledAreaPoint2Y, vecAngledAreaPoint2Z, distanceOfOppositeFace, weaponType, positionOut, bIsPlayer)

def NEXT_ONSCREEN_KEYBOARD_RESULT_WILL_DISPLAY_USING_THESE_FONTS(p0: int) -> None:
    _iv(0x3ED1438C1F5C6612, p0)

def IS_BULLET_IN_AREA(x: float, y: float, z: float, radius: float, ownedByPlayer: bool) -> bool:
    return _ib(0x3F2023999AD51C1F, x, y, z, radius, ownedByPlayer)

def GET_REAL_WORLD_TIME() -> int:
    return _ii(0x3F60413F5DF65748)

def CREATE_INCIDENT(dispatchService: int, x: float, y: float, z: float, numUnits: int, radius: float, outIncidentID: int, p7: int, p8: int) -> bool:
    return _ib(0x3F892CAF67444AE7, dispatchService, x, y, z, numUnits, radius, outIncidentID, p7, p8)

def WATER_OVERRIDE_SET_OCEANWAVEAMPLITUDE(amplitude: float) -> None:
    _iv(0x405591EC8FD9096D, amplitude)

def RESET_END_USER_BENCHMARK() -> None:
    _iv(0x437138B6A830166A)

def SET_BEAST_JUMP_THIS_FRAME(player: int) -> None:
    _iv(0x438822C279B73B93, player)

def SET_RANDOM_SEED(seed: int) -> None:
    _iv(0x444D98F98C11F3EC, seed)

def QUEUE_MISSION_REPEAT_SAVE() -> bool:
    return _ib(0x44A0BDC559B35F6E)

def IS_PREV_WEATHER_TYPE(weatherType: str) -> bool:
    return _ib(0x44F28F86433B10A9, weatherType)

def SET_DISPATCH_TIME_BETWEEN_SPAWN_ATTEMPTS(p0: int, p1: float) -> None:
    _iv(0x44F7CBC1BEB3327D, p0, p1)

def ADD_POLICE_RESTART(p0: float, p1: float, p2: float, p3: float, p4: int) -> int:
    return _ii(0x452736765B31FC4B, p0, p1, p2, p3, p4)

def GET_BENCHMARK_ITERATIONS() -> int:
    return _ii(0x4750FC27570311EC)

def SET_DISPATCH_TIME_BETWEEN_SPAWN_ATTEMPTS_MULTIPLIER(p0: int, p1: float) -> None:
    _iv(0x48838ED9937A15D1, p0, p1)

def IS_PC_VERSION() -> bool:
    return _ib(0x48AF36444B965238)

def REGISTER_TEXT_LABEL_23_TO_SAVE(p0: int, name: str) -> None:
    _iv(0x48F069265A0E4BEC, p0, name)

def SET_FADE_OUT_AFTER_DEATH(toggle: bool) -> None:
    _iv(0x4A18E01DF2C87B86, toggle)

def SET_CONTENT_ID_INDEX(contentId: int, index: int) -> None:
    _iv(0x4B82FA6F2D624634, contentId, index)

def GET_FAKE_WANTED_LEVEL() -> int:
    return _ii(0x4C9296CBCD1B971E)

def IS_DURANGO_VERSION() -> bool:
    return _ib(0x4D982ADB1978442D)

def ACTIVITY_FEED_CREATE(p0: str, p1: str) -> None:
    _iv(0x4DCDF92BF64236CD, p0, p1)

def SET_PLAYER_IS_IN_ANIMAL_FORM(toggle: bool) -> None:
    _iv(0x4EBB7E87AA0DBED4, toggle)

def SET_SAVE_HOUSE(savehouseHandle: int, p1: bool, p2: bool) -> None:
    _iv(0x4F548CABEAE553BC, savehouseHandle, p1, p2)

def DO_AUTO_SAVE() -> None:
    _iv(0x50EEAAD86232EE55)

def IS_PROJECTILE_IN_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, ownedByPlayer: bool) -> bool:
    return _ib(0x5270A8FBC098C3F8, x1, y1, z1, x2, y2, z2, ownedByPlayer)

def GET_BITS_IN_RANGE(var: int, rangeStart: int, rangeEnd: int) -> int:
    return _ii(0x53158863FCC0893A, var, rangeStart, rangeEnd)

def SET_TENNIS_MOVE_NETWORK_SIGNAL_FLOAT(ped: int, p1: str, p2: float) -> None:
    _iv(0x54F157E0336A3822, ped, p1, p2)

def DELETE_INCIDENT(incidentId: int) -> None:
    _iv(0x556C1AA270D5A207, incidentId)

def HAS_PC_CHEAT_WITH_HASH_BEEN_ACTIVATED(hash: int) -> bool:
    return _ib(0x557E43C447E700A8, hash)

def GET_PREV_WEATHER_TYPE_HASH_NAME() -> int:
    return _ii(0x564B884A05EC45A3)

def SET_GAME_PAUSED(toggle: bool) -> None:
    _iv(0x577D1284D6873711, toggle)

def SET_CURR_WEATHER_STATE(weatherType1: int, weatherType2: int, percentWeather2: float) -> None:
    _iv(0x578C752848ECFA0C, weatherType1, weatherType2, percentWeather2)

def SET_SUPER_JUMP_THIS_FRAME(player: int) -> None:
    _iv(0x57FFF03E423A4C0B, player)

def RESET_DISPATCH_SPAWN_LOCATION() -> None:
    _iv(0x5896F2BD5683A4E1)

def CANCEL_ONSCREEN_KEYBOARD() -> None:
    _iv(0x58A39BE597CE99CD)

def STRING_TO_INT(string: str, outInteger: int) -> bool:
    return _ib(0x5A5F40FE637EB584, string, outInteger)

def ARE_PROFILE_SETTINGS_VALID() -> bool:
    return _ib(0x5AA3BEFA29F03AD4)

def GET_REPLAY_STAT_MISSION_ID() -> int:
    return _ii(0x5B1F2E327B6B6FE1)

def IS_TENNIS_MODE(ped: int) -> bool:
    return _ib(0x5D5479D115290C3F, ped)

def START_SAVE_ARRAY_WITH_SIZE(p0: int, size: int, arrayName: str) -> None:
    _iv(0x60FE567DF1B1AF9D, p0, size, arrayName)

def IS_SNIPER_INVERTED() -> bool:
    return _ib(0x61A23B7EDA9BDA24)

def WATER_OVERRIDE_SET_RIPPLEMINBUMPINESS(minBumpiness: float) -> None:
    _iv(0x6216B116083A7CB4, minBumpiness)

def TAN(p0: float) -> float:
    return _if(0x632106CC96E82E91, p0)

def SET_RAIN(intensity: float) -> None:
    _iv(0x643E26EA6E024D92, intensity)

def SET_SCRIPT_HIGH_PRIO(toggle: bool) -> None:
    _iv(0x65D2EBB47E1CEC21, toggle)

def ADD_POP_MULTIPLIER_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, p6: float, p7: float, p8: bool, p9: bool) -> int:
    return _ii(0x67F6413D3220E18D, x1, y1, z1, x2, y2, z2, p6, p7, p8, p9)

def PLM_IS_IN_CONSTRAINED_MODE() -> bool:
    return _ib(0x684A41975F077262)

def GET_TOTAL_SUCCESSFUL_STUNT_JUMPS() -> int:
    return _ii(0x6856EC3D35C81EA4)

def FIND_SPAWN_POINT_IN_DIRECTION(posX: float, posY: float, posZ: float, fwdVecX: float, fwdVecY: float, fwdVecZ: float, distance: float, spawnPoint: int) -> bool:
    return _ib(0x6874E2190B0C1972, posX, posY, posZ, fwdVecX, fwdVecY, fwdVecZ, distance, spawnPoint)

def IS_AUTO_SAVE_IN_PROGRESS() -> bool:
    return _ib(0x69240733738C19A0)

def USE_ACTIVE_CAMERA_FOR_TIMESLICING_CENTRE() -> None:
    _iv(0x693478ACBD7F18E7)

def ADD_REPLAY_STAT_VALUE(value: int) -> None:
    _iv(0x69FE6DC87BD2A5E9, value)

def GET_IS_AUTO_SAVE_OFF() -> bool:
    return _ib(0x6E04F06094C87047)

def SET_THIS_IS_A_TRIGGER_SCRIPT(toggle: bool) -> None:
    _iv(0x6F2135B6129620C1, toggle)

def REGISTER_TEXT_LABEL_15_TO_SAVE(p0: int, name: str) -> None:
    _iv(0x6F7794F28C6B2535, p0, name)

def HAS_GAME_INSTALLED_THIS_SESSION() -> bool:
    return _ib(0x6FDDF453C0C756EC)

def SET_DISPATCH_IDEAL_SPAWN_DISTANCE(distance: float) -> None:
    _iv(0x6FE601A64180D423, distance)

def ACTIVITY_FEED_ACTION_START_WITH_COMMAND_LINE_ADD(p0: str) -> None:
    _iv(0x703CC7F60CBB2B57, p0)

def SET_WEATHER_TYPE_PERSIST(weatherType: str) -> None:
    _iv(0x704983DF373B198F, weatherType)

def SET_RESTART_COORD_OVERRIDE(x: float, y: float, z: float, heading: float) -> None:
    _iv(0x706B5EDCAA7FA663, x, y, z, heading)

def GET_NEXT_WEATHER_TYPE_HASH_NAME() -> int:
    return _ii(0x711327CD09C8F162)

def QUEUE_MISSION_REPEAT_LOAD() -> bool:
    return _ib(0x72DE52178C291CB5)

def ABSF(value: float) -> float:
    return _if(0x73D57CFFDD12C355, value)

def SET_GRAVITY_LEVEL(level: int) -> None:
    _iv(0x740E14FAD5842351, level)

def POPULATE_NOW() -> None:
    _iv(0x7472BB270D7B4F3E)

def STOP_SAVE_DATA() -> None:
    _iv(0x74E20C9145FB66FD)

def RESET_DISPATCH_IDEAL_SPAWN_DISTANCE() -> None:
    _iv(0x77A84429DD9F0A15)

def IS_STUNT_JUMP_IN_PROGRESS() -> bool:
    return _ib(0x7A3F19700A4D0525)

def IS_THIS_A_MINIGAME_SCRIPT() -> bool:
    return _ib(0x7B30F65D7B710098)

def WATER_OVERRIDE_SET_RIPPLEBUMPINESS(bumpiness: float) -> None:
    _iv(0x7C9C0B1EEB1F9072, bumpiness)

def REGISTER_FLOAT_TO_SAVE(p0: int, name: str) -> None:
    _iv(0x7CAEC29ECB5DFEBB, p0, name)

def IS_FRONTEND_FADING() -> bool:
    return _ib(0x7EA2B6AF97ECA6ED)

def CLEAR_SCENARIO_SPAWN_HISTORY() -> None:
    _iv(0x7EC6F9A478A6A512)

def SET_SNOW(level: float) -> None:
    _iv(0x7F06937B0CDCBC1A, level)

def GET_RATIO_OF_CLOSEST_POINT_ON_LINE(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, x3: float, y3: float, z3: float, clamp: bool) -> float:
    return _if(0x7F8F6405F4777AF6, x1, y1, z1, x2, y2, z2, x3, y3, z3, clamp)

def IS_PROSPERO_VERSION() -> bool:
    return _ib(0x807ABE1AB65C24D2)

def GET_REPLAY_STAT_AT_INDEX(index: int) -> int:
    return _ii(0x8098C8D6597AAE18, index)

def REGISTER_TEXT_LABEL_31_TO_SAVE(p0: int, name: str) -> None:
    _iv(0x8269816F6CFD40F8, p0, name)

def GET_PROJECTILE_OF_PROJECTILE_TYPE_WITHIN_DISTANCE(ped: int, weaponHash: int, distance: float, outCoords: int, outProjectile: int, p5: bool) -> bool:
    return _ib(0x82FDE6A57EE4EE44, ped, weaponHash, distance, outCoords, outProjectile, p5)

def GET_ONSCREEN_KEYBOARD_RESULT() -> str:
    return _is(0x8362B09B91893647)

def SHOOT_SINGLE_BULLET_BETWEEN_COORDS(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, damage: int, p7: bool, weaponHash: int, ownerPed: int, isAudible: bool, isInvisible: bool, speed: float) -> None:
    _iv(0x867654CBC7606F2C, x1, y1, z1, x2, y2, z2, damage, p7, weaponHash, ownerPed, isAudible, isInvisible, speed)

def ATAN2(p0: float, p1: float) -> float:
    return _if(0x8927CBF9D22261A4, p0, p1)

def ACTIVITY_FEED_POST() -> None:
    _iv(0x8951EB9C6906D3C8)

def IS_MEMORY_CARD_IN_USE() -> bool:
    return _ib(0x8A75CE2956274ADD)

def SET_RANDOM_WEATHER_TYPE() -> None:
    _iv(0x8B05F884CF7E8020)

def GET_ALLOCATED_STACK_SIZE() -> int:
    return _ii(0x8B3CA62B1EF19B62)

def _GET_CONTENT_PROP_TYPE(model: int) -> int:
    return _ii(0x8BAF8AD59F47AAFC, model)

def GET_GROUND_Z_AND_NORMAL_FOR_3D_COORD(x: float, y: float, z: float, groundZ: int, normal: int) -> bool:
    return _ib(0x8BDC7BFC57A81E76, x, y, z, groundZ, normal)

def INFORM_CODE_OF_CONTENT_ID_OF_CURRENT_UGC_MISSION(p0: str) -> None:
    _iv(0x8D74E26F54B4E5C3, p0)

def GET_COORDS_OF_PROJECTILE_TYPE_IN_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, projectileHash: int, projectilePos: int, ownedByPlayer: bool) -> bool:
    return _ib(0x8D7A43EC6A5FEA45, x1, y1, z1, x2, y2, z2, projectileHash, projectilePos, ownedByPlayer)

def SET_BITS_IN_RANGE(var: int, rangeStart: int, rangeEnd: int, p3: int) -> None:
    _iv(0x8EF07E15701D61ED, var, rangeStart, rangeEnd, p3)

def SCRIPT_RACE_GET_PLAYER_SPLIT_TIME(player: int, p1: int, p2: int) -> bool:
    return _ib(0x8EF5573A1F801A5C, player, p1, p2)

def PLAY_TENNIS_DIVE_ANIM(ped: int, p1: int, p2: float, p3: float, p4: float, p5: bool) -> None:
    _iv(0x8FA9C42FC5D7C64B, ped, p1, p2, p3, p4, p5)

def ACTIVITY_FEED_LARGE_IMAGE_URL(p0: str) -> None:
    _iv(0x916CA67D26FD1E37, p0)

def ADD_DISPATCH_SPAWN_ANGLED_BLOCKING_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, width: float) -> int:
    return _ii(0x918C7B2D2FF3928B, x1, y1, z1, x2, y2, z2, width)

def NETWORK_SET_SCRIPT_IS_SAFE_FOR_NETWORK_GAME() -> None:
    _iv(0x9243BAC96D64C050)

def START_END_USER_BENCHMARK() -> None:
    _iv(0x92790862E36C2ADA)

def SET_BIT(address: int, offset: int) -> None:
    _iv(0x933D6A9EEC1BACD0, address, offset)

def CLEAR_AREA_LEAVE_VEHICLE_HEALTH(x: float, y: float, z: float, radius: float, p4: bool, p5: bool, p6: bool, p7: bool) -> None:
    _iv(0x957838AAF91BD12D, x, y, z, radius, p4, p5, p6, p7)

def UNLOAD_ALL_CLOUD_HATS() -> None:
    _iv(0x957E790EA1727B64)

def GET_RAIN_LEVEL() -> float:
    return _if(0x96695E368AD855F3)

def GET_IS_PLAYER_IN_ANIMAL_FORM() -> bool:
    return _ib(0x9689123E3F213AA5)

def SET_RANDOM_EVENT_FLAG(toggle: bool) -> None:
    _iv(0x971927086CFD2158, toggle)

def ACTIVITY_FEED_ADD_INT_TO_CAPTION(p0: int) -> None:
    _iv(0x97E7E2C04245115B, p0)

def HAS_BULLET_IMPACTED_IN_AREA(x: float, y: float, z: float, p3: float, p4: bool, p5: bool) -> bool:
    return _ib(0x9870ACFB89A90995, x, y, z, p3, p4, p5)

def GET_NUM_SUCCESSFUL_STUNT_JUMPS() -> int:
    return _ii(0x996DD1E1E02F1008)

def BLOCK_DISPATCH_SERVICE_RESOURCE_CREATION(dispatchService: int, toggle: bool) -> None:
    _iv(0x9B2BD3773123EA2F, dispatchService, toggle)

def SET_INSTANCE_PRIORITY_MODE(p0: int) -> None:
    _iv(0x9BAE5AD2508DF078, p0)

def GET_GAME_TIMER() -> int:
    return _ii(0x9CD27B0045628463)

def SET_PLAYER_IS_REPEATING_A_MISSION(toggle: bool) -> None:
    _iv(0x9D8D44ADBBA61EF2, toggle)

def TERMINATE_ALL_SCRIPTS_WITH_THIS_NAME(scriptName: str) -> None:
    _iv(0x9DC711BC69C548DF, scriptName)

def GET_GROUND_Z_EXCLUDING_OBJECTS_FOR_3D_COORD(x: float, y: float, z: float, groundZ: int, p4: bool, p5: bool) -> bool:
    return _ib(0x9E82F0F362881B29, x, y, z, groundZ, p4, p5)

def IS_AUSSIE_VERSION() -> bool:
    return _ib(0x9F1935CA1F724008)

def WATER_OVERRIDE_SET_RIPPLEMAXBUMPINESS(maxBumpiness: float) -> None:
    _iv(0x9F5E6BB6B34540DA, maxBumpiness)

def IS_COMMANDLINE_END_USER_BENCHMARK() -> bool:
    return _ib(0xA049A5BE0F04F2F8)

def GET_SIZE_OF_SAVE_DATA(p0: bool) -> int:
    return _ii(0xA09F896CE912481F, p0)

def GET_POINT_AREA_OVERLAP(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int, p7: int, p8: int, p9: int, p10: int, p11: int, p12: int, p13: int) -> bool:
    return _ib(0xA0AD167E4B39D9A2, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13)

def SET_FORCED_JUMP_THIS_FRAME(player: int) -> None:
    _iv(0xA1183BCFEE0F93D1, player)

def END_REPLAY_STATS() -> None:
    _iv(0xA23E821FBDF8A5F2)

def CLEAR_RESTART_COORD_OVERRIDE() -> None:
    _iv(0xA2716D40842EAF79)

def GET_MISSION_FLAG() -> bool:
    return _ib(0xA33CDCCDA663159E)

def SET_OVERRIDE_WEATHER(weatherType: str) -> None:
    _iv(0xA43D5C6FE51ADBEF, weatherType)

def GET_SAVE_HOUSE_DETAILS_AFTER_SUCCESSFUL_LOAD(p0: int, p1: int, fadeInAfterLoad: int, p3: int) -> bool:
    return _ib(0xA4A0065E39C9F25C, p0, p1, fadeInAfterLoad, p3)

def DISABLE_STUNT_JUMP_SET(p0: int) -> None:
    _iv(0xA5272EBEDD4747F6, p0)

def CLEAR_AREA(X: float, Y: float, Z: float, radius: float, p4: bool, ignoreCopCars: bool, ignoreObjects: bool, p7: bool) -> None:
    _iv(0xA56F01F3765B93A0, X, Y, Z, radius, p4, ignoreCopCars, ignoreObjects, p7)

def IS_AREA_OCCUPIED(p0: float, p1: float, p2: float, p3: float, p4: float, p5: float, p6: bool, p7: bool, p8: bool, p9: bool, p10: bool, p11: int, p12: bool) -> bool:
    return _ib(0xA61B4DF533DCB56E, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12)

def SET_EXPLOSIVE_AMMO_THIS_FRAME(player: int) -> None:
    _iv(0xA66C71C98D5F2CFB, player)

def ACTION_MANAGER_ENABLE_ACTION(hash: int, enable: bool) -> None:
    _iv(0xA6A12939F16D85BE, hash, enable)

def IS_ORBIS_VERSION() -> bool:
    return _ib(0xA72BC0B675B1519E)

def REGISTER_INT64_TO_SAVE(p0: int, name: str) -> None:
    _iv(0xA735353C77334EA0, p0, name)

def UNLOAD_CLOUD_HAT(name: str, p1: float) -> None:
    _iv(0xA74802FB8D0B7814, name, p1)

def WATER_OVERRIDE_SET_SHOREWAVEMAXAMPLITUDE(maxAmplitude: float) -> None:
    _iv(0xA7A1127490312C36, maxAmplitude)

def WATER_OVERRIDE_FADE_IN(p0: float) -> None:
    _iv(0xA8434F1DFF41D6E7, p0)

def GET_WIND_SPEED() -> float:
    return _if(0xA8CF1CC0AFCD3F12)

def START_SAVE_DATA(p0: int, p1: int, p2: bool) -> None:
    _iv(0xA9575F812C6A7997, p0, p1, p2)

def ATAN(p0: float) -> float:
    return _if(0xA9D1795CD5043663, p0)

def SET_THIS_SCRIPT_CAN_BE_PAUSED(toggle: bool) -> None:
    _iv(0xAA391C728106F7AF, toggle)

def PLM_GET_CONSTRAINED_DURATION_MS() -> int:
    return _ii(0xABB2FA71C83A1B72)

def SET_WIND(speed: float) -> None:
    _iv(0xAC3A74E8384A9919, speed)

def RESET_DISPATCH_SPAWN_BLOCKING_AREAS() -> None:
    _iv(0xAC7BFD5C1D83EA75)

def IS_POSITION_OCCUPIED(x: float, y: float, z: float, range: float, p4: bool, checkVehicles: bool, checkPeds: bool, p7: bool, p8: bool, ignoreEntity: int, p10: bool) -> bool:
    return _ib(0xADCDE75E1C60F32D, x, y, z, range, p4, checkVehicles, checkPeds, p7, p8, ignoreEntity, p10)

def SET_INCIDENT_REQUESTED_UNITS(incidentId: int, dispatchService: int, numUnits: int) -> None:
    _iv(0xB08B85D860E7BA3C, incidentId, dispatchService, numUnits)

def REMOVE_POP_MULTIPLIER_AREA(id: int, p1: bool) -> None:
    _iv(0xB129E447A2EDA4BF, id, p1)

def GET_BASE_ELEMENT_LOCATION_FROM_METADATA_BLOCK(p0: int, p1: int, p2: int, p3: bool) -> bool:
    return _ib(0xB335F761606DB47C, p0, p1, p2, p3)

def CLEAR_TACTICAL_NAV_MESH_POINTS() -> None:
    _iv(0xB3CD58CCA6CDA852)

def WATER_OVERRIDE_SET_OCEANWAVEMAXAMPLITUDE(maxAmplitude: float) -> None:
    _iv(0xB3E6360DDE733E82, maxAmplitude)

def SET_CREDITS_FADE_OUT_WITH_SCREEN(toggle: bool) -> None:
    _iv(0xB51B9AB9EF81868C, toggle)

def ADD_TACTICAL_NAV_MESH_POINT(x: float, y: float, z: float) -> None:
    _iv(0xB8721407EE9C3FF6, x, y, z)

def IS_JAPANESE_VERSION() -> bool:
    return _ib(0xB8C0BB75D8A77DB3)

def WATER_OVERRIDE_SET_SHOREWAVEAMPLITUDE(amplitude: float) -> None:
    _iv(0xB8F87EAD7533B176, amplitude)

def SET_CREDITS_ACTIVE(toggle: bool) -> None:
    _iv(0xB938B7E6D3C0620C, toggle)

def SET_THIS_SCRIPT_CAN_REMOVE_BLIPS_CREATED_BY_ANY_SCRIPT(toggle: bool) -> None:
    _iv(0xB98236CAAECEF897, toggle)

def WATER_OVERRIDE_SET_RIPPLEDISTURB(disturb: float) -> None:
    _iv(0xB9854DFDE0D833D6, disturb)

def _SET_CONTENT_PROP_TYPE(model: int, type: int) -> None:
    _iv(0xBA4583AF4C678A9B, model, type)

def ACTIVITY_FEED_ONLINE_PLAYED_WITH_POST(p0: str) -> None:
    _iv(0xBA4B8D83BDC75551, p0)

def ADD_STUNT_JUMP_ANGLED(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, radius1: float, x3: float, y3: float, z3: float, x4: float, y4: float, z4: float, radius2: float, camX: float, camY: float, camZ: float, p17: int, p18: int, p19: int) -> int:
    return _ii(0xBBE5D803A5360CBF, x1, y1, z1, x2, y2, z2, radius1, x3, y3, z3, x4, y4, z4, radius2, camX, camY, camZ, p17, p18, p19)

def CLEAR_AREA_OF_PEDS(x: float, y: float, z: float, radius: float, flags: int) -> None:
    _iv(0xBE31FD6CE464AC59, x, y, z, radius, flags)

def START_SAVE_STRUCT_WITH_SIZE(p0: int, size: int, structName: str) -> None:
    _iv(0xBF737600CDDBEADD, p0, size, structName)

def SHOOT_SINGLE_BULLET_BETWEEN_COORDS_IGNORE_ENTITY_NEW(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, damage: int, p7: bool, weaponHash: int, ownerPed: int, isAudible: bool, isInvisible: bool, speed: float, entity: int, p14: bool, p15: bool, targetEntity: int, p17: bool, p18: int, p19: int, p20: int) -> None:
    _iv(0xBFE5756E7407064A, x1, y1, z1, x2, y2, z2, damage, p7, weaponHash, ownerPed, isAudible, isInvisible, speed, entity, p14, p15, targetEntity, p17, p18, p19, p20)

def REGISTER_SAVE_HOUSE(x: float, y: float, z: float, p3: float, p4: str, p5: int, p6: int) -> int:
    return _ii(0xC0714D0A7EEECA54, x, y, z, p3, p4, p5, p6)

def FORCE_GAME_STATE_PLAYING() -> None:
    _iv(0xC0AA53F866B3134D)

def WATER_OVERRIDE_FADE_OUT(p0: float) -> None:
    _iv(0xC3C221ADDDE31A11, p0)

def WATER_OVERRIDE_SET_SHOREWAVEMINAMPLITUDE(minAmplitude: float) -> None:
    _iv(0xC3EAD29AB273ECE8, minAmplitude)

def SET_MISSION_FLAG(toggle: bool) -> None:
    _iv(0xC4301E5121A0ED73, toggle)

def GET_PROFILE_SETTING(profileSetting: int) -> int:
    return _ii(0xC488FF2356EA7791, profileSetting)

def IS_SCARLETT_VERSION() -> bool:
    return _ib(0xC545AB1CF97ABB34)

def WATER_OVERRIDE_SET_STRENGTH(strength: float) -> None:
    _iv(0xC54A08C85AE4D410, strength)

def GET_SNOW_LEVEL() -> float:
    return _if(0xC5868A966E5BE3AE)

def SET_INSTANCE_PRIORITY_HINT(flag: int) -> None:
    _iv(0xC5F0A8EBD3F361CE, flag)

def CLEANUP_ASYNC_INSTALL() -> None:
    _iv(0xC79AE21974B01FB2)

def STOP_END_USER_BENCHMARK() -> None:
    _iv(0xC7DB36C24634F52B)

def ASIN(p0: float) -> float:
    return _if(0xC843060B5765DCE7, p0)

def DISABLE_HOSPITAL_RESTART(hospitalIndex: int, toggle: bool) -> None:
    _iv(0xC8535819C450EBA8, hospitalIndex, toggle)

def IS_INCIDENT_VALID(incidentId: int) -> bool:
    return _ib(0xC8BC6461E629BEAA, incidentId)

def REGISTER_BOOL_TO_SAVE(p0: int, name: str) -> None:
    _iv(0xC8F4131414C835A1, p0, name)

def GET_GROUND_Z_FOR_3D_COORD(x: float, y: float, z: float, groundZ: int, ignoreWater: bool, p5: bool) -> bool:
    return _ib(0xC906A7DAB05C8D2B, x, y, z, groundZ, ignoreWater, p5)

def SET_SAVE_MENU_ACTIVE(ignoreVehicle: bool) -> None:
    _iv(0xC9BF75D28165FF77, ignoreVehicle)

def IS_STRING_NULL_OR_EMPTY(string: str) -> bool:
    return _ib(0xCA042B6957743895, string)

def DISPLAY_ONSCREEN_KEYBOARD_WITH_LONGER_INITIAL_STRING(p0: int, windowTitle: str, p2: int, defaultText: str, defaultConcat1: str, defaultConcat2: str, defaultConcat3: str, defaultConcat4: str, defaultConcat5: str, defaultConcat6: str, defaultConcat7: str, maxInputLength: int) -> None:
    _iv(0xCA78CFA0366592FE, p0, windowTitle, p2, defaultText, defaultConcat1, defaultConcat2, defaultConcat3, defaultConcat4, defaultConcat5, defaultConcat6, defaultConcat7, maxInputLength)

def GET_INDEX_OF_CURRENT_LEVEL() -> int:
    return _ii(0xCBAD6729F7B1F4FC)

def IS_PS3_VERSION() -> bool:
    return _ib(0xCCA1072C29D096C2)

def CLEAR_WEATHER_TYPE_PERSIST() -> None:
    _iv(0xCCC39339BEF76CF5)

def GET_CITY_DENSITY() -> float:
    return _if(0xD10282B6E3751BA0)

def SET_DISPATCH_SPAWN_LOCATION(x: float, y: float, z: float) -> None:
    _iv(0xD10F442036302D50, x, y, z)

def ARE_CREDITS_RUNNING() -> bool:
    return _ib(0xD19C0826DC20CF1C)

def GET_HASH_KEY(string: str) -> int:
    return _ii(0xD24D37CC275948CC, string)

def SET_IDEAL_SPAWN_DISTANCE_FOR_INCIDENT(incidentId: int, p1: float) -> None:
    _iv(0xD261BA3E7E998072, incidentId, p1)

def GET_RANDOM_EVENT_FLAG() -> bool:
    return _ib(0xD2D57F1D764117B1)

def SHOULD_USE_METRIC_MEASUREMENTS() -> bool:
    return _ib(0xD3D15555431AB793)

def GET_RANDOM_INT_IN_RANGE(startRange: int, endRange: int) -> int:
    return _ii(0xD53343AA4FB7DD28, startRange, endRange)

def HAVE_REPLAY_STATS_BEEN_STORED() -> bool:
    return _ib(0xD642319C54AADEB6)

def SET_STUNT_JUMPS_CAN_TRIGGER(toggle: bool) -> None:
    _iv(0xD79185689F8FD5DF, toggle)

def RESET_WANTED_RESPONSE_NUM_PEDS_TO_SPAWN() -> None:
    _iv(0xD9F692D349249528)

def SET_FADE_IN_AFTER_DEATH_ARREST(toggle: bool) -> None:
    _iv(0xDA66D2796BA33F12, toggle)

def ENABLE_DISPATCH_SERVICE(dispatchService: int, toggle: bool) -> None:
    _iv(0xDC0F817884CDD856, dispatchService, toggle)

def DELETE_STUNT_JUMP(p0: int) -> None:
    _iv(0xDC518000E39DAE1F, p0)

def HAS_BULLET_IMPACTED_IN_BOX(p0: float, p1: float, p2: float, p3: float, p4: float, p5: float, p6: bool, p7: bool) -> bool:
    return _ib(0xDC8C5D7CFEAB8394, p0, p1, p2, p3, p4, p5, p6, p7)

def GET_REPLAY_STAT_COUNT() -> int:
    return _ii(0xDC9274A7EF6B2867)

def CLEAR_AREA_OF_OBJECTS(x: float, y: float, z: float, radius: float, flags: int) -> None:
    _iv(0xDD9B9B385AAC7F5B, x, y, z, radius, flags)

def IS_BULLET_IN_BOX(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, ownedByPlayer: bool) -> bool:
    return _ib(0xDE0F6D7450D37351, x1, y1, z1, x2, y2, z2, ownedByPlayer)

def ALLOW_MISSION_CREATOR_WARP(toggle: bool) -> None:
    _iv(0xDEA36202FC3382DF, toggle)

def GET_COORDS_OF_PROJECTILE_TYPE_WITHIN_DISTANCE(ped: int, weaponHash: int, distance: float, outCoords: int, p4: bool) -> bool:
    return _ib(0xDFB4138EEFED7B81, ped, weaponHash, distance, outCoords, p4)

def BEGIN_REPLAY_STATS(p0: int, p1: int) -> None:
    _iv(0xE0E500246FF73D66, p0, p1)

def PLAY_TENNIS_SWING_ANIM(ped: int, animDict: str, animName: str, p3: float, p4: float, p5: bool) -> None:
    _iv(0xE266ED23311F24D4, ped, animDict, animName, p3, p4, p5)

def _IS_XBOXPC_VERSION() -> bool:
    return _ib(0xE2BCD0EFAE90D1F4)

def ENABLE_STUNT_JUMP_SET(p0: int) -> None:
    _iv(0xE369A5783B866016, p0)

def SHOOT_SINGLE_BULLET_BETWEEN_COORDS_IGNORE_ENTITY(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, damage: int, p7: bool, weaponHash: int, ownerPed: int, isAudible: bool, isInvisible: bool, speed: float, entity: int, p14: int) -> None:
    _iv(0xE3A7742E0B7A2F8B, x1, y1, z1, x2, y2, z2, damage, p7, weaponHash, ownerPed, isAudible, isInvisible, speed, entity, p14)

def PREVENT_ARREST_STATE_THIS_FRAME() -> None:
    _iv(0xE3D969D2785FFB5E)

def SET_WANTED_RESPONSE_NUM_PEDS_TO_SPAWN(p0: int, p1: int) -> None:
    _iv(0xE532EC1A63231B4F, p0, p1)

def IS_POINT_OBSCURED_BY_A_MISSION_ENTITY(p0: float, p1: float, p2: float, p3: float, p4: float, p5: float, p6: int) -> bool:
    return _ib(0xE54E209C35FFA18D, p0, p1, p2, p3, p4, p5, p6)

def RESTART_GAME() -> None:
    _iv(0xE574A662ACAEFBB1)

def GET_SYSTEM_TIME_STEP() -> float:
    return _if(0xE599A503B3837E1B)

def REMOVE_POP_MULTIPLIER_SPHERE(id: int, p1: bool) -> None:
    _iv(0xE6869BECDD8F2403, id, p1)

def CANCEL_STUNT_JUMP() -> None:
    _iv(0xE6B7B0ACD4E4B75E)

def CLEAR_BIT(address: int, offset: int) -> None:
    _iv(0xE80492A9AC099A93, address, offset)

def HAS_RESUMED_FROM_SUSPEND() -> bool:
    return _ib(0xE8B9C0EC9E183F35)

def GET_TENNIS_SWING_ANIM_SWUNG(ped: int) -> bool:
    return _ib(0xE95B0C7D5BA3B96B, ped)

def UI_STARTED_END_USER_BENCHMARK() -> bool:
    return _ib(0xEA2F2061875EED90)

def ACTIVITY_FEED_ACTION_START_WITH_COMMAND_LINE(p0: str, p1: str) -> None:
    _iv(0xEB078CA2B5E82ADD, p0, p1)

def SET_WIND_DIRECTION(direction: float) -> None:
    _iv(0xEB0F4468467B4528, direction)

def STOP_SAVE_STRUCT() -> None:
    _iv(0xEB1774DF12BB9F12)

def QUEUE_MISSION_REPEAT_SAVE_FOR_BENCHMARK_TEST() -> bool:
    return _ib(0xEB2104E905C6F2E9)

def RESET_DISPATCH_TIME_BETWEEN_SPAWN_ATTEMPTS(p0: int) -> None:
    _iv(0xEB2DB0CAD13154B3, p0)

def GET_NUMBER_RESOURCES_ALLOCATED_TO_WANTED_LEVEL(dispatchService: int) -> int:
    return _ii(0xEB4A0C2D56441717, dispatchService)

def QUIT_GAME() -> None:
    _iv(0xEB6891F03362FB12)

def ACTIVITY_FEED_ADD_LITERAL_SUBSTRING_TO_CAPTION(p0: str) -> None:
    _iv(0xEBD3205A207939ED, p0)

def GET_CONTENT_ID_INDEX(contentId: int) -> int:
    return _ii(0xECF041186C5A94DC, contentId)

def SET_WEATHER_TYPE_NOW_PERSIST(weatherType: str) -> None:
    _iv(0xED712CA327900C8A, weatherType)

def REGISTER_TEXT_LABEL_TO_SAVE(p0: int, name: str) -> None:
    _iv(0xEDB1232C5BEAE62F, p0, name)

def SET_WIND_SPEED(speed: float) -> None:
    _iv(0xEE09ECEDBABE47FC, speed)

def IS_PROJECTILE_TYPE_IN_ANGLED_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, width: float, p7: int, ownedByPlayer: bool) -> bool:
    return _ib(0xF0BC12401061DEA0, x1, y1, z1, x2, y2, z2, width, p7, ownedByPlayer)

def ABSI(value: int) -> int:
    return _ii(0xF0D31AD191A74F87, value)

def USING_MISSION_CREATOR(toggle: bool) -> None:
    _iv(0xF14878FC50BEC6EE, toggle)

def GET_DISTANCE_BETWEEN_COORDS(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, useZ: bool) -> float:
    return _if(0xF1B760881820C952, x1, y1, z1, x2, y2, z2, useZ)

def IS_STRING_NULL(string: str) -> bool:
    return _ib(0xF22B6C47C6EAB066, string)

def GET_RANDOM_MWC_INT_IN_RANGE(startRange: int, endRange: int) -> int:
    return _ii(0xF2D49816A804D134, startRange, endRange)

def SLERP_NEAR_QUATERNION(t: float, x: float, y: float, z: float, w: float, x1: float, y1: float, z1: float, w1: float, outX: int, outY: int, outZ: int, outW: int) -> None:
    _iv(0xF2F6A2FA49278625, t, x, y, z, w, x1, y1, z1, w1, outX, outY, outZ, outW)

def SET_CLOUDS_ALPHA(opacity: float) -> None:
    _iv(0xF36199225D6D8C86, opacity)

def GET_CURR_WEATHER_STATE(weatherType1: int, weatherType2: int, percentWeather2: int) -> None:
    _iv(0xF3BBE884A14BB413, weatherType1, weatherType2, percentWeather2)

def SET_FADE_IN_AFTER_LOAD(toggle: bool) -> None:
    _iv(0xF3D78F59DFE18D79, toggle)

def GET_LINE_PLANE_INTERSECTION(p0: float, p1: float, p2: float, p3: float, p4: float, p5: float, p6: float, p7: float, p8: float, p9: float, p10: float, p11: float, p12: int) -> bool:
    return _ib(0xF56DFB7B61BE7276, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12)

def FORCE_LIGHTNING_FLASH() -> None:
    _iv(0xF6062E089251C898)

def IS_XBOX360_VERSION() -> bool:
    return _ib(0xF6201B4DAF662A9D)

def WATER_OVERRIDE_SET_OCEANWAVEMINAMPLITUDE(minAmplitude: float) -> None:
    _iv(0xF751B16FB32ABC1D, minAmplitude)

def IS_SCE_PLATFORM() -> bool:
    return _ib(0xF911E695C1EB8518)

def OVERRIDE_FREEZE_FLAGS(p0: bool) -> None:
    _iv(0xFA3FFB0EEBC288A3, p0)

def REGISTER_TEXT_LABEL_63_TO_SAVE(p0: int, name: str) -> None:
    _iv(0xFAA457EF263E8763, p0, name)

def SET_TICKER_JOHNMARSTON_IS_DONE() -> None:
    _iv(0xFB00CA71DA386228)

def SET_WEATHER_TYPE_OVERTIME_PERSIST(weatherType: str, time: float) -> None:
    _iv(0xFB5045B7C42B75BF, weatherType, time)

def TOGGLE_SHOW_OPTIONAL_STUNT_JUMP_CAMERA(toggle: bool) -> None:
    _iv(0xFB80AB299D2EE1BD, toggle)

def LOAD_CLOUD_HAT(name: str, transitionTime: float) -> None:
    _iv(0xFC4842A34657BFCB, name, transitionTime)

def GET_FRAME_COUNT() -> int:
    return _ii(0xFC8202EFC642E6F2)

def GET_NUMBER_OF_FREE_STACKS_OF_THIS_SIZE(stackSize: int) -> int:
    return _ii(0xFEAD16FC8F9DFC0F, stackSize)

def IS_SNIPER_BULLET_IN_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> bool:
    return _ib(0xFEFCF11B01287125, x1, y1, z1, x2, y2, z2)

def SET_EXPLOSIVE_MELEE_THIS_FRAME(player: int) -> None:
    _iv(0xFF1BED81BFDC0FE0, player)
