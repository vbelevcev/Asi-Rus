"""Auto-generated raw native bindings for namespace STATS.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_str as _is


def PLAYSTATS_NPC_PHONE(p0: int) -> None:
    _iv(0x0077F15613D36993, p0)

def SEND_METRIC_PUNISH_BODYGUARD(p0: int) -> None:
    _iv(0x015B03EE1C43E6EC, p0)

def _PLAYSTATS_DEATH_INFO(victimPed: int, killerPed: int, mentalState: int, revengeKill: bool, victimKvK: int, killerKvK: int) -> None:
    _iv(0x01D8B04D02F1217F, victimPed, killerPed, mentalState, revengeKill, victimKvK, killerKvK)

def PLAYSTATS_MC_FORMATION_ENDS(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int) -> None:
    _iv(0x03C2EEBB04B3FB72, p0, p1, p2, p3, p4, p5, p6)

def STAT_SET_CHEAT_IS_ACTIVE() -> None:
    _iv(0x047CBED6F6F8B63C)

def PLAYSTATS_CASINO_INSIDE_TRACK(p0: int) -> None:
    _iv(0x049F059625058A86, p0)

def PLAYSTATS_RECOVER_CONTRABAND_MISSION(data: int) -> None:
    _iv(0x04D90BA8207ADA2D, data)

def PLAYSTATS_BC_SMASH_AND_GRAB(p0: int) -> None:
    _iv(0x06EAF70AE066441E, p0)

def PLAYSTATS_STARTED_SESSION_IN_OFFLINEMODE() -> None:
    _iv(0x098760C7461724CD)

def PLAYSTATS_CASINO_CHIP(p0: int) -> None:
    _iv(0x0999F3F090EC5012, p0)

def PLAYSTATS_SWITCH_MC_EMBLEM(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x0A50D2604E05CB94, p0, p1, p2, p3, p4)

def PLAYSTATS_FM_EVENT_DEADDROP(p0: int) -> None:
    _iv(0x0A9C7F36E5D7B683, p0)

def PLAYSTATS_CHANGE_MC_ROLE(p0: int, p1: int, p2: int, p3: int, role: int, p5: int, p6: int) -> None:
    _iv(0x0B565B0AAE56A0E8, p0, p1, p2, p3, role, p5, p6)

def STAT_GET_VEHICLE_BAIL_DISTANCE() -> float:
    return _if(0x0B8B7F74BF061C6D)

def PLAYSTATS_DAR_CHECKPOINT(data: int) -> None:
    _iv(0x0BC254FF3A911501, data)

def GET_PACKED_STAT_INT_CODE(index: int, characterSlot: int) -> int:
    return _ii(0x0BC900A6FE73770C, index, characterSlot)

def LEADERBOARDS_WRITE_ADD_COLUMN(p0: int, p1: int, p2: float) -> None:
    _iv(0x0BCA1D2C47B0D269, p0, p1, p2)

def PLAYSTATS_CASINO_LUCKY_SEVEN(p0: int) -> None:
    _iv(0x0C432C1435F5E4FA, p0)

def SET_FREEMODE_PROLOGUE_DONE(p0: int, characterSlot: int) -> None:
    _iv(0x0D01D20616FC73FB, p0, characterSlot)

def STAT_SLOT_IS_LOADED(statSlot: int) -> bool:
    return _ib(0x0D0A9F0E7BD91E3C, statSlot)

def PLAYSTATS_GUNRUNNING_MISSION_ENDED(data: int) -> None:
    _iv(0x0EACDF8487D5155A, data)

def PLAYSTATS_FRIEND_ACTIVITY(p0: int, p1: bool) -> None:
    _iv(0x0F71DE29AB2258F1, p0, p1)

def PLAYSTATS_VEH_DEL(bossId1: int, bossId2: int, bossType: int, vehicleID: int, reason: int) -> None:
    _iv(0x10A691F5756416D0, bossId1, bossId2, bossType, vehicleID, reason)

def LEADERBOARDS_GET_NUMBER_OF_COLUMNS(p0: int, p1: int) -> int:
    return _ii(0x117B45156D7EFF2E, p0, p1)

def PLAYSTATS_CARCLUB_CHALLENGE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x1187CB58D7F3BED7, p0, p1, p2, p3)

def STAT_GET_BOOL(statHash: int, outValue: int, p2: int) -> bool:
    return _ib(0x11B5E6D2AE73F48E, statHash, outValue, p2)

def PRESENCE_EVENT_UPDATESTAT_INT(statHash: int, value: int, p2: int) -> None:
    _iv(0x11FF1C80276097ED, statHash, value, p2)

def PLAYSTATS_ROS_BET(amount: int, act: int, player: int, cm: float) -> None:
    _iv(0x121FB4DDDC2D5291, amount, act, player, cm)

def PLAYSTATS_JOB_LTS_ROUND_END(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x14E0B2D1AD1044E0, p0, p1, p2, p3)

def PLAYSTATS_BC_PROTECTION_RACKET(p0: int) -> None:
    _iv(0x14EDA9EE27BD1626, p0)

def _PLAYSTATS_SHOWROOM_OVERVIEW(data: int) -> None:
    _iv(0x151D6C04C9E2742F, data)

def SET_PACKED_STAT_INT_CODE(index: int, value: int, characterSlot: int) -> None:
    _iv(0x1581503AE529CD2E, index, value, characterSlot)

def PLAYSTATS_FM_EVENT_KINGOFTHECASTLE(p0: int) -> None:
    _iv(0x164C5FF663790845, p0)

def PLAYSTATS_SHOP_ITEM(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x176852ACAAC173D1, p0, p1, p2, p3, p4)

def STAT_SET_GXT_LABEL(statName: int, value: str, save: bool) -> bool:
    return _ib(0x17695002FD8B2AE0, statName, value, save)

def PLAYSTATS_FREEMODE_CASINO_MISSION_ENDED(data: int) -> None:
    _iv(0x1A0D4A6C336B7BC5, data)

def PLAYSTATS_ROBBERY_PREP(p0: int) -> None:
    _iv(0x1A67DFBF1F5C3835, p0)

def PLAYSTATS_FM_EVENT_PENNEDIN(p0: int) -> None:
    _iv(0x1A7CE7CD3E653485, p0)

def STAT_GET_FLYING_ALTITUDE(outValue: int) -> bool:
    return _ib(0x1A8EA222F9C67DBB, outValue)

def PLAYSTATS_CRATE_DROP_MISSION_DONE(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int, p7: int) -> None:
    _iv(0x1CAE5D2E3F9A07F0, p0, p1, p2, p3, p4, p5, p6, p7)

def PLAYSTATS_INSTANCED_HEIST_ENDED(data: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x1E1497D0D2108115, data, p1, p2, p3)

def PLAYSTATS_PIMENU_HIDE_OPTIONS(data: int) -> None:
    _iv(0x203B381133817079, data)

def STAT_GET_USER_ID(statHash: int) -> str:
    return _is(0x2365C388E393BBE2, statHash)

def PLAYSTATS_CASINO_INSIDE_TRACK_LIGHT(p0: int) -> None:
    _iv(0x23A3CBCD50D54E47, p0)

def PLAYSTATS_DEFEND_CONTRABAND_MISSION(data: int) -> None:
    _iv(0x2605663BD4F23B5D, data)

def STAT_RESET_ALL_ONLINE_CHARACTER_STATS(p0: int) -> None:
    _iv(0x26D7399B9587FE89, p0)

def PLAYSTATS_RIVAL_BEHAVIOR(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int, p7: int, p8: int, p9: int) -> None:
    _iv(0x27AA1C973CACFE63, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)

def PLAYSTATS_HUB_ENTRY(p0: int) -> None:
    _iv(0x2818FF6638CB09DE, p0)

def PLAYSTATS_BW_FRAGILE_GOODS(p0: int) -> None:
    _iv(0x282B6739644F4347, p0)

def PLAYSTATS_CHANGE_MC_OUTFIT(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x28ECB8AC2F607DB2, p0, p1, p2, p3, p4)

def GET_PACKED_NG_INT_STAT_KEY(index: int, spStat: bool, charStat: bool, character: int, section: str) -> int:
    return _ii(0x2B4CDCA6F07FF3DA, index, spStat, charStat, character, section)

def PLAYSTATS_IMPORT_EXPORT_MISSION_DONE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x2B69F5074C894811, p0, p1, p2, p3)

def STAT_SET_DATE(statName: int, value: int, numFields: int, save: bool) -> bool:
    return _ib(0x2C29BFB64F4FCBE4, statName, value, numFields, save)

def PLAYSTATS_FM_EVENT_HUNTBEAST(p0: int) -> None:
    _iv(0x2CD90358F67D0AA8, p0)

def STAT_GET_NUMBER_OF_SECONDS(statName: int) -> int:
    return _ii(0x2CE056FF3723F00B, statName)

def PLAYSTATS_WAREHOUSE_MISSION_ENDED(p0: int) -> None:
    _iv(0x2D7A9B577E72385E, p0)

def PLAYSTATS_HEIST3_FINALE(p0: int) -> None:
    _iv(0x2E0259BABC27A327, p0)

def LEADERBOARDS_WRITE_ADD_COLUMN_LONG(p0: int, p1: int, p2: int) -> None:
    _iv(0x2E65248609523599, p0, p1, p2)

def PLAYSTATS_HEIST4_HACK(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x2FA3173480008493, p0, p1, p2, p3, p4)

def LEADERBOARDS_READ_SUCCESSFUL(p0: int, p1: int, p2: int) -> bool:
    return _ib(0x2FB19228983E832C, p0, p1, p2)

def PRESENCE_EVENT_UPDATESTAT_FLOAT(statHash: int, value: float, p2: int) -> None:
    _iv(0x30A6614C1F7799B8, statHash, value, p2)

def PLAYSTATS_BUSINESS_BATTLE_ENDED(p0: int) -> None:
    _iv(0x316DB59CD14C1774, p0)

def PLAYSTATS_SMUGGLER_MISSION_ENDED(data: int) -> None:
    _iv(0x320C35147D5B5DDD, data)

def STAT_SAVE_MIGRATION_CONSUME_CONTENT(contentId: int, srcPlatform: str, srcGamerHandle: str) -> bool:
    return _ib(0x3270F67EED31FBC1, contentId, srcPlatform, srcGamerHandle)

def STAT_GET_CURRENT_DRIVING_REVERSE_DISTANCE() -> float:
    return _if(0x32CAC93C9DE73D32)

def STAT_START_RECORD_STAT(statType: int, valueType: int) -> bool:
    return _ib(0x33D72899E24C3365, statType, valueType)

def LEADERBOARDS2_READ_GET_ROW_DATA_INFO(p0: int, p1: int) -> bool:
    return _ib(0x34770B9CE0E03B91, p0, p1)

def PLAYSTATS_CLOTH_CHANGE(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x34B973047A2268B9, p0, p1, p2, p3, p4)

def STAT_GET_POS(statName: int, outX: int, outY: int, outZ: int, p4: int) -> bool:
    return _ib(0x350F82CCB186AA1B, statName, outX, outY, outZ, p4)

def PLAYSTATS_STONE_HATCHET_ENDED(data: int) -> None:
    _iv(0x35E39E5570358630, data)

def PLAYSTATS_SWITCH_PASSIVE_MODE(p0: bool, p1: int, p2: int, p3: int) -> None:
    _iv(0x35EEC6C2BC821A71, p0, p1, p2, p3)

def LEADERBOARDS2_READ_GET_ROW_DATA_FLOAT(p0: int, p1: int) -> float:
    return _if(0x38491439B6BA7F7D, p0, p1)

def SET_PROFILE_SETTING_CREATOR_DM_DONE(value: int) -> None:
    _iv(0x38BAAA5DD4C9D19F, value)

def PLAYSTATS_FM_EVENT_CHECKPOINTCOLLECTION(p0: int) -> None:
    _iv(0x3DE3AA516FB126A4, p0)

def PLAYSTATS_CASINO_BLACKJACK(p0: int) -> None:
    _iv(0x3EAE97309727E7AD, p0)

def START_BEING_BOSS(p0: int, p1: int, p2: int) -> None:
    _iv(0x3EBEAC6C3F81F6BD, p0, p1, p2)

def PLAYSTATS_FM_EVENT_PASSTHEPARCEL(p0: int) -> None:
    _iv(0x419615486BBF1956, p0)

def STAT_NETWORK_INCREMENT_ON_SUICIDE(p0: int, p1: float) -> None:
    _iv(0x428EAF89E24F6C36, p0, p1)

def CHANGE_GOON_LOOKING_FOR_WORK(p0: int) -> None:
    _iv(0x44919CC079BB60BF, p0)

def PLAYSTATS_APPEND_DIRECTOR_METRIC(p0: int) -> None:
    _iv(0x46326E13DA4E0546, p0)

def PLAYSTATS_FM_MISSION_END(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x46A70777BE6CEAB9, p0, p1, p2, p3)

def PLAYSTATS_AWARD_XP(amount: int, type: int, category: int) -> None:
    _iv(0x46F917F6B4128FE4, amount, type, category)

def PLAYSTATS_AWARD_BAD_SPORT(id: int) -> None:
    _iv(0x47B32F5611E6E483, id)

def STAT_SET_FLOAT(statName: int, value: float, save: bool) -> bool:
    return _ib(0x4851997F37FE9B3C, statName, value, save)

def _PLAYSTATS_PLAYER_STYLE(p0: int) -> None:
    _iv(0x48FAC5DC7AC6EA99, p0)

def STAT_DELETE_SLOT(p0: int) -> bool:
    return _ib(0x49A49BED12794D70, p0)

def STAT_SET_BOOL(statName: int, value: bool, save: bool) -> bool:
    return _ib(0x4B33C4243DE0C432, statName, value, save)

def STAT_MIGRATE_CHECK_ALREADY_DONE() -> bool:
    return _ib(0x4C89FE2BDEB3F169)

def PLAYSTATS_FAST_TRVL(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int, p7: int, p8: int, p9: int, p10: int) -> None:
    _iv(0x4DC416F246A41FC8, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)

def PLAYSTATS_ARCADE_LOVE_MATCH(p0: int, p1: int) -> None:
    _iv(0x4FCDBD3F0A813C25, p0, p1)

def STAT_SAVE_MIGRATION_CANCEL_PENDING_OPERATION() -> bool:
    return _ib(0x4FEF53183C3C6414)

def PLAYSTATS_BACKGROUND_SCRIPT_ACTION(action: str, value: int) -> None:
    _iv(0x5009DFD741329729, action, value)

def PLAYSTATS_EARNED_MC_POINTS(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int) -> None:
    _iv(0x501478855A6074CE, p0, p1, p2, p3, p4, p5)

def PLAYSTATS_BAN_ALERT(p0: int) -> None:
    _iv(0x516FC96EB88EEFE5, p0)

def PLAYSTATS_ARCADE_GAME(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int) -> None:
    _iv(0x533A7D1EA58DF958, p0, p1, p2, p3, p4, p5, p6)

def PLAYSTATS_HEIST3_PREP(p0: int) -> None:
    _iv(0x53C31853EC9531FF, p0)

def PLAYSTATS_BC_CASHING(p0: int) -> None:
    _iv(0x53CAE13E9B426993, p0)

def STAT_GET_LICENSE_PLATE(statName: int) -> str:
    return _is(0x5473D4195058B2E4, statName)

def SET_PROFILE_SETTING_CREATOR_CTF_DONE(value: int) -> None:
    _iv(0x55384438FC55AD8E, value)

def STAT_GET_CURRENT_SPEED() -> float:
    return _if(0x55A8BECAF28A4EB7)

def _PLAYSTATS_ALERT(data: int) -> None:
    _iv(0x5649CA22AF74E019, data)

def STAT_GET_CANCEL_SAVE_MIGRATION_STATUS() -> int:
    return _ii(0x567384DFA67029E6)

def STAT_SET_OPEN_SAVETYPE_IN_JOB(p0: int) -> None:
    _iv(0x5688585E6D563CD8, p0)

def _PLAYSTATS_SCRIPT_EVENT_FPOM(data: int) -> None:
    _iv(0x574A7808450E141C, data)

def LEADERBOARDS_GET_CACHE_NUMBER_OF_ROWS(p0: int) -> int:
    return _ii(0x58A651CD201D89AD, p0)

def PLAYSTATS_HUB_EXIT(p0: int) -> None:
    _iv(0x5A46ACE5C4661132, p0)

def STAT_COMMUNITY_START_SYNCH() -> bool:
    return _ib(0x5A556B229A169402)

def STAT_MIGRATE_CHECK_GET_IS_PLATFORM_AVAILABLE(p0: int) -> int:
    return _ii(0x5BD5F255321C4AAF, p0)

def PLAYSTATS_QUIT_MODE(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x5BF29846C6527C54, p0, p1, p2, p3, p4)

def PLAYSTATS_NJVS_VOTE(p0: int) -> None:
    _iv(0x5CDAED54B34B0ED0, p0)

def LEADERBOARDS2_READ_BY_RADIUS(p0: int, p1: int, p2: int) -> bool:
    return _ib(0x5CE587FB5A42C8C4, p0, p1, p2)

def PLAYSTATS_IDLE_KICK(msStoodIdle: int) -> None:
    _iv(0x5DA3A8DE8CB6226F, msStoodIdle)

def GET_PLAYER_HAS_DRIVEN_ALL_VEHICLES() -> bool:
    return _ib(0x5EAD2BF6484852E4)

def PLAYSTATS_BW_HEAD_HUNTER(p0: int) -> None:
    _iv(0x5FF2C33B13A02A11, p0)

def PLAYSTATS_CHEAT_APPLIED(cheat: str) -> None:
    _iv(0x6058665D72302D3F, cheat)

def PLAYSTATS_HIT_CONTRABAND_DESTROY_LIMIT(p0: int) -> None:
    _iv(0x60EEDC12AF66E846, p0)

def GET_PACKED_INT_STAT_KEY(index: int, spStat: bool, charStat: bool, character: int) -> int:
    return _ii(0x61E111E323419E07, index, spStat, charStat, character)

def STAT_DISABLE_STATS_TRACKING() -> None:
    _iv(0x629526ABA383BCAA)

def PRESENCE_EVENT_UPDATESTAT_INT_WITH_STRING(statHash: int, value: int, p2: int, string: str) -> None:
    _iv(0x6483C25849031C4F, statHash, value, p2, string)

def STAT_GET_MASKED_INT(statHash: int, outValue: int, p2: int, p3: int, p4: int) -> bool:
    return _ib(0x655185A06D9EEAAB, statHash, outValue, p2, p3, p4)

def PLAYSTATS_FM_EVENT_COMPETITIVEURBANWARFARE(p0: int) -> None:
    _iv(0x6551B1F7F6CD46EA, p0)

def PLAYSTATS_CASINO_ROULETTE_LIGHT(p0: int) -> None:
    _iv(0x6572ABA3DE1197FC, p0)

def PLAYSTATS_DRONE_USAGE(p0: int, p1: int, p2: int) -> None:
    _iv(0x66C7BB2416ED3FCE, p0, p1, p2)

def PLAYSTATS_SPIN_WHEEL(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x6731DE84A38BFAD0, p0, p1, p2, p3)

def PLAYSTATS_BW_ASSAULT(p0: int) -> None:
    _iv(0x678F86D8FC040BDB, p0)

def STAT_SET_PROFILE_SETTING_VALUE(profileSetting: int, value: int) -> None:
    _iv(0x68F01422BE1D838F, profileSetting, value)

def PLAYSTATS_CARCLUB_PRIZE(p0: int, vehicleModel: int) -> None:
    _iv(0x69C922B677621428, p0, vehicleModel)

def PLAYSTATS_ODDJOB_DONE(totalTimeMs: int, p1: int, p2: bool) -> None:
    _iv(0x69DEA3E9DB727B4C, totalTimeMs, p1, p2)

def STAT_SET_LICENSE_PLATE(statName: int, str: str) -> bool:
    return _ib(0x69FF13266D7296DA, statName, str)

def PLAYSTATS_FM_EVENT_CHALLENGES(p0: int) -> None:
    _iv(0x6A60E43998228229, p0)

def STAT_GET_BLOCK_SAVES() -> bool:
    return _ib(0x6A7F19756F1A9016)

def GET_BOSS_GOON_UUID(characterSlot: int, p1: int, p2: int) -> None:
    _iv(0x6BC0ACD0673ACEBE, characterSlot, p1, p2)

def END_BEING_GOON(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x6BCCF9948492FD85, p0, p1, p2, p3, p4)

def PLAYSTATS_CREATE_MATCH_HISTORY_ID_2(playerAccountId: int, posixTime: int) -> bool:
    return _ib(0x6DEE77AFF8C21BD1, playerAccountId, posixTime)

def STAT_GET_CHALLENGE_FLYING_DIST() -> float:
    return _if(0x6E0A5253375C4584)

def FORCE_CLOUD_MP_STATS_DOWNLOAD_AND_OVERWRITE_LOCAL_SAVE() -> None:
    _iv(0x6F361B8889A792A3)

def PLAYSTATS_ARENA_WARS_SPECTATOR(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x6F4F599753F8200A, p0, p1, p2, p3, p4)

def SEND_METRIC_GHOSTING_TO_PLAYER(p0: int) -> None:
    _iv(0x7033EEFD9B28088E, p0)

def PLAYSTATS_AWARD_NAV(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0x70F52471E758EBAE, p0, p1, p2, p3)

def PLAYSTATS_RANDOM_MISSION_DONE(name: str, p1: int, p2: int, p3: int) -> None:
    _iv(0x71862B1D855F32E1, name, p1, p2, p3)

def LEADERBOARDS2_READ_GET_ROW_DATA_END() -> None:
    _iv(0x71B008056E5692D6)

def SET_JOB_ACTIVITY_ID_STARTED(p0: int, characterSlot: int) -> None:
    _iv(0x723C1CE13FBFDB67, p0, characterSlot)

def PLAYSTATS_BC_POINT_TO_POINT(p0: int) -> None:
    _iv(0x73001E34F85137F8, p0)

def STAT_GET_NUMBER_OF_MINUTES(statName: int) -> int:
    return _ii(0x7583B4BE4C5A41B5, statName)

def STAT_GET_INT(statHash: int, outValue: int, p2: int) -> bool:
    return _ib(0x767FBC2AC802EF3D, statHash, outValue, p2)

def HIRED_LIMO(p0: int, p1: int) -> None:
    _iv(0x792271AB35C356A4, p0, p1)

def PLAYSTATS_ACQUIRED_HIDDEN_PACKAGE(p0: int) -> None:
    _iv(0x79AB33F0FBFAC40C, p0)

def SET_FREEMODE_STRAND_PROGRESSION_STATUS(profileSetting: int, settingValue: int) -> None:
    _iv(0x79D310A861697CC9, profileSetting, settingValue)

def PLAYSTATS_BC_CAR_JACKING(p0: int) -> None:
    _iv(0x7B18DA61F6BAE9D5, p0)

def STAT_SET_MASKED_INT(statName: int, p1: int, p2: int, p3: int, save: bool) -> bool:
    return _ib(0x7BBB1B54583ED410, statName, p1, p2, p3, save)

def PLAYSTATS_MISSION_OVER(p0: str, p1: int, p2: int, p3: bool, p4: bool, p5: bool) -> None:
    _iv(0x7C4BB33A8CED7324, p0, p1, p2, p3, p4, p5)

def LEADERBOARDS_READ_CLEAR(p0: int, p1: int, p2: int) -> int:
    return _ii(0x7CCE5C737A665701, p0, p1, p2)

def PLAYSTATS_BC_SALVAGE(p0: int) -> None:
    _iv(0x7D36291161859389, p0)

def STAT_SAVE_PENDING() -> bool:
    return _ib(0x7D3A583856F2C5AC)

def PLAYSTATS_IMPEXP_MISSION_ENDED(p0: int) -> None:
    _iv(0x7D8BA05688AD64C7, p0)

def _PLAYSTATS_INIT_MULTIPLAYER(p0: int, p1: int, p2: int) -> None:
    _iv(0x7E5EED10B11CEDBA, p0, p1, p2)

def STAT_CLOUD_SLOT_SAVE_FAILED(p0: int) -> bool:
    return _ib(0x7E6946F68A38B74F, p0)

def _PLAYSTATS_RANDOM_EVENT(p0: int) -> None:
    _iv(0x7EA06F970F999394, p0)

def LEADERBOARDS2_READ_BY_SCORE_INT(p0: int, p1: int, p2: int) -> bool:
    return _ib(0x7EEC7E4F6984A16A, p0, p1, p2)

def STAT_CLOUD_SLOT_LOAD_FAILED(p0: int) -> bool:
    return _ib(0x7F2C4CDF2E82DF4C, p0)

def PLAYSTATS_MASTER_CONTROL(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x810B5FCC52EC7FF0, p0, p1, p2, p3, p4)

def PLAYSTATS_NIGHTCLUB_MISSION_ENDED(p0: int) -> None:
    _iv(0x830C3A44EB3F2CF9, p0)

def PLAYSTATS_DUPE_DETECTED(data: int) -> None:
    _iv(0x848B66100EE33B05, data)

def STAT_GET_CURRENT_FRONT_WHEEL_DISTANCE() -> float:
    return _if(0x84A810B375E69C0E)

def PLAYSTATS_FM_EVENT_HOTPROPERTY(p0: int) -> None:
    _iv(0x84DFC579C2FC214C, p0)

def PLAYSTATS_ENTER_SESSION_PACK(data: int) -> None:
    _iv(0x878FF156D36E9956, data)

def PLAYSTATS_BW_HUNT_THE_BOSS(p0: int) -> None:
    _iv(0x88087EE1F28024AE, p0)

def LEADERBOARDS2_READ_GET_ROW_DATA_INT(p0: int, p1: int) -> int:
    return _ii(0x88578F6EC36B4A3A, p0, p1)

def STAT_GET_SAVE_MIGRATION_STATUS(data: int) -> int:
    return _ii(0x886913BBEACA68C1, data)

def PLAYSTATS_INVENTORY(p0: int) -> None:
    _iv(0x887DAD63CF5B7908, p0)

def PLAYSTATS_MC_CLUBHOUSE_ACTIVITY(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int, p7: int) -> None:
    _iv(0x8989CBD7B4E82534, p0, p1, p2, p3, p4, p5, p6, p7)

def _PLAYSTATS_ACID_MISSION_END(p0: int) -> None:
    _iv(0x8A23D1324F6B2BAC, p0)

def PLAYSTATS_STOP_TRACKING_STUNTS() -> None:
    _iv(0x8A800DACCC0DA55D)

def STAT_GET_DATE(statHash: int, outValue: int, numFields: int, p3: int) -> bool:
    return _ib(0x8B0FACEFC36C824B, statHash, outValue, numFields, p3)

def STAT_IS_RECORDING_STAT() -> bool:
    return _ib(0x8B9CDBD6C566C38C)

def PLAYSTATS_FM_EVENT_URBANWARFARE(p0: int) -> None:
    _iv(0x8C9D11605E59D955, p0)

def STAT_SET_USER_ID(statName: int, value: str, save: bool) -> bool:
    return _ib(0x8CDDF1E452BABE11, statName, value, save)

def PLAYSTATS_BW_BOSSONBOSSDEATHMATCH(p0: int) -> None:
    _iv(0x8D8ADB562F09A245, p0)

def LEADERBOARDS_CLEAR_CACHE_DATA_ID(p0: int) -> None:
    _iv(0x8EC74CEB042E7CFF, p0)

def PLAYSTATS_QUICKFIX_TOOL(element: int, item: str) -> None:
    _iv(0x90D0622866E80445, element, item)

def LEADERBOARDS_GET_CACHE_DATA_ROW(p0: int, p1: int, p2: int) -> bool:
    return _ib(0x9120E8DBA3D69273, p0, p1, p2)

def LEADERBOARDS2_READ_FRIENDS_BY_ROW(p0: int, p1: int, p2: int, p3: bool, p4: int, p5: int) -> bool:
    return _ib(0x918B101666F9CB83, p0, p1, p2, p3, p4, p5)

def PLAYSTATS_START_TRACKING_STUNTS() -> None:
    _iv(0x928DBFB892638EF3)

def PLAYSTATS_HEIST3_HACK(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int) -> None:
    _iv(0x92FC0EEDFAC04A14, p0, p1, p2, p3, p4, p5)

def PLAYSTATS_NPC_INVITE(p0: str) -> None:
    _iv(0x93054C88E6AA7C44, p0)

def PLAYSTATS_BC_MOST_WANTED(p0: int) -> None:
    _iv(0x930F504203F561C9, p0)

def PACKED_STAT_GET_INT_STAT_INDEX(p0: int) -> int:
    return _ii(0x94F12ABF9C79E339, p0)

def PLAYSTATS_CASINO_ROULETTE(p0: int) -> None:
    _iv(0x95101C443A84E7F1, p0)

def PLAYSTATS_PEGASUS_AS_PERSONAL_AIRCRAFT(modelHash: int) -> None:
    _iv(0x9572BD4DD6B72122, modelHash)

def _PLAYSTATS_SHOWROOM_NAV(p0: int, p1: int, entity: int) -> None:
    _iv(0x961D4157B9B428DB, p0, p1, entity)

def START_BEING_GOON(p0: int, p1: int, p2: int) -> None:
    _iv(0x96E6D5150DBF1C09, p0, p1, p2)

def STAT_ENABLE_STATS_TRACKING() -> None:
    _iv(0x98E2BC1CA26287C3)

def STAT_MIGRATE_SAVEGAME_GET_STATUS() -> int:
    return _ii(0x9A62EC95AE10E011)

def STAT_CLEAR_DIRTY_READ_DETECTED() -> None:
    _iv(0x9B4BD21D69B1E609)

def STAT_INCREMENT(statName: int, value: float) -> None:
    _iv(0x9B5A68C6489E9909, statName, value)

def PLAYSTATS_RACE_CHECKPOINT(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0x9C375C315099DDE4, p0, p1, p2, p3, p4)

def LEADERBOARDS_GET_CACHE_EXISTS(p0: int) -> bool:
    return _ib(0x9C51349BE6CDFE2C, p0)

def STAT_GET_CURRENT_JUMP_DISTANCE() -> float:
    return _if(0x9EC8858184CD253A)

def PLAYSTATS_ACTIVITY_DONE(p0: int, activityId: int, p2: int) -> None:
    _iv(0xA071E0ED98F91286, p0, activityId, p2)

def LEADERBOARDS2_READ_GET_ROW_DATA_START(p0: int) -> bool:
    return _ib(0xA0F93D5465B3094D, p0)

def STAT_LOAD_PENDING(statSlot: int) -> bool:
    return _ib(0xA1750FFAFA181661, statSlot)

def LEADERBOARDS_READ_ANY_PENDING() -> bool:
    return _ib(0xA31FD15197B192BD)

def LEADERBOARDS_READ_CLEAR_ALL() -> int:
    return _ii(0xA34CB6E6F0DF4A0B)

def END_BEING_BOSS(p0: int, p1: int, p2: int) -> None:
    _iv(0xA3C53804BDB68ED2, p0, p1, p2)

def STAT_MIGRATE_SAVEGAME_START(platformName: str) -> bool:
    return _ib(0xA5C80D8E768A9E66, platformName)

def STAT_LOAD(statSlot: int) -> bool:
    return _ib(0xA651443F437B1CE6, statSlot)

def PLAYSTATS_BW_BELLY_OF_THE_BEAST(p0: int) -> None:
    _iv(0xA6F54BB2FFCA35EA, p0)

def PLAYSTATS_JOB_LTS_END(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xA736CF7FB7C5BFF4, p0, p1, p2, p3)

def STAT_STOP_RECORD_STAT() -> bool:
    return _ib(0xA761D4AC6115623D)

def STAT_LOCAL_RESET_ALL_ONLINE_CHARACTER_STATS(p0: int) -> None:
    _iv(0xA78B8FA58200DA56, p0)

def STAT_CLEAR_PENDING_SAVES(p0: int) -> None:
    _iv(0xA8733668D1047B51, p0)

def STAT_SET_STRING(statName: int, value: str, save: bool) -> bool:
    return _ib(0xA87B2335D12531D7, statName, value, save)

def STAT_GET_CURRENT_REAR_WHEEL_DISTANCE() -> float:
    return _if(0xA943FD1722E11EFD)

def _PLAYSTATS_NAMED_USER_CONTENT(isBoss: bool, bossType: int, bossId1: int, bossId2: int, textType: int, textString: str, textSource: int) -> None:
    _iv(0xAA434D7D0A89A95C, isBoss, bossType, bossId1, bossId2, textType, textString, textSource)

def SEND_METRIC_VIP_POACH(p0: int, p1: int, p2: int) -> None:
    _iv(0xAA525DFF66BB82F5, p0, p1, p2)

def LEADERBOARDS_READ_PENDING(p0: int, p1: int, p2: int) -> bool:
    return _ib(0xAC392C8483342AC2, p0, p1, p2)

def PLAYSTATS_RACE_TO_POINT_MISSION_DONE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xADDD1C754E2E2914, p0, p1, p2, p3)

def LEADERBOARDS2_WRITE_DATA(p0: int) -> bool:
    return _ib(0xAE2206545888AE49, p0)

def PLAYSTATS_CRATE_CREATED(p0: float, p1: float, p2: float) -> None:
    _iv(0xAFC7E5E075A96F46, p0, p1, p2)

def STAT_GET_CURRENT_SKYDIVING_DISTANCE() -> float:
    return _if(0xAFF47709F1D5DCCE)

def STAT_COMMUNITY_SYNCH_IS_PENDING() -> bool:
    return _ib(0xB1D2BB1E1631F5B1)

def PLAYSTATS_DJ_USAGE(p0: int, p1: int) -> None:
    _iv(0xB26F670685631727, p0, p1)

def STAT_SET_INT(statName: int, value: int, save: bool) -> bool:
    return _ib(0xB3271D7AB655B441, statName, value, save)

def STAT_ROLLBACK_SAVE_MIGRATION() -> bool:
    return _ib(0xB3DA2606774A8E2D)

def SET_PROFILE_SETTING_PROLOGUE_COMPLETE() -> None:
    _iv(0xB475F27C6A994D65)

def PLAYSTATS_ARENA_WARS_ENDED(data: int) -> None:
    _iv(0xB479D9F0D48A1BC5, data)

def PLAYSTATS_COPY_RANK_INTO_NEW_SLOT(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int) -> None:
    _iv(0xB7257BA2550EA10A, p0, p1, p2, p3, p4, p5, p6)

def LEADERBOARDS_CACHE_DATA_ROW(p0: int) -> bool:
    return _ib(0xB9BB18E2C40142ED, p0)

def LEADERBOARDS2_READ_BY_RANK(p0: int, p1: int, p2: int) -> bool:
    return _ib(0xBA2C7DB0C129449A, p0, p1, p2)

def PLAYSTATS_PROP_CHANGE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xBA739D6D5A05D6E7, p0, p1, p2, p3)

def STAT_GET_CURRENT_DRIVE_NOCRASH_DISTANCE() -> float:
    return _if(0xBA9749CC94C1FD85)

def PLAYSTATS_FM_EVENT_ATOB(p0: int) -> None:
    _iv(0xBAA2F0490E146BE8, p0)

def PLAYSTATS_ROBBERY_FINALE(p0: int) -> None:
    _iv(0xBBA55BE9AAAABF44, p0)

def STAT_SAVE_PENDING_OR_REQUESTED() -> bool:
    return _ib(0xBBB6AD006F1BBEA3)

def PLAYSTATS_MATCH_STARTED(p0: int, p1: int, p2: int) -> None:
    _iv(0xBC80E22DED931E3D, p0, p1, p2)

def _PLAYSTATS_ATTRITION_STAGE_END(p0: int) -> None:
    _iv(0xBD642335A732F1A8, p0)

def STAT_IS_STATS_TRACKING_ENABLED() -> bool:
    return _ib(0xBE3DB208333D9844)

def PLAYSTATS_SPENT_PI_CUSTOM_LOADOUT(amount: int) -> None:
    _iv(0xBE509B0A3693DE8B, amount)

def _PLAYSTATS_RECOVER_VEHICLE(data: int) -> None:
    _iv(0xBEB0D930B3CCE4D5, data)

def STAT_COMMUNITY_GET_HISTORY(statName: int, p1: int, outValue: int) -> bool:
    return _ib(0xBED9F5693F34ED17, statName, p1, outValue)

def PLAYSTATS_MISSION_ENDED(p0: int) -> None:
    _iv(0xBF371CD2B64212FD, p0)

def LEADERBOARDS_GET_COLUMN_TYPE(p0: int, p1: int, p2: int) -> int:
    return _ii(0xBF4FEF46DB7894D3, p0, p1, p2)

def PLAYSTATS_FM_EVENT_VEHICLETARGET(p0: int) -> None:
    _iv(0xBFAFDB5FAAA5C5AB, p0)

def STATS_COMPLETED_CHARACTER_CREATION(p0: int) -> None:
    _iv(0xC01D2470F22CDE5A, p0)

def PLAYSTATS_MISSION_VOTE(p0: int) -> None:
    _iv(0xC03FAB2C2F92289B, p0)

def STAT_GET_LOAD_SAFE_TO_PROGRESS_TO_MP_FROM_SP() -> bool:
    return _ib(0xC0E0D686DDFC6EAE)

def SET_HAS_POSTED_ALL_VEHICLES_DRIVEN() -> None:
    _iv(0xC141B8917E0017EC)

def PLAYSTATS_MINIGAME_USAGE(p0: int, p1: int, p2: int) -> None:
    _iv(0xC14BD9F5337219B2, p0, p1, p2)

def PLAYSTATS_MISSION_STARTED(p0: str, p1: int, p2: int, p3: bool) -> None:
    _iv(0xC19A2925C34D2231, p0, p1, p2, p3)

def PLAYSTATS_HEIST4_FINALE(p0: int) -> None:
    _iv(0xC1E963C58664B556, p0)

def STAT_SET_CURRENT_POSIX_TIME(statName: int, p1: bool) -> bool:
    return _ib(0xC2F84B7F9C4D0C61, statName, p1)

def LEADERBOARDS2_READ_BY_HANDLE(p0: int, p1: int) -> bool:
    return _ib(0xC30713A383BFBF0E, p0, p1)

def LEADERBOARDS2_READ_RANK_PREDICTION(p0: int, p1: int, p2: int) -> bool:
    return _ib(0xC38DC1E90D22547C, p0, p1, p2)

def _PLAYSTATS_FLOW_MEDIUM(posX: float, posY: float, posZ: float, action: str, p4: bool, p5: int) -> None:
    _iv(0xC4493521BAA12CCE, posX, posY, posZ, action, p4, p5)

def LEADERBOARDS_GET_COLUMN_ID(p0: int, p1: int, p2: int) -> int:
    return _ii(0xC4B5467A1886EA7E, p0, p1, p2)

def PLAYSTATS_LEAVE_JOB_CHAIN(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0xC5BE134EC7BA96A0, p0, p1, p2, p3, p4)

def SET_PROFILE_SETTING_SP_CHOP_MISSION_COMPLETE() -> None:
    _iv(0xC67E2DA1CBE759E2)

def STAT_MIGRATE_CHECK_START() -> bool:
    return _ib(0xC6E0E2616A7576BB)

def PLAYSTATS_SELL_CONTRABAND_MISSION(data: int) -> None:
    _iv(0xC729991A9065376E, data)

def PLAYSTATS_RANK_UP(rank: int) -> None:
    _iv(0xC7F2DE41D102BFB4, rank)

def STAT_MIGRATE_CLEAR_FOR_RESTART() -> None:
    _iv(0xC847B43F369AC0B5)

def PLAYSTATS_CASINO_THREE_CARD_POKER_LIGHT(p0: int) -> None:
    _iv(0xC9001364B4388F22, p0)

def PLAYSTATS_MISSION_CHECKPOINT(p0: str, p1: int, p2: int, p3: int) -> None:
    _iv(0xC900596A63978C1D, p0, p1, p2, p3)

def LEADERBOARDS2_WRITE_DATA_FOR_EVENT_TYPE(p0: int, p1: int) -> bool:
    return _ib(0xC980E62E33DF1D5C, p0, p1)

def PLAYSTATS_HOLD_UP_MISSION_DONE(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xCB00196B31C39EB1, p0, p1, p2, p3)

def PLAYSTATS_MC_REQUEST_BIKE(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0xCC25A4553DFBF9EA, p0, p1, p2, p3, p4)

def PLAYSTATS_COLLECTIBLE_PICKED_UP(p0: int, objectHash: int, p2: int, p3: int, moneyAmount: int, rpAmount: int, chipsAmount: int, p7: int, p8: int, p9: int, p10: int) -> None:
    _iv(0xCD0A8A9338681CF2, p0, objectHash, p2, p3, moneyAmount, rpAmount, chipsAmount, p7, p8, p9, p10)

def STAT_GET_SAVE_MIGRATION_CONSUME_CONTENT_STATUS(p0: int) -> int:
    return _ii(0xCE5AA445ABA8DEE0, p0)

def ORDER_BOSS_VEHICLE(p0: int, p1: int, vehicleHash: int) -> None:
    _iv(0xCEA553E35C2246E1, p0, p1, vehicleHash)

def _PLAYSTATS_ACID_RND(p0: int) -> None:
    _iv(0xCEACCF0550FDC5BA, p0)

def _PLAYSTATS_FLOW_HIGH(posX: float, posY: float, posZ: float, action: str, p4: bool, p5: int) -> None:
    _iv(0xCFB0E9C3456319EA, posX, posY, posZ, action, p4, p5)

def PLAYSTATS_SET_JOIN_TYPE(joinType: int) -> None:
    _iv(0xD1032E482629049E, joinType)

def GET_PACKED_TU_INT_STAT_KEY(index: int, spStat: bool, charStat: bool, character: int) -> int:
    return _ii(0xD16C2AD6B8E32854, index, spStat, charStat, character)

def PLAYSTATS_BW_YATCHATTACK(p0: int) -> None:
    _iv(0xD1A1EE3B4FA8E760, p0)

def CHANGE_UNIFORM(p0: int, p1: int, p2: int) -> None:
    _iv(0xD1C9B92BDD3F151D, p0, p1, p2)

def PLAYSTATS_SUB_WEAP(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xD4367D310F079DB0, p0, p1, p2, p3)

def LEADERBOARDS_CLEAR_CACHE_DATA() -> None:
    _iv(0xD4B02A6B476E1FDC)

def PLAYSTATS_CASINO_BLACKJACK_LIGHT(p0: int) -> None:
    _iv(0xD5451C7BF151EB6F, p0)

def PLAYSTATS_ABANDONED_MC(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0xD558BEC0BBA7E8D2, p0, p1, p2, p3, p4)

def PLAYSTATS_BUY_CONTRABAND_MISSION(data: int) -> None:
    _iv(0xD6781E42755531F7, data)

def _GET_STAT_HASH_FOR_CHARACTER_STAT(dataType: int, statIndex: int, charSlot: int) -> int:
    return _ii(0xD69CE161FE614531, dataType, statIndex, charSlot)

def PLAYSTATS_DJ_MISSION_ENDED(p0: int) -> None:
    _iv(0xD6CA58B3B53A0F22, p0)

def STAT_GET_FLOAT(statHash: int, outValue: int, p2: int) -> bool:
    return _ib(0xD7AE6C9C9C6AC54C, statHash, outValue, p2)

def PLAYSTATS_FM_HEIST_PREP_ENDED(data: int) -> None:
    _iv(0xD8AFB345A9C5CCBB, data)

def GET_PACKED_STAT_BOOL_CODE(index: int, characterSlot: int) -> bool:
    return _ib(0xDA7EBFC49AE3F1B0, index, characterSlot)

def SET_HAS_SPECIALEDITION_CONTENT(value: int) -> None:
    _iv(0xDAC073C7901F9E15, value)

def PLAYSTATS_GUNRUNNING_RND(p0: int) -> None:
    _iv(0xDAF80797FC534BEC, p0)

def STAT_SET_POS(statName: int, x: float, y: float, z: float, save: bool) -> bool:
    return _ib(0xDB283FDE680FE72E, statName, x, y, z, save)

def SET_PACKED_STAT_BOOL_CODE(index: int, value: bool, characterSlot: int) -> None:
    _iv(0xDB8A58AEAA67CD07, index, value, characterSlot)

def PLAYSTATS_WEBSITE_VISITED(scaleformHash: int, p1: int) -> None:
    _iv(0xDDF24D535060F811, scaleformHash, p1)

def STAT_MIGRATE_CHECK_GET_PLATFORM_STATUS(p0: int, p1: int) -> int:
    return _ii(0xDEAAF77EB3687E97, p0, p1)

def PLAYSTATS_HEIST3_DRONE(p0: int) -> None:
    _iv(0xDFBD93BF2943E29B, p0)

def PLAYSTATS_HEIST4_PREP(p0: int) -> None:
    _iv(0xDFCDB14317A9B361, p0)

def STAT_SAVE(p0: int, p1: bool, p2: int, p3: bool) -> bool:
    return _ib(0xE07BCA305B82D2FD, p0, p1, p2, p3)

def STAT_GET_NUMBER_OF_DAYS(statName: int) -> int:
    return _ii(0xE0E854F5280FB769, statName)

def PLAYSTATS_BC_FINDERS_KEEPERS(p0: int) -> None:
    _iv(0xE3261D791EB44ACB, p0)

def STAT_CLOUD_SLOT_LOAD_FAILED_CODE(p0: int) -> int:
    return _ii(0xE496A53BA5F50A56, p0)

def STAT_GET_STRING(statHash: int, p1: int) -> str:
    return _is(0xE50384ACC2C3DB74, statHash, p1)

def PLAYSTATS_CASINO_SLOT_MACHINE_LIGHT(p0: int) -> None:
    _iv(0xE60054A0FAE8227F, p0)

def LEADERBOARDS2_READ_BY_SCORE_FLOAT(p0: int, p1: float, p2: int) -> bool:
    return _ib(0xE662C8B759D08F3C, p0, p1, p2)

def _PLAYSTATS_FLOW_LOW(posX: float, posY: float, posZ: float, action: str, p4: bool, p5: int) -> None:
    _iv(0xE6A27CDA42887F93, posX, posY, posZ, action, p4, p5)

def _PLAYSTATS_PIMENU_NAV(data: int) -> None:
    _iv(0xE6D323A5E9EFFB76, data)

def STAT_GET_CURRENT_NEAR_MISS_NOCRASH_PRECISE() -> int:
    return _ii(0xE8853FBCE7D8D0D6)

def PLAYSTATS_WEAPON_MODE_CHANGE(weaponHash: int, componentHashTo: int, componentHashFrom: int) -> None:
    _iv(0xE95C8A1875A02CA4, weaponHash, componentHashTo, componentHashFrom)

def STAT_CLEAR_SLOT_FOR_RELOAD(statSlot: int) -> bool:
    return _ib(0xEB0A72181D4AA4AD, statSlot)

def _PLAYSTATS_IDLE(p0: int, p1: int, p2: int) -> None:
    _iv(0xEC9553A178E8F1D1, p0, p1, p2)

def STAT_LOAD_DIRTY_READ_DETECTED() -> bool:
    return _ib(0xECB41AC6AB754401)

def PLAYSTATS_FM_EVENT_CRIMINALDAMAGE(p0: int) -> None:
    _iv(0xEDBF6C9B0D2C65C8, p0)

def PLAYSTATS_CASINO_SLOT_MACHINE(p0: int) -> None:
    _iv(0xEF5EC67D392B830A, p0)

def LEADERBOARDS_GET_CACHE_TIME(p0: int) -> int:
    return _ii(0xF04C1C27DA35F6C8, p0)

def PLAYSTATS_BW_AIR_FREIGHT(p0: int) -> None:
    _iv(0xF06A6F41CB445443, p0)

def STAT_GET_RECORDED_VALUE(value: int) -> bool:
    return _ib(0xF11F01D98113536A, value)

def SET_PROFILE_SETTING_CREATOR_RACES_DONE(value: int) -> None:
    _iv(0xF1A1803D3476F215, value)

def LEADERBOARDS2_READ_BY_PLAFORM(p0: int, gamerHandleCsv: str, platformName: str) -> bool:
    return _ib(0xF1AE5DCDBFCA2721, p0, gamerHandleCsv, platformName)

def STAT_GET_NUMBER_OF_HOURS(statName: int) -> int:
    return _ii(0xF2D4B2FE415AAFC3, statName)

def STAT_SET_BLOCK_SAVES(toggle: bool) -> None:
    _iv(0xF434A10BA01C37D0, toggle)

def PLAYSTATS_HEIST_SAVE_CHEAT(hash: int, p1: int) -> None:
    _iv(0xF4FF020A08BC8863, hash, p1)

def PLAYSTATS_MC_KILLED_RIVAL_MC_MEMBER(p0: int, p1: int, p2: int, p3: int, p4: int) -> None:
    _iv(0xF534D94DFA2EAD26, p0, p1, p2, p3, p4)

def PLAYSTATS_JOB_BEND(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xF5BB8DAC426A52C0, p0, p1, p2, p3)

def SET_SAVE_MIGRATION_TRANSACTION_ID_WARNING(transactionId: int) -> None:
    _iv(0xF6792800AC95350D, transactionId)

def PLAYSTATS_CASINO_THREE_CARD_POKER(p0: int) -> None:
    _iv(0xF740FB339D471C35, p0)

def PLAYSTATS_JOB_ACTIVITY_END(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xF8C54A461C3E11DC, p0, p1, p2, p3)

def PLAYSTATS_ARCADE_CABINET(p0: int) -> None:
    _iv(0xF9096193DF1F99D4, p0)

def _PLAYSTATS_SHOPMENU_NAV(p0: int, p1: int, p2: int, p3: int) -> None:
    _iv(0xF96E9EA876D9DC92, p0, p1, p2, p3)

def STAT_IS_PLAYER_VEHICLE_ABOVE_OCEAN() -> bool:
    return _ib(0xF9F2922717B819EC)

def PLAYSTATS_EXTRA_EVENT(p0: int) -> None:
    _iv(0xFA5B74BAB8A7EF99, p0)

def PLAYSTATS_BW_SIGHTSEER(p0: int) -> None:
    _iv(0xFCC228E07217FCAC, p0)

def PLAYSTATS_CASINO_STORY_MISSION_ENDED(p0: int, p1: int) -> None:
    _iv(0xFCCCAC2BD3C1F180, p0, p1)

def PLAYSTATS_INST_MISSION_END(p0: int) -> None:
    _iv(0xFEA3F7E83C0610FA, p0)

def PLAYSTATS_CARCLUB_POINTS(p0: int) -> None:
    _iv(0xFF14D6FEEC507BBE, p0)
