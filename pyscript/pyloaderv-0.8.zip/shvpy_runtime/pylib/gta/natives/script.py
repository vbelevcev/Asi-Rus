"""Auto-generated raw native bindings for namespace SCRIPT.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_str as _is


def GET_NAME_OF_SCRIPT_WITH_THIS_ID(threadId: int) -> str:
    return _is(0x05A42BA9FC8DA96B, threadId)

def SHUTDOWN_LOADING_SCREEN() -> None:
    _iv(0x078EBE9809CCD637)

def BG_DOES_LAUNCH_PARAM_EXIST(scriptIndex: int, p1: str) -> bool:
    return _ib(0x0F6F1EBBC4E1D5E6, scriptIndex, p1)

def BG_END_CONTEXT_HASH(contextHash: int) -> None:
    _iv(0x107E5CC7CA942BC1, contextHash)

def TERMINATE_THIS_THREAD() -> None:
    _iv(0x1090044AD1DA76FA)

def GET_NO_LOADING_SCREEN() -> bool:
    return _ib(0x18C1270EA7F199BC)

def BG_GET_LAUNCH_PARAM_VALUE(scriptIndex: int, p1: str) -> int:
    return _ii(0x22E21FBCFC88C149, scriptIndex, p1)

def GET_EVENT_DATA(eventGroup: int, eventIndex: int, eventData: int, eventDataSize: int) -> bool:
    return _ib(0x2902843FCD2B2D79, eventGroup, eventIndex, eventData, eventDataSize)

def GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(scriptHash: int) -> int:
    return _ii(0x2C83A9DA6BFFC4F9, scriptHash)

def SCRIPT_THREAD_ITERATOR_GET_NEXT_THREAD_ID() -> int:
    return _ii(0x30B4FA1C82DD4B9F)

def GET_THIS_SCRIPT_NAME() -> str:
    return _is(0x442E0A7EDE4A738A)

def IS_THREAD_ACTIVE(threadId: int) -> bool:
    return _ib(0x46E9AE36D8FA6417, threadId)

def SET_NO_LOADING_SCREEN(toggle: bool) -> None:
    _iv(0x5262CC1995D07E09, toggle)

def TRIGGER_SCRIPT_EVENT(eventGroup: int, eventData: int, eventDataSize: int, playerBits: int) -> None:
    _iv(0x5AE99C571D5BBE5D, eventGroup, eventData, eventDataSize, playerBits)

def HAS_SCRIPT_WITH_NAME_HASH_LOADED(scriptHash: int) -> bool:
    return _ib(0x5F0F0C783EB16C04, scriptHash)

def GET_NUMBER_OF_EVENTS(eventGroup: int) -> int:
    return _ii(0x5F92A689A06620AA, eventGroup)

def REQUEST_SCRIPT(scriptName: str) -> None:
    _iv(0x6EB5F71AA68F2E8E, scriptName)

def _SEND_TU_SCRIPT_EVENT_NEW(eventGroup: int, eventData: int, eventDataSize: int, playerBits: int, eventType: int) -> None:
    _iv(0x71A6F836422FDD2B, eventGroup, eventData, eventDataSize, playerBits, eventType)

def BG_START_CONTEXT_HASH(contextHash: int) -> None:
    _iv(0x75B18E49607874C7, contextHash)

def BG_SET_EXITFLAG_RESPONSE() -> None:
    _iv(0x760910B49D2B98EA)

def BG_GET_SCRIPT_ID_FROM_NAME_HASH(p0: int) -> int:
    return _ii(0x829CD22E043A2577, p0)

def BG_IS_EXITFLAG_SET() -> bool:
    return _ib(0x836B62713E0534CA)

def GET_HASH_OF_THIS_SCRIPT_NAME() -> int:
    return _ii(0x8A1C8B1738FFE87E)

def GET_EVENT_EXISTS(eventGroup: int, eventIndex: int) -> bool:
    return _ib(0x936E6168A9BCEDB5, eventGroup, eventIndex)

def BG_START_CONTEXT(contextName: str) -> None:
    _iv(0x9D5A25BADB742ACD, contextName)

def COMMIT_TO_LOADINGSCREEN_SELCTION() -> None:
    _iv(0xB1577667C3708F9B)

def GET_ID_OF_THIS_THREAD() -> int:
    return _ii(0xC30338E8088E2E21)

def SET_SCRIPT_WITH_NAME_HASH_AS_NO_LONGER_NEEDED(scriptHash: int) -> None:
    _iv(0xC5BC038960E9DB27, scriptHash)

def TERMINATE_THREAD(threadId: int) -> None:
    _iv(0xC8B189ED9138BCD4, threadId)

def SET_SCRIPT_AS_NO_LONGER_NEEDED(scriptName: str) -> None:
    _iv(0xC90D2DCACD56184C, scriptName)

def REQUEST_SCRIPT_WITH_NAME_HASH(scriptHash: int) -> None:
    _iv(0xD62A67D26D9653E6, scriptHash)

def GET_EVENT_AT_INDEX(eventGroup: int, eventIndex: int) -> int:
    return _ii(0xD8F66A3A60C62153, eventGroup, eventIndex)

def SCRIPT_THREAD_ITERATOR_RESET() -> None:
    _iv(0xDADFADA5A20143A8)

def BG_END_CONTEXT(contextName: str) -> None:
    _iv(0xDC2BACD920D0A0DD, contextName)

def HAS_SCRIPT_LOADED(scriptName: str) -> bool:
    return _ib(0xE6CC9F3BA0FB9EF1, scriptName)

def DOES_SCRIPT_WITH_NAME_HASH_EXIST(scriptHash: int) -> bool:
    return _ib(0xF86AA3C56BA31381, scriptHash)

def DOES_SCRIPT_EXIST(scriptName: str) -> bool:
    return _ib(0xFC04745FBE67C19A, scriptName)
