"""Auto-generated raw native bindings for namespace SAVEMIGRATION.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_bool as _ib, _invoke_int as _ii


def SAVEMIGRATION_MP_GET_STATUS() -> int:
    return _ii(0x690B76BD2763E068)

def SAVEMIGRATION_MP_NUM_ACCOUNTS() -> int:
    return _ii(0x77A16200E18E0C55)

def SAVEMIGRATION_IS_MP_ENABLED() -> bool:
    return _ib(0x84B418E93894AC1C)

def SAVEMIGRATION_MP_REQUEST_ACCOUNTS() -> bool:
    return _ib(0x85F41F9225D08C72)

def SAVEMIGRATION_MP_GET_ACCOUNTS_STATUS() -> int:
    return _ii(0xC8CB5999919EA2CA)

def SAVEMIGRATION_MP_REQUEST_STATUS() -> bool:
    return _ib(0xE5E9746A66359F9D)

def SAVEMIGRATION_MP_GET_ACCOUNT(p0: int, p1: int) -> bool:
    return _ib(0xFCE2747EEF1D05FC, p0, p1)
