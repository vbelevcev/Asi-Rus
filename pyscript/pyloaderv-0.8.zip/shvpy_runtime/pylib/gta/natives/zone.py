"""Auto-generated raw native bindings for namespace ZONE.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_int as _ii, _invoke_str as _is


def GET_ZONE_AT_COORDS(x: float, y: float, z: float) -> int:
    return _ii(0x27040C25DE6CB2F4, x, y, z)

def GET_ZONE_POPSCHEDULE(zoneId: int) -> int:
    return _ii(0x4334BC40AA0CB4BB, zoneId)

def CLEAR_POPSCHEDULE_OVERRIDE_VEHICLE_MODEL(scheduleId: int) -> None:
    _iv(0x5C0DE367AA0D911C, scheduleId)

def GET_ZONE_SCUMMINESS(zoneId: int) -> int:
    return _ii(0x5F7B268D15BA0739, zoneId)

def OVERRIDE_POPSCHEDULE_VEHICLE_MODEL(scheduleId: int, vehicleHash: int) -> None:
    _iv(0x5F7D596BAC2E7777, scheduleId, vehicleHash)

def GET_HASH_OF_MAP_AREA_AT_COORDS(x: float, y: float, z: float) -> int:
    return _ii(0x7EE64D51E8498728, x, y, z)

def GET_ZONE_FROM_NAME_ID(zoneName: str) -> int:
    return _ii(0x98CD1D2934B76CC1, zoneName)

def SET_ZONE_ENABLED(zoneId: int, toggle: bool) -> None:
    _iv(0xBA5ECEEA120E5611, zoneId, toggle)

def GET_NAME_OF_ZONE(x: float, y: float, z: float) -> str:
    return _is(0xCD90657D4C30E1CA, x, y, z)
