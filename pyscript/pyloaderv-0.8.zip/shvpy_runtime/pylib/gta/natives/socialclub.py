"""Auto-generated raw native bindings for namespace SOCIALCLUB.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_str as _is


def SC_INBOX_GET_TOTAL_NUM_MESSAGES() -> int:
    return _ii(0x03A93FF1A2CA0864)

def SC_EMAIL_RETRIEVE_EMAILS(offset: int, limit: int) -> None:
    _iv(0x040ADDCBAFA1018A, offset, limit)

def SC_LICENSEPLATE_GET_ADD_IS_PENDING(token: int) -> bool:
    return _ib(0x07C61676E5BB52CD, token)

def SC_EMAIL_SET_CURRENT_EMAIL_TAG(p0: int) -> bool:
    return _ib(0x07DBD622D9533857, p0)

def SC_LICENSEPLATE_ISVALID(plateText: str, token: int) -> bool:
    return _ib(0x0F73393BAC7E6730, plateText, token)

def SC_EMAIL_SEND_EMAIL(p0: str) -> None:
    _iv(0x116FB94DC4B79F17, p0)

def SC_EMAIL_GET_RETRIEVAL_STATUS() -> int:
    return _ii(0x16DA8172459434AA)

def SC_PROFANITY_GET_CHECK_IS_VALID(token: int) -> bool:
    return _ib(0x1753344C770358AE, token)

def SC_COMMUNITY_EVENT_GET_DISPLAY_NAME_BY_ID(p0: int, p1: str) -> bool:
    return _ib(0x19853B5B17D77BCA, p0, p1)

def SC_LICENSEPLATE_ADD(plateText: str, plateData: int, token: int) -> bool:
    return _ib(0x1989C6E6F67E76A8, plateText, plateData, token)

def SC_ACCOUNT_INFO_GET_NICKNAME() -> str:
    return _is(0x198D161F458ECC7F)

def SC_COMMUNITY_EVENT_GET_EXTRA_DATA_STRING_FOR_TYPE(p0: str, p1: str, p2: str) -> bool:
    return _ib(0x1D12A56FC95BE92E, p0, p1, p2)

def SC_LICENSEPLATE_GET_PLATE(token: int, plateIndex: int) -> str:
    return _is(0x1D4446A62D35B0D0, token, plateIndex)

def SC_PRESENCE_ATTR_SET_INT(attrHash: int, value: int) -> bool:
    return _ib(0x1F1E9682483697C7, attrHash, value)

def SC_ACHIEVEMENT_INFO_STATUS(p0: int) -> bool:
    return _ib(0x225798743970412B, p0)

def SC_EMAIL_MESSAGE_PUSH_GAMER_TO_RECIP_LIST(gamerHandle: int) -> None:
    _iv(0x2330C12A7A605D16, gamerHandle)

def SC_COMMUNITY_EVENT_GET_EXTRA_DATA_FLOAT_FOR_TYPE(p0: str, p1: int, p2: str) -> bool:
    return _ib(0x2570E26BE63964E3, p0, p1, p2)

def SC_PRESENCE_ATTR_SET_STRING(attrHash: int, value: str) -> bool:
    return _ib(0x287F1F75D2803595, attrHash, value)

def SC_INBOX_SET_MESSAGE_AS_READ_AT_INDEX(msgIndex: int) -> bool:
    return _ib(0x2C015348CF19CA1D, msgIndex)

def SC_GAMERDATA_GET_ACTIVE_XP_BONUS(value: int) -> bool:
    return _ib(0x2D874D4AE612A65F, value)

def SC_LICENSEPLATE_GET_PLATE_DATA(token: int, plateIndex: int) -> str:
    return _is(0x2E89990DDFF670C3, token, plateIndex)

def SC_TRANSITION_NEWS_HAS_EXTRA_DATA_TU() -> bool:
    return _ib(0x3001BEF2FECA3680)

def SC_COMMUNITY_EVENT_GET_DISPLAY_NAME_FOR_TYPE(p0: str, p1: str) -> bool:
    return _ib(0x33DF47CC0642061B, p0, p1)

def SC_HAS_ACHIEVEMENT_BEEN_PASSED(achievementId: int) -> bool:
    return _ib(0x418DC16FAE452C1C, achievementId)

def SC_EMAIL_DELETE_EMAILS(p0: int, p1: int) -> None:
    _iv(0x44ACA259D67651DB, p0, p1)

def SC_COMMUNITY_EVENT_IS_ACTIVE_FOR_TYPE(p0: str) -> bool:
    return _ib(0x450819D8CF90C416, p0)

def SC_EMAIL_GET_EMAIL_AT_INDEX(p0: int, p1: int) -> bool:
    return _ib(0x4737980E8A283806, p0, p1)

def SC_PRESENCE_SET_ACTIVITY_RATING(p0: int, p1: float) -> bool:
    return _ib(0x487912FD248EFDDF, p0, p1)

def SC_COMMUNITY_EVENT_GET_EVENT_ID_FOR_TYPE(p0: str) -> int:
    return _ii(0x4A7D6E727F941747, p0)

def SC_COMMUNITY_EVENT_GET_EVENT_ID() -> int:
    return _ii(0x4ED9C8D6DA297639)

def SC_COMMUNITY_EVENT_GET_EXTRA_DATA_FLOAT(p0: str, p1: int) -> bool:
    return _ib(0x50A8A36201DBF83E, p0, p1)

def SC_EMAIL_MESSAGE_CLEAR_RECIP_LIST() -> None:
    _iv(0x55DF6DB45179236E)

def SC_LICENSEPLATE_GET_ISVALID_STATUS(token: int) -> int:
    return _ii(0x5C4EBFFA98BDB41C, token)

def SC_TRANSITION_NEWS_END() -> None:
    _iv(0x675721C9F644D161)

def SC_COMMUNITY_EVENT_GET_EXTRA_DATA_STRING_BY_ID(p0: int, p1: str, p2: str) -> bool:
    return _ib(0x699E4A5C8C893A18, p0, p1, p2)

def _SC_EMAIL_MARKETING_EMAIL_OPENED(index: int, type: int) -> None:
    _iv(0x69AA35F3F391CDBA, index, type)

def SC_INBOX_MESSAGE_GET_UGCDATA(p0: int, p1: int) -> bool:
    return _ib(0x69D82604A1A5A254, p0, p1)

def SC_TRANSITION_NEWS_SHOW(p0: int) -> bool:
    return _ib(0x6BFB12CE158E3DD4, p0)

def SC_LICENSEPLATE_GET_COUNT(token: int) -> int:
    return _ii(0x700569DBA175A77C, token)

def SC_COMMUNITY_EVENT_GET_EXTRA_DATA_INT(p0: str, p1: int) -> bool:
    return _ib(0x710BCDA8071EDED1, p0, p1)

def SC_PROFANITY_CHECK_STRING(string: str, token: int) -> bool:
    return _ib(0x75632C5ECD7ED843, string, token)

def SC_INBOX_MESSAGE_GET_DATA_STRING(p0: int, context: str, out: str) -> bool:
    return _ib(0x7572EF42FC6A9B6D, p0, context, out)

def SC_PROFANITY_GET_PROFANE_WORD(token: int, outProfaneWord: str) -> bool:
    return _ib(0x75CC8931A11128C9, token, outProfaneWord)

def SC_EMAIL_GET_NUM_RETRIEVED_EMAILS() -> int:
    return _ii(0x7DB18CA8CAD5B098)

def SC_GAMERDATA_GET_STRING(name: str, value: str) -> bool:
    return _ib(0x7FFCBFEE44ECFABF, name, value)

def SC_LICENSEPLATE_GET_ADD_STATUS(token: int) -> int:
    return _ii(0x8147FFF6A718E1AD, token)

def SC_PROFANITY_GET_CHECK_IS_PENDING(token: int) -> bool:
    return _ib(0x82E4A58BABC15AE7, token)

def SC_GAMERDATA_GET_BOOL(name: str) -> bool:
    return _ib(0x8416FE4E4629D7D7, name)

def SC_PROFANITY_GET_STRING_PASSED(token: int) -> bool:
    return _ib(0x85535ACF97FC0969, token)

def SC_INBOX_GET_BOUNTY_DATA_AT_INDEX(index: int, outData: int) -> bool:
    return _ib(0x87E0052F08BD64E6, index, outData)

def SC_PAUSE_NEWS_GET_PENDING_STORY(p0: int) -> bool:
    return _ib(0x8A4416C0DB05FA66, p0)

def SC_COMMUNITY_EVENT_GET_EXTRA_DATA_INT_BY_ID(p0: int, p1: str, p2: int) -> bool:
    return _ib(0x8CC469AB4D349B7C, p0, p1, p2)

def SC_LICENSEPLATE_GET_CHECK_IS_PENDING(p0: int) -> bool:
    return _ib(0x9237E334F6E43156, p0)

def SC_TRANSITION_NEWS_GET_EXTRA_DATA_INT_TU(p0: str, p1: int) -> bool:
    return _ib(0x92DA6E70EF249BD1, p0, p1)

def SC_INBOX_GET_MESSAGE_IS_READ_AT_INDEX(msgIndex: int) -> bool:
    return _ib(0x93028F1DB42BFD08, msgIndex)

def SC_PROFANITY_GET_STRING_STATUS(token: int) -> int:
    return _ii(0x930DE22F07B1CCE3, token)

def SC_INBOX_MESSAGE_DO_APPLY(p0: int) -> bool:
    return _ib(0x9A2C8064B6C1E41A, p0)

def SC_COMMUNITY_EVENT_GET_EXTRA_DATA_STRING(p0: str, p1: str) -> bool:
    return _ib(0x9DE5D2F723575ED0, p0, p1)

def SC_INBOX_MESSAGE_GET_DATA_INT(p0: int, context: str, out: int) -> bool:
    return _ib(0xA00EFE4082C4056E, p0, context, out)

def SC_COMMUNITY_EVENT_IS_ACTIVE_BY_ID(p0: int) -> bool:
    return _ib(0xA468E0BE12B12C70, p0)

def SC_INBOX_SEND_UGCSTATUPDATE_TO_RECIP_LIST(data: int) -> None:
    _iv(0xA68D3D229F4F3B06, data)

def SC_GAMERDATA_GET_FLOAT(name: str, value: int) -> bool:
    return _ib(0xA770C8EEC6FB2AC5, name, value)

def SC_INBOX_GET_MESSAGE_TYPE_AT_INDEX(msgIndex: int) -> int:
    return _ii(0xBB8EA16ECBC976C4, msgIndex)

def SC_HAS_NEW_ROCKSTAR_MSG() -> bool:
    return _ib(0xBC1CC91205EC8D6E)

def SC_CACHE_NEW_ROCKSTAR_MSGS(toggle: bool) -> None:
    _iv(0xBFA0A56A817C6C7D, toggle)

def SC_COMMUNITY_EVENT_GET_DISPLAY_NAME(p0: str) -> bool:
    return _ib(0xC2C97EA97711D1AE, p0)

def SC_PRESENCE_ATTR_SET_FLOAT(attrHash: int, value: float) -> bool:
    return _ib(0xC4C4575F62534A24, attrHash, value)

def SC_COMMUNITY_EVENT_GET_EXTRA_DATA_FLOAT_BY_ID(p0: int, p1: str, p2: int) -> bool:
    return _ib(0xC5A35C73B68F3C49, p0, p1, p2)

def SC_GAMERDATA_GET_INT(name: str, value: int) -> bool:
    return _ib(0xC85A7127E7AD02AA, name, value)

def SC_LICENSEPLATE_SET_PLATE_DATA(oldPlateText: str, newPlateText: str, plateData: int) -> bool:
    return _ib(0xD0EE05FE193646EA, oldPlateText, newPlateText, plateData)

def SC_LICENSEPLATE_GET_ISVALID_IS_PENDING(token: int) -> bool:
    return _ib(0xD302E99EDF0449CF, token)

def SC_TRANSITION_NEWS_SHOW_NEXT_ITEM() -> bool:
    return _ib(0xD8122C407663B995)

def SC_INBOX_MESSAGE_PUSH_GAMER_T0_RECIP_LIST(gamerHandle: int) -> None:
    _iv(0xDA024BDBD600F44A, gamerHandle)

def SC_GET_NEW_ROCKSTAR_MSG() -> str:
    return _is(0xDF649C4E9AFDD788)

def SC_PAUSE_NEWS_INIT_STARTER_PACK(p0: int) -> bool:
    return _ib(0xE4F6E8D07A2F0F51, p0)

def SC_COMMUNITY_EVENT_GET_EXTRA_DATA_INT_FOR_TYPE(p0: str, p1: int, p2: str) -> bool:
    return _ib(0xE75A4A2E5E316D86, p0, p1, p2)

def SC_PAUSE_NEWS_SHUTDOWN() -> None:
    _iv(0xEA95C0853A27888E)

def SC_PROFANITY_CHECK_STRING_UGC(string: str, token: int) -> bool:
    return _ib(0xEB2BF817463DFA28, string, token)

def SC_LICENSEPLATE_GET_CHECK_IS_VALID(p0: int) -> bool:
    return _ib(0xF22CA0FD74B80E7A, p0)

def SC_INBOX_MESSAGE_GET_RAW_TYPE_AT_INDEX(p0: int) -> str:
    return _is(0xF3E31D16CBDCB304, p0)

def SC_LICENSEPLATE_CHECK_STRING(p0: str, p1: int) -> bool:
    return _ib(0xF6BAAAF762E1BF40, p0, p1)

def SC_TRANSITION_NEWS_SHOW_TIMED(p0: int, p1: int) -> bool:
    return _ib(0xFE4C1D0D3B9CC17E, p0, p1)

def SC_COMMUNITY_EVENT_IS_ACTIVE() -> bool:
    return _ib(0xFF8F3A92B75ED67A)

def SC_INBOX_MESSAGE_GET_DATA_BOOL(p0: int, p1: str) -> bool:
    return _ib(0xFFE5C16F402D851D, p0, p1)
