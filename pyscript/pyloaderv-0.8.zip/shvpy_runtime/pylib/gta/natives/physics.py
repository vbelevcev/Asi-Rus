"""Auto-generated raw native bindings for namespace PHYSICS.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_vector3 as _ivec


def SET_DISABLE_FRAG_DAMAGE(object: int, toggle: bool) -> None:
    _iv(0x01BA3AED21C16CFB, object, toggle)

def GET_IS_ENTITY_A_FRAG(object: int) -> bool:
    return _ib(0x0C112765300C7E1E, object)

def START_ROPE_WINDING(ropeId: int) -> None:
    _iv(0x1461C72C889E343E, ropeId)

def SET_USE_KINEMATIC_PHYSICS(entity: int, toggle: bool) -> None:
    _iv(0x15F944730C832252, entity, toggle)

def GET_ROPE_LAST_VERTEX_COORD(ropeId: int) -> 'gta.Vector3':
    return _ivec(0x21BB0FBD3E217C2D, ropeId)

def DOES_SCRIPT_OWN_ROPE(ropeId: int) -> bool:
    return _ib(0x271C9D3ACA5D6409, ropeId)

def PIN_ROPE_VERTEX(ropeId: int, vertex: int, x: float, y: float, z: float) -> None:
    _iv(0x2B320CF14146B69A, ropeId, vertex, x, y, z)

def BREAK_ENTITY_GLASS(entity: int, p1: float, p2: float, p3: float, p4: float, p5: float, p6: float, p7: float, p8: float, p9: int, p10: bool) -> None:
    _iv(0x2E648D16F6E308F3, entity, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)

def GET_ROPE_VERTEX_COUNT(ropeId: int) -> int:
    return _ii(0x3655F544CD30F0B5, ropeId)

def ROPE_SET_SMOOTH_REELIN(ropeId: int, p1: bool) -> None:
    _iv(0x36CCB9BE67B970FD, ropeId, p1)

def ATTACH_ENTITIES_TO_ROPE(ropeId: int, ent1: int, ent2: int, ent1_x: float, ent1_y: float, ent1_z: float, ent2_x: float, ent2_y: float, ent2_z: float, length: float, p10: bool, p11: bool, p12: int, p13: int) -> None:
    _iv(0x3D95EC8B6D940AC3, ropeId, ent1, ent2, ent1_x, ent1_y, ent1_z, ent2_x, ent2_y, ent2_z, length, p10, p11, p12, p13)

def ATTACH_ROPE_TO_ENTITY(ropeId: int, entity: int, x: float, y: float, z: float, p5: bool) -> None:
    _iv(0x4B490A6832559A65, ropeId, entity, x, y, z, p5)

def UNPIN_ROPE_VERTEX(ropeId: int, vertex: int) -> None:
    _iv(0x4B5AE2EEE4A8F180, ropeId, vertex)

def DELETE_ROPE(ropeId: int) -> None:
    _iv(0x52B4829281364649, ropeId)

def ROPE_CONVERT_TO_SIMPLE(ropeId: int) -> None:
    _iv(0x5389D48EFA2F079A, ropeId)

def START_ROPE_UNWINDING_FRONT(ropeId: int) -> None:
    _iv(0x538D1179EC1AA9A9, ropeId)

def SET_DISABLE_BREAKING(object: int, toggle: bool) -> None:
    _iv(0x5CEC1A84620E7D5B, object, toggle)

def ROPE_UNLOAD_TEXTURES() -> None:
    _iv(0x6CE36C35C1AC8163)

def ACTIVATE_PHYSICS(entity: int) -> None:
    _iv(0x710311ADF0E20730, entity)

def ROPE_GET_DISTANCE_BETWEEN_ENDS(ropeId: int) -> float:
    return _if(0x73040398DFF9A4A6, ropeId)

def GET_CGOFFSET(entity: int) -> 'gta.Vector3':
    return _ivec(0x8214A4B5A7A33612, entity)

def IS_ROPE_ATTACHED_AT_BOTH_ENDS(ropeId: int) -> bool:
    return _ib(0x84DE3B5FB3E666F0, ropeId)

def GET_DAMPING(entity: int, type: int) -> 'gta.Vector3':
    return _ivec(0x8C520A929415BCD2, entity, type)

def ROPE_LOAD_TEXTURES() -> None:
    _iv(0x9B9039DBF2D258C1)

def SET_IN_STUNT_MODE(p0: bool) -> None:
    _iv(0x9EBD751E5787BAF2, p0)

def ROPE_DRAW_ENABLED(ropeId: int, p1: bool) -> None:
    _iv(0xA1AE736541B0FCA3, ropeId, p1)

def DELETE_CHILD_ROPE(ropeId: int) -> None:
    _iv(0xAA5D6B1888E4DB20, ropeId)

def SET_IN_ARENA_MODE(toggle: bool) -> None:
    _iv(0xAA6A6098851C396F, toggle)

def ROPE_CHANGE_SCRIPT_OWNER(p0: int, p1: bool, p2: bool) -> None:
    _iv(0xB1B6216CA2E7B55E, p0, p1, p2)

def ROPE_SET_REFFRAMEVELOCITY_COLLIDERORDER(ropeId: int, p1: int) -> None:
    _iv(0xB743F735C03D7810, ropeId, p1)

def ROPE_ATTACH_VIRTUAL_BOUND_GEOM(ropeId: int, p1: int, p2: float, p3: float, p4: float, p5: float, p6: float, p7: float, p8: float, p9: float, p10: float, p11: float, p12: float, p13: float) -> None:
    _iv(0xBC0CE682D4D05650, ropeId, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13)

def DETACH_ROPE_FROM_ENTITY(ropeId: int, entity: int) -> None:
    _iv(0xBCF3026912A8647D, ropeId, entity)

def SET_CG_AT_BOUNDCENTER(entity: int) -> None:
    _iv(0xBE520D9761FF811F, entity)

def ROPE_RESET_LENGTH(ropeId: int, length: float) -> None:
    _iv(0xC16DE94D9BEA14A0, ropeId, length)

def ROPE_SET_UPDATE_PINVERTS(ropeId: int) -> None:
    _iv(0xC8D667EE52114ABA, ropeId)

def STOP_ROPE_WINDING(ropeId: int) -> None:
    _iv(0xCB2D4AB84A19AA7C, ropeId)

def LOAD_ROPE_DATA(ropeId: int, rope_preset: str) -> None:
    _iv(0xCBB203C04D1ABD27, ropeId, rope_preset)

def RESET_DISABLE_BREAKING(object: int) -> None:
    _iv(0xCC6E963682533882, object)

def ROPE_FORCE_LENGTH(ropeId: int, length: float) -> None:
    _iv(0xD009F759A723DB1B, ropeId, length)

def SET_CGOFFSET(entity: int, x: float, y: float, z: float) -> None:
    _iv(0xD8FA3908D7B86904, entity, x, y, z)

def ROPE_SET_UPDATE_ORDER(ropeId: int, p1: int) -> None:
    _iv(0xDC57A637A20006ED, ropeId, p1)

def APPLY_IMPULSE_TO_CLOTH(posX: float, posY: float, posZ: float, vecX: float, vecY: float, vecZ: float, impulse: float) -> None:
    _iv(0xE37F721824571784, posX, posY, posZ, vecX, vecY, vecZ, impulse)

def ADD_ROPE(x: float, y: float, z: float, rotX: float, rotY: float, rotZ: float, length: float, ropeType: int, maxLength: float, minLength: float, windingSpeed: float, p11: bool, p12: bool, rigid: bool, p14: float, breakWhenShot: bool, unkPtr: int) -> int:
    return _ii(0xE832D760399EB220, x, y, z, rotX, rotY, rotZ, length, ropeType, maxLength, minLength, windingSpeed, p11, p12, rigid, p14, breakWhenShot, unkPtr)

def GET_ROPE_VERTEX_COORD(ropeId: int, vertex: int) -> 'gta.Vector3':
    return _ivec(0xEA61CA8E80F09E4D, ropeId, vertex)

def SET_DAMPING(entity: int, vertex: int, value: float) -> None:
    _iv(0xEEA3B200A6FEB65B, entity, vertex, value)

def ROPE_DRAW_SHADOW_ENABLED(ropeId: int, toggle: bool) -> None:
    _iv(0xF159A63806BB5BA8, ropeId, toggle)

def ROPE_ARE_TEXTURES_LOADED() -> bool:
    return _ib(0xF2D0E6A75CC05597)

def DOES_ROPE_EXIST(ropeId: int) -> bool:
    return _ib(0xFD5448BE3111ED96, ropeId)

def STOP_ROPE_UNWINDING_FRONT(ropeId: int) -> None:
    _iv(0xFFF3A50779EFBBB3, ropeId)
