"""Auto-generated raw native bindings for namespace EVENT.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii


def IS_SHOCKING_EVENT_IN_SPHERE(eventType: int, x: float, y: float, z: float, radius: float) -> bool:
    return _ib(0x1374ABB7C15BAB92, eventType, x, y, z, radius)

def REMOVE_SHOCKING_EVENT(event: int) -> bool:
    return _ib(0x2CDA538C44C6CCE5, event)

def SUPPRESS_SHOCKING_EVENTS_NEXT_FRAME() -> None:
    _iv(0x2F9A292AD0A3BD89)

def REMOVE_SHOCKING_EVENT_SPAWN_BLOCKING_AREAS() -> None:
    _iv(0x340F1415B68AEADE)

def SUPPRESS_SHOCKING_EVENT_TYPE_NEXT_FRAME(eventType: int) -> None:
    _iv(0x3FD2EC8BF1F1CF30, eventType)

def CLEAR_DECISION_MAKER_EVENT_RESPONSE(name: int, eventType: int) -> None:
    _iv(0x4FC9381A7AEE8968, name, eventType)

def SUPPRESS_AGITATION_EVENTS_NEXT_FRAME() -> None:
    _iv(0x5F3B7749C112D552)

def ADD_SHOCKING_EVENT_FOR_ENTITY(eventType: int, entity: int, duration: float) -> int:
    return _ii(0x7FD8F3BE76F89422, eventType, entity, duration)

def SET_DECISION_MAKER(ped: int, name: int) -> None:
    _iv(0xB604A2942ADED0EE, ped, name)

def UNBLOCK_DECISION_MAKER_EVENT(name: int, eventType: int) -> None:
    _iv(0xD7CD9CF34F2C99E8, name, eventType)

def ADD_SHOCKING_EVENT_AT_POSITION(eventType: int, x: float, y: float, z: float, duration: float) -> int:
    return _ii(0xD9F8455409B525E9, eventType, x, y, z, duration)

def BLOCK_DECISION_MAKER_EVENT(name: int, eventType: int) -> None:
    _iv(0xE42FCDFD0E4196F7, name, eventType)

def REMOVE_ALL_SHOCKING_EVENTS(p0: bool) -> None:
    _iv(0xEAABE8FDFA21274C, p0)
