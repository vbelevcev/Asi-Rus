"""Auto-generated raw native bindings for namespace PATHFIND.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if


def SET_ROADS_BACK_TO_ORIGINAL_IN_ANGLED_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, width: float, p7: int) -> None:
    _iv(0x0027501B9F3B407E, x1, y1, z1, x2, y2, z2, width, p7)

def GET_NUM_NAVMESHES_EXISTING_IN_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> int:
    return _ii(0x01708E8DD3FF8C65, x1, y1, z1, x2, y2, z2)

def GET_VEHICLE_NODE_PROPERTIES(x: float, y: float, z: float, density: int, flags: int) -> bool:
    return _ib(0x0568566ACBB5DEDC, x, y, z, density, flags)

def REQUEST_PATH_NODES_IN_AREA_THIS_FRAME(x1: float, y1: float, x2: float, y2: float) -> bool:
    return _ib(0x07FB139B592FA687, x1, y1, x2, y2)

def SET_AMBIENT_PED_RANGE_MULTIPLIER_THIS_FRAME(multiplier: float) -> None:
    _iv(0x0B919E1FB47CC4E0, multiplier)

def DOES_NAVMESH_BLOCKING_OBJECT_EXIST(p0: int) -> bool:
    return _ib(0x0EAEB0DB4B132399, p0)

def UPDATE_NAVMESH_BLOCKING_OBJECT(p0: int, p1: float, p2: float, p3: float, p4: float, p5: float, p6: float, p7: float, p8: int) -> None:
    _iv(0x109E99373F290687, p0, p1, p2, p3, p4, p5, p6, p7, p8)

def IS_POINT_ON_ROAD(x: float, y: float, z: float, vehicle: int) -> bool:
    return _ib(0x125BF4ABFC536B09, x, y, z, vehicle)

def GET_CLOSEST_ROAD(x: float, y: float, z: float, p3: float, p4: int, p5: int, p6: int, p7: int, p8: int, p9: int, p10: bool) -> bool:
    return _ib(0x132F52BBA570FE92, x, y, z, p3, p4, p5, p6, p7, p8, p9, p10)

def GET_POSITION_BY_SIDE_OF_ROAD(x: float, y: float, z: float, p3: int, outPosition: int) -> bool:
    return _ib(0x16F46FB18C8009E4, x, y, z, p3, outPosition)

def SET_ROADS_IN_ANGLED_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, width: float, unknown1: bool, unknown2: bool, unknown3: bool) -> None:
    _iv(0x1A5AA1208AF5DB59, x1, y1, z1, x2, y2, z2, width, unknown1, unknown2, unknown3)

def IS_VEHICLE_NODE_ID_VALID(vehicleNodeId: int) -> bool:
    return _ib(0x1EAF30FCFBF5AF74, vehicleNodeId)

def SET_ROADS_BACK_TO_ORIGINAL(p0: float, p1: float, p2: float, p3: float, p4: float, p5: float, p6: int) -> None:
    _iv(0x1EE7063B80FFC77C, p0, p1, p2, p3, p4, p5, p6)

def SET_IGNORE_NO_GPS_FLAG_UNTIL_FIRST_NORMAL_NODE(toggle: bool) -> None:
    _iv(0x1FC289A0C3FF470F, toggle)

def SET_ALLOW_STREAM_PROLOGUE_NODES(toggle: bool) -> None:
    _iv(0x228E5C6AD4D74BFD, toggle)

def GET_NTH_CLOSEST_VEHICLE_NODE_ID(x: float, y: float, z: float, nth: int, nodeFlags: int, p5: float, p6: float) -> int:
    return _ii(0x22D7275A79FE8215, x, y, z, nth, nodeFlags, p5, p6)

def GET_CLOSEST_VEHICLE_NODE(x: float, y: float, z: float, outPosition: int, nodeFlags: int, p5: float, p6: float) -> bool:
    return _ib(0x240A18690AE96513, x, y, z, outPosition, nodeFlags, p5, p6)

def CLEAR_GPS_DISABLED_ZONE_AT_INDEX(index: int) -> None:
    _iv(0x2801D0012266DF07, index)

def GET_APPROX_HEIGHT_FOR_POINT(x: float, y: float) -> float:
    return _if(0x29C24BFBED8AB8FB, x, y)

def GET_CLOSEST_MAJOR_VEHICLE_NODE(x: float, y: float, z: float, outPosition: int, unknown1: float, unknown2: float) -> bool:
    return _ib(0x2EABE3B06F58C1BE, x, y, z, outPosition, unknown1, unknown2)

def GET_STREET_NAME_AT_COORD(x: float, y: float, z: float, streetName: int, crossingRoad: int) -> None:
    _iv(0x2EB41072B4C1E4C0, x, y, z, streetName, crossingRoad)

def GET_APPROX_FLOOR_FOR_POINT(x: float, y: float) -> float:
    return _if(0x336511A34F2E5185, x, y)

def SET_PED_PATHS_IN_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, p6: bool, p7: int) -> None:
    _iv(0x34F060F4BF92E018, x1, y1, z1, x2, y2, z2, p6, p7)

def GET_APPROX_FLOOR_FOR_AREA(x1: float, y1: float, x2: float, y2: float) -> float:
    return _if(0x3599D741C9AC6310, x1, y1, x2, y2)

def ADD_NAVMESH_REQUIRED_REGION(x: float, y: float, radius: float) -> None:
    _iv(0x387EAD7EE42F6685, x, y, radius)

def GET_NTH_CLOSEST_VEHICLE_NODE_FAVOUR_DIRECTION(x: float, y: float, z: float, desiredX: float, desiredY: float, desiredZ: float, nthClosest: int, outPosition: int, outHeading: int, nodeFlags: int, p10: float, p11: float) -> bool:
    return _ib(0x45905BE8654AE067, x, y, z, desiredX, desiredY, desiredZ, nthClosest, outPosition, outHeading, nodeFlags, p10, p11)

def REMOVE_NAVMESH_BLOCKING_OBJECT(p0: int) -> None:
    _iv(0x46399A7895957C0E, p0)

def DISABLE_NAVMESH_IN_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, toggle: bool) -> None:
    _iv(0x4C8872D8CDBE1B8B, x1, y1, z1, x2, y2, z2, toggle)

def GET_VEHICLE_NODE_IS_SWITCHED_OFF(nodeID: int) -> bool:
    return _ib(0x4F5070AA58F69279, nodeID)

def GET_NTH_CLOSEST_VEHICLE_NODE_ID_WITH_HEADING(x: float, y: float, z: float, nthClosest: int, outPosition: int, outHeading: int, nodeFlags: int, p7: float, p8: float) -> int:
    return _ii(0x6448050E9C2A7207, x, y, z, nthClosest, outPosition, outHeading, nodeFlags, p7, p8)

def GET_VEHICLE_NODE_POSITION(nodeId: int, outPosition: int) -> None:
    _iv(0x703123E5E7D429C2, nodeId, outPosition)

def IS_NAVMESH_REQUIRED_REGION_IN_USE() -> bool:
    return _ib(0x705A844002B39DC0)

def SET_IGNORE_NO_GPS_FLAG(toggle: bool) -> None:
    _iv(0x72751156E7678833, toggle)

def GET_SPAWN_COORDS_FOR_VEHICLE_NODE(nodeAddress: int, towardsCoorsX: float, towardsCoorsY: float, towardsCoorsZ: float, centrePoint: int, heading: int) -> None:
    _iv(0x809549AFC7AEC597, nodeAddress, towardsCoorsX, towardsCoorsY, towardsCoorsZ, centrePoint, heading)

def GET_NTH_CLOSEST_VEHICLE_NODE_WITH_HEADING(x: float, y: float, z: float, nthClosest: int, outPosition: int, outHeading: int, outNumLanes: int, nodeFlags: int, unknown3: float, unknown4: float) -> bool:
    return _ib(0x80CA6A8B6C094CC4, x, y, z, nthClosest, outPosition, outHeading, outNumLanes, nodeFlags, unknown3, unknown4)

def ARE_ALL_NAVMESH_REGIONS_LOADED() -> bool:
    return _ib(0x8415D95B194A3AEA)

def GET_GPS_BLIP_ROUTE_FOUND() -> bool:
    return _ib(0x869DAACBBE9FA006)

def GET_APPROX_HEIGHT_FOR_AREA(x1: float, y1: float, x2: float, y2: float) -> float:
    return _if(0x8ABE8608576D9CE3, x1, y1, x2, y2)

def REMOVE_NAVMESH_REQUIRED_REGIONS() -> None:
    _iv(0x916F0A3CDEC3445E)

def GET_RANDOM_VEHICLE_NODE(x: float, y: float, z: float, radius: float, p4: bool, p5: bool, p6: bool, outPosition: int, nodeId: int) -> bool:
    return _ib(0x93E0DB8440B73A7D, x, y, z, radius, p4, p5, p6, outPosition, nodeId)

def GET_ROAD_BOUNDARY_USING_HEADING(x: float, y: float, z: float, heading: float, outPosition: int) -> bool:
    return _ib(0xA0F8A7517A273C05, x, y, z, heading, outPosition)

def GET_VEHICLE_NODE_IS_GPS_ALLOWED(nodeID: int) -> bool:
    return _ib(0xA2AE5C478B96E3B6, nodeID)

def ADJUST_AMBIENT_PED_SPAWN_DENSITIES_THIS_FRAME(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int) -> None:
    _iv(0xAA76052DDA9BFC3E, p0, p1, p2, p3, p4, p5, p6)

def CALCULATE_TRAVEL_DISTANCE_BETWEEN_POINTS(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> float:
    return _if(0xADD95C7005C4A197, x1, y1, z1, x2, y2, z2)

def GET_SAFE_COORD_FOR_PED(x: float, y: float, z: float, onGround: bool, outPosition: int, flags: int) -> bool:
    return _ib(0xB61C8E878A4199CA, x, y, z, onGround, outPosition, flags)

def GET_GPS_BLIP_ROUTE_LENGTH() -> int:
    return _ii(0xBBB45C3CF5C8AA85)

def SET_ROADS_IN_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, nodeEnabled: bool, unknown2: bool) -> None:
    _iv(0xBF1A602B5BA52FEE, x1, y1, z1, x2, y2, z2, nodeEnabled, unknown2)

def LOAD_ALL_PATH_NODES(set: bool) -> bool:
    return _ib(0xC2AB6BFE34E92F8B, set)

def SET_GPS_DISABLED_ZONE_AT_INDEX(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, index: int) -> None:
    _iv(0xD0BC1C6FB18EE154, x1, y1, z1, x2, y2, z2, index)

def GET_NEXT_GPS_DISABLED_ZONE_INDEX() -> int:
    return _ii(0xD3A6A0EF48823A8C)

def SET_GPS_DISABLED_ZONE(x1: float, y1: float, z1: float, x2: float, y2: float, z3: float) -> None:
    _iv(0xDC20483CD3DD5201, x1, y1, z1, x2, y2, z3)

def SET_PED_PATHS_BACK_TO_ORIGINAL(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, p6: int) -> None:
    _iv(0xE04B48F2CC926253, x1, y1, z1, x2, y2, z2, p6)

def GET_NTH_CLOSEST_VEHICLE_NODE(x: float, y: float, z: float, nthClosest: int, outPosition: int, nodeFlags: int, unknown1: float, unknown2: float) -> bool:
    return _ib(0xE50E52416CCF948B, x, y, z, nthClosest, outPosition, nodeFlags, unknown1, unknown2)

def GET_POS_ALONG_GPS_TYPE_ROUTE(result: int, p1: bool, p2: float, p3: int) -> bool:
    return _ib(0xF3162836C28F9DA5, result, p1, p2, p3)

def SET_ALLOW_STREAM_HEIST_ISLAND_NODES(type: int) -> None:
    _iv(0xF74B1FFA4A15FBEA, type)

def ARE_NODES_LOADED_FOR_AREA(x1: float, y1: float, x2: float, y2: float) -> bool:
    return _ib(0xF7B79A50B905A30D, x1, y1, x2, y2)

def IS_NAVMESH_LOADED_IN_AREA(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> bool:
    return _ib(0xF813C7E63F9062A5, x1, y1, z1, x2, y2, z2)

def GENERATE_DIRECTIONS_TO_COORD(x: float, y: float, z: float, p3: bool, direction: int, p5: int, distToNxJunction: int) -> int:
    return _ii(0xF90125F1F79ECDF8, x, y, z, p3, direction, p5, distToNxJunction)

def ADD_NAVMESH_BLOCKING_OBJECT(p0: float, p1: float, p2: float, p3: float, p4: float, p5: float, p6: float, p7: bool, p8: int) -> int:
    return _ii(0xFCD5C8E06E502F5A, p0, p1, p2, p3, p4, p5, p6, p7, p8)

def GET_CLOSEST_VEHICLE_NODE_WITH_HEADING(x: float, y: float, z: float, outPosition: int, outHeading: int, nodeType: int, p6: float, p7: float) -> bool:
    return _ib(0xFF071FB798B803B0, x, y, z, outPosition, outHeading, nodeType, p6, p7)
