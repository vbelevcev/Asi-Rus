"""Auto-generated raw native bindings for namespace DATAFILE.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_str as _is, _invoke_vector3 as _ivec


def DATAFILE_SELECT_CREATOR_STATS(p0: int, p1: int) -> bool:
    return _ib(0x01095C95CD46B624, p0, p1)

def DATADICT_GET_TYPE(objectData: int, key: str) -> int:
    return _ii(0x031C55ED33227371, objectData, key)

def DATAARRAY_GET_COUNT(arrayData: int) -> int:
    return _ii(0x065DB281590CEA2D, arrayData)

def DATADICT_GET_FLOAT(objectData: int, key: str) -> float:
    return _if(0x06610343E73B9727, objectData, key)

def DATADICT_GET_BOOL(objectData: int, key: str) -> bool:
    return _ib(0x1186940ED72FFEEC, objectData, key)

def DATAFILE_HAS_LOADED_FILE_DATA(requestId: int) -> bool:
    return _ib(0x15FF52B809DB2353, requestId)

def DATAFILE_SELECT_ACTIVE_FILE(requestId: int, p1: int) -> bool:
    return _ib(0x22DA66936E0FFF37, requestId, p1)

def DATAFILE_STORE_MISSION_HEADER(p0: int) -> None:
    _iv(0x2ED61456317B8178, p0)

def DATAARRAY_ADD_STRING(arrayData: int, value: str) -> None:
    _iv(0x2F0661C155AEEEAA, arrayData, value)

def DATADICT_SET_BOOL(objectData: int, key: str, value: bool) -> None:
    _iv(0x35124302A556A325, objectData, key, value)

def DATAARRAY_GET_TYPE(arrayData: int, arrayIndex: int) -> int:
    return _ii(0x3A0014ADB172A3C5, arrayData, arrayIndex)

def DATADICT_GET_STRING(objectData: int, key: str) -> str:
    return _is(0x3D2FD9E763B24472, objectData, key)

def DATAARRAY_GET_INT(arrayData: int, arrayIndex: int) -> int:
    return _ii(0x3E5AE19425CD74BE, arrayData, arrayIndex)

def DATAARRAY_ADD_VECTOR(arrayData: int, valueX: float, valueY: float, valueZ: float) -> None:
    _iv(0x407F8D034F70F0C2, arrayData, valueX, valueY, valueZ)

def UGC_UPDATE_MISSION(contentId: str, contentName: str, description: str, tagsCsv: str, contentTypeName: str, p5: int) -> bool:
    return _ib(0x4645DE9980999E93, contentId, contentName, description, tagsCsv, contentTypeName, p5)

def DATADICT_GET_VECTOR(objectData: int, key: str) -> 'gta.Vector3':
    return _ivec(0x46CD3CB66E0825CC, objectData, key)

def DATADICT_SET_VECTOR(objectData: int, key: str, valueX: float, valueY: float, valueZ: float) -> None:
    _iv(0x4CD49B76338C7DEE, objectData, key, valueX, valueY, valueZ)

def DATAFILE_UPDATE_SAVE_TO_CLOUD(p0: int) -> bool:
    return _ib(0x4DFDD9EB705F8140, p0)

def DATAARRAY_GET_BOOL(arrayData: int, arrayIndex: int) -> bool:
    return _ib(0x50C1B2874E50C114, arrayData, arrayIndex)

def DATAFILE_SELECT_UGC_PLAYER_DATA(p0: int, p1: int) -> bool:
    return _ib(0x52818819057F2B40, p0, p1)

def DATAARRAY_ADD_FLOAT(arrayData: int, value: float) -> None:
    _iv(0x57A995FD75D37F56, arrayData, value)

def DATADICT_CREATE_ARRAY(objectData: int, key: str) -> int:
    return _ii(0x5B11728527CA6E5F, objectData, key)

def UGC_UPDATE_CONTENT(contentId: str, data: int, dataCount: int, contentName: str, description: str, tagsCsv: str, contentTypeName: str, p7: int) -> bool:
    return _ib(0x648E7A5434AF7969, contentId, data, dataCount, contentName, description, tagsCsv, contentTypeName, p7)

def DATAARRAY_ADD_DICT(arrayData: int) -> int:
    return _ii(0x6889498B3E19C797, arrayData)

def UGC_SET_PLAYER_DATA(contentId: str, rating: float, contentTypeName: str, p3: int) -> bool:
    return _ib(0x692D808C34A82143, contentId, rating, contentTypeName, p3)

def DATAFILE_DELETE_FOR_ADDITIONAL_DATA_FILE(p0: int) -> None:
    _iv(0x6AD0BD5E087866CB, p0)

def DATAFILE_CLEAR_WATCH_LIST() -> None:
    _iv(0x6CC86E78358D5119)

def DATADICT_GET_INT(objectData: int, key: str) -> int:
    return _ii(0x78F06F6B1FB5A80C, objectData, key)

def DATADICT_GET_ARRAY(objectData: int, key: str) -> int:
    return _ii(0x7A983AA9DA2659ED, objectData, key)

def DATAFILE_START_SAVE_TO_CLOUD(filename: str, p1: int) -> bool:
    return _ib(0x83BCCE3224735F05, filename, p1)

def DATAARRAY_GET_DICT(arrayData: int, arrayIndex: int) -> int:
    return _ii(0x8B5FADCC4E3A145F, arrayData, arrayIndex)

def DATAARRAY_GET_VECTOR(arrayData: int, arrayIndex: int) -> 'gta.Vector3':
    return _ivec(0x8D2064E5B64A628A, arrayData, arrayIndex)

def DATAFILE_DELETE_REQUESTED_FILE(requestId: int) -> bool:
    return _ib(0x8F5EA1C01D65A100, requestId)

def DATADICT_SET_STRING(objectData: int, key: str, value: str) -> None:
    _iv(0x8FF3847DADD8E30C, objectData, key, value)

def DATAFILE_GET_FILE_DICT(p0: int) -> int:
    return _ii(0x906B778CA1DC72B6, p0)

def DATAFILE_DELETE(p0: int) -> None:
    _iv(0x9AB9C1CFC8862DFB, p0)

def DATAFILE_SELECT_UGC_STATS(p0: int, p1: bool, p2: int) -> bool:
    return _ib(0x9CB0BFA7A9342C3D, p0, p1, p2)

def DATADICT_CREATE_DICT(objectData: int, key: str) -> int:
    return _ii(0xA358F56F10732EE1, objectData, key)

def UGC_CREATE_MISSION(contentName: str, description: str, tagsCsv: str, contentTypeName: str, publish: bool, p5: int) -> bool:
    return _ib(0xA5EFC3E847D60507, contentName, description, tagsCsv, contentTypeName, publish, p5)

def DATAFILE_SELECT_UGC_DATA(p0: int, p1: int) -> bool:
    return _ib(0xA69AC4ADE82B57A4, p0, p1)

def DATAFILE_LOAD_OFFLINE_UGC_FOR_ADDITIONAL_DATA_FILE(p0: int, p1: int) -> bool:
    return _ib(0xA6EEF01087181EDD, p0, p1)

def DATAFILE_WATCH_REQUEST_ID(requestId: int) -> None:
    _iv(0xAD6875BBC0FC899C, requestId)

def DATADICT_GET_DICT(objectData: int, key: str) -> int:
    return _ii(0xB6B9DDC412FCEEE2, objectData, key)

def DATAFILE_IS_SAVE_PENDING() -> bool:
    return _ib(0xBEDB96A7584AA8CF)

def DATAARRAY_GET_FLOAT(arrayData: int, arrayIndex: int) -> float:
    return _if(0xC0C527B525D7CFB5, arrayData, arrayIndex)

def DATADICT_SET_FLOAT(objectData: int, key: str, value: float) -> None:
    _iv(0xC27E1CC2D795105E, objectData, key, value)

def DATAFILE_LOAD_OFFLINE_UGC(filename: str, p1: int) -> bool:
    return _ib(0xC5238C011AF405E4, filename, p1)

def DATAFILE_FLUSH_MISSION_HEADER() -> None:
    _iv(0xC55854C7D7274882)

def UGC_CREATE_CONTENT(data: int, dataCount: int, contentName: str, description: str, tagsCsv: str, contentTypeName: str, publish: bool, p7: int) -> bool:
    return _ib(0xC84527E235FCA219, data, dataCount, contentName, description, tagsCsv, contentTypeName, publish, p7)

def DATAARRAY_ADD_INT(arrayData: int, value: int) -> None:
    _iv(0xCABDB751D86FE93B, arrayData, value)

def DATAFILE_CREATE(p0: int) -> None:
    _iv(0xD27058A1CA2B13EE, p0)

def DATAARRAY_GET_STRING(arrayData: int, arrayIndex: int) -> str:
    return _is(0xD3F2FFEB8D836F52, arrayData, arrayIndex)

def DATAFILE_GET_FILE_DICT_FOR_ADDITIONAL_DATA_FILE(p0: int) -> int:
    return _ii(0xDBF860CF1DB8E599, p0)

def DATADICT_SET_INT(objectData: int, key: str, value: int) -> None:
    _iv(0xE7E035450A7948D5, objectData, key, value)

def DATAARRAY_ADD_BOOL(arrayData: int, value: bool) -> None:
    _iv(0xF8B0F5A43E928C76, arrayData, value)

def DATAFILE_HAS_VALID_FILE_DATA(requestId: int) -> bool:
    return _ib(0xF8CC1EBE0B62E29F, requestId)

def DATAFILE_IS_VALID_REQUEST_ID(index: int) -> bool:
    return _ib(0xFCCAE5B92A830878, index)
