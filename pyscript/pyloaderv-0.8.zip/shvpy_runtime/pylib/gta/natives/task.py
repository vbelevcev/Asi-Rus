"""Auto-generated raw native bindings for namespace TASK.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_str as _is, _invoke_vector3 as _ivec


def WAYPOINT_RECORDING_GET_SPEED_AT_POINT(name: str, point: int) -> float:
    return _if(0x005622AEBC33ACA9, name, point)

def GET_SEQUENCE_PROGRESS(ped: int) -> int:
    return _ii(0x00A9010CFE1E3533, ped)

def SET_SCENARIO_GROUP_ENABLED(scenarioGroup: str, enabled: bool) -> None:
    _iv(0x02C8E5B49848664E, scenarioGroup, enabled)

def SET_ANIM_RATE(entity: int, rate: float, priority: int, secondary: bool) -> None:
    _iv(0x032D49C5E359C847, entity, rate, priority, secondary)

def TASK_GO_TO_ENTITY_WHILE_AIMING_AT_COORD(ped: int, entity: int, aimX: float, aimY: float, aimZ: float, moveBlendRatio: float, shoot: bool, targetRadius: float, slowDistance: float, useNavMesh: bool, instantBlendToAim: bool, firingPattern: int) -> None:
    _iv(0x04701832B739DCE5, ped, entity, aimX, aimY, aimZ, moveBlendRatio, shoot, targetRadius, slowDistance, useNavMesh, instantBlendToAim, firingPattern)

def WAYPOINT_PLAYBACK_START_SHOOTING_AT_COORD(ped: int, x: float, y: float, z: float, p4: bool, firingPattern: int) -> None:
    _iv(0x057A25CFCC9DB671, ped, x, y, z, p4, firingPattern)

def SET_PARACHUTE_TASK_THRUST(ped: int, thrust: float) -> None:
    _iv(0x0729BAC1B8C64317, ped, thrust)

def TASK_FOLLOW_WAYPOINT_RECORDING(ped: int, name: str, p2: int, p3: int, p4: int) -> None:
    _iv(0x0759591819534F7B, ped, name, p2, p3, p4)

def TASK_SHOOT_AT_ENTITY(entity: int, target: int, duration: int, firingPattern: int) -> None:
    _iv(0x08DA95E8298AE772, entity, target, duration, firingPattern)

def TASK_RAPPEL_FROM_HELI(ped: int, minHeightAboveGround: float) -> None:
    _iv(0x09693B0312F91649, ped, minHeightAboveGround)

def DOES_SCENARIO_OF_TYPE_EXIST_IN_AREA(x: float, y: float, z: float, scenarioName: str, radius: float, mustBeFree: bool) -> bool:
    return _ib(0x0A9D0C2A3BBC86C1, x, y, z, scenarioName, radius, mustBeFree)

def TASK_JUMP(ped: int, usePlayerLaunchForce: bool, doSuperJump: bool, useFullSuperJumpForce: bool) -> None:
    _iv(0x0AE4086104E067B1, ped, usePlayerLaunchForce, doSuperJump, useFullSuperJumpForce)

def RESET_SCENARIO_TYPES_ENABLED() -> None:
    _iv(0x0D40EE2A7F2B2D6D)

def _SET_AMBIENT_PED_ENABLE_COLLISION_ON_NETWORK_CLONE_WHEN_FIXED(ped: int, enable: bool) -> None:
    _iv(0x0EFE4834A2F40563, ped, enable)

def WAYPOINT_PLAYBACK_PAUSE(p0: int, p1: bool, p2: bool) -> None:
    _iv(0x0F342546AA06FED5, p0, p1, p2)

def TASK_VEHICLE_PARK(ped: int, vehicle: int, x: float, y: float, z: float, heading: float, mode: int, radius: float, keepEngineOn: bool) -> None:
    _iv(0x0F3E34E968EA374E, ped, vehicle, x, y, z, heading, mode, radius, keepEngineOn)

def TASK_CLEAR_LOOK_AT(ped: int) -> None:
    _iv(0x0F804F1DB19B9689, ped)

def TASK_VEHICLE_ESCORT(ped: int, vehicle: int, targetVehicle: int, mode: int, speed: float, drivingStyle: int, minDistance: float, minHeightAboveTerrain: int, noRoadsDistance: float) -> None:
    _iv(0x0FA6E4B75F302400, ped, vehicle, targetVehicle, mode, speed, drivingStyle, minDistance, minHeightAboveTerrain, noRoadsDistance)

def SET_TASK_MOVE_NETWORK_ENABLE_COLLISION_ON_NETWORK_CLONE_WHEN_FIXED(ped: int, enable: bool) -> bool:
    return _ib(0x0FFB3C758E8C07B9, ped, enable)

def TASK_VEHICLE_SHOOT_AT_PED(ped: int, target: int, fireTolerance: float) -> None:
    _iv(0x10AB107B887214D8, ped, target, fireTolerance)

def TASK_GO_TO_COORD_WHILE_AIMING_AT_COORD(ped: int, x: float, y: float, z: float, aimAtX: float, aimAtY: float, aimAtZ: float, moveBlendRatio: float, shoot: bool, targetRadius: float, slowDistance: float, useNavMesh: bool, navFlags: int, instantBlendToAim: bool, firingPattern: int) -> None:
    _iv(0x11315AB3385B8AC0, ped, x, y, z, aimAtX, aimAtY, aimAtZ, moveBlendRatio, shoot, targetRadius, slowDistance, useNavMesh, navFlags, instantBlendToAim, firingPattern)

def VEHICLE_WAYPOINT_PLAYBACK_OVERRIDE_SPEED(vehicle: int, speed: float) -> None:
    _iv(0x121F0593E0A431D7, vehicle, speed)

def TASK_SCRIPTED_ANIMATION(ped: int, priorityLowData: int, priorityMidData: int, priorityHighData: int, blendInDelta: float, blendOutDelta: float) -> None:
    _iv(0x126EF75F1E17ABE5, ped, priorityLowData, priorityMidData, priorityHighData, blendInDelta, blendOutDelta)

def ASSISTED_MOVEMENT_OVERRIDE_LOAD_DISTANCE_THIS_FRAME(dist: float) -> None:
    _iv(0x13945951E16EF912, dist)

def TASK_START_SCENARIO_IN_PLACE(ped: int, scenarioName: str, unkDelay: int, playEnterAnim: bool) -> None:
    _iv(0x142A02425FF02BD9, ped, scenarioName, unkDelay, playEnterAnim)

def TASK_VEHICLE_DRIVE_TO_COORD_LONGRANGE(ped: int, vehicle: int, x: float, y: float, z: float, speed: float, driveMode: int, stopRange: float) -> None:
    _iv(0x158BB33F920D360C, ped, vehicle, x, y, z, speed, driveMode, stopRange)

def TASK_BOAT_MISSION(pedDriver: int, vehicle: int, targetVehicle: int, targetPed: int, x: float, y: float, z: float, mission: int, maxSpeed: float, drivingStyle: int, targetReached: float, boatFlags: int) -> None:
    _iv(0x15C86013127CE63F, pedDriver, vehicle, targetVehicle, targetPed, x, y, z, mission, maxSpeed, drivingStyle, targetReached, boatFlags)

def TASK_FOLLOW_NAV_MESH_TO_COORD(ped: int, x: float, y: float, z: float, moveBlendRatio: float, time: int, targetRadius: float, flags: int, targetHeading: float) -> None:
    _iv(0x15D3A79D4E44B913, ped, x, y, z, moveBlendRatio, time, targetRadius, flags, targetHeading)

def CLEAR_PED_SECONDARY_TASK(ped: int) -> None:
    _iv(0x176CECF6F920D707, ped)

def TASK_FOLLOW_NAV_MESH_TO_COORD_ADVANCED(ped: int, x: float, y: float, z: float, moveBlendRatio: float, time: int, targetRadius: float, flags: int, slideToCoordHeading: float, maxSlopeNavigable: float, clampMaxSearchDistance: float, targetHeading: float) -> None:
    _iv(0x17F58B88D085DBAC, ped, x, y, z, moveBlendRatio, time, targetRadius, flags, slideToCoordHeading, maxSlopeNavigable, clampMaxSearchDistance, targetHeading)

def TASK_VEHICLE_GOTO_NAVMESH(ped: int, vehicle: int, x: float, y: float, z: float, speed: float, behaviorFlag: int, stoppingRange: float) -> None:
    _iv(0x195AEEB13CEFE2EE, ped, vehicle, x, y, z, speed, behaviorFlag, stoppingRange)

def TASK_AGITATED_ACTION_CONFRONT_RESPONSE(ped: int, ped2: int) -> None:
    _iv(0x19D1B791CB3670FE, ped, ped2)

def TASK_PUT_PED_DIRECTLY_INTO_MELEE(ped: int, meleeTarget: int, blendInDuration: float, timeInMelee: float, strafePhaseSync: float, aiCombatFlags: int) -> None:
    _iv(0x1C6CD14A876FFE39, ped, meleeTarget, blendInDuration, timeInMelee, strafePhaseSync, aiCombatFlags)

def TASK_GO_TO_COORD_ANY_MEANS_EXTRA_PARAMS(ped: int, x: float, y: float, z: float, moveBlendRatio: float, vehicle: int, useLongRangeVehiclePathing: bool, drivingFlags: int, maxRangeToShootTargets: float, extraVehToTargetDistToPreferVehicle: float, driveStraightLineDistance: float, extraFlags: int, warpTimerMS: float) -> None:
    _iv(0x1DD45F9ECFDB1BC9, ped, x, y, z, moveBlendRatio, vehicle, useLongRangeVehiclePathing, drivingFlags, maxRangeToShootTargets, extraVehToTargetDistToPreferVehicle, driveStraightLineDistance, extraFlags, warpTimerMS)

def TASK_TURN_PED_TO_FACE_COORD(ped: int, x: float, y: float, z: float, duration: int) -> None:
    _iv(0x1DDA930A0AC38571, ped, x, y, z, duration)

def TASK_VEHICLE_HELI_PROTECT(pilot: int, vehicle: int, entityToFollow: int, targetSpeed: float, drivingFlags: int, radius: float, altitude: int, heliFlags: int) -> None:
    _iv(0x1E09C32048FEFD1C, pilot, vehicle, entityToFollow, targetSpeed, drivingFlags, radius, altitude, heliFlags)

def TASK_EXTEND_ROUTE(x: float, y: float, z: float) -> None:
    _iv(0x1E7889778264843A, x, y, z)

def SET_PED_DESIRED_MOVE_BLEND_RATIO(ped: int, newMoveBlendRatio: float) -> None:
    _iv(0x1E982AC8716912C5, ped, newMoveBlendRatio)

def GET_PHONE_GESTURE_ANIM_TOTAL_TIME(ped: int) -> float:
    return _if(0x1EE0F68A7C25DEC6, ped)

def REMOVE_SPECIFIC_COVER_BLOCKING_AREAS(startX: float, startY: float, startZ: float, endX: float, endY: float, endZ: float, blockObjects: bool, blockVehicles: bool, blockMap: bool, blockPlayer: bool) -> None:
    _iv(0x1F351CF1C6475734, startX, startY, startZ, endX, endY, endZ, blockObjects, blockVehicles, blockMap, blockPlayer)

def TASK_SWEEP_AIM_ENTITY(ped: int, animDict: str, lowAnimName: str, medAnimName: str, hiAnimName: str, runtime: int, targetEntity: int, turnRate: float, blendInDuration: float) -> None:
    _iv(0x2047C02158D6405A, ped, animDict, lowAnimName, medAnimName, hiAnimName, runtime, targetEntity, turnRate, blendInDuration)

def SET_ANIM_WEIGHT(entity: int, weight: float, priority: int, index: int, secondary: bool) -> None:
    _iv(0x207F1A47C0342F48, entity, weight, priority, index, secondary)

def WAYPOINT_PLAYBACK_START_AIMING_AT_PED(ped: int, target: int, p2: bool) -> None:
    _iv(0x20E330937C399D29, ped, target, p2)

def TASK_SMART_FLEE_PED(ped: int, fleeTarget: int, safeDistance: float, fleeTime: int, preferPavements: bool, updateToNearestHatedPed: bool) -> None:
    _iv(0x22B0D0E37CCB840D, ped, fleeTarget, safeDistance, fleeTime, preferPavements, updateToNearestHatedPed)

def ADD_PATROL_ROUTE_LINK(nodeId1: int, nodeId2: int) -> None:
    _iv(0x23083260DEC3A551, nodeId1, nodeId2)

def TASK_PLANE_MISSION(pilot: int, aircraft: int, targetVehicle: int, targetPed: int, destinationX: float, destinationY: float, destinationZ: float, missionFlag: int, angularDrag: float, targetReached: float, targetHeading: float, maxZ: float, minZ: float, precise: bool) -> None:
    _iv(0x23703CD154E83B88, pilot, aircraft, targetVehicle, targetPed, destinationX, destinationY, destinationZ, missionFlag, angularDrag, targetReached, targetHeading, maxZ, minZ, precise)

def WAYPOINT_PLAYBACK_RESUME(p0: int, p1: bool, p2: int, p3: int) -> None:
    _iv(0x244F70C84C547D2D, p0, p1, p2, p3)

def IS_MOVE_BLEND_RATIO_SPRINTING(ped: int) -> bool:
    return _ib(0x24A2AD74FA9814E2, ped)

def GET_PED_WAYPOINT_PROGRESS(ped: int) -> int:
    return _ii(0x2720AAA75001E094, ped)

def TASK_USE_NEAREST_SCENARIO_TO_COORD(ped: int, x: float, y: float, z: float, distance: float, duration: int) -> None:
    _iv(0x277F471BA9DB000B, ped, x, y, z, distance, duration)

def ADD_SCRIPTED_COVER_AREA(x: float, y: float, z: float, radius: float) -> None:
    _iv(0x28B7B9BFDAF274AA, x, y, z, radius)

def PED_HAS_USE_SCENARIO_TASK(ped: int) -> bool:
    return _ib(0x295E3CCEC879CCD7, ped)

def TASK_MOVE_NETWORK_ADVANCED_BY_NAME_WITH_INIT_PARAMS(ped: int, network: str, initialParameters: int, x: float, y: float, z: float, rotX: float, rotY: float, rotZ: float, rotOrder: int, blendDuration: float, allowOverrideCloneUpdate: bool, dictionary: str, flags: int) -> None:
    _iv(0x29682E2CCF21E9B5, ped, network, initialParameters, x, y, z, rotX, rotY, rotZ, rotOrder, blendDuration, allowOverrideCloneUpdate, dictionary, flags)

def IS_PED_GETTING_UP(ped: int) -> bool:
    return _ib(0x2A74E1D5F2F00EEC, ped)

def TASK_COMBAT_HATED_TARGETS_AROUND_PED_TIMED(ped: int, radius: float, time: int, combatFlags: int) -> None:
    _iv(0x2BBA30B854534A0C, ped, radius, time, combatFlags)

def TASK_PLANE_CHASE(pilot: int, entityToFollow: int, x: float, y: float, z: float) -> None:
    _iv(0x2D2386F273FF7A25, pilot, entityToFollow, x, y, z)

def TASK_MOVE_NETWORK_BY_NAME(ped: int, task: str, multiplier: float, allowOverrideCloneUpdate: bool, animDict: str, flags: int) -> None:
    _iv(0x2D537BA194896636, ped, task, multiplier, allowOverrideCloneUpdate, animDict, flags)

def TASK_DRIVE_BY(driverPed: int, targetPed: int, targetVehicle: int, targetX: float, targetY: float, targetZ: float, distanceToShoot: float, pedAccuracy: int, pushUnderneathDrivingTaskIfDriving: bool, firingPattern: int) -> None:
    _iv(0x2F8AF0E82773A171, driverPed, targetPed, targetVehicle, targetX, targetY, targetZ, distanceToShoot, pedAccuracy, pushUnderneathDrivingTaskIfDriving, firingPattern)

def WAYPOINT_RECORDING_GET_COORD(name: str, point: int, coord: int) -> bool:
    return _ib(0x2FB897405C90B361, name, point, coord)

def TASK_FOLLOW_TO_OFFSET_OF_ENTITY(ped: int, entity: int, offsetX: float, offsetY: float, offsetZ: float, movementSpeed: float, timeout: int, stoppingRange: float, persistFollowing: bool) -> None:
    _iv(0x304AE42E357B8C7E, ped, entity, offsetX, offsetY, offsetZ, movementSpeed, timeout, stoppingRange, persistFollowing)

def IS_TASK_MOVE_NETWORK_READY_FOR_TRANSITION(ped: int) -> bool:
    return _ib(0x30ED88D5E0C56A37, ped)

def TASK_VEHICLE_FOLLOW_WAYPOINT_RECORDING(ped: int, vehicle: int, WPRecording: str, p3: int, p4: int, p5: int, p6: int, p7: float, p8: bool, p9: float) -> None:
    _iv(0x3123FAA6DB1CF7ED, ped, vehicle, WPRecording, p3, p4, p5, p6, p7, p8, p9)

def _SET_SCRIPT_TASK_ENABLE_COLLISION_ON_NETWORK_CLONE_WHEN_FIXED(ped: int, enable: bool) -> None:
    _iv(0x32F6EEF031F943DC, ped, enable)

def TASK_GOTO_ENTITY_OFFSET_XY(ped: int, entity: int, duration: int, targetRadius: float, offsetX: float, offsetY: float, moveBlendRatio: float, gotoEntityOffsetFlags: int) -> None:
    _iv(0x338E7EF52B6095A9, ped, entity, duration, targetRadius, offsetX, offsetY, moveBlendRatio, gotoEntityOffsetFlags)

def IS_MOVE_BLEND_RATIO_STILL(ped: int) -> bool:
    return _ib(0x349CE7B56DAFD95C, ped)

def ASSISTED_MOVEMENT_REMOVE_ROUTE(route: str) -> None:
    _iv(0x3548536485DD792B, route)

def IS_SCENARIO_GROUP_ENABLED(scenarioGroup: str) -> bool:
    return _ib(0x367A09DED4E05B99, scenarioGroup)

def SET_TASK_MOVE_NETWORK_SIGNAL_LOCAL_FLOAT(ped: int, signalName: str, value: float) -> None:
    _iv(0x373EF409B82697A3, ped, signalName, value)

def CLEAR_SEQUENCE_TASK(taskSequenceId: int) -> None:
    _iv(0x3841422E9C488D8C, taskSequenceId)

def SET_PED_PATH_PREFER_TO_AVOID_WATER(ped: int, avoidWater: bool) -> None:
    _iv(0x38FE1EC73743793C, ped, avoidWater)

def TASK_SEEK_COVER_TO_COORDS(ped: int, x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, timeout: int, shortRoute: bool) -> None:
    _iv(0x39246A6958EF072C, ped, x1, y1, z1, x2, y2, z2, timeout, shortRoute)

def CLOSE_SEQUENCE_TASK(taskSequenceId: int) -> None:
    _iv(0x39E72BC99E6360CB, taskSequenceId)

def IS_SCENARIO_TYPE_ENABLED(scenarioType: str) -> bool:
    return _ib(0x3A815DB3EA088722, scenarioType)

def GET_CLIP_SET_FOR_SCRIPTED_GUN_TASK(gunTaskType: int) -> str:
    return _is(0x3A8CADC7D37AACC5, gunTaskType)

def TASK_VEHICLE_CHASE(driver: int, targetEnt: int) -> None:
    _iv(0x3C08A8E30363B353, driver, targetEnt)

def TASK_MOVE_NETWORK_BY_NAME_WITH_INIT_PARAMS(ped: int, network: str, initialParameters: int, blendDuration: float, allowOverrideCloneUpdate: bool, animDict: str, flags: int) -> None:
    _iv(0x3D45B0B355C5E0C9, ped, network, initialParameters, blendDuration, allowOverrideCloneUpdate, animDict, flags)

def IS_PED_RUNNING_ARREST_TASK(ped: int) -> bool:
    return _ib(0x3DC52677769B4AE0, ped)

def IS_CONTROLLED_VEHICLE_UNABLE_TO_GET_TO_ROAD(ped: int) -> bool:
    return _ib(0x3E38E28A1D80DDF6, ped)

def TASK_COWER(ped: int, duration: int) -> None:
    _iv(0x3EB1FE9E8E908E15, ped, duration)

def TASK_STOP_PHONE_GESTURE_ANIMATION(ped: int, blendOutOverride: float) -> None:
    _iv(0x3FA00D4F4641BFAE, ped, blendOutOverride)

def SET_DRIVE_TASK_MAX_CRUISE_SPEED(ped: int, speed: float, updateBaseTask: bool) -> None:
    _iv(0x404A5AA9B9F0B746, ped, speed, updateBaseTask)

def GET_VEHICLE_WAYPOINT_TARGET_POINT(vehicle: int) -> int:
    return _ii(0x416B62AC8B9E5BBD, vehicle)

def TASK_PUT_PED_DIRECTLY_INTO_COVER(ped: int, x: float, y: float, z: float, time: int, allowPeekingAndFiring: bool, blendInDuration: float, forceInitialFacingDirection: bool, forceFaceLeft: bool, identifier: int, doEntry: bool) -> None:
    _iv(0x4172393E6BE1FECE, ped, x, y, z, time, allowPeekingAndFiring, blendInDuration, forceInitialFacingDirection, forceFaceLeft, identifier, doEntry)

def RESET_EXCLUSIVE_SCENARIO_GROUP() -> None:
    _iv(0x4202BBCB8684563D)

def SET_PED_PATH_AVOID_FIRE(ped: int, avoidFire: bool) -> None:
    _iv(0x4455517B28441E60, ped, avoidFire)

def TASK_VEHICLE_AIM_AT_COORD(ped: int, x: float, y: float, z: float) -> None:
    _iv(0x447C1E9EF844BC0F, ped, x, y, z)

def GET_TASK_MOVE_NETWORK_SIGNAL_FLOAT(ped: int, signalName: str) -> float:
    return _if(0x44AB0B3AFECCE242, ped, signalName)

def TASK_SHOCKING_EVENT_REACT(ped: int, eventHandle: int) -> None:
    _iv(0x452419CBD838065B, ped, eventHandle)

def ADD_COVER_BLOCKING_AREA(startX: float, startY: float, startZ: float, endX: float, endY: float, endZ: float, blockObjects: bool, blockVehicles: bool, blockMap: bool, blockPlayer: bool) -> None:
    _iv(0x45C597097DD7CB81, startX, startY, startZ, endX, endY, endZ, blockObjects, blockVehicles, blockMap, blockPlayer)

def TASK_SHOOT_AT_COORD(ped: int, x: float, y: float, z: float, duration: int, firingPattern: int) -> None:
    _iv(0x46A6CC01E0826106, ped, x, y, z, duration, firingPattern)

def GET_PHONE_GESTURE_ANIM_CURRENT_TIME(ped: int) -> float:
    return _if(0x47619ABE8B268C60, ped)

def WAYPOINT_PLAYBACK_STOP_AIMING_OR_SHOOTING(ped: int) -> None:
    _iv(0x47EFA040EBB8E2EA, ped)

def TASK_VEHICLE_DRIVE_WANDER(ped: int, vehicle: int, speed: float, drivingStyle: int) -> None:
    _iv(0x480142959D337D00, ped, vehicle, speed, drivingStyle)

def TASK_GUARD_CURRENT_POSITION(ped: int, maxPatrolProximity: float, defensiveAreaRadius: float, setDefensiveArea: bool) -> None:
    _iv(0x4A58A47A72E3FCB4, ped, maxPatrolProximity, defensiveAreaRadius, setDefensiveArea)

def TASK_COMBAT_HATED_TARGETS_IN_AREA(ped: int, x: float, y: float, z: float, radius: float, combatFlags: int) -> None:
    _iv(0x4CF5F55DAC3280A0, ped, x, y, z, radius, combatFlags)

def TASK_FORCE_MOTION_STATE(ped: int, state: int, forceRestart: bool) -> None:
    _iv(0x4F056E1AFFEF17AB, ped, state, forceRestart)

def TASK_LEAVE_ANY_VEHICLE(ped: int, delayTime: int, flags: int) -> None:
    _iv(0x504D54DF3F6F2247, ped, delayTime, flags)

def TASK_VEHICLE_SHOOT_AT_COORD(ped: int, x: float, y: float, z: float, fireTolerance: float) -> None:
    _iv(0x5190796ED39C9B6D, ped, x, y, z, fireTolerance)

def GET_PATROL_TASK_INFO(ped: int, timeLeftAtNode: int, nodeId: int) -> bool:
    return _ib(0x52F734CEBE20DFBA, ped, timeLeftAtNode, nodeId)

def WAYPOINT_RECORDING_GET_NUM_POINTS(name: str, points: int) -> bool:
    return _ib(0x5343532C01A07234, name, points)

def GET_ACTIVE_VEHICLE_MISSION_TYPE(vehicle: int) -> int:
    return _ii(0x534AEBA6E5ED4CAB, vehicle)

def SET_EXCLUSIVE_SCENARIO_GROUP(scenarioGroup: str) -> None:
    _iv(0x535E97E1F7FC0C6A, scenarioGroup)

def CLEAR_VEHICLE_CRASH_TASK(vehicle: int) -> None:
    _iv(0x53DDC75BC3AC0A90, vehicle)

def IS_PED_SPRINTING(ped: int) -> bool:
    return _ib(0x57E457CD2C0FC168, ped)

def SET_SEQUENCE_TO_REPEAT(taskSequenceId: int, repeat: bool) -> None:
    _iv(0x58C70CF3A41E4AE7, taskSequenceId, repeat)

def TASK_USE_NEAREST_SCENARIO_TO_COORD_WARP(ped: int, x: float, y: float, z: float, radius: float, timeToLeave: int) -> None:
    _iv(0x58E2E0F23F6B76C3, ped, x, y, z, radius, timeToLeave)

def GET_SCRIPTED_COVER_POINT_COORDS(coverpoint: int) -> 'gta.Vector3':
    return _ivec(0x594A1028FC2A3E85, coverpoint)

def TASK_FOLLOW_POINT_ROUTE(ped: int, speed: float, mode: int) -> None:
    _iv(0x595583281858626E, ped, speed, mode)

def USE_WAYPOINT_RECORDING_AS_ASSISTED_MOVEMENT_ROUTE(name: str, p1: bool, p2: float, p3: float) -> None:
    _iv(0x5A353B8E6B1095B5, name, p1, p2, p3)

def TASK_PED_SLIDE_TO_COORD_HDG_RATE(ped: int, x: float, y: float, z: float, heading: float, speed: float, headingChangeRate: float) -> None:
    _iv(0x5A4A6A6D3DC64F52, ped, x, y, z, heading, speed, headingChangeRate)

def DOES_SCENARIO_EXIST_IN_AREA(x: float, y: float, z: float, radius: float, mustBeFree: bool) -> bool:
    return _ib(0x5A59271FFADD33C1, x, y, z, radius, mustBeFree)

def TASK_PERFORM_SEQUENCE(ped: int, taskSequenceId: int) -> None:
    _iv(0x5ABA3986D90D8A3B, ped, taskSequenceId)

def TASK_TURN_PED_TO_FACE_ENTITY(ped: int, entity: int, duration: int) -> None:
    _iv(0x5AD23D40115353AC, ped, entity, duration)

def TASK_GO_TO_COORD_ANY_MEANS(ped: int, x: float, y: float, z: float, moveBlendRatio: float, vehicle: int, useLongRangeVehiclePathing: bool, drivingFlags: int, maxRangeToShootTargets: float) -> None:
    _iv(0x5BC448CB78FA3E88, ped, x, y, z, moveBlendRatio, vehicle, useLongRangeVehiclePathing, drivingFlags, maxRangeToShootTargets)

def SET_DRIVE_TASK_CRUISE_SPEED(driver: int, cruiseSpeed: float) -> None:
    _iv(0x5C9B84BD7D31D908, driver, cruiseSpeed)

def VEHICLE_WAYPOINT_PLAYBACK_USE_DEFAULT_SPEED(vehicle: int) -> None:
    _iv(0x5CEB25A7D2848963, vehicle)

def ADD_VEHICLE_SUBTASK_ATTACK_COORD(ped: int, x: float, y: float, z: float) -> None:
    _iv(0x5CF0D8F9BBA0DD75, ped, x, y, z)

def TASK_USE_MOBILE_PHONE_TIMED(ped: int, duration: int) -> None:
    _iv(0x5EE02954A14C69DB, ped, duration)

def TASK_SKY_DIVE(ped: int, instant: bool) -> None:
    _iv(0x601736CFE536B0A0, ped, instant)

def TASK_SHARK_CIRCLE_COORD(ped: int, x: float, y: float, z: float, moveBlendRatio: float, radius: float) -> None:
    _iv(0x60A19CF85FF4CEFA, ped, x, y, z, moveBlendRatio, radius)

def ASSISTED_MOVEMENT_IS_ROUTE_LOADED(route: str) -> bool:
    return _ib(0x60F9A4393A21F741, route)

def CLEAR_DEFAULT_PRIMARY_TASK(ped: int) -> None:
    _iv(0x6100B3CEFD43452E, ped)

def TASK_GO_STRAIGHT_TO_COORD_RELATIVE_TO_ENTITY(ped: int, entity: int, x: float, y: float, z: float, moveBlendRatio: float, time: int) -> None:
    _iv(0x61E360B7E040D12E, ped, entity, x, y, z, moveBlendRatio, time)

def IS_PED_PLAYING_BASE_CLIP_IN_SCENARIO(ped: int) -> bool:
    return _ib(0x621C6E4729388E41, ped)

def TASK_RELOAD_WEAPON(ped: int, drawWeapon: bool) -> None:
    _iv(0x62D2916F56B9CD2D, ped, drawWeapon)

def GET_NAVMESH_ROUTE_RESULT(ped: int) -> int:
    return _ii(0x632E831F382A0FA8, ped)

def SET_TASK_VEHICLE_CHASE_IDEAL_PURSUIT_DISTANCE(ped: int, distance: float) -> None:
    _iv(0x639B642FACBE4EDD, ped, distance)

def TASK_VEHICLE_MISSION(driver: int, vehicle: int, vehicleTarget: int, missionType: int, cruiseSpeed: float, drivingStyle: int, targetReached: float, straightLineDistance: float, DriveAgainstTraffic: bool) -> None:
    _iv(0x659427E0EF36BCDE, driver, vehicle, vehicleTarget, missionType, cruiseSpeed, drivingStyle, targetReached, straightLineDistance, DriveAgainstTraffic)

def WAYPOINT_PLAYBACK_USE_DEFAULT_SPEED(p0: int) -> None:
    _iv(0x6599D834B12D0800, p0)

def TASK_AIM_GUN_AT_COORD(ped: int, x: float, y: float, z: float, time: int, instantBlendToAim: bool, playAnimIntro: bool) -> None:
    _iv(0x6671F3EEC681BDA1, ped, x, y, z, time, instantBlendToAim, playAnimIntro)

def UNCUFF_PED(ped: int) -> None:
    _iv(0x67406F2C8F87FC4F, ped)

def SET_PED_WAYPOINT_PROGRESS(ped: int, progress: int) -> None:
    _iv(0x686ECCD99D4E61BB, ped, progress)

def TASK_WANDER_SPECIFIC(ped: int, conditionalAnimGroupStr: str, conditionalAnimStr: str, heading: float) -> None:
    _iv(0x6919A2F136426098, ped, conditionalAnimGroupStr, conditionalAnimStr, heading)

def TASK_LOOK_AT_ENTITY(ped: int, lookAt: int, duration: int, flags: int, priority: int) -> None:
    _iv(0x69F4BE8C8CC4796C, ped, lookAt, duration, flags, priority)

def TASK_VEHICLE_PLAY_ANIM(vehicle: int, animationSet: str, animationName: str) -> None:
    _iv(0x69F5C3BD0F3EBD89, vehicle, animationSet, animationName)

def TASK_GO_TO_ENTITY(entity: int, target: int, duration: int, distance: float, moveBlendRatio: float, slowDownDistance: float, flags: int) -> None:
    _iv(0x6A071245EB0D1882, entity, target, duration, distance, moveBlendRatio, slowDownDistance, flags)

def SET_GLOBAL_MIN_BIRD_FLIGHT_HEIGHT(height: float) -> None:
    _iv(0x6C6B148586F934F7, height)

def TASK_WARP_PED_DIRECTLY_INTO_COVER(ped: int, time: int, allowPeekingAndFiring: bool, forceInitialFacingDirection: bool, forceFaceLeft: bool, identifier: int) -> None:
    _iv(0x6E01E9E8D89F8276, ped, time, allowPeekingAndFiring, forceInitialFacingDirection, forceFaceLeft, identifier)

def TASK_LOOK_AT_COORD(entity: int, x: float, y: float, z: float, duration: int, flags: int, priority: int) -> None:
    _iv(0x6FA46612594F7973, entity, x, y, z, duration, flags, priority)

def SET_ANIM_LOOPED(entity: int, looped: bool, priority: int, secondary: bool) -> None:
    _iv(0x70033C3CC29A1FF4, entity, looped, priority, secondary)

def WAYPOINT_PLAYBACK_GET_IS_PAUSED(p0: int) -> bool:
    return _ib(0x701375A7D43F01CB, p0)

def GET_TASK_MOVE_NETWORK_STATE(ped: int) -> str:
    return _is(0x717E4D1F2048376D, ped)

def TASK_THROW_PROJECTILE(ped: int, x: float, y: float, z: float, ignoreCollisionEntityIndex: int, createInvincibleProjectile: bool) -> None:
    _iv(0x7285951DBF6B5A51, ped, x, y, z, ignoreCollisionEntityIndex, createInvincibleProjectile)

def TASK_REACT_AND_FLEE_PED(ped: int, fleeTarget: int) -> None:
    _iv(0x72C896464915D1B1, ped, fleeTarget)

def PLAY_ANIM_ON_RUNNING_SCENARIO(ped: int, animDict: str, animName: str) -> None:
    _iv(0x748040460F8DF5DC, ped, animDict, animName)

def IS_PED_CUFFED(ped: int) -> bool:
    return _ib(0x74E559B3BC910685, ped)

def TASK_SEEK_COVER_FROM_POS(ped: int, x: float, y: float, z: float, duration: int, allowPeekingAndFiring: bool) -> None:
    _iv(0x75AC2B60386D89F2, ped, x, y, z, duration, allowPeekingAndFiring)

def DELETE_PATROL_ROUTE(patrolRoute: str) -> None:
    _iv(0x7767DD9D65E91319, patrolRoute)

def PLAY_ENTITY_SCRIPTED_ANIM(entity: int, priorityLowData: int, priorityMidData: int, priorityHighData: int, blendInDelta: float, blendOutDelta: float) -> None:
    _iv(0x77A1EEC547E7FCF1, entity, priorityLowData, priorityMidData, priorityHighData, blendInDelta, blendOutDelta)

def SET_PED_PATH_CAN_USE_LADDERS(ped: int, Toggle: bool) -> None:
    _iv(0x77A5B103C87F476E, ped, Toggle)

def GET_SCRIPT_TASK_STATUS(ped: int, taskHash: int) -> int:
    return _ii(0x77F1BEB8863288D5, ped, taskHash)

def IS_SCENARIO_OCCUPIED(x: float, y: float, z: float, maxRange: float, onlyUsersActuallyAtScenario: bool) -> bool:
    return _ib(0x788756D73AC2E07C, x, y, z, maxRange, onlyUsersActuallyAtScenario)

def TASK_EXIT_COVER(ped: int, exitType: int, x: float, y: float, z: float) -> None:
    _iv(0x79B258E397854D29, ped, exitType, x, y, z)

def TASK_AIM_GUN_SCRIPTED(ped: int, scriptTask: int, disableBlockingClip: bool, instantBlendToAim: bool) -> None:
    _iv(0x7A192BE16D373D00, ped, scriptTask, disableBlockingClip, instantBlendToAim)

def TASK_SHUFFLE_TO_NEXT_VEHICLE_SEAT(ped: int, vehicle: int, useAlternateShuffle: bool) -> None:
    _iv(0x7AA80209BDA643EB, ped, vehicle, useAlternateShuffle)

def TASK_SWEEP_AIM_POSITION(ped: int, animDict: str, lowAnimName: str, medAnimName: str, hiAnimName: str, runtime: int, x: float, y: float, z: float, turnRate: float, blendInDuration: float) -> None:
    _iv(0x7AFE8FDC10BC07D2, ped, animDict, lowAnimName, medAnimName, hiAnimName, runtime, x, y, z, turnRate, blendInDuration)

def TASK_COMBAT_HATED_TARGETS_AROUND_PED(ped: int, radius: float, combatFlags: int) -> None:
    _iv(0x7BF835BB9E2698C8, ped, radius, combatFlags)

def WAYPOINT_PLAYBACK_OVERRIDE_SPEED(p0: int, p1: float, p2: bool) -> None:
    _iv(0x7D7D2B47FA788E85, p0, p1, p2)

def TASK_EVERYONE_LEAVE_VEHICLE(vehicle: int) -> None:
    _iv(0x7F93691AB4B92272, vehicle)

def ASSISTED_MOVEMENT_REQUEST_ROUTE(route: str) -> None:
    _iv(0x817268968605947A, route)

def TASK_PLAY_ANIM_ADVANCED(ped: int, animDict: str, animName: str, posX: float, posY: float, posZ: float, rotX: float, rotY: float, rotZ: float, animEnterSpeed: float, animExitSpeed: float, duration: int, flag: int, animTime: float, rotOrder: int, ikFlags: int) -> None:
    _iv(0x83CDB10EA29B370B, ped, animDict, animName, posX, posY, posZ, rotX, rotY, rotZ, animEnterSpeed, animExitSpeed, duration, flag, animTime, rotOrder, ikFlags)

def TASK_FLUSH_ROUTE() -> None:
    _iv(0x841142A1376E9006)

def SET_TASK_MOVE_NETWORK_ANIM_SET(ped: int, clipSet: int, variableClipSet: int) -> None:
    _iv(0x8423541E8B3A1589, ped, clipSet, variableClipSet)

def TASK_SEEK_COVER_FROM_PED(ped: int, target: int, duration: int, allowPeekingAndFiring: bool) -> None:
    _iv(0x84D32B3BEC531324, ped, target, duration, allowPeekingAndFiring)

def GET_PED_DESIRED_MOVE_BLEND_RATIO(ped: int) -> float:
    return _if(0x8517D4A6CA8513ED, ped)

def ADD_VEHICLE_SUBTASK_ATTACK_PED(ped: int, target: int) -> None:
    _iv(0x85F462BADC7DA47F, ped, target)

def TASK_AIM_GUN_SCRIPTED_WITH_TARGET(ped: int, target: int, x: float, y: float, z: float, gunTaskType: int, disableBlockingClip: bool, forceAim: bool) -> None:
    _iv(0x8605AF0DE8B3A5AC, ped, target, x, y, z, gunTaskType, disableBlockingClip, forceAim)

def SET_TASK_MOVE_NETWORK_SIGNAL_FLOAT_LERP_RATE(ped: int, signalName: str, value: float) -> None:
    _iv(0x8634CEF2522D987B, ped, signalName, value)

def IS_DRIVEBY_TASK_UNDERNEATH_DRIVING_TASK(ped: int) -> bool:
    return _ib(0x8785E6E40C7A8818, ped)

def SET_PED_PATH_CLIMB_COST_MODIFIER(ped: int, modifier: float) -> None:
    _iv(0x88E32DB8C1A4AA4B, ped, modifier)

def TASK_PERFORM_SEQUENCE_FROM_PROGRESS(ped: int, taskIndex: int, progress1: int, progress2: int) -> None:
    _iv(0x89221B16730234F0, ped, taskIndex, progress1, progress2)

def WAYPOINT_PLAYBACK_START_AIMING_AT_COORD(ped: int, x: float, y: float, z: float, p4: bool) -> None:
    _iv(0x8968400D900ED8B3, ped, x, y, z, p4)

def TASK_CLIMB(ped: int, usePlayerLaunchForce: bool) -> None:
    _iv(0x89D9FCC2435112F1, ped, usePlayerLaunchForce)

def VEHICLE_WAYPOINT_PLAYBACK_PAUSE(vehicle: int) -> None:
    _iv(0x8A4E6AC373666BC5, vehicle)

def TASK_PERFORM_SEQUENCE_LOCALLY(ped: int, taskSequenceId: int) -> None:
    _iv(0x8C33220C8D78CA0D, ped, taskSequenceId)

def TASK_CHAT_TO_PED(ped: int, target: int, flags: int, goToLocationX: float, goToLocationY: float, goToLocationZ: float, headingDegs: float, idleTime: float) -> None:
    _iv(0x8C338E0263E4FD19, ped, target, flags, goToLocationX, goToLocationY, goToLocationZ, headingDegs, idleTime)

def SET_HIGH_FALL_TASK(ped: int, minTime: int, maxTime: int, entryType: int) -> None:
    _iv(0x8C825BDC7741D37C, ped, minTime, maxTime, entryType)

def SET_PED_PATH_CAN_USE_CLIMBOVERS(ped: int, Toggle: bool) -> None:
    _iv(0x8E06A6FE76C9EFF4, ped, Toggle)

def ADD_PATROL_ROUTE_NODE(nodeId: int, nodeType: str, posX: float, posY: float, posZ: float, headingX: float, headingY: float, headingZ: float, duration: int) -> None:
    _iv(0x8EDF950167586B7C, nodeId, nodeType, posX, posY, posZ, headingX, headingY, headingZ, duration)

def TASK_PLAY_PHONE_GESTURE_ANIMATION(ped: int, animDict: str, animation: str, boneMaskType: str, blendInDuration: float, blendOutDuration: float, isLooping: bool, holdLastFrame: bool) -> None:
    _iv(0x8FBB6758B3B3E9EC, ped, animDict, animation, boneMaskType, blendInDuration, blendOutDuration, isLooping, holdLastFrame)

def SET_PED_CAN_PLAY_AMBIENT_IDLES(ped: int, blockIdleClips: bool, removeIdleClipIfPlaying: bool) -> None:
    _iv(0x8FD89A6240813FD0, ped, blockIdleClips, removeIdleClipIfPlaying)

def IS_PED_BEING_ARRESTED(ped: int) -> bool:
    return _ib(0x90A09F3A45FED688, ped)

def TASK_SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(ped: int, toggle: bool) -> None:
    _iv(0x90D2156198831D69, ped, toggle)

def TASK_STAND_STILL(ped: int, time: int) -> None:
    _iv(0x919BE13EED931959, ped, time)

def IS_TASK_MOVE_NETWORK_ACTIVE(ped: int) -> bool:
    return _ib(0x921CE12C489C4C41, ped)

def TASK_PLANE_TAXI(pilot: int, aircraft: int, x: float, y: float, z: float, cruiseSpeed: float, targetReached: float) -> None:
    _iv(0x92C360B5F15D2302, pilot, aircraft, x, y, z, cruiseSpeed, targetReached)

def TASK_SET_SPHERE_DEFENSIVE_AREA(ped: int, x: float, y: float, z: float, radius: float) -> None:
    _iv(0x933C06518B52A9A4, ped, x, y, z, radius)

def TASK_ACHIEVE_HEADING(ped: int, heading: float, timeout: int) -> None:
    _iv(0x93B93A37987F1F3D, ped, heading, timeout)

def TASK_COMBAT_PED_TIMED(ped: int, target: int, time: int, flags: int) -> None:
    _iv(0x944F30DCB7096BDE, ped, target, time, flags)

def TASK_VEHICLE_MISSION_PED_TARGET(ped: int, vehicle: int, pedTarget: int, missionType: int, maxSpeed: float, drivingStyle: int, minDistance: float, straightLineDistance: float, DriveAgainstTraffic: bool) -> None:
    _iv(0x9454528DF15D657A, ped, vehicle, pedTarget, missionType, maxSpeed, drivingStyle, minDistance, straightLineDistance, DriveAgainstTraffic)

def TASK_SMART_FLEE_COORD(ped: int, x: float, y: float, z: float, distance: float, time: int, preferPavements: bool, quitIfOutOfRange: bool) -> None:
    _iv(0x94587F17E9C365D5, ped, x, y, z, distance, time, preferPavements, quitIfOutOfRange)

def TASK_CLEAR_DEFENSIVE_AREA(ped: int) -> None:
    _iv(0x95A6C46A31D1917D, ped)

def TASK_OPEN_VEHICLE_DOOR(ped: int, vehicle: int, timeOut: int, seat: int, speed: float) -> None:
    _iv(0x965791A9A488A062, ped, vehicle, timeOut, seat, speed)

def TASK_PLANT_BOMB(ped: int, x: float, y: float, z: float, heading: float) -> None:
    _iv(0x965FEC691D55E9BF, ped, x, y, z, heading)

def UPDATE_TASK_AIM_GUN_SCRIPTED_TARGET(ped: int, target: int, x: float, y: float, z: float, disableBlockingClip: bool) -> None:
    _iv(0x9724FB59A3E72AD0, ped, target, x, y, z, disableBlockingClip)

def TASK_GO_TO_ENTITY_WHILE_AIMING_AT_ENTITY(ped: int, entityToWalkTo: int, entityToAimAt: int, speed: float, shootatEntity: bool, targetRadius: float, slowDistance: float, useNavMesh: bool, instantBlendToAim: bool, firingPattern: int) -> None:
    _iv(0x97465886D35210E9, ped, entityToWalkTo, entityToAimAt, speed, shootatEntity, targetRadius, slowDistance, useNavMesh, instantBlendToAim, firingPattern)

def TASK_USE_NEAREST_SCENARIO_CHAIN_TO_COORD_WARP(ped: int, x: float, y: float, z: float, radius: float, timeToLeave: int) -> None:
    _iv(0x97A28E63F0BA5631, ped, x, y, z, radius, timeToLeave)

def STOP_ANIM_TASK(entity: int, animDictionary: str, animationName: str, blendDelta: float) -> None:
    _iv(0x97FF36A1D40EA00A, entity, animDictionary, animationName, blendDelta)

def GET_VEHICLE_WAYPOINT_PROGRESS(vehicle: int) -> int:
    return _ii(0x9824CFF8FC66E159, vehicle)

def TASK_WARP_PED_INTO_VEHICLE(ped: int, vehicle: int, seat: int) -> None:
    _iv(0x9A7D091411C5F684, ped, vehicle, seat)

def TASK_AIM_GUN_AT_ENTITY(ped: int, entity: int, duration: int, instantBlendToAim: bool) -> None:
    _iv(0x9B53BB6E8943AF53, ped, entity, duration, instantBlendToAim)

def TASK_GET_OFF_BOAT(ped: int, boat: int) -> None:
    _iv(0x9C00E77AF14B2DFF, ped, boat)

def GET_TASK_RAPPEL_DOWN_WALL_STATE(ped: int) -> int:
    return _ii(0x9D252648778160DF, ped)

def REQUEST_WAYPOINT_RECORDING(name: str) -> None:
    _iv(0x9EEFB62EB27B5792, name)

def TASK_USE_NEAREST_SCENARIO_CHAIN_TO_COORD(ped: int, x: float, y: float, z: float, maxRange: float, timeToLeave: int) -> None:
    _iv(0x9FDA1B3D7E7028B3, ped, x, y, z, maxRange, timeToLeave)

def TASK_SWAP_WEAPON(ped: int, drawWeapon: bool) -> None:
    _iv(0xA21C51255B205245, ped, drawWeapon)

def IS_MOUNTED_WEAPON_TASK_UNDERNEATH_DRIVING_TASK(ped: int) -> bool:
    return _ib(0xA320EF046186FA3B, ped)

def OPEN_PATROL_ROUTE(patrolRoute: str) -> None:
    _iv(0xA36BFB5EE89F3D82, patrolRoute)

def TASK_GO_TO_COORD_AND_AIM_AT_HATED_ENTITIES_NEAR_COORD(pedHandle: int, goToLocationX: float, goToLocationY: float, goToLocationZ: float, focusLocationX: float, focusLocationY: float, focusLocationZ: float, speed: float, shootAtEnemies: bool, distanceToStopAt: float, noRoadsDistance: float, useNavMesh: bool, navFlags: int, taskFlags: int, firingPattern: int) -> None:
    _iv(0xA55547801EB331FC, pedHandle, goToLocationX, goToLocationY, goToLocationZ, focusLocationX, focusLocationY, focusLocationZ, speed, shootAtEnemies, distanceToStopAt, noRoadsDistance, useNavMesh, navFlags, taskFlags, firingPattern)

def GET_WAYPOINT_DISTANCE_ALONG_ROUTE(name: str, point: int) -> float:
    return _if(0xA5B769058763E497, name, point)

def GET_TASK_MOVE_NETWORK_SIGNAL_BOOL(ped: int, signalName: str) -> bool:
    return _ib(0xA7FFBA498E4AAF67, ped, signalName)

def DOES_SCRIPTED_COVER_POINT_EXIST_AT_COORDS(x: float, y: float, z: float) -> bool:
    return _ib(0xA98B8E3C088E5A31, x, y, z)

def UPDATE_TASK_HANDS_UP_DURATION(ped: int, duration: int) -> None:
    _iv(0xA98FCAFD7893C834, ped, duration)

def TASK_GOTO_ENTITY_AIMING(ped: int, target: int, distanceToStopAt: float, StartAimingDist: float) -> None:
    _iv(0xA9DA48FAB8A76C12, ped, target, distanceToStopAt, StartAimingDist)

def IS_PED_ACTIVE_IN_SCENARIO(ped: int) -> bool:
    return _ib(0xAA135F9482C82CC3, ped)

def TASK_STEALTH_KILL(killer: int, target: int, stealthKillActionResultHash: int, desiredMoveBlendRatio: float, stealthFlags: int) -> None:
    _iv(0xAA5DC05579D60BD9, killer, target, stealthKillActionResultHash, desiredMoveBlendRatio, stealthFlags)

def CLEAR_PED_TASKS_IMMEDIATELY(ped: int) -> None:
    _iv(0xAAA34F8A7CB32098, ped)

def SET_EXPECTED_CLONE_NEXT_TASK_MOVE_NETWORK_STATE(ped: int, state: str) -> bool:
    return _ib(0xAB13A5565480B6D9, ped, state)

def IS_PED_STILL(ped: int) -> bool:
    return _ib(0xAC29253EEF8F0180, ped)

def TASK_HELI_CHASE(pilot: int, entityToFollow: int, x: float, y: float, z: float) -> None:
    _iv(0xAC83B1DB38D0ADA0, pilot, entityToFollow, x, y, z)

def TASK_TOGGLE_DUCK(ped: int, toggleType: int) -> None:
    _iv(0xAC96609B9995EDF8, ped, toggleType)

def TASK_STAND_GUARD(ped: int, x: float, y: float, z: float, heading: float, scenarioName: str) -> None:
    _iv(0xAE032F8BBA959E90, ped, x, y, z, heading, scenarioName)

def REMOVE_COVER_POINT(coverpoint: int) -> None:
    _iv(0xAE287C923D891715, coverpoint)

def CREATE_PATROL_ROUTE() -> None:
    _iv(0xAF8A443CCC8018DC)

def CLOSE_PATROL_ROUTE() -> None:
    _iv(0xB043ECA801B8CBC1)

def GET_IS_TASK_ACTIVE(ped: int, taskIndex: int) -> bool:
    return _ib(0xB0760331C7AA4155, ped, taskIndex)

def SET_TASK_MOVE_NETWORK_SIGNAL_BOOL(ped: int, signalName: str, value: bool) -> None:
    _iv(0xB0A6CFD2C69C1088, ped, signalName, value)

def TASK_GO_TO_COORD_WHILE_AIMING_AT_ENTITY(ped: int, x: float, y: float, z: float, aimAtID: int, moveBlendRatio: float, shoot: bool, targetRadius: float, slowDistance: float, useNavMesh: bool, navFlags: int, instantBlendToAim: bool, firingPattern: int, time: int) -> None:
    _iv(0xB2A16444EAD9AE47, ped, x, y, z, aimAtID, moveBlendRatio, shoot, targetRadius, slowDistance, useNavMesh, navFlags, instantBlendToAim, firingPattern, time)

def TASK_PARACHUTE_TO_TARGET(ped: int, x: float, y: float, z: float) -> None:
    _iv(0xB33E291AFA6BD03A, ped, x, y, z)

def TASK_HELI_ESCORT_HELI(pilot: int, heli1: int, heli2: int, offsetX: float, offsetY: float, offsetZ: float) -> None:
    _iv(0xB385523325077210, pilot, heli1, heli2, offsetX, offsetY, offsetZ)

def GET_TASK_MOVE_NETWORK_EVENT(ped: int, eventName: str) -> bool:
    return _ib(0xB4F47213DF45A64C, ped, eventName)

def WAYPOINT_RECORDING_GET_CLOSEST_WAYPOINT(name: str, x: float, y: float, z: float, point: int) -> bool:
    return _ib(0xB629A298081F876F, name, x, y, z, point)

def TASK_CLIMB_LADDER(ped: int, fast: bool) -> None:
    _iv(0xB6C987F9285A3814, ped, fast)

def IS_PLAYING_PHONE_GESTURE_ANIM(ped: int) -> bool:
    return _ib(0xB8EBB1E9D3588C10, ped)

def TASK_GO_TO_COORD_ANY_MEANS_EXTRA_PARAMS_WITH_CRUISE_SPEED(ped: int, x: float, y: float, z: float, moveBlendRatio: float, vehicle: int, useLongRangeVehiclePathing: bool, drivingFlags: int, maxRangeToShootTargets: float, extraVehToTargetDistToPreferVehicle: float, driveStraightLineDistance: float, extraFlags: int, cruiseSpeed: float, targetArriveDist: float) -> None:
    _iv(0xB8ECD61F531A7B02, ped, x, y, z, moveBlendRatio, vehicle, useLongRangeVehiclePathing, drivingFlags, maxRangeToShootTargets, extraVehToTargetDistToPreferVehicle, driveStraightLineDistance, extraFlags, cruiseSpeed, targetArriveDist)

def UPDATE_TASK_SWEEP_AIM_POSITION(ped: int, x: float, y: float, z: float) -> None:
    _iv(0xBB106883F5201FC4, ped, x, y, z)

def TASK_WANDER_STANDARD(ped: int, heading: float, flags: int) -> None:
    _iv(0xBB9CE077274F6A1B, ped, heading, flags)

def TASK_USE_MOBILE_PHONE(ped: int, usePhone: bool, desiredPhoneMode: int) -> None:
    _iv(0xBD2A8EC3AF4DE7DB, ped, usePhone, desiredPhoneMode)

def TASK_PATROL(ped: int, patrolRouteName: str, alertState: int, canChatToPeds: bool, useHeadLookAt: bool) -> None:
    _iv(0xBDA5DF49D080FE4E, ped, patrolRouteName, alertState, canChatToPeds, useHeadLookAt)

def TASK_PLANE_LAND(pilot: int, plane: int, runwayStartX: float, runwayStartY: float, runwayStartZ: float, runwayEndX: float, runwayEndY: float, runwayEndZ: float) -> None:
    _iv(0xBF19721FA34D32C0, pilot, plane, runwayStartX, runwayStartY, runwayStartZ, runwayEndX, runwayEndY, runwayEndZ)

def TASK_ENTER_VEHICLE(ped: int, vehicle: int, timeout: int, seat: int, speed: float, flag: int, overrideEntryClipsetName: str) -> None:
    _iv(0xC20E50AA46D09CA8, ped, vehicle, timeout, seat, speed, flag, overrideEntryClipsetName)

def TASK_SUBMARINE_GOTO_AND_STOP(ped: int, submarine: int, x: float, y: float, z: float, autopilot: bool) -> None:
    _iv(0xC22B40579A498CA4, ped, submarine, x, y, z, autopilot)

def SET_PARACHUTE_TASK_TARGET(ped: int, x: float, y: float, z: float) -> None:
    _iv(0xC313379AF0FCEDA7, ped, x, y, z)

def CLEAR_DRIVEBY_TASK_UNDERNEATH_DRIVING_TASK(ped: int) -> None:
    _iv(0xC35B5CDB2824CF69, ped)

def TASK_VEHICLE_TEMP_ACTION(driver: int, vehicle: int, action: int, time: int) -> None:
    _iv(0xC429DCEEB339E129, driver, vehicle, action, time)

def IS_PED_RUNNING(ped: int) -> bool:
    return _ib(0xC5286FFC176F28A2, ped)

def GET_NAVMESH_ROUTE_DISTANCE_REMAINING(ped: int, distanceRemaining: int, isPathReady: int) -> int:
    return _ii(0xC6F5C0BCDC74D62D, ped, distanceRemaining, isPathReady)

def TASK_GUARD_SPHERE_DEFENSIVE_AREA(ped: int, defendPositionX: float, defendPositionY: float, defendPositionZ: float, heading: float, maxPatrolProximity: float, time: int, x: float, y: float, z: float, defensiveAreaRadius: float) -> None:
    _iv(0xC946FE14BE0EB5E2, ped, defendPositionX, defendPositionY, defendPositionZ, heading, maxPatrolProximity, time, x, y, z, defensiveAreaRadius)

def GET_IS_WAYPOINT_RECORDING_LOADED(name: str) -> bool:
    return _ib(0xCB4E8BE8A0063C5D, name)

def SET_TASK_VEHICLE_CHASE_BEHAVIOR_FLAG(ped: int, flag: int, set: bool) -> None:
    _iv(0xCC665AAC360D31E7, ped, flag, set)

def SET_MOUNTED_WEAPON_TARGET(shootingPed: int, targetPed: int, targetVehicle: int, x: float, y: float, z: float, taskMode: int, ignoreTargetVehDeadCheck: bool) -> None:
    _iv(0xCCD892192C6D2BB9, shootingPed, targetPed, targetVehicle, x, y, z, taskMode, ignoreTargetVehDeadCheck)

def TASK_WRITHE(ped: int, target: int, minFireLoops: int, startState: int, forceShootOnGround: bool, shootFromGroundTimer: int) -> None:
    _iv(0xCDDC2B77CE54AC6E, ped, target, minFireLoops, startState, forceShootOnGround, shootFromGroundTimer)

def REQUEST_TASK_MOVE_NETWORK_STATE_TRANSITION(ped: int, name: str) -> bool:
    return _ib(0xD01015C7316AE176, ped, name)

def TASK_PED_SLIDE_TO_COORD(ped: int, x: float, y: float, z: float, heading: float, speed: float) -> None:
    _iv(0xD04FE6765D990A06, ped, x, y, z, heading, speed)

def TASK_GUARD_ASSIGNED_DEFENSIVE_AREA(ped: int, x: float, y: float, z: float, heading: float, maxPatrolProximity: float, timer: int) -> None:
    _iv(0xD2A207EEBDF9889B, ped, x, y, z, heading, maxPatrolProximity, timer)

def TASK_PARACHUTE(ped: int, giveParachuteItem: bool, instant: bool) -> None:
    _iv(0xD2F1C53C97EE81AB, ped, giveParachuteItem, instant)

def TASK_LEAVE_VEHICLE(ped: int, vehicle: int, flags: int) -> None:
    _iv(0xD3DBCE61A490BE02, ped, vehicle, flags)

def TASK_SEEK_COVER_TO_COVER_POINT(ped: int, coverpoint: int, x: float, y: float, z: float, time: int, allowPeekingAndFiring: bool) -> None:
    _iv(0xD43D95C7A869447F, ped, coverpoint, x, y, z, time, allowPeekingAndFiring)

def IS_MOVE_BLEND_RATIO_RUNNING(ped: int) -> bool:
    return _ib(0xD4D8636C0199A939, ped)

def ASSISTED_MOVEMENT_SET_ROUTE_PROPERTIES(route: str, props: int) -> None:
    _iv(0xD5002D78B7162E1B, route, props)

def TASK_MOVE_NETWORK_ADVANCED_BY_NAME(ped: int, network: str, x: float, y: float, z: float, rotX: float, rotY: float, rotZ: float, rotOrder: int, blendDuration: float, allowOverrideCloneUpdate: bool, animDict: str, flags: int) -> None:
    _iv(0xD5B35BEA41919ACB, ped, network, x, y, z, rotX, rotY, rotZ, rotOrder, blendDuration, allowOverrideCloneUpdate, animDict, flags)

def SET_TASK_MOVE_NETWORK_SIGNAL_FLOAT(ped: int, signalName: str, value: float) -> None:
    _iv(0xD5BB4025AE449A4E, ped, signalName, value)

def ADD_COVER_POINT(x: float, y: float, z: float, direction: float, usage: int, height: int, arc: int, isPriority: bool) -> int:
    return _ii(0xD5C12A75C7B9497F, x, y, z, direction, usage, height, arc, isPriority)

def TASK_GO_STRAIGHT_TO_COORD(ped: int, x: float, y: float, z: float, speed: float, timeout: int, targetHeading: float, distanceToSlide: float) -> None:
    _iv(0xD76B57B44F1E6F8B, ped, x, y, z, speed, timeout, targetHeading, distanceToSlide)

def SET_DRIVE_TASK_DRIVING_STYLE(ped: int, drivingStyle: int) -> None:
    _iv(0xDACE1BE37D88AF67, ped, drivingStyle)

def TASK_HELI_MISSION(pilot: int, aircraft: int, targetVehicle: int, targetPed: int, destinationX: float, destinationY: float, destinationZ: float, missionFlag: int, maxSpeed: float, radius: float, targetHeading: float, maxHeight: int, minHeight: int, slowDownDistance: float, behaviorFlags: int) -> None:
    _iv(0xDAD029E187A2BEB4, pilot, aircraft, targetVehicle, targetPed, destinationX, destinationY, destinationZ, missionFlag, maxSpeed, radius, targetHeading, maxHeight, minHeight, slowDownDistance, behaviorFlags)

def REMOVE_ALL_COVER_BLOCKING_AREAS() -> None:
    _iv(0xDB6708C0B46F56D8)

def CLEAR_PRIMARY_VEHICLE_TASK(vehicle: int) -> None:
    _iv(0xDBBC7A2432524127, vehicle)

def VEHICLE_WAYPOINT_PLAYBACK_RESUME(vehicle: int) -> None:
    _iv(0xDC04FCAA7839D492, vehicle)

def CONTROL_MOUNTED_WEAPON(ped: int) -> bool:
    return _ib(0xDCFE42068FE0135A, ped)

def RESET_SCENARIO_GROUPS_ENABLED() -> None:
    _iv(0xDD902D0349AFAD3A)

def SET_ANIM_PHASE(entity: int, phase: float, priority: int, secondary: bool) -> None:
    _iv(0xDDF3CB5A0A4C0B49, entity, phase, priority, secondary)

def IS_PED_WALKING(ped: int) -> bool:
    return _ib(0xDE4C184B2B9B071A, ped)

def IS_PED_IN_WRITHE(ped: int) -> bool:
    return _ib(0xDEB6D52126E7D640, ped)

def IS_WAYPOINT_PLAYBACK_GOING_ON_FOR_PED(ped: int) -> bool:
    return _ib(0xE03B3F2D3DC59B64, ped)

def TASK_WANDER_IN_AREA(ped: int, x: float, y: float, z: float, radius: float, minimalLength: float, timeBetweenWalks: float) -> None:
    _iv(0xE054346CA3A0F315, ped, x, y, z, radius, minimalLength, timeBetweenWalks)

def CLEAR_PED_TASKS(ped: int) -> None:
    _iv(0xE1EF3C1216AFF2CD, ped)

def TASK_VEHICLE_DRIVE_TO_COORD(ped: int, vehicle: int, x: float, y: float, z: float, speed: float, p6: int, vehicleModel: int, drivingMode: int, stopRange: float, straightLineDistance: float) -> None:
    _iv(0xE2A2AA2F659D77A7, ped, vehicle, x, y, z, speed, p6, vehicleModel, drivingMode, stopRange, straightLineDistance)

def SET_PED_PATH_CAN_DROP_FROM_HEIGHT(ped: int, Toggle: bool) -> None:
    _iv(0xE361C5C71C431A4F, ped, Toggle)

def TASK_GOTO_ENTITY_OFFSET(ped: int, entity: int, time: int, seekRadius: float, seekAngleDeg: float, moveBlendRatio: float, gotoEntityOffsetFlags: int) -> None:
    _iv(0xE39B4FF4FDEBDE27, ped, entity, time, seekRadius, seekAngleDeg, moveBlendRatio, gotoEntityOffsetFlags)

def TASK_VEHICLE_AIM_AT_PED(ped: int, target: int) -> None:
    _iv(0xE41885592B08B097, ped, target)

def VEHICLE_WAYPOINT_PLAYBACK_GET_IS_PAUSED(vehicle: int) -> bool:
    return _ib(0xE435D3539EFDCD1B, vehicle)

def IS_PED_STRAFING(ped: int) -> bool:
    return _ib(0xE45B7F222DE47E09, ped)

def UPDATE_TASK_SWEEP_AIM_ENTITY(ped: int, entity: int) -> None:
    _iv(0xE4973DBDBE6E44B3, ped, entity)

def SET_DRIVEBY_TASK_TARGET(shootingPed: int, targetPed: int, targetVehicle: int, x: float, y: float, z: float) -> None:
    _iv(0xE5B302114D8162EE, shootingPed, targetPed, targetVehicle, x, y, z)

def TASK_STAY_IN_COVER(ped: int) -> None:
    _iv(0xE5DA8615A6180789, ped)

def GET_PED_WAYPOINT_DISTANCE(p0: int) -> float:
    return _if(0xE6A877C64CAF1BC5, p0)

def WAYPOINT_PLAYBACK_START_SHOOTING_AT_PED(ped: int, ped2: int, p2: bool, p3: bool) -> None:
    _iv(0xE70BA7B90F8390DC, ped, ped2, p2, p3)

def TASK_PAUSE(ped: int, ms: int) -> None:
    _iv(0xE73A266DB0CA9042, ped, ms)

def OPEN_SEQUENCE_TASK(taskSequenceId: int) -> None:
    _iv(0xE8854A4326B9E12B, taskSequenceId)

def TASK_PLAY_ANIM(ped: int, animDictionary: str, animationName: str, blendInSpeed: float, blendOutSpeed: float, duration: int, flag: int, playbackRate: float, lockX: bool, lockY: bool, lockZ: bool) -> None:
    _iv(0xEA47FE3719165B94, ped, animDictionary, animationName, blendInSpeed, blendOutSpeed, duration, flag, playbackRate, lockX, lockY, lockZ)

def TASK_RAPPEL_DOWN_WALL_USING_CLIPSET_OVERRIDE(ped: int, x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, minZ: float, ropeHandle: int, clipSet: str, p10: int, p11: int) -> None:
    _iv(0xEAF66ACDDC794793, ped, x1, y1, z1, x2, y2, z2, minZ, ropeHandle, clipSet, p10, p11)

def SET_SCENARIO_TYPE_ENABLED(scenarioType: str, toggle: bool) -> None:
    _iv(0xEB47EC4E34FB7EE1, scenarioType, toggle)

def TASK_SET_DECISION_MAKER(ped: int, decisionMakerId: int) -> None:
    _iv(0xEB8517DDA73720DA, ped, decisionMakerId)

def SET_PED_WAYPOINT_ROUTE_OFFSET(ped: int, x: float, y: float, z: float) -> bool:
    return _ib(0xED98E10B0AFCE4B4, ped, x, y, z)

def STOP_ANIM_PLAYBACK(entity: int, priority: int, secondary: bool) -> None:
    _iv(0xEE08C992D238C5D1, entity, priority, secondary)

def TASK_SYNCHRONIZED_SCENE(ped: int, scene: int, animDictionary: str, animationName: str, blendIn: float, blendOut: float, flags: int, ragdollBlockingFlags: int, moverBlendDelta: float, ikFlags: int) -> None:
    _iv(0xEEA929141F699854, ped, scene, animDictionary, animationName, blendIn, blendOut, flags, ragdollBlockingFlags, moverBlendDelta, ikFlags)

def TASK_VEHICLE_MISSION_COORS_TARGET(ped: int, vehicle: int, x: float, y: float, z: float, mission: int, cruiseSpeed: float, drivingStyle: int, targetReached: float, straightLineDistance: float, DriveAgainstTraffic: bool) -> None:
    _iv(0xF0AF20AA7731F8C3, ped, vehicle, x, y, z, mission, cruiseSpeed, drivingStyle, targetReached, straightLineDistance, DriveAgainstTraffic)

def IS_MOVE_BLEND_RATIO_WALKING(ped: int) -> bool:
    return _ib(0xF133BBBE91E1691F, ped)

def TASK_COMBAT_PED(ped: int, targetPed: int, combatFlags: int, threatResponseFlags: int) -> None:
    _iv(0xF166E48407BAC484, ped, targetPed, combatFlags, threatResponseFlags)

def SET_NEXT_DESIRED_MOVE_STATE(nextMoveState: float) -> None:
    _iv(0xF1B9F16E89E2C93A, nextMoveState)

def TASK_HANDS_UP(ped: int, duration: int, facingPed: int, timeToFacePed: int, flags: int) -> None:
    _iv(0xF2EAB31979A7F910, ped, duration, facingPed, timeToFacePed, flags)

def SET_PED_PATH_MAY_ENTER_WATER(ped: int, mayEnterWater: bool) -> None:
    _iv(0xF35425A4204367EC, ped, mayEnterWater)

def TASK_ARREST_PED(ped: int, target: int) -> None:
    _iv(0xF3B9A78A178572B1, ped, target)

def IS_WAYPOINT_PLAYBACK_GOING_ON_FOR_VEHICLE(vehicle: int) -> bool:
    return _ib(0xF5134943EA29868C, vehicle)

def SET_SEQUENCE_PREVENT_MIGRATION(taskSequenceId: int) -> None:
    _iv(0xF5D1F489147CB683, taskSequenceId)

def CLEAR_PED_SCRIPT_TASK_IF_RUNNING_THREAT_RESPONSE_NON_TEMP_TASK(ped: int) -> None:
    _iv(0xF6DC48E56BE1243A, ped)

def TASK_PLANE_GOTO_PRECISE_VTOL(ped: int, vehicle: int, x: float, y: float, z: float, flightHeight: int, minHeightAboveTerrain: int, useDesiredOrientation: bool, desiredOrientation: float, autopilot: bool) -> None:
    _iv(0xF7F9DCCA89E7505B, ped, vehicle, x, y, z, flightHeight, minHeightAboveTerrain, useDesiredOrientation, desiredOrientation, autopilot)

def DOES_SCENARIO_GROUP_EXIST(scenarioGroup: str) -> bool:
    return _ib(0xF9034C136C9E00D3, scenarioGroup)

def TASK_START_SCENARIO_AT_POSITION(ped: int, scenarioName: str, x: float, y: float, z: float, heading: float, duration: int, sittingScenario: bool, teleport: bool) -> None:
    _iv(0xFA4EFC79F69D4F07, ped, scenarioName, x, y, z, heading, duration, sittingScenario, teleport)

def REMOVE_COVER_BLOCKING_AREAS_AT_POSITION(x: float, y: float, z: float) -> None:
    _iv(0xFA83CA6776038F64, x, y, z)

def TASK_VEHICLE_FOLLOW(driver: int, vehicle: int, targetEntity: int, speed: float, drivingStyle: int, minDistance: int) -> None:
    _iv(0xFC545A9F0626E3B6, driver, vehicle, targetEntity, speed, drivingStyle, minDistance)

def REMOVE_WAYPOINT_RECORDING(name: str) -> None:
    _iv(0xFF1B8B4AA1C25DC8, name)
