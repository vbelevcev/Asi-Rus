"""Auto-generated raw native bindings for namespace ENTITY.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_str as _is, _invoke_vector3 as _ivec


def HAS_ENTITY_CLEAR_LOS_TO_ENTITY_IN_FRONT(entity1: int, entity2: int) -> bool:
    return _ib(0x0267D00AF114F17A, entity1, entity2)

def REMOVE_MODEL_SWAP(x: float, y: float, z: float, radius: float, originalModel: int, newModel: int, p6: bool) -> None:
    _iv(0x033C0F9A64E229AE, x, y, z, radius, originalModel, newModel, p6)

def GET_PED_INDEX_FROM_ENTITY_INDEX(entity: int) -> int:
    return _ii(0x04A2A40C73395041, entity)

def DOES_ENTITY_HAVE_DRAWABLE(entity: int) -> bool:
    return _ib(0x060D6E96F8B8E48D, entity)

def SET_ENTITY_COORDS(entity: int, xPos: float, yPos: float, zPos: float, xAxis: bool, yAxis: bool, zAxis: bool, clearArea: bool) -> None:
    _iv(0x06843DA7060A026B, entity, xPos, yPos, zPos, xAxis, yAxis, zAxis, clearArea)

def FIND_ANIM_EVENT_PHASE(animDictionary: str, animName: str, p2: str, p3: int, p4: int) -> bool:
    return _ib(0x07F1BE2BCCAA27A7, animDictionary, animName, p2, p3, p4)

def _SET_ENTITY_NO_COLLISION_WITH_NETWORKED_ENTITY(entity1: int, entity2: int) -> None:
    _iv(0x0A27A7827347B3B1, entity1, entity2)

def SET_ENTITY_RECORDS_COLLISIONS(entity: int, toggle: bool) -> None:
    _iv(0x0A50A1EEDAD01E65, entity, toggle)

def GET_ENTITY_FORWARD_VECTOR(entity: int) -> 'gta.Vector3':
    return _ivec(0x0A794A5A57F8DF91, entity)

def IS_ENTITY_A_MISSION_ENTITY(entity: int) -> bool:
    return _ib(0x0A7B270912999B3C, entity)

def SET_ENTITY_LOAD_COLLISION_FLAG(entity: int, toggle: bool, p2: int) -> None:
    _iv(0x0DC7CABAB1E9B67E, entity, toggle, p2)

def SET_ENTITY_MAX_SPEED(entity: int, speed: float) -> None:
    _iv(0x0E46A3FCBDE2A1B1, entity, speed)

def IS_ENTITY_TOUCHING_MODEL(entity: int, modelHash: int) -> bool:
    return _ib(0x0F42323798A58C8C, entity, modelHash)

def STOP_SYNCHRONIZED_MAP_ENTITY_ANIM(x1: float, y1: float, z1: float, x2: float, y2: int, z2: float) -> bool:
    return _ib(0x11E79CAB7183B6F5, x1, y1, z1, x2, y2, z2)

def IS_ENTITY_STATIC(entity: int) -> bool:
    return _ib(0x1218E6886D3D8327, entity)

def CREATE_FORCED_OBJECT(x: float, y: float, z: float, p3: int, modelHash: int, p5: bool) -> None:
    _iv(0x150E808B375A385A, x, y, z, p3, modelHash, p5)

def GET_ENTITY_MAX_HEALTH(entity: int) -> int:
    return _ii(0x15D757606D170C3C, entity)

def SET_ENTITY_MAX_HEALTH(entity: int, value: int) -> None:
    _iv(0x166E7CF68597D8B5, entity, value)

def ATTACH_ENTITY_TO_ENTITY_PHYSICALLY_OVERRIDE_INVERSE_MASS(firstEntityIndex: int, secondEntityIndex: int, firstEntityBoneIndex: int, secondEntityBoneIndex: int, secondEntityOffsetX: float, secondEntityOffsetY: float, secondEntityOffsetZ: float, firstEntityOffsetX: float, firstEntityOffsetY: float, firstEntityOffsetZ: float, vecRotationX: float, vecRotationY: float, vecRotationZ: float, physicalStrength: float, constrainRotation: bool, doInitialWarp: bool, collideWithEntity: bool, addInitialSeperation: bool, rotOrder: int, invMassScaleA: float, invMassScaleB: float) -> None:
    _iv(0x168A09D1B25B0BA4, firstEntityIndex, secondEntityIndex, firstEntityBoneIndex, secondEntityBoneIndex, secondEntityOffsetX, secondEntityOffsetY, secondEntityOffsetZ, firstEntityOffsetX, firstEntityOffsetY, firstEntityOffsetZ, vecRotationX, vecRotationY, vecRotationZ, physicalStrength, constrainRotation, doInitialWarp, collideWithEntity, addInitialSeperation, rotOrder, invMassScaleA, invMassScaleB)

def SET_ENTITY_DYNAMIC(entity: int, toggle: bool) -> None:
    _iv(0x1718DE8E3F2823CA, entity, toggle)

def SET_ENTITY_CAN_BE_DAMAGED(entity: int, toggle: bool) -> None:
    _iv(0x1760FFA8AB074D66, entity, toggle)

def IS_ENTITY_TOUCHING_ENTITY(entity: int, targetEntity: int) -> bool:
    return _ib(0x17FFC1B2BA35A494, entity, targetEntity)

def GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(entity: int, offsetX: float, offsetY: float, offsetZ: float) -> 'gta.Vector3':
    return _ivec(0x1899F328B0E12848, entity, offsetX, offsetY, offsetZ)

def APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(entity: int, forceType: int, x: float, y: float, z: float, p5: bool, isDirectionRel: bool, isForceRel: bool, p8: bool) -> None:
    _iv(0x18FF00FC7EFF559E, entity, forceType, x, y, z, p5, isDirectionRel, isForceRel, p8)

def SET_ENTITY_USE_MAX_DISTANCE_FOR_WATER_REFLECTION(entity: int, p1: bool) -> None:
    _iv(0x1A092BB0C3808B96, entity, p1)

def SET_ENTITY_COLLISION(entity: int, toggle: bool, keepPhysics: bool) -> None:
    _iv(0x1A9205C1B9EE827F, entity, toggle, keepPhysics)

def SET_ENTITY_VELOCITY(entity: int, x: float, y: float, z: float) -> None:
    _iv(0x1C99BB7B6E96D16F, entity, x, y, z)

def IS_ENTITY_UPSIDEDOWN(entity: int) -> bool:
    return _ib(0x1DBD58820FA61D71, entity)

def GET_ENTITY_HEIGHT_ABOVE_GROUND(entity: int) -> float:
    return _if(0x1DD55701034110E5, entity)

def IS_ENTITY_PLAYING_ANIM(entity: int, animDict: str, animName: str, taskFlag: int) -> bool:
    return _ib(0x1F0B79228E461EC9, entity, animDict, animName, taskFlag)

def GET_ENTITY_OF_TYPE_ATTACHED_TO_ENTITY(entity: int, modelHash: int) -> int:
    return _ii(0x1F922734E259BD26, entity, modelHash)

def IS_ENTITY_AT_COORD(entity: int, xPos: float, yPos: float, zPos: float, xSize: float, ySize: float, zSize: float, p7: bool, p8: bool, p9: int) -> bool:
    return _ib(0x20B60995556D004F, entity, xPos, yPos, zPos, xSize, ySize, zSize, p7, p8, p9)

def HAS_ENTITY_ANIM_FINISHED(entity: int, animDict: str, animName: str, p3: int) -> bool:
    return _ib(0x20B711662962B472, entity, animDict, animName, p3)

def GET_ENTITY_ROTATION_VELOCITY(entity: int) -> 'gta.Vector3':
    return _ivec(0x213B91045D09B983, entity)

def DOES_ENTITY_HAVE_ANIM_DIRECTOR(entity: int) -> bool:
    return _ib(0x2158E81A6AF65EA9, entity)

def GET_OFFSET_FROM_ENTITY_GIVEN_WORLD_COORDS(entity: int, posX: float, posY: float, posZ: float) -> 'gta.Vector3':
    return _ivec(0x2274BC1C4885E333, entity, posX, posY, posZ)

def SET_ENTITY_COORDS_NO_OFFSET(entity: int, xPos: float, yPos: float, zPos: float, xAxis: bool, yAxis: bool, zAxis: bool) -> None:
    _iv(0x239A3351AC1DA385, entity, xPos, yPos, zPos, xAxis, yAxis, zAxis)

def SET_PED_AS_NO_LONGER_NEEDED(ped: int) -> None:
    _iv(0x2595DD4236549CE3, ped)

def IS_ENTITY_ATTACHED_TO_ANY_VEHICLE(entity: int) -> bool:
    return _ib(0x26AA915AD89BFB4B, entity)

def STOP_ENTITY_ANIM(entity: int, animation: str, animGroup: str, p3: float) -> bool:
    return _ib(0x28004F88151E03E0, entity, animation, animGroup, p3)

def SET_ENTITY_ANIM_SPEED(entity: int, animDictionary: str, animName: str, speedMultiplier: float) -> None:
    _iv(0x28D1A16553C51776, entity, animDictionary, animName, speedMultiplier)

def SET_ENTITY_MOTION_BLUR(entity: int, toggle: bool) -> None:
    _iv(0x295D82A8559F9150, entity, toggle)

def SET_ENTITY_NOWEAPONDECALS(entity: int, p1: bool) -> None:
    _iv(0x2C2E3DC128F44309, entity, p1)

def GET_ENTITY_ANIM_CURRENT_TIME(entity: int, animDict: str, animName: str) -> float:
    return _if(0x346D81500D088F42, entity, animDict, animName)

def SET_ENTITY_CAN_ONLY_BE_DAMAGED_BY_SCRIPT_PARTICIPANTS(entity: int, toggle: bool) -> None:
    _iv(0x352E2B5CF420BF3B, entity, toggle)

def SET_ALLOW_MIGRATE_TO_SPECTATOR(entity: int, p1: int) -> None:
    _iv(0x36F32DE87082343E, entity, p1)

def SET_ENTITY_INVINCIBLE(entity: int, toggle: bool, dontResetOnCleanup: bool) -> None:
    _iv(0x3882114BDE571AD4, entity, toggle, dontResetOnCleanup)

def SET_ENTITY_SHOULD_FREEZE_WAITING_ON_COLLISION(entity: int, toggle: bool) -> None:
    _iv(0x3910051CCECDB00C, entity, toggle)

def HAS_ENTITY_CLEAR_LOS_TO_ENTITY_ADJUST_FOR_COVER(entity1: int, entity2: int, traceType: int) -> bool:
    return _ib(0x394BDE2A7BBA031E, entity1, entity2, traceType)

def CREATE_MODEL_HIDE_EXCLUDING_SCRIPT_OBJECTS(x: float, y: float, z: float, radius: float, modelHash: int, p5: bool) -> None:
    _iv(0x3A52AE588830BF7F, x, y, z, radius, modelHash, p5)

def SET_OBJECT_AS_NO_LONGER_NEEDED(object: int) -> None:
    _iv(0x3AE22DEB5BA5A3E6, object)

def GET_ENTITY_COORDS(entity: int, alive: bool) -> 'gta.Vector3':
    return _ivec(0x3FEF770D40960D5A, entity, alive)

def FORCE_ENTITY_AI_AND_ANIMATION_UPDATE(entity: int) -> None:
    _iv(0x40FDEDB72F8293B2, entity)

def GET_ENTITY_LOD_DIST(entity: int) -> int:
    return _ii(0x4159C2762B5791D6, entity)

def FREEZE_ENTITY_POSITION(entity: int, toggle: bool) -> None:
    _iv(0x428CA6DBD1094446, entity, toggle)

def STOP_SYNCHRONIZED_ENTITY_ANIM(entity: int, p1: float, p2: bool) -> bool:
    return _ib(0x43D3807C077261E3, entity, p1, p2)

def SET_ENTITY_ANIM_CURRENT_TIME(entity: int, animDictionary: str, animName: str, time: float) -> None:
    _iv(0x4487C259F0F70977, entity, animDictionary, animName, time)

def SET_ENTITY_ALPHA(entity: int, alphaLevel: int, skin: bool) -> None:
    _iv(0x44A0870B7E92D7C0, entity, alphaLevel, skin)

def GET_WORLD_POSITION_OF_ENTITY_BONE(entity: int, boneIndex: int) -> 'gta.Vector3':
    return _ivec(0x44A8FCB8ED227738, entity, boneIndex)

def GET_ENTITY_BONE_POSTION(entity: int, boneIndex: int) -> 'gta.Vector3':
    return _ivec(0x46F8696933A63C9B, entity, boneIndex)

def IS_ENTITY_VISIBLE(entity: int) -> bool:
    return _ib(0x47D6F43D77935C75, entity)

def GET_ENTITY_VELOCITY(entity: int) -> 'gta.Vector3':
    return _ivec(0x4805D2B1D8CF94A9, entity)

def GET_ENTITY_ATTACHED_TO(entity: int) -> int:
    return _ii(0x48C2BED9180FE123, entity)

def RESET_PICKUP_ENTITY_GLOW(entity: int) -> None:
    _iv(0x490861B88F4FD846, entity)

def SET_ENTITY_HAS_GRAVITY(entity: int, toggle: bool) -> None:
    _iv(0x4A4722448F18EEF5, entity, toggle)

def GET_VEHICLE_INDEX_FROM_ENTITY_INDEX(entity: int) -> int:
    return _ii(0x4B53F92932ADFAC0, entity)

def GET_NEAREST_PLAYER_TO_ENTITY_ON_TEAM(entity: int, team: int) -> int:
    return _ii(0x4DC9A62F844D9337, entity, team)

def GET_ENTITY_ANIM_TOTAL_TIME(entity: int, animDict: str, animName: str) -> float:
    return _if(0x50BD2730B191E360, entity, animDict, animName)

def IS_ENTITY_IN_ANGLED_AREA(entity: int, x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, width: float, debug: bool, includeZ: bool, p10: int) -> bool:
    return _ib(0x51210CED3DA1C78A, entity, x1, y1, z1, x2, y2, z2, width, debug, includeZ, p10)

def IS_ENTITY_A_PED(entity: int) -> bool:
    return _ib(0x524AC5ECEA15343E, entity)

def IS_ENTITY_UPRIGHT(entity: int, angle: float) -> bool:
    return _ib(0x5333F526F6AB19AA, entity, angle)

def IS_ENTITY_IN_AREA(entity: int, x1: float, y1: float, z1: float, x2: float, y2: float, z2: float, p7: bool, p8: bool, p9: int) -> bool:
    return _ib(0x54736AA40E271165, entity, x1, y1, z1, x2, y2, z2, p7, p8, p9)

def SET_ENTITY_TRAFFICLIGHT_OVERRIDE(entity: int, state: int) -> None:
    _iv(0x57C5DB656185EAC4, entity, state)

def SET_ENTITY_LOD_DIST(entity: int, value: int) -> None:
    _iv(0x5927F96A78577363, entity, value)

def GET_ENTITY_ALPHA(entity: int) -> int:
    return _ii(0x5A47B3B5E63E94C6, entity)

def GET_ENTITY_HEIGHT(entity: int, X: float, Y: float, Z: float, atTop: bool, inWorldCoords: bool) -> float:
    return _if(0x5A504562485944DD, entity, X, Y, Z, atTop, inWorldCoords)

def SET_ENTITY_SORT_BIAS(entity: int, p1: float) -> None:
    _iv(0x5C3B791D580E0BC2, entity, p1)

def GET_LAST_MATERIAL_HIT_BY_ENTITY(entity: int) -> int:
    return _ii(0x5C3D0A935F535C4C, entity)

def ATTACH_ENTITY_BONE_TO_ENTITY_BONE(entity1: int, entity2: int, boneIndex1: int, boneIndex2: int, p4: bool, p5: bool) -> None:
    _iv(0x5C48B75732C8456C, entity1, entity2, boneIndex1, boneIndex2, p4, p5)

def IS_ENTITY_DEAD(entity: int, p1: bool) -> bool:
    return _ib(0x5F9532F3B5CC2551, entity, p1)

def HAS_ENTITY_BEEN_DAMAGED_BY_ANY_PED(entity: int) -> bool:
    return _ib(0x605F5A140F202491, entity)

def REMOVE_FORCED_OBJECT(x: float, y: float, z: float, p3: float, modelHash: int) -> None:
    _iv(0x61B6775E83C0DB6F, x, y, z, p3, modelHash)

def SET_ENTITY_COORDS_WITHOUT_PLANTS_RESET(entity: int, xPos: float, yPos: float, zPos: float, alive: bool, deadFlag: bool, ragdollFlag: bool, clearArea: bool) -> None:
    _iv(0x621873ECE1178967, entity, xPos, yPos, zPos, alive, deadFlag, ragdollFlag, clearArea)

def SET_VEHICLE_AS_NO_LONGER_NEEDED(vehicle: int) -> None:
    _iv(0x629BFA74418D6239, vehicle)

def SET_ENTITY_CANT_CAUSE_COLLISION_DAMAGED_ENTITY(entity1: int, entity2: int) -> None:
    _iv(0x68B562E124CC0AEF, entity1, entity2)

def SET_ENTITY_REQUIRES_MORE_EXPENSIVE_RIVER_CHECK(entity: int, toggle: bool) -> None:
    _iv(0x694E00132F2823ED, entity, toggle)

def IS_ENTITY_A_VEHICLE(entity: int) -> bool:
    return _ib(0x6AC7003FA6E5575E, entity)

def SET_ENTITY_HEALTH(entity: int, health: int, instigator: int, weaponType: int) -> None:
    _iv(0x6B76DC1F3AE6E6A3, entity, health, instigator, weaponType)

def ATTACH_ENTITY_TO_ENTITY(entity1: int, entity2: int, boneIndex: int, xPos: float, yPos: float, zPos: float, xRot: float, yRot: float, zRot: float, p9: bool, useSoftPinning: bool, collision: bool, isPed: bool, vertexIndex: int, fixedRot: bool, p15: int) -> None:
    _iv(0x6B9BBD38AB0796DF, entity1, entity2, boneIndex, xPos, yPos, zPos, xRot, yRot, zRot, p9, useSoftPinning, collision, isPed, vertexIndex, fixedRot, p15)

def ENABLE_ENTITY_BULLET_COLLISION(entity: int) -> None:
    _iv(0x6CE177D014502E8A, entity)

def SET_ENTITY_ONLY_DAMAGED_BY_RELATIONSHIP_GROUP(entity: int, p1: bool, p2: int) -> None:
    _iv(0x7022BD828FA0B082, entity, p1, p2)

def GET_NEAREST_PLAYER_TO_ENTITY(entity: int) -> int:
    return _ii(0x7196842CB375CDB3, entity)

def DOES_ENTITY_EXIST(entity: int) -> bool:
    return _ib(0x7239B21A38F536BA, entity)

def SET_ENTITY_RENDER_SCORCHED(entity: int, toggle: bool) -> None:
    _iv(0x730F5F8D3F0F2050, entity, toggle)

def IS_AN_ENTITY(handle: int) -> bool:
    return _ib(0x731EC8A916BD11A1, handle)

def IS_ENTITY_AT_ENTITY(entity1: int, entity2: int, xSize: float, ySize: float, zSize: float, p5: bool, p6: bool, p7: int) -> bool:
    return _ib(0x751B70C3D034E187, entity1, entity2, xSize, ySize, zSize, p5, p6, p7)

def DOES_ENTITY_HAVE_SKELETON(entity: int) -> bool:
    return _ib(0x764EB96874EFFDC1, entity)

def SET_ENTITY_QUATERNION(entity: int, x: float, y: float, z: float, w: float) -> None:
    _iv(0x77B21BE7AC540F07, entity, x, y, z, w)

def SET_ENTITY_IS_IN_VEHICLE(entity: int) -> None:
    _iv(0x78E8E3A640178255, entity)

def SET_ENTITY_ONLY_DAMAGED_BY_PLAYER(entity: int, toggle: bool) -> None:
    _iv(0x79F020FF9EDC0748, entity, toggle)

def GET_ENTITY_QUATERNION(entity: int, x: int, y: int, z: int, w: int) -> None:
    _iv(0x7B3703D2D32DFA18, entity, x, y, z, w)

def SET_ENTITY_LIGHTS(entity: int, toggle: bool) -> None:
    _iv(0x7CFBA6A80BDF3874, entity, toggle)

def PLAY_ENTITY_ANIM(entity: int, animName: str, animDict: str, p3: float, loop: bool, stayInAnim: bool, p6: bool, delta: float, bitset: int) -> bool:
    return _ib(0x7FB218262B810701, entity, animName, animDict, p3, loop, stayInAnim, p6, delta, bitset)

def GET_ENTITY_ROLL(entity: int) -> float:
    return _if(0x831E0242595560DF, entity)

def SET_ENTITY_ANGULAR_VELOCITY(entity: int, x: float, y: float, z: float) -> None:
    _iv(0x8339643499D1222E, entity, x, y, z)

def GET_ENTITY_HEADING_FROM_EULERS(entity: int) -> float:
    return _if(0x846BF6291198A71E, entity)

def SET_ENTITY_ROTATION(entity: int, pitch: float, roll: float, yaw: float, rotationOrder: int, p5: bool) -> None:
    _iv(0x8524A8B0171D5E07, entity, pitch, roll, yaw, rotationOrder, p5)

def GET_ENTITY_FORWARD_Y(entity: int) -> float:
    return _if(0x866A4A5FAE349510, entity)

def IS_ENTITY_IN_AIR(entity: int) -> bool:
    return _ib(0x886E37EC497200B6, entity)

def CREATE_MODEL_HIDE(x: float, y: float, z: float, radius: float, modelHash: int, p5: bool) -> None:
    _iv(0x8A97BCA30A0CE478, x, y, z, radius, modelHash, p5)

def GET_ENTITY_TYPE(entity: int) -> int:
    return _ii(0x8ACD366038D14505, entity)

def HAS_ENTITY_COLLIDED_WITH_ANYTHING(entity: int) -> bool:
    return _ib(0x8BAD02F0368D9E14, entity)

def GET_ENTITY_FORWARD_X(entity: int) -> float:
    return _if(0x8BB4EF4214E0E6D5, entity)

def IS_ENTITY_AN_OBJECT(entity: int) -> bool:
    return _ib(0x8D68C8FD0FACA94E, entity)

def SET_ENTITY_HEADING(entity: int, heading: float) -> None:
    _iv(0x8E2530AA8ADA980E, entity, heading)

def CREATE_MODEL_SWAP(x: float, y: float, z: float, radius: float, originalModel: int, newModel: int, p6: bool) -> None:
    _iv(0x92C47782FDA8B2A3, x, y, z, radius, originalModel, newModel, p6)

def HAS_ENTITY_BEEN_DAMAGED_BY_ANY_OBJECT(entity: int) -> bool:
    return _ib(0x95EB9964FF5C5C65, entity)

def GET_ENTITY_UPRIGHT_VALUE(entity: int) -> float:
    return _if(0x95EED5A694951F9F, entity)

def DETACH_ENTITY(entity: int, dynamic: bool, collision: bool) -> None:
    _iv(0x961AC54BF0613F5D, entity, dynamic, collision)

def GET_ENTITY_SPEED_VECTOR(entity: int, relative: bool) -> 'gta.Vector3':
    return _ivec(0x9A8D700A51CB7B0D, entity, relative)

def RESET_ENTITY_ALPHA(entity: int) -> None:
    _iv(0x9B1E824FFBB7027A, entity)

def SET_ENTITY_COMPLETELY_DISABLE_COLLISION(entity: int, toggle: bool, keepPhysics: bool) -> None:
    _iv(0x9EBC85ED0FFFE51C, entity, toggle, keepPhysics)

def GET_ENTITY_MODEL(entity: int) -> int:
    return _ii(0x9F47B058362C84B5, entity)

def SET_ENTITY_NO_COLLISION_ENTITY(entity1: int, entity2: int, thisFrameOnly: bool) -> None:
    _iv(0xA53ED5520C07654A, entity1, entity2, thisFrameOnly)

def GET_ENTITY_SCRIPT(entity: int, script: int) -> str:
    return _is(0xA6E9C38DB51D7748, entity, script)

def CLEAR_ENTITY_LAST_DAMAGE_ENTITY(entity: int) -> None:
    _iv(0xA72CD9CA74A5ECBA, entity)

def _GET_LAST_ENTITY_HIT_BY_ENTITY(entity: int) -> int:
    return _ii(0xA75EE4F689B85391, entity)

def SET_CAN_CLIMB_ON_ENTITY(entity: int, toggle: bool) -> None:
    _iv(0xA80AE305E0A3044F, entity, toggle)

def SET_ENTITY_ALWAYS_PRERENDER(entity: int, toggle: bool) -> None:
    _iv(0xACAD101E1FB66689, entity, toggle)

def SET_ENTITY_AS_MISSION_ENTITY(entity: int, p1: bool, p2: bool) -> None:
    _iv(0xAD738C3085FE7E11, entity, p1, p2)

def DELETE_ENTITY(entity: int) -> None:
    _iv(0xAE3CBE5BF394C9C9, entity)

def GET_ENTITY_ROTATION(entity: int, rotationOrder: int) -> 'gta.Vector3':
    return _ivec(0xAFBD61CC738D9EB9, entity, rotationOrder)

def IS_ENTITY_ATTACHED_TO_ANY_PED(entity: int) -> bool:
    return _ib(0xB1632E9A5F988D11, entity)

def SET_ENTITY_CAN_ONLY_BE_DAMAGED_BY_ENTITY(entity1: int, entity2: int) -> None:
    _iv(0xB17BC6453F6CF5AC, entity1, entity2)

def GET_ENTITY_BONE_COUNT(entity: int) -> int:
    return _ii(0xB328DCC3A3AA401B, entity)

def IS_ENTITY_ATTACHED(entity: int) -> bool:
    return _ib(0xB346476EF1A64897, entity)

def IS_ENTITY_IN_ZONE(entity: int, zone: str) -> bool:
    return _ib(0xB6463CF6AF527071, entity, zone)

def SET_ENTITY_AS_NO_LONGER_NEEDED(entity: int) -> None:
    _iv(0xB736A491E64A32CF, entity)

def PLAY_SYNCHRONIZED_MAP_ENTITY_ANIM(x1: float, y1: float, z1: float, x2: float, y2: int, z2: float, p6: str, p7: str, p8: float, p9: float, p10: int, p11: float) -> bool:
    return _ib(0xB9C54555ED30FBC4, x1, y1, z1, x2, y2, z2, p6, p7, p8, p9, p10, p11)

def GET_ENTITY_BONE_OBJECT_ROTATION(entity: int, boneIndex: int) -> 'gta.Vector3':
    return _ivec(0xBD8D32550E5CEBFE, entity, boneIndex)

def GET_ENTITY_PROOFS(entity: int, bulletProof: int, fireProof: int, explosionProof: int, collisionProof: int, meleeProof: int, steamProof: int, p7: int, drownProof: int) -> bool:
    return _ib(0xBE8CD9BE829BBEBF, entity, bulletProof, fireProof, explosionProof, collisionProof, meleeProof, steamProof, p7, drownProof)

def SET_ENTITY_WATER_REFLECTION_FLAG(entity: int, toggle: bool) -> None:
    _iv(0xC34BC448DA29F5E9, entity, toggle)

def ATTACH_ENTITY_TO_ENTITY_PHYSICALLY(entity1: int, entity2: int, boneIndex1: int, boneIndex2: int, xPos1: float, yPos1: float, zPos1: float, xPos2: float, yPos2: float, zPos2: float, xRot: float, yRot: float, zRot: float, breakForce: float, fixedRot: bool, p15: bool, collision: bool, p17: bool, p18: int) -> None:
    _iv(0xC3675780C92F90F9, entity1, entity2, boneIndex1, boneIndex2, xPos1, yPos1, zPos1, xPos2, yPos2, zPos2, xRot, yRot, zRot, breakForce, fixedRot, p15, collision, p17, p18)

def APPLY_FORCE_TO_ENTITY(entity: int, forceFlags: int, x: float, y: float, z: float, offX: float, offY: float, offZ: float, boneIndex: int, isDirectionRel: bool, ignoreUpVec: bool, isForceRel: bool, p12: bool, p13: bool) -> None:
    _iv(0xC5F68BE9613E2D18, entity, forceFlags, x, y, z, offX, offY, offZ, boneIndex, isDirectionRel, ignoreUpVec, isForceRel, p12, p13)

def PLAY_SYNCHRONIZED_ENTITY_ANIM(entity: int, syncedScene: int, animation: str, propName: str, p4: float, p5: float, p6: int, p7: float) -> bool:
    return _ib(0xC77720A12FE14A86, entity, syncedScene, animation, propName, p4, p5, p6, p7)

def HAS_ENTITY_BEEN_DAMAGED_BY_ENTITY(entity1: int, entity2: int, p2: bool) -> bool:
    return _ib(0xC86D67D52A707CF8, entity1, entity2, p2)

def GET_ENTITY_COLLISION_DISABLED(entity: int) -> bool:
    return _ib(0xCCF1E97BEFDAE480, entity)

def GET_ENTITY_BONE_ROTATION(entity: int, boneIndex: int) -> 'gta.Vector3':
    return _ivec(0xCE6294A232D03786, entity, boneIndex)

def SET_PICKUP_COLLIDES_WITH_PROJECTILES(p0: int, p1: int) -> None:
    _iv(0xCEA7C8E1B48FF68C, p0, p1)

def GET_ENTITY_BONE_OBJECT_POSTION(entity: int, boneIndex: int) -> 'gta.Vector3':
    return _ivec(0xCF1247CC86961FD6, entity, boneIndex)

def IS_ENTITY_ATTACHED_TO_ANY_OBJECT(entity: int) -> bool:
    return _ib(0xCF511840CEEDE0CC, entity)

def IS_ENTITY_IN_WATER(entity: int) -> bool:
    return _ib(0xCFB0A0D8EDD145A3, entity)

def IS_ENTITY_WAITING_FOR_WORLD_COLLISION(entity: int) -> bool:
    return _ib(0xD05BFF0C0A12C68F, entity)

def SET_ENTITY_CAN_BE_TARGETED_WITHOUT_LOS(entity: int, toggle: bool) -> None:
    _iv(0xD3997889736FD899, entity, toggle)

def GET_ENTITY_PITCH(entity: int) -> float:
    return _if(0xD45DC2893621E1FE, entity)

def GET_ENTITY_SPEED(entity: int) -> float:
    return _if(0xD5037BA82E12416F, entity)

def IS_ENTITY_VISIBLE_TO_SCRIPT(entity: int) -> bool:
    return _ib(0xD796CB5BA8F20E32, entity)

def SET_PICK_UP_BY_CARGOBOB_DISABLED(entity: int, toggle: bool) -> None:
    _iv(0xD7B80E7C3BEFC396, entity, toggle)

def GET_OBJECT_INDEX_FROM_ENTITY_INDEX(entity: int) -> int:
    return _ii(0xD7E3B9735C0F89D6, entity)

def GET_ENTITY_CAN_BE_DAMAGED(entity: int) -> bool:
    return _ib(0xD95CC5D2AB15A09F, entity)

def REMOVE_MODEL_HIDE(x: float, y: float, z: float, radius: float, modelHash: int, p5: bool) -> None:
    _iv(0xD9E3006FB3CBD765, x, y, z, radius, modelHash, p5)

def DOES_ENTITY_HAVE_PHYSICS(entity: int) -> bool:
    return _ib(0xDA95EA3317CC5064, entity)

def SET_WAIT_FOR_COLLISIONS_BEFORE_PROBE(entity: int, toggle: bool) -> None:
    _iv(0xDC6F8601FAF2E893, entity, toggle)

def DOES_ENTITY_BELONG_TO_THIS_SCRIPT(entity: int, p1: bool) -> bool:
    return _ib(0xDDE6DF5AE89981D2, entity, p1)

def HAS_ENTITY_BEEN_DAMAGED_BY_ANY_VEHICLE(entity: int) -> bool:
    return _ib(0xDFD5033FDBA0A9C8, entity)

def SET_CAN_AUTO_VAULT_ON_ENTITY(entity: int, toggle: bool) -> None:
    _iv(0xE12ABE5E3A389A6C, entity, toggle)

def SET_ENTITY_CAN_BE_DAMAGED_BY_RELATIONSHIP_GROUP(entity: int, bCanBeDamaged: bool, relGroup: int) -> None:
    _iv(0xE22D8FDE858B8119, entity, bCanBeDamaged, relGroup)

def IS_ENTITY_OCCLUDED(entity: int) -> bool:
    return _ib(0xE31C2C72B8692B64, entity)

def GET_COLLISION_NORMAL_OF_LAST_HIT_FOR_ENTITY(entity: int) -> 'gta.Vector3':
    return _ivec(0xE465D4AB7CA6AE72, entity)

def IS_ENTITY_ON_SCREEN(entity: int) -> bool:
    return _ib(0xE659E47AF827484B, entity)

def SET_ENTITY_MIRROR_REFLECTION_FLAG(entity: int, p1: bool) -> None:
    _iv(0xE66377CDDADA4810, entity, p1)

def GET_ENTITY_SUBMERGED_LEVEL(entity: int) -> float:
    return _if(0xE81AFC1BC4CC41CE, entity)

def GET_ENTITY_HEADING(entity: int) -> float:
    return _if(0xE83D4F9BA2A38914, entity)

def HAS_COLLISION_LOADED_AROUND_ENTITY(entity: int) -> bool:
    return _ib(0xE9676F61BC0B3321, entity)

def SET_ENTITY_IS_TARGET_PRIORITY(entity: int, p1: bool, p2: float) -> None:
    _iv(0xEA02E132F5C68722, entity, p1, p2)

def SET_ENTITY_VISIBLE(entity: int, toggle: bool, p2: bool) -> None:
    _iv(0xEA1C610A04DB6BBB, entity, toggle, p2)

def HAS_ANIM_EVENT_FIRED(entity: int, actionHash: int) -> bool:
    return _ib(0xEAF4CD9EA3E7E922, entity, actionHash)

def GET_ENTITY_MATRIX(entity: int, forwardVector: int, rightVector: int, upVector: int, position: int) -> None:
    _iv(0xECB2FC7235A7D137, entity, forwardVector, rightVector, upVector, position)

def WOULD_ENTITY_BE_OCCLUDED(entityModelHash: int, x: float, y: float, z: float, p4: bool) -> bool:
    return _ib(0xEE5D2A122E09EC42, entityModelHash, x, y, z, p4)

def GET_ENTITY_HEALTH(entity: int) -> int:
    return _ii(0xEEF059FAD016D209, entity)

def IS_ENTITY_ATTACHED_TO_ENTITY(from_: int, to: int) -> bool:
    return _ib(0xEFBE71898A993728, from_, to)

def PROCESS_ENTITY_ATTACHMENTS(entity: int) -> None:
    _iv(0xF4080490ADC51C6F, entity)

def GET_ENTITY_POPULATION_TYPE(entity: int) -> int:
    return _ii(0xF6F5161F4534EDFF, entity)

def SET_ENTITY_PROOFS(entity: int, bulletProof: bool, fireProof: bool, explosionProof: bool, collisionProof: bool, meleeProof: bool, steamProof: bool, dontResetOnCleanup: bool, waterProof: bool) -> None:
    _iv(0xFAEE099C6F890BB8, entity, bulletProof, fireProof, explosionProof, collisionProof, meleeProof, steamProof, dontResetOnCleanup, waterProof)

def GET_ENTITY_BONE_INDEX_BY_NAME(entity: int, boneName: str) -> int:
    return _ii(0xFB71170B7E76ACBA, entity, boneName)

def HAS_ENTITY_CLEAR_LOS_TO_ENTITY(entity1: int, entity2: int, traceType: int) -> bool:
    return _ib(0xFCDFF7B72D23A1AC, entity1, entity2, traceType)

def ATTACH_ENTITY_BONE_TO_ENTITY_BONE_Y_FORWARD(entity1: int, entity2: int, boneIndex1: int, boneIndex2: int, p4: bool, p5: bool) -> None:
    _iv(0xFD1695C5D3B05439, entity1, entity2, boneIndex1, boneIndex2, p4, p5)

def GET_ANIM_DURATION(animDict: str, animName: str) -> float:
    return _if(0xFEDDF04D62B8D790, animDict, animName)

def GET_NEAREST_PARTICIPANT_TO_ENTITY(entity: int) -> int:
    return _ii(0xFFBD7052D65BE0FF, entity)
