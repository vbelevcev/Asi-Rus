"""Auto-generated raw native bindings for namespace HUD.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib, _invoke_int as _ii, _invoke_float as _if, _invoke_str as _is, _invoke_vector3 as _ivec


def GET_BLIP_ROTATION(blip: int) -> int:
    return _ii(0x003E92BA477F9D7F, blip)

def GET_CURRENT_WEBPAGE_ID() -> int:
    return _ii(0x01A358D9128B7A86)

def HAS_ADDITIONAL_TEXT_LOADED(slot: int) -> bool:
    return _ib(0x02245FE4BED318B8, slot)

def FLASH_ABILITY_BAR(millisecondsToFlash: int) -> None:
    _iv(0x02CFBA0C9E9275CE, millisecondsToFlash)

def SET_TEXT_PROPORTIONAL(p0: bool) -> None:
    _iv(0x038C1F517D7FDCF8, p0)

def ADD_TEXT_COMPONENT_INTEGER(value: int) -> None:
    _iv(0x03B504CF259931BC, value)

def SET_BLIP_COLOUR(blip: int, color: int) -> None:
    _iv(0x03D7FB09E75D6B7E, blip, color)

def SET_DIRECTOR_MODE_AVAILABLE(toggle: bool) -> None:
    _iv(0x04655F9D075D0AE5, toggle)

def GET_MENU_PED_BOOL_STAT(statHash: int, outValue: int) -> bool:
    return _ib(0x052991E59076E4E4, statHash, outValue)

def SET_MAX_ARMOUR_HUD_DISPLAY(maximumValue: int) -> None:
    _iv(0x06A320535F5F0248, maximumValue)

def CHANGE_FAKE_MP_CASH(cash: int, bank: int) -> None:
    _iv(0x0772DF77852C2E30, cash, bank)

def SET_TEXT_SCALE(scale: float, size: float) -> None:
    _iv(0x07C837F9A01C34C9, scale, size)

def SET_MINIMAP_FOW_REVEAL_COORDINATE(x: float, y: float, z: float) -> None:
    _iv(0x0923DBF87DFF735E, x, y, z)

def SET_RADAR_ZOOM(zoomLevel: int) -> None:
    _iv(0x096EF57A0C999BBA, zoomLevel)

def IS_SCRIPTED_HUD_COMPONENT_HIDDEN_THIS_FRAME(id: int) -> bool:
    return _ib(0x09C0403ED9A751C2, id)

def BEGIN_TEXT_COMMAND_IS_THIS_HELP_MESSAGE_BEING_DISPLAYED(labelName: str) -> None:
    _iv(0x0A24DA3A41B718F5, labelName)

def HUD_SUPPRESS_WEAPON_WHEEL_RESULTS_THIS_FRAME() -> None:
    _iv(0x0AFC4AF510774B47)

def SHOW_HUD_COMPONENT_THIS_FRAME(id: int) -> None:
    _iv(0x0B4DF1FA60C0E664, id)

def SET_PED_AI_BLIP_FORCED_ON(ped: int, toggle: bool) -> None:
    _iv(0x0C4BBF625CA98C4E, ped, toggle)

def SET_WARNING_MESSAGE_OPTION_ITEMS(index: int, name: str, cash: int, rp: int, lvl: int, colour: int) -> bool:
    return _ib(0x0C5A80A9E096D529, index, name, cash, rp, lvl, colour)

def USE_VEHICLE_TARGETING_RETICULE(p0: int) -> None:
    _iv(0x0C698D8F099174C7, p0)

def SET_SAVEGAME_LIST_UNIQUE_ID(p0: int) -> None:
    _iv(0x0CF54F20DE43879C, p0)

def ADD_TEXT_COMPONENT_FORMATTED_INTEGER(value: int, commaSeparated: bool) -> None:
    _iv(0x0E4C749FF9DE9CC4, value, commaSeparated)

def RESTART_FRONTEND_MENU(menuHash: int, p1: int) -> None:
    _iv(0x10706DC6AD2D49C0, menuHash, p1)

def END_TEXT_COMMAND_IS_THIS_HELP_MESSAGE_BEING_DISPLAYED(p0: int) -> bool:
    return _ib(0x10BDDBFC529428DD, p0)

def BUSYSPINNER_OFF() -> None:
    _iv(0x10D373323E5B9C0D)

def ADD_TEXT_COMPONENT_SUBSTRING_TIME(timestamp: int, flags: int) -> None:
    _iv(0x1115F16B8AB9E8BF, timestamp, flags)

def FORCE_SONAR_BLIPS_THIS_FRAME() -> bool:
    return _ib(0x1121BFA1A1A522A8)

def IS_NAMED_RENDERTARGET_LINKED(modelHash: int) -> bool:
    return _ib(0x113750538FA31298, modelHash)

def SET_TEXT_INPUT_BOX_ENABLED(p0: bool) -> None:
    _iv(0x1185A8087587322C, p0)

def RESET_RETICULE_VALUES() -> None:
    _iv(0x12782CE0A636E9F0)

def LOCK_MINIMAP_POSITION(x: float, y: float) -> None:
    _iv(0x1279E861A329E73F, x, y)

def SET_BLIP_NAME_TO_PLAYER_NAME(blip: int, player: int) -> None:
    _iv(0x127DE7B20C60A6A3, blip, player)

def SET_BLIP_SHOW_CONE(blip: int, toggle: bool, hudColorIndex: int) -> None:
    _iv(0x13127EC3665E8EE1, blip, toggle, hudColorIndex)

def END_TEXT_COMMAND_THEFEED_POST_CREWTAG_WITH_GAME_NAME(p0: bool, p1: bool, p2: int, p3: int, isLeader: bool, unk0: bool, clanDesc: int, playerName: str, R: int, G: int, B: int) -> int:
    return _ii(0x137BC35589E34E1E, p0, p1, p2, p3, isLeader, unk0, clanDesc, playerName, R, G, B)

def PAUSE_MENU_GET_MOUSE_HOVER_UNIQUE_ID() -> int:
    return _ii(0x13C4B962653A5280)

def RELEASE_CONTROL_OF_FRONTEND() -> None:
    _iv(0x14621BB1DF14E2B2)

def SET_BLIP_SECONDARY_COLOUR(blip: int, r: int, g: int, b: int) -> None:
    _iv(0x14892474891E09EB, blip, r, g, b)

def HUD_SHOWING_CHARACTER_SWITCH_SELECTION(toggle: bool) -> None:
    _iv(0x14C9FDCC41F81F63, toggle)

def GET_NEXT_BLIP_INFO_ID(blipSprite: int) -> int:
    return _ii(0x14F96AA50D6FBEA7, blipSprite)

def SET_MP_GAMER_TAGS_POINT_HEALTH(gamerTagId: int, value: int, maximumValue: int) -> None:
    _iv(0x1563FE35E9928E67, gamerTagId, value, maximumValue)

def IS_RADAR_HIDDEN() -> bool:
    return _ib(0x157F93B036700462)

def SET_WARNING_MESSAGE_WITH_HEADER_AND_SUBSTRING_FLAGS_EXTENDED(labelTitle: str, labelMessage: str, p2: int, p3: int, labelMessage2: str, p5: bool, p6: int, p7: int, p8: str, p9: str, background: bool, errorCode: int) -> None:
    _iv(0x15803FEC3B9A872B, labelTitle, labelMessage, p2, p3, labelMessage2, p5, p6, p7, p8, p9, background, errorCode)

def DOES_PED_HAVE_AI_BLIP(ped: int) -> bool:
    return _ib(0x15B8ECF844EE67ED, ped)

def THEFEED_SHOW() -> None:
    _iv(0x15CFA549788D35EF)

def GET_CHARACTER_FROM_AUDIO_CONVERSATION_FILENAME(text: str, position: int, length: int) -> str:
    return _is(0x169BD9382084C8C0, text, position, length)

def SET_SECOND_SCRIPT_VARIABLE_HUD_COLOUR(r: int, g: int, b: int, a: int) -> None:
    _iv(0x16A304E6CB2BFAB9, r, g, b, a)

def USE_FAKE_MP_CASH(toggle: bool) -> None:
    _iv(0x170F541E1CADD1DE, toggle)

def ADD_TEXT_COMPONENT_SUBSTRING_TEXT_LABEL_HASH_KEY(gxtEntryHash: int) -> None:
    _iv(0x17299B63C7683A2B, gxtEntryHash)

def THEFEED_SET_RGBA_PARAMETER_FOR_NEXT_MESSAGE(red: int, green: int, blue: int, alpha: int) -> None:
    _iv(0x17430B918701C342, red, green, blue, alpha)

def THEFEED_SET_FLASH_DURATION_PARAMETER_FOR_NEXT_MESSAGE(count: int) -> None:
    _iv(0x17AD8C9706BDD88A, count)

def GET_WAYPOINT_BLIP_ENUM_ID() -> int:
    return _ii(0x186E5D252FA50E7D)

def IS_HUD_PREFERENCE_SWITCHED_ON() -> bool:
    return _ib(0x1930DFA731813EC4)

def SHOW_FOR_SALE_ICON_ON_BLIP(blip: int, toggle: bool) -> None:
    _iv(0x19BD6E3C0E16A8FA, blip, toggle)

def SET_MINIMAP_IN_SPECTATOR_MODE(toggle: bool, ped: int) -> None:
    _iv(0x1A5CD7752DD28CD3, toggle, ped)

def GET_NAMED_RENDERTARGET_RENDER_ID(name: str) -> int:
    return _ii(0x1A6478B61C6BDC3B, name)

def CLOSE_MP_TEXT_CHAT() -> None:
    _iv(0x1AC8F4AD40E22127)

def _USE_VEHICLE_TARGETING_RETICULE_ON_VEHICLES(enable: bool) -> None:
    _iv(0x1BC0EA2912708625, enable)

def GET_FIRST_BLIP_INFO_ID(blipSprite: int) -> int:
    return _ii(0x1BEDE233E6CD2A1F, blipSprite)

def IS_PAUSE_MENU_RESTARTING() -> bool:
    return _ib(0x1C491717107431C7)

def DOES_TEXT_BLOCK_EXIST(gxt: str) -> bool:
    return _ib(0x1C7302E725259789, gxt)

def SET_TEXT_DROP_SHADOW() -> None:
    _iv(0x1CA3E9EAC9D93E5E)

def REPLACE_HUD_COLOUR(hudColorIndex: int, hudColorIndex2: int) -> None:
    _iv(0x1CCC708F0F850613, hudColorIndex, hudColorIndex2)

def END_TEXT_COMMAND_THEFEED_POST_MESSAGETEXT(txdName: str, textureName: str, flash: bool, iconType: int, sender: str, subject: str) -> int:
    return _ii(0x1CCD9A37359072CF, txdName, textureName, flash, iconType, sender, subject)

def MP_TEXT_CHAT_DISABLE(toggle: bool) -> None:
    _iv(0x1DB21A44B09E8BA3, toggle)

def IS_WAYPOINT_ACTIVE() -> bool:
    return _ib(0x1DD1F58F493F1DA5)

def SET_ABILITY_BAR_VISIBILITY(visible: bool) -> None:
    _iv(0x1DFEDD15019315A9, visible)

def GET_BLIP_INFO_ID_DISPLAY(blip: int) -> int:
    return _ii(0x1E314167F701DC3B, blip)

def END_TEXT_COMMAND_THEFEED_POST_MESSAGETEXT_TU(txdName: str, textureName: str, flash: bool, iconType: int, sender: str, subject: str, duration: float) -> int:
    return _ii(0x1E6611149DB3DB6B, txdName, textureName, flash, iconType, sender, subject, duration)

def SET_RACE_TRACK_RENDER(toggle: bool) -> None:
    _iv(0x1EAC5F91BCBC5073, toggle)

def CUSTOM_MINIMAP_SET_BLIP_OBJECT(spriteId: int) -> None:
    _iv(0x1EAE6DD17B7A5EFA, spriteId)

def GET_BLIP_SPRITE(blip: int) -> int:
    return _ii(0x1FC877464A04FC4F, blip)

def BEGIN_TEXT_COMMAND_THEFEED_POST(text: str) -> None:
    _iv(0x202709F4C58A0424, text)

def HIDE_MINIMAP_INTERIOR_MAP_THIS_FRAME() -> None:
    _iv(0x20FE7FDFEEAD38C0)

def DRAW_FRONTEND_BACKGROUND_THIS_FRAME() -> None:
    _iv(0x211C4EF450086857)

def HAS_SCRIPT_HIDDEN_HELP_THIS_FRAME() -> bool:
    return _ib(0x214CD562A939246A)

def FORCE_SCRIPTED_GFX_WHEN_FRONTEND_ACTIVE(p0: str) -> None:
    _iv(0x2162C446DFDF38FD, p0)

def CLEAR_GPS_FLAGS() -> None:
    _iv(0x21986729D6A3A830)

def GET_HUD_COMPONENT_POSITION(id: int) -> 'gta.Vector3':
    return _ivec(0x223CA69A8C4417FD, id)

def GET_CURRENT_FRONTEND_MENU_VERSION() -> int:
    return _ii(0x2309595AD6145265)

def SET_BIGMAP_ACTIVE(toggleBigMap: bool, showFullMap: bool) -> None:
    _iv(0x231C8F89D0539D8F, toggleBigMap, showFullMap)

def SET_BLIP_CATEGORY(blip: int, index: int) -> None:
    _iv(0x234CDD44D996FD9A, blip, index)

def END_TEXT_COMMAND_DISPLAY_HELP(p0: int, loop: bool, beep: bool, shape: int) -> None:
    _iv(0x238FFE5C7B0498A6, p0, loop, beep, shape)

def SHOW_FRIEND_INDICATOR_ON_BLIP(blip: int, toggle: bool) -> None:
    _iv(0x23C3EB807312F01A, blip, toggle)

def BEGIN_TEXT_COMMAND_ADD_DIRECTLY_TO_PREVIOUS_BRIEFS(p0: str) -> None:
    _iv(0x23D69E0465570028, p0)

def IS_FLOATING_HELP_TEXT_ON_SCREEN(hudIndex: int) -> bool:
    return _ib(0x2432784ACA090DA4, hudIndex)

def HIDE_HUDMARKERS_THIS_FRAME() -> None:
    _iv(0x243296A510B562B6)

def GET_CHARACTER_MENU_PED_MASKED_INT_STAT(statHash: int, outValue: int, p2: int, mask: int, p4: bool) -> bool:
    return _ib(0x24A49BEAF468DC90, statHash, outValue, p2, mask, p4)

def SET_BLIP_AS_MISSION_CREATOR_BLIP(blip: int, toggle: bool) -> None:
    _iv(0x24AC0137444F9FD5, blip, toggle)

def SET_TEXT_OUTLINE() -> None:
    _iv(0x2513DFB0FB8400FE)

def SET_RADIUS_BLIP_EDGE(blip: int, toggle: bool) -> None:
    _iv(0x25615540D894B814, blip, toggle)

def _SET_BLIP_GPS_ROUTE_DISPLAY_DISTANCE(blip: int, blipChangeParam46: int, blipChangeParam47: bool) -> None:
    _iv(0x25D984CFB64ED6DE, blip, blipChangeParam46, blipChangeParam47)

def THEFEED_HIDE_THIS_FRAME() -> None:
    _iv(0x25F87B30C382FCA7)

def BEGIN_TEXT_COMMAND_DISPLAY_TEXT(text: str) -> None:
    _iv(0x25FBB336DF1804CB, text)

def SET_DIRECTOR_MODE_LAUNCHED_BY_SCRIPT() -> None:
    _iv(0x2632482FD6B9AB87)

def IS_MISSION_CREATOR_BLIP(blip: int) -> bool:
    return _ib(0x26F49BF3381D933D, blip)

def CUSTOM_MINIMAP_CLEAR_BLIPS() -> None:
    _iv(0x2708FC083123F9FF)

def GET_PAUSE_MENU_STATE() -> int:
    return _ii(0x272ACD84970869C5)

def DISPLAY_AREA_NAME(toggle: bool) -> None:
    _iv(0x276B6CE369C33678, toggle)

def SET_FORCE_SHOW_GPS(toggle: bool) -> None:
    _iv(0x2790F4B17D098E26, toggle)

def RELOAD_MAP_MENU() -> None:
    _iv(0x2916A928514C9827)

def LOCK_MINIMAP_ANGLE(angle: int) -> None:
    _iv(0x299FAEBB108AE05B, angle)

def CLEAR_ADDITIONAL_TEXT(p0: int, p1: bool) -> None:
    _iv(0x2A179DF17CCF04CD, p0, p1)

def PAUSE_MENU_IS_CONTEXT_MENU_ACTIVE() -> bool:
    return _ib(0x2A25ADC48F87841F)

def SET_CUSTOM_MP_HUD_COLOR(hudColorId: int) -> None:
    _iv(0x2ACCB195F3CCD9DE, hudColorId)

def SET_BLIP_FADE(blip: int, opacity: int, duration: int) -> None:
    _iv(0x2AEE8F8390D2298C, blip, opacity, duration)

def SET_BLIP_AS_MINIMAL_ON_EDGE(blip: int, toggle: bool) -> None:
    _iv(0x2B6D467DAB714E8D, blip, toggle)

def END_TEXT_COMMAND_THEFEED_POST_STATS(statTitle: str, iconEnum: int, stepVal: bool, barValue: int, isImportant: bool, pictureTextureDict: str, pictureTextureName: str) -> int:
    return _ii(0x2B7E9A4EAAA93C89, statTitle, iconEnum, stepVal, barValue, isImportant, pictureTextureDict, pictureTextureName)

def GET_BLIP_FADE_DIRECTION(blip: int) -> int:
    return _ii(0x2C173AE2BDB9385E, blip)

def SET_BLIP_USE_HEIGHT_INDICATOR_ON_EDGE(blip: int, p1: int) -> None:
    _iv(0x2C9F302398E13141, blip, p1)

def CLEAR_SMALL_PRINTS() -> None:
    _iv(0x2CEA2839313C09AC)

def PAUSE_TOGGLE_FULLSCREEN_MAP(p0: int) -> None:
    _iv(0x2DE6C5E2E996F178, p0)

def HAS_MENU_LAYOUT_CHANGED_EVENT_OCCURRED() -> bool:
    return _ib(0x2E22FEFA0100275E)

def SET_BLIP_FLASHES_ALTERNATE(blip: int, toggle: bool) -> None:
    _iv(0x2E8D9498C56DD0D1, blip, toggle)

def END_TEXT_COMMAND_THEFEED_POST_TICKER(blink: bool, p1: bool) -> int:
    return _ii(0x2ED7843F8F801023, blink, p1)

def IS_STORE_PENDING_NETWORK_SHUTDOWN_TO_OPEN() -> bool:
    return _ib(0x2F057596F2BD0061)

def ADD_POINT_TO_GPS_CUSTOM_ROUTE(x: float, y: float, z: float) -> None:
    _iv(0x311438A071DD9B1A, x, y, z)

def SET_MP_GAMER_TAG_HEALTH_BAR_COLOUR(gamerTagId: int, hudColorIndex: int) -> None:
    _iv(0x3158C77A7E888AB4, gamerTagId, hudColorIndex)

def REMOVE_MP_GAMER_TAG(gamerTagId: int) -> None:
    _iv(0x31698AA80E0223F8, gamerTagId)

def THEFEED_UPDATE_ITEM_TEXTURE(txdString1: str, txnString1: str, txdString2: str, txnString2: str) -> None:
    _iv(0x317EBA71D7543F52, txdString1, txnString1, txdString2, txnString2)

def SET_GPS_FLASHES(toggle: bool) -> None:
    _iv(0x320D0E0D936A0E9B, toggle)

def IS_HELP_MESSAGE_FADING_OUT() -> bool:
    return _ib(0x327EDEEEAC55C369)

def THEFEED_HIDE() -> None:
    _iv(0x32888337579A5970)

def END_TEXT_COMMAND_THEFEED_POST_UNLOCK(gxtLabel1: str, p1: int, gxtLabel2: str) -> int:
    return _ii(0x33EE12743CCD6343, gxtLabel1, p1, gxtLabel2)

def PAUSE_MENU_GET_MOUSE_HOVER_INDEX() -> int:
    return _ii(0x359AF31A4B52F5ED)

def REMOVE_FAKE_CONE_DATA(blip: int) -> None:
    _iv(0x35A3CD97B2C0A6D2, blip)

def _SET_PAUSE_EXTERIOR_RENDERING_WHILE_IN_INTERIOR() -> None:
    _iv(0x35CCE12EAECB4A51)

def SET_MINIMAP_GOLF_COURSE_OFF() -> None:
    _iv(0x35EDD5B2E3FF01C0)

def GET_MENU_TRIGGER_EVENT_DETAILS(lastItemMenuId: int, selectedItemUniqueId: int) -> None:
    _iv(0x36C1451A88A09630, lastItemMenuId, selectedItemUniqueId)

def END_TEXT_COMMAND_THEFEED_POST_TICKER_WITH_TOKENS(blink: bool, p1: bool) -> int:
    return _ii(0x378E809BF61EC840, blink, p1)

def SET_WARNING_MESSAGE_WITH_HEADER_EXTENDED(entryHeader: str, entryLine1: str, flags: int, entryLine2: str, p4: bool, p5: int, p6: int, p7: int, showBg: bool, p9: int, p10: int) -> None:
    _iv(0x38B55259C2E078ED, entryHeader, entryLine1, flags, entryLine2, p4, p5, p6, p7, showBg, p9, p10)

def SET_COLOUR_OF_NEXT_TEXT_COMPONENT(hudColor: int) -> None:
    _iv(0x39BBF623FC803EAC, hudColor)

def IS_FRONTEND_READY_FOR_CONTROL() -> bool:
    return _ib(0x3BAB9A4E4F2FF5C7)

def SET_PAUSE_MENU_PED_LIGHTING(state: bool) -> None:
    _iv(0x3CA6050692BC61B0, state)

def START_GPS_MULTI_ROUTE(hudColor: int, routeFromPlayer: bool, displayOnFoot: bool) -> None:
    _iv(0x3D3D15AF7BCAAF83, hudColor, routeFromPlayer, displayOnFoot)

def IS_MOUSE_ROLLED_OVER_INSTRUCTIONAL_BUTTONS() -> bool:
    return _ib(0x3D9ACB1EB139E702)

def SET_GPS_MULTI_ROUTE_RENDER(toggle: bool) -> None:
    _iv(0x3DDA37128DD1ACA8, toggle)

def UNLOCK_MINIMAP_POSITION() -> None:
    _iv(0x3E93E06DB8EF1F30)

def SET_PED_AI_BLIP_HAS_CONE(ped: int, toggle: bool) -> None:
    _iv(0x3EED80DFF7325CAA, ped, toggle)

def GET_NORTH_BLID_INDEX() -> int:
    return _ii(0x3F0CF9CB7E589B88)

def SET_HEALTH_HUD_DISPLAY_VALUES(health: int, capacity: int, wasAdded: bool) -> None:
    _iv(0x3F5CC444DCAAA8F2, health, capacity, wasAdded)

def DISPLAY_HUD_WHEN_PAUSED_THIS_FRAME() -> None:
    _iv(0x402F9ED62087E898)

def SET_PM_WARNINGSCREEN_ACTIVE(p0: bool) -> None:
    _iv(0x41350B4FC28E3941, p0)

def IS_HOVERING_OVER_MISSION_CREATOR_BLIP() -> bool:
    return _ib(0x4167EFE0527D706E)

def GET_LENGTH_OF_LITERAL_STRING_IN_BYTES(string: str) -> int:
    return _ii(0x43E4111189E54F0E, string)

def SET_TEXT_EDGE(p0: int, r: int, g: int, b: int, a: int) -> None:
    _iv(0x441603240D202FA6, p0, r, g, b, a)

def PAUSE_MENU_DEACTIVATE_CONTEXT(contextHash: int) -> None:
    _iv(0x444D8CF241EC25C5, contextHash)

def END_TEXT_COMMAND_THEFEED_POST_TICKER_FORCED(blink: bool, p1: bool) -> int:
    return _ii(0x44FA03975424A0EE, blink, p1)

def RESET_HUD_COMPONENT_VALUES(id: int) -> None:
    _iv(0x450930E616475D0D, id)

def SET_BLIP_ALPHA(blip: int, alpha: int) -> None:
    _iv(0x45FF974EEE1C8734, blip, alpha)

def SET_TEXT_DROPSHADOW(distance: int, r: int, g: int, b: int, a: int) -> None:
    _iv(0x465C84BC39F1C351, distance, r, g, b, a)

def ADD_BLIP_FOR_RADIUS(posX: float, posY: float, posZ: float, radius: float) -> int:
    return _ii(0x46818D79B1F7499A, posX, posY, posZ, radius)

def HUD_FORCE_SPECIAL_VEHICLE_WEAPON_WHEEL() -> None:
    _iv(0x488043841BBE156F)

def PAUSE_MENU_REDRAW_INSTRUCTIONAL_BUTTONS(p0: int) -> None:
    _iv(0x4895BDEA16E7C080, p0)

def THEFEED_SET_VIBRATE_PARAMETER_FOR_NEXT_MESSAGE(toggle: bool) -> None:
    _iv(0x4A0C7C9BB10ABB36, toggle)

def GET_STANDARD_BLIP_ENUM_ID() -> int:
    return _ii(0x4A9923385BDB9DAD)

def HIDE_LOADING_ON_FADE_THIS_FRAME() -> None:
    _iv(0x4B0311D3CDC4648F)

def SET_BLIP_SHORT_HEIGHT_THRESHOLD(p0: int, p1: int) -> None:
    _iv(0x4B5B620C9B59ED34, p0, p1)

def GET_BLIP_INFO_ID_ENTITY_INDEX(blip: int) -> int:
    return _ii(0x4BA4E2553AFEDC2C, blip)

def IS_HELP_MESSAGE_BEING_DISPLAYED() -> bool:
    return _ib(0x4D79439A6B55AC67)

def SET_TEXT_JUSTIFICATION(justifyType: int) -> None:
    _iv(0x4E096588B13FFECA, justifyType)

def IS_NAVIGATING_MENU_CONTENT() -> bool:
    return _ib(0x4E3CD0EF8A489541)

def IS_MP_GAMER_TAG_ACTIVE(gamerTagId: int) -> bool:
    return _ib(0x4E929E7A5796FD26, gamerTagId)

def SHOW_SCRIPTED_HUD_COMPONENT_THIS_FRAME(id: int) -> None:
    _iv(0x4F38DCA127DAAEA2, id)

def SET_BLIP_ROUTE(blip: int, enabled: bool) -> None:
    _iv(0x4F7D8A9BFB0B43E9, blip, enabled)

def CLEAR_FLOATING_HELP(hudIndex: int, p1: bool) -> None:
    _iv(0x50085246ABD3FEFA, hudIndex, p1)

def SET_INSIDE_VERY_SMALL_INTERIOR(toggle: bool) -> None:
    _iv(0x504DFE62A1692296, toggle)

def BEGIN_TEXT_COMMAND_GET_NUMBER_OF_LINES_FOR_STRING(entry: str) -> None:
    _iv(0x521FB041D93DD0E4, entry)

def OPEN_REPORTUGC_MENU() -> None:
    _iv(0x523A590C1A3CC0D3)

def GET_DEFAULT_SCRIPT_RENDERTARGET_RENDER_ID() -> int:
    return _ii(0x52F0982D7FD156B6)

def END_TEXT_COMMAND_THEFEED_POST_MESSAGETEXT_WITH_CREW_TAG_AND_ADDITIONAL_ICON(txdName: str, textureName: str, flash: bool, iconType1: int, sender: str, subject: str, duration: float, clanTag: str, iconType2: int, p9: int) -> int:
    return _ii(0x531B84E7DA981FB6, txdName, textureName, flash, iconType1, sender, subject, duration, clanTag, iconType2, p9)

def HIDE_NUMBER_ON_BLIP(blip: int) -> None:
    _iv(0x532CFF637EF80148, blip)

def CUSTOM_MINIMAP_SET_ACTIVE(toggle: bool) -> None:
    _iv(0x5354C5BA2EA868A4, toggle)

def SET_BLIP_HIDDEN_ON_LEGEND(blip: int, toggle: bool) -> None:
    _iv(0x54318C915D27E4CE, blip, toggle)

def BEGIN_TEXT_COMMAND_GET_SCREEN_WIDTH_OF_DISPLAY_TEXT(text: str) -> None:
    _iv(0x54CE8AC98E120CAB, text)

def CUSTOM_MINIMAP_CREATE_BLIP(x: float, y: float, z: float) -> int:
    return _ii(0x551DF99658DB6EE8, x, y, z)

def THEFEED_SET_SCRIPTED_MENU_HEIGHT(pos: float) -> None:
    _iv(0x55598D21339CB998, pos)

def DONT_ZOOM_MINIMAP_WHEN_SNIPING_THIS_FRAME() -> None:
    _iv(0x55F5A5F07134DE60)

def GET_AI_PED_VEHICLE_BLIP_INDEX(ped: int) -> int:
    return _ii(0x56176892826A4FE8, ped)

def THEFEED_AUTO_POST_GAMETIPS_ON() -> None:
    _iv(0x56C8B608CFD49854)

def SET_ALLOW_COMMA_ON_TEXT_INPUT(p0: int) -> None:
    _iv(0x577599CCED639CA2, p0)

def FORCE_NEXT_MESSAGE_TO_PREVIOUS_BRIEFS_LIST(p0: int) -> None:
    _iv(0x57D760D55F54E071, p0)

def REGISTER_NAMED_RENDERTARGET(name: str, p1: bool) -> bool:
    return _ib(0x57D9C12635E25CE3, name, p1)

def THEFEED_FORCE_RENDER_OFF() -> None:
    _iv(0x583049884A2EEE3C)

def GET_BLIP_COORDS(blip: int) -> 'gta.Vector3':
    return _ivec(0x586AFE3FF72D996E, blip)

def SET_MINIMAP_BLOCK_WAYPOINT(toggle: bool) -> None:
    _iv(0x58FADDED207897DC, toggle)

def GET_SCREEN_CODE_WANTS_SCRIPT_TO_CONTROL() -> int:
    return _ii(0x593FEAE1F73392D4)

def IS_MP_GAMER_TAG_FREE(gamerTagId: int) -> bool:
    return _ib(0x595B5178E412E199, gamerTagId)

def SET_RADAR_AS_INTERIOR_THIS_FRAME(interior: int, x: float, y: float, z: int, zoom: int) -> None:
    _iv(0x59E727A1C9D3E31A, interior, x, y, z, zoom)

def ADD_BLIP_FOR_COORD(x: float, y: float, z: float) -> int:
    return _ii(0x5A039BB0BCA604B6, x, y, z)

def SET_GPS_FLAGS(p0: int, p1: float) -> None:
    _iv(0x5B440763A4C8D15B, p0, p1)

def GET_PAUSE_MENU_POSITION() -> 'gta.Vector3':
    return _ivec(0x5BFF36D6ED83E0AE)

def GET_NEW_SELECTED_MISSION_CREATOR_BLIP() -> int:
    return _ii(0x5C90988E7C8E1AF4)

def END_TEXT_COMMAND_THEFEED_POST_MESSAGETEXT_WITH_CREW_TAG(txdName: str, textureName: str, flash: bool, iconType: int, sender: str, subject: str, duration: float, clanTag: str) -> int:
    return _ii(0x5CBF7BADE20DB93E, txdName, textureName, flash, iconType, sender, subject, duration, clanTag)

def ADD_BLIP_FOR_ENTITY(entity: int) -> int:
    return _ii(0x5CDE92C702A8FCE7, entity)

def SET_USE_ISLAND_MAP(toggle: bool) -> None:
    _iv(0x5E1460624D194A38, toggle)

def CLEAR_PED_IN_PAUSE_MENU() -> None:
    _iv(0x5E62BE5DC58E9E06)

def SET_TEXT_RENDER_ID(renderId: int) -> None:
    _iv(0x5F15302936E07111, renderId)

def SET_MISSION_NAME(p0: bool, name: str) -> None:
    _iv(0x5F28ECF5FC84772F, p0, name)

def ADD_TEXT_COMPONENT_SUBSTRING_KEYBOARD_DISPLAY(string: str) -> None:
    _iv(0x5F68520888E69014, string)

def HIDE_MINIMAP_EXTERIOR_MAP_THIS_FRAME() -> None:
    _iv(0x5FBAE526203990C9)

def SHOW_HEADING_INDICATOR_ON_BLIP(blip: int, toggle: bool) -> None:
    _iv(0x5FBCA48327B914DF, blip, toggle)

def GET_MENU_PED_FLOAT_STAT(statHash: int, outValue: int) -> bool:
    return _ib(0x5FBD7095FE7AE57F, statHash, outValue)

def REQUEST_ADDITIONAL_TEXT_FOR_DLC(gxt: str, slot: int) -> None:
    _iv(0x6009F9F1AE90D8A6, gxt, slot)

def ADD_NEXT_MESSAGE_TO_PREVIOUS_BRIEFS(p0: bool) -> None:
    _iv(0x60296AF4BA14ABC5, p0)

def ALLOW_SONAR_BLIPS(toggle: bool) -> None:
    _iv(0x60734CC207C9833C, toggle)

def SHOW_ACCOUNT_PICKER() -> None:
    _iv(0x60E892BA4F5BDCA4)

def SET_MP_GAMER_TAG_COLOUR(gamerTagId: int, component: int, hudColorIndex: int) -> None:
    _iv(0x613ED644950626AE, gamerTagId, component, hudColorIndex)

def CLEAR_ALL_HELP_MESSAGES() -> None:
    _iv(0x6178F68A87A4D3A0)

def SET_MINIMAP_FOW_DO_NOT_UPDATE(p0: bool) -> None:
    _iv(0x62E849B7EB28E770, p0)

def SET_TEXT_WRAP(start: float, end: float) -> None:
    _iv(0x63145D9C883A1A70, start, end)

def GET_MOUSE_EVENT(scaleformHandle: int, p1: int, p2: int, p3: int) -> bool:
    return _ib(0x632B2940C67F4EA9, scaleformHandle, p1, p2, p3)

def SET_MP_GAMER_TAG_VISIBILITY(gamerTagId: int, component: int, toggle: bool, p3: int) -> None:
    _iv(0x63BB75ABEDC1F6A0, gamerTagId, component, toggle, p3)

def SET_TEXT_FONT(fontType: int) -> None:
    _iv(0x66E0276CC5F6B9DA, fontType)

def CODE_WANTS_SCRIPT_TO_TAKE_CONTROL() -> bool:
    return _ib(0x66E7CB63C97B7D20)

def CLEAR_GPS_MULTI_ROUTE() -> None:
    _iv(0x67EEDEA1B9BAFD94)

def HIDE_HUD_COMPONENT_THIS_FRAME(id: int) -> None:
    _iv(0x6806C51AD12B83B8, id)

def OVERRIDE_MP_TEXT_CHAT_TEAM_STRING(gxtEntryHash: int) -> None:
    _iv(0x6A1738B4323FE2D9, gxtEntryHash)

def TOGGLE_STEALTH_RADAR(toggle: bool) -> None:
    _iv(0x6AFDFB93754950C7, toggle)

def FLASH_MINIMAP_DISPLAY_WITH_COLOR(hudColorIndex: int) -> None:
    _iv(0x6B1DE27EE78E6A19, hudColorIndex)

def SET_TEXT_RIGHT_JUSTIFY(toggle: bool) -> None:
    _iv(0x6B3C4650BC8BEE47, toggle)

def SET_MINIMAP_SONAR_SWEEP(toggle: bool) -> None:
    _iv(0x6B50FC8749632EC1, toggle)

def ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text: str) -> None:
    _iv(0x6C188BE134E074AA, text)

def SET_USE_SET_DESTINATION_IN_PAUSE_MAP(toggle: bool) -> None:
    _iv(0x6CDD58146A436083, toggle)

def DONT_TILT_MINIMAP_THIS_FRAME() -> None:
    _iv(0x6D14BFDC33B34F55)

def DISABLE_FRONTEND_THIS_FRAME() -> None:
    _iv(0x6D3465A73092F0E6)

def CREATE_MP_GAMER_TAG_WITH_CREW_COLOR(player: int, username: str, pointedClanTag: bool, isRockstarClan: bool, clanTag: str, clanFlag: int, r: int, g: int, b: int) -> None:
    _iv(0x6DD05E9D83EFA4C9, player, username, pointedClanTag, isRockstarClan, clanTag, clanFlag, r, g, b)

def IS_MP_GAMER_TAG_MOVIE_ACTIVE() -> bool:
    return _ib(0x6E0EB3EB47C8D7AA)

def GET_MINIMAP_FOW_COORDINATE_IS_REVEALED(x: float, y: float, z: float) -> bool:
    return _ib(0x6E31B91145873922, x, y, z)

def REMOVE_WARNING_MESSAGE_OPTION_ITEMS() -> None:
    _iv(0x6EF54AB721DC6242)

def THEFEED_ONLY_SHOW_TOOLTIPS(toggle: bool) -> None:
    _iv(0x6F1554B0CC2089FA, toggle)

def SET_BLIP_AS_FRIENDLY(blip: int, toggle: bool) -> None:
    _iv(0x6F6F290102C02AB4, blip, toggle)

def IS_ONLINE_POLICIES_MENU_ACTIVE() -> bool:
    return _ib(0x6F72CD94F7B5B68C)

def SET_WARNING_MESSAGE_WITH_HEADER_AND_SUBSTRING_FLAGS(entryHeader: str, entryLine1: str, instructionalKey: int, entryLine2: str, p4: bool, p5: int, additionalIntInfo: int, additionalTextInfoLine1: str, additionalTextInfoLine2: str, showBackground: bool, errorCode: int) -> None:
    _iv(0x701919482C74B5AB, entryHeader, entryLine1, instructionalKey, entryLine2, p4, p5, additionalIntInfo, additionalTextInfoLine1, additionalTextInfoLine2, showBackground, errorCode)

def HIDE_HUD_AND_RADAR_THIS_FRAME() -> None:
    _iv(0x719FF505F097FD20)

def REQUEST_ADDITIONAL_TEXT(gxt: str, slot: int) -> None:
    _iv(0x71A78003C8E71424, gxt, slot)

def SET_MINIMAP_GOLF_COURSE(hole: int) -> None:
    _iv(0x71BDB63DBAF8DA59, hole)

def GET_BLIP_HUD_COLOUR(blip: int) -> int:
    return _ii(0x729B5F1EFBC0AAEE, blip)

def HUD_SET_WEAPON_WHEEL_TOP_SLOT(weaponHash: int) -> None:
    _iv(0x72C1056D678BB7D8, weaponHash)

def TRIGGER_SONAR_BLIP(posX: float, posY: float, posZ: float, radius: float, p4: int) -> None:
    _iv(0x72DD432F3CDFC0EE, posX, posY, posZ, radius, p4)

def DISPLAY_SNIPER_SCOPE_THIS_FRAME() -> None:
    _iv(0x73115226F4814E62)

def PULSE_BLIP(blip: int) -> None:
    _iv(0x742D6FD43115AF73, blip)

def SHOW_TICK_ON_BLIP(blip: int, toggle: bool) -> None:
    _iv(0x74513EA3E505181E, blip, toggle)

def SET_FRONTEND_ACTIVE(active: bool) -> None:
    _iv(0x745711A75AB09277, active)

def SHOW_HEIGHT_ON_BLIP(blip: int, toggle: bool) -> None:
    _iv(0x75A16C3DA34F1245, blip, toggle)

def SET_MINIMAP_COMPONENT(componentId: int, toggle: bool, overrideColor: int) -> bool:
    return _ib(0x75A9A10948D1DEA6, componentId, toggle, overrideColor)

def OPEN_SOCIAL_CLUB_MENU(menu: int) -> None:
    _iv(0x75D3691713C3B05A, menu)

def ADD_TEXT_COMPONENT_SUBSTRING_PHONE_NUMBER(p0: str, p1: int) -> None:
    _iv(0x761B77454205A61D, p0, p1)

def DISPLAY_HUD_WHEN_NOT_IN_STATE_OF_PLAY_THIS_FRAME() -> None:
    _iv(0x7669F9E39DC17063)

def SET_FLOATING_HELP_TEXT_SCREEN_POSITION(hudIndex: int, x: float, y: float) -> None:
    _iv(0x7679CC1BCEBE3D4C, hudIndex, x, y)

def CLEAR_DYNAMIC_PAUSE_MENU_ERROR_MESSAGE() -> None:
    _iv(0x7792424AA0EAC32E)

def SET_FAKE_PAUSEMAP_PLAYER_POSITION_THIS_FRAME(x: float, y: float) -> None:
    _iv(0x77E2DD177910E1CF, x, y)

def PAUSE_MENUCEPTION_GO_DEEPER(page: int) -> None:
    _iv(0x77F16B447824DA6C, page)

def SET_FLOATING_HELP_TEXT_WORLD_POSITION(hudIndex: int, x: float, y: float, z: float) -> None:
    _iv(0x784BA7E0ECEB4178, hudIndex, x, y, z)

def SET_FLOATING_HELP_TEXT_STYLE(hudIndex: int, p1: int, p2: int, p3: int, p4: int, p5: int) -> None:
    _iv(0x788E7FD431BD67F1, hudIndex, p1, p2, p3, p4, p5)

def IS_NAMED_RENDERTARGET_REGISTERED(name: str) -> bool:
    return _ib(0x78DCDC15C9F116B4, name)

def IS_MESSAGE_BEING_DISPLAYED() -> bool:
    return _ib(0x7984C03AA5CC2F41)

def CLEAR_GPS_RACE_TRACK() -> None:
    _iv(0x7AA5B4CE533C858B)

def END_TEXT_COMMAND_THEFEED_POST_UNLOCK_TU_WITH_COLOR(p0: int, p1: int, p2: int, p3: int, p4: int, p5: int) -> int:
    return _ii(0x7AE0589093A2E088, p0, p1, p2, p3, p4, p5)

def SET_WARNING_MESSAGE(titleMsg: str, flags: int, promptMsg: str, p3: bool, p4: int, p5: str, p6: str, showBackground: bool, errorCode: int) -> None:
    _iv(0x7B1776B3B53F8D74, titleMsg, flags, promptMsg, p3, p4, p5, p6, showBackground, errorCode)

def SET_PLAYER_ICON_COLOUR(color: int) -> None:
    _iv(0x7B21E0BB01E8224A, color)

def GET_FILENAME_FOR_AUDIO_CONVERSATION(labelName: str) -> str:
    return _is(0x7B5280EBA9840C72, labelName)

def SET_MP_GAMER_TAG_BIG_TEXT(gamerTagId: int, string: str) -> None:
    _iv(0x7B7723747CCB55B6, gamerTagId, string)

def MP_TEXT_CHAT_IS_TEAM_JOB(p0: int) -> None:
    _iv(0x7C226D5346D4D10A, p0)

def GET_HUD_COLOUR(hudColorIndex: int, r: int, g: int, b: int, a: int) -> None:
    _iv(0x7C9C91AB74A0360F, hudColorIndex, r, g, b, a)

def GET_AI_PED_PED_BLIP_INDEX(ped: int) -> int:
    return _ii(0x7CD934010E115C2C, ped)

def GET_MENU_LAYOUT_CHANGED_EVENT_DETAILS(lastItemMenuId: int, selectedItemMenuId: int, selectedItemUniqueId: int) -> None:
    _iv(0x7E17BE53E1AAABAF, lastItemMenuId, selectedItemMenuId, selectedItemUniqueId)

def SET_INSIDE_VERY_LARGE_INTERIOR(toggle: bool) -> None:
    _iv(0x7EC8ABA5E74B3D7A, toggle)

def IS_IME_IN_PROGRESS() -> bool:
    return _ib(0x801879A9B4F4B2FB)

def GET_LENGTH_OF_STRING_WITH_THIS_TEXT_LABEL(gxt: str) -> int:
    return _ii(0x801BD273D3A23F74, gxt)

def OPEN_ONLINE_POLICIES_MENU() -> None:
    _iv(0x805D7CBB36FD6C4C)

def SET_PLAYER_IS_IN_DIRECTOR_MODE(toggle: bool) -> None:
    _iv(0x808519373FD336A3, toggle)

def ADD_TEXT_COMPONENT_SUBSTRING_BLIP_NAME(blip: int) -> None:
    _iv(0x80EAD8E2E1D5D52E, blip)

def THEFEED_CLEAR_FROZEN_POST() -> None:
    _iv(0x80FE4F3AB4E1B62A)

def SET_DESCRIPTION_FOR_UGC_MISSION_EIGHT_STRINGS(p0: bool, p1: str, p2: str, p3: str, p4: str, p5: str, p6: str, p7: str, p8: str) -> None:
    _iv(0x817B86108EB94E51, p0, p1, p2, p3, p4, p5, p6, p7, p8)

def UNLOCK_MINIMAP_ANGLE() -> None:
    _iv(0x8183455E16C42E3A)

def GET_WARNING_SCREEN_MESSAGE_HASH() -> int:
    return _ii(0x81DF9ABA6C83DFF9)

def REFRESH_WAYPOINT() -> None:
    _iv(0x81FA173F170560D1)

def THEFEED_GET_LAST_SHOWN_PHONE_ACTIVATABLE_FEED_ID() -> int:
    return _ii(0x82352748437638CA)

def DISPLAY_PLAYER_NAME_TAGS_ON_BLIPS(toggle: bool) -> None:
    _iv(0x82CEDC33687E1F50, toggle)

def SET_BLIP_ROUTE_COLOUR(blip: int, colour: int) -> None:
    _iv(0x837155CD2F63DA09, blip, colour)

def CLEAR_FAKE_CONE_ARRAY() -> None:
    _iv(0x8410C5E0CD847B9D)

def PAUSE_MENU_IS_CONTEXT_ACTIVE(contextHash: int) -> bool:
    return _ib(0x84698AB38D0C6636, contextHash)

def BEGIN_TEXT_COMMAND_DISPLAY_HELP(inputType: str) -> None:
    _iv(0x8509B634FBE7DA11, inputType)

def BEGIN_TEXT_COMMAND_IS_MESSAGE_DISPLAYED(text: str) -> None:
    _iv(0x853648FD1063A213, text)

def END_TEXT_COMMAND_GET_SCREEN_WIDTH_OF_DISPLAY_TEXT(p0: bool) -> float:
    return _if(0x85F061DA64ED2F67, p0)

def REMOVE_BLIP(blip: int) -> None:
    _iv(0x86A652570E5F25DD, blip)

def FORCE_CLOSE_TEXT_INPUT_BOX() -> None:
    _iv(0x8817605C2BA76200)

def SET_ALLOW_ABILITY_BAR(toggle: bool) -> None:
    _iv(0x889329C80FE5963C, toggle)

def DONT_ZOOM_MINIMAP_WHEN_RUNNING_THIS_FRAME() -> None:
    _iv(0x89DA85D949CE57A0)

def END_TEXT_COMMAND_IS_MESSAGE_DISPLAYED() -> bool:
    return _ib(0x8A9BA1AB3E237613)

def IS_STREAMING_ADDITIONAL_TEXT(p0: int) -> bool:
    return _ib(0x8B6817B71B85EBF0, p0)

def SET_MOUSE_CURSOR_STYLE(spriteId: int) -> None:
    _iv(0x8DB8CFFD58B62552, spriteId)

def CLEAR_HELP(toggle: bool) -> None:
    _iv(0x8DFCED7A656F8802, toggle)

def END_TEXT_COMMAND_THEFEED_POST_CREW_RANKUP_WITH_LITERAL_FLAG(p0: str, p1: str, p2: str, p3: bool, p4: bool) -> int:
    return _ii(0x8EFCCF6EC66D85E4, p0, p1, p2, p3, p4)

def GET_CHARACTER_MENU_PED_FLOAT_STAT(statHash: float, outValue: int, p2: bool) -> bool:
    return _ib(0x8F08017F9D7C47BD, statHash, outValue, p2)

def BEGIN_TEXT_COMMAND_OVERRIDE_BUTTON_TEXT(gxtEntry: str) -> None:
    _iv(0x8F9EE5687F8EECCD, gxtEntry)

def SET_GPS_CUSTOM_ROUTE_RENDER(toggle: bool, radarThickness: int, mapThickness: int) -> None:
    _iv(0x900086F371220B6F, toggle, radarThickness, mapThickness)

def SET_BLIP_DISPLAY(blip: int, displayId: int) -> None:
    _iv(0x9029B2F3DA924928, blip, displayId)

def END_TEXT_COMMAND_GET_NUMBER_OF_LINES_FOR_STRING(x: float, y: float) -> int:
    return _ii(0x9040DFB09BE75706, x, y)

def IS_PAUSEMAP_IN_INTERIOR_MODE() -> bool:
    return _ib(0x9049FE339D5F6F6F)

def GET_MENU_PED_MASKED_INT_STAT(statHash: int, outValue: int, mask: int, p3: bool) -> bool:
    return _ib(0x90A6526CF0381030, statHash, outValue, mask, p3)

def SET_MINIMAP_IN_PROLOGUE(toggle: bool) -> None:
    _iv(0x9133955F1A2DA957, toggle)

def IS_REPORTUGC_MENU_OPEN() -> bool:
    return _ib(0x9135584D09A3437E)

def DISABLE_PAUSEMENU_SPINNER(p0: bool) -> None:
    _iv(0x9245E81072704B8A, p0)

def THEFEED_SET_BACKGROUND_COLOR_FOR_NEXT_POST(hudColorIndex: int) -> None:
    _iv(0x92F0DA1E27DB96DC, hudColorIndex)

def ADD_TEXT_COMPONENT_SUBSTRING_WEBSITE(website: str) -> None:
    _iv(0x94CF4AC034C9C986, website)

def REMOVE_MULTIPLAYER_WALLET_CASH() -> None:
    _iv(0x95CF81BD06EE1887)

def DISPLAY_HELP_TEXT_THIS_FRAME(message: str, p1: bool) -> None:
    _iv(0x960C9FF8F616E41C, message, p1)

def REMOVE_MULTIPLAYER_HUD_CASH() -> None:
    _iv(0x968F270E39141ECA)

def DISPLAY_CASH(toggle: bool) -> None:
    _iv(0x96DEC8D5430208B7, toggle)

def GET_BLIP_ALPHA(blip: int) -> int:
    return _ii(0x970F608F0EE6C885, blip)

def SET_MAX_HEALTH_HUD_DISPLAY(maximumValue: int) -> None:
    _iv(0x975D66A0BC17064C, maximumValue)

def SET_PED_AI_BLIP_NOTICE_RANGE(ped: int, range: float) -> None:
    _iv(0x97C65887D4B37FA9, ped, range)

def END_TEXT_COMMAND_THEFEED_POST_CREWTAG(p0: bool, p1: bool, p2: int, p3: int, isLeader: bool, unk0: bool, clanDesc: int, R: int, G: int, B: int) -> int:
    return _ii(0x97C9E4E7024A8F2C, p0, p1, p2, p3, isLeader, unk0, clanDesc, R, G, B)

def GET_CURRENT_WEBSITE_ID() -> int:
    return _ii(0x97D47996FC48CBAD)

def SET_MOUSE_CURSOR_VISIBLE(toggle: bool) -> None:
    _iv(0x98215325A695E78A, toggle)

def GET_FIRST_N_CHARACTERS_OF_LITERAL_STRING(string: str, length: int) -> str:
    return _is(0x98C3CF913D895111, string, length)

def SET_ABILITY_BAR_VALUE(p0: float, p1: float) -> None:
    _iv(0x9969599CCFF5D85E, p0, p1)

def GET_NUMBER_OF_ACTIVE_BLIPS() -> int:
    return _ii(0x9A3FF3DE163034E8)

def GET_BLIP_INFO_ID_PICKUP_INDEX(blip: int) -> int:
    return _ii(0x9B6786E4C03DD382, blip)

def SET_MP_GAMER_TAG_NUM_PACKAGES(gamerTagId: int, p1: int) -> None:
    _iv(0x9C16459B2324B2CF, gamerTagId, p1)

def CLEAR_BRIEF() -> None:
    _iv(0x9D292F73ADBD9313)

def END_TEXT_COMMAND_PRINT(duration: int, drawImmediately: bool) -> None:
    _iv(0x9D77056A530643F6, duration, drawImmediately)

def SET_SOCIAL_CLUB_TOUR(name: str) -> None:
    _iv(0x9E778248D6685FE0, name)

def IS_RADAR_PREFERENCE_SWITCHED_ON() -> bool:
    return _ib(0x9EB6522EA68F22FE)

def SET_TEXT_LINE_HEIGHT_MULT(lineHeightMult: float) -> None:
    _iv(0x9F4624F76E6953D1, lineHeightMult)

def SET_COP_BLIP_SPRITE(p0: int, p1: float) -> None:
    _iv(0x9FCB3CBFB3EAD69A, p0, p1)

def DISPLAY_RADAR(toggle: bool) -> None:
    _iv(0xA0EBB943C300E693, toggle)

def THEFEED_FORCE_RENDER_ON() -> None:
    _iv(0xA13C11E1B5C06BFC)

def HUD_GET_WEAPON_WHEEL_TOP_SLOT(weaponTypeIndex: int) -> int:
    return _ii(0xA13E93403F26C812, weaponTypeIndex)

def SET_FAKE_GPS_PLAYER_POSITION_THIS_FRAME(x: float, y: float, z: float) -> None:
    _iv(0xA17784FCA9548D15, x, y, z)

def FLASH_WANTED_DISPLAY(p0: bool) -> None:
    _iv(0xA18AFB39081B6A1F, p0)

def GET_PM_PLAYER_CREW_COLOR(r: int, g: int, b: int) -> bool:
    return _ib(0xA238192F33110615, r, g, b)

def HAS_DIRECTOR_MODE_BEEN_LAUNCHED_BY_CODE() -> bool:
    return _ib(0xA277800A9EAE340E)

def SHOW_NUMBER_ON_BLIP(blip: int, number: int) -> None:
    _iv(0xA3C0B359DCB848B6, blip, number)

def HUD_GET_WEAPON_WHEEL_CURRENTLY_HIGHLIGHTED() -> int:
    return _ii(0xA48931185F0536FE)

def HIDE_STREET_AND_CAR_NAMES_THIS_FRAME() -> None:
    _iv(0xA4DEDE28B1814289)

def SET_TEXT_LEADING(p0: int) -> None:
    _iv(0xA50ABC31E3CDFAFF, p0)

def IS_BLIP_FLASHING(blip: int) -> bool:
    return _ib(0xA5E41FD83AD6CEF0, blip)

def DISPLAY_AMMO_THIS_FRAME(display: bool) -> None:
    _iv(0xA5E78BA2B1331C55, display)

def DISPLAY_HUD(toggle: bool) -> None:
    _iv(0xA6294919E56FF02A, toggle)

def SET_MP_GAMER_TAGS_SHOULD_USE_VEHICLE_HEALTH(gamerTagId: int, toggle: bool) -> None:
    _iv(0xA67F9C46D612B6F1, gamerTagId, toggle)

def DOES_BLIP_EXIST(blip: int) -> bool:
    return _ib(0xA6DB27D19ECBB7DA, blip)

def SET_WAYPOINT_OFF() -> None:
    _iv(0xA7E4E2D361C2627F)

def IS_HUD_HIDDEN() -> bool:
    return _ib(0xA86478C6958735C5)

def END_TEXT_COMMAND_OVERRIDE_BUTTON_TEXT(p0: int) -> None:
    _iv(0xA86911979638106F, p0)

def SET_BLIP_ROTATION_WITH_FLOAT(blip: int, heading: float) -> None:
    _iv(0xA8B6AFDAC320AC87, blip, heading)

def THEFEED_FLUSH_QUEUE() -> None:
    _iv(0xA8FDB297A8D25FBA)

def ADD_POINT_TO_GPS_MULTI_ROUTE(x: float, y: float, z: float) -> None:
    _iv(0xA905192A6781C41B, x, y, z)

def THEFEED_IS_PAUSED() -> bool:
    return _ib(0xA9CBFD40B3FA3010)

def END_TEXT_COMMAND_THEFEED_POST_AWARD(textureDict: str, textureName: str, rpBonus: int, colorOverlay: int, titleLabel: str) -> int:
    return _ii(0xAA295B6F28BD587D, textureDict, textureName, rpBonus, colorOverlay, titleLabel)

def SET_BLIP_FLASH_INTERVAL(blip: int, p1: int) -> None:
    _iv(0xAA51DB313C010A7E, blip, p1)

def SET_HUD_COMPONENT_POSITION(id: int, x: float, y: float) -> None:
    _iv(0xAABB1F56E2A17CED, id, x, y)

def SET_MOUSE_CURSOR_THIS_FRAME() -> None:
    _iv(0xAAE7CE1D63167423)

def BEGIN_TEXT_COMMAND_BUSYSPINNER_ON(string: str) -> None:
    _iv(0xABA17D7CE615ADBF, string)

def DOES_TEXT_LABEL_EXIST(gxt: str) -> bool:
    return _ib(0xAC09CA973C564252, gxt)

def GIVE_PED_TO_PAUSE_MENU(ped: int, p1: int) -> None:
    _iv(0xAC0BFBDC3BE00E14, ped, p1)

def IS_SUBTITLE_PREFERENCE_SWITCHED_ON() -> bool:
    return _ib(0xAD6DACA4BA53E0A4)

def HAS_THIS_ADDITIONAL_TEXT_LOADED(gxt: str, slot: int) -> bool:
    return _ib(0xADBF060E2B30C5BC, gxt, slot)

def THEFEED_AUTO_POST_GAMETIPS_OFF() -> None:
    _iv(0xADED7F5748ACAFE6)

def SET_BLIP_COORDS(blip: int, posX: float, posY: float, posZ: float) -> None:
    _iv(0xAE2AF67E9D9AF65D, blip, posX, posY, posZ)

def SET_BLIP_PRIORITY(blip: int, priority: int) -> None:
    _iv(0xAE9FC9EF6A9FAC79, blip, priority)

def IS_WARNING_MESSAGE_READY_FOR_CONTROL() -> bool:
    return _ib(0xAF42195A42C63BBA)

def IS_MINIMAP_RENDERING() -> bool:
    return _ib(0xAF754F20EB5CD51A)

def IS_PAUSE_MENU_ACTIVE() -> bool:
    return _ib(0xB0034A223497FFCB)

def SET_FLOATING_HELP_TEXT_TO_ENTITY(hudIndex: int, entity: int, offsetX: float, offsetY: float) -> None:
    _iv(0xB094BC1DB4018240, hudIndex, entity, offsetX, offsetY)

def SET_MINIMAP_BACKGROUND_HIDDEN(toggle: bool) -> None:
    _iv(0xB09D42557C45EBA1, toggle)

def IS_MP_TEXT_CHAT_TYPING() -> bool:
    return _ib(0xB118AF58B5F332A1)

def SET_PED_HAS_AI_BLIP_WITH_COLOUR(ped: int, hasCone: bool, color: int) -> None:
    _iv(0xB13DCB4C6FAAD238, ped, hasCone, color)

def SET_BLIP_FLASHES(blip: int, toggle: bool) -> None:
    _iv(0xB14552383D39CE3E, blip, toggle)

def SET_BLIP_BRIGHT(blip: int, toggle: bool) -> None:
    _iv(0xB203913733F27884, blip, toggle)

def GET_CHARACTER_FROM_AUDIO_CONVERSATION_FILENAME_WITH_BYTE_LIMIT(text: str, position: int, length: int, maxLength: int) -> str:
    return _is(0xB2798643312205C5, text, position, length, maxLength)

def BUSYSPINNER_IS_DISPLAYING() -> bool:
    return _ib(0xB2A592B04648A9CB)

def SET_BLIP_MARKER_LONG_DISTANCE(p0: int, p1: int) -> None:
    _iv(0xB552929B85FC27EC, p0, p1)

def CLEAR_REMINDER_MESSAGE() -> None:
    _iv(0xB57D8DD645CFA2CF)

def END_TEXT_COMMAND_THEFEED_POST_VERSUS_TU(txdName1: str, textureName1: str, count1: int, txdName2: str, textureName2: str, count2: int, hudColor1: int, hudColor2: int) -> int:
    return _ii(0xB6871B0555B02996, txdName1, textureName1, count1, txdName2, textureName2, count2, hudColor1, hudColor2)

def THEFEED_REPORT_LOGO_OFF() -> None:
    _iv(0xB695E2CD0A2DA9EE)

def SET_COP_BLIP_SPRITE_AS_STANDARD() -> None:
    _iv(0xB7B873520C84C118)

def SHOW_OUTLINE_INDICATOR_ON_BLIP(blip: int, toggle: bool) -> None:
    _iv(0xB81656BC81FE24D1, blip, toggle)

def BEGIN_TEXT_COMMAND_PRINT(GxtEntry: str) -> None:
    _iv(0xB87A37EEB7FAA67D, GxtEntry)

def RESET_GLOBAL_ACTIONSCRIPT_FLAG(flagIndex: int) -> None:
    _iv(0xB99C4E4D9499DF29, flagIndex)

def SET_HELP_MESSAGE_STYLE(style: int, hudColor: int, alpha: int, p3: int, p4: int) -> None:
    _iv(0xB9C362BABECDDC7A, style, hudColor, alpha, p3, p4)

def SUPPRESS_FRONTEND_RENDERING_THIS_FRAME() -> None:
    _iv(0xBA751764F0821256)

def FORCE_OFF_WANTED_STAR_FLASH(toggle: bool) -> None:
    _iv(0xBA8D65C1C65702E5, toggle)

def THEFEED_SET_SNAP_FEED_ITEM_POSITIONS(p0: bool) -> None:
    _iv(0xBAE4F9B97CD43B30, p0)

def END_TEXT_COMMAND_SET_BLIP_NAME(blip: int) -> None:
    _iv(0xBC38B49BCB83BC9B, blip)

def IS_HUD_COMPONENT_ACTIVE(id: int) -> bool:
    return _ib(0xBC4C9EA5391ECC0D, id)

def GET_BLIP_FROM_ENTITY(entity: int) -> int:
    return _ii(0xBC8DBDCA2436F7E8, entity)

def SET_RADAR_ZOOM_PRECISE(zoom: float) -> None:
    _iv(0xBD12C5EEE184C337, zoom)

def END_TEXT_COMMAND_BUSYSPINNER_ON(busySpinnerType: int) -> None:
    _iv(0xBD12F8228410D9B4, busySpinnerType)

def ADD_BLIP_FOR_PICKUP(pickup: int) -> int:
    return _ii(0xBE339365C863BD36, pickup)

def THEFEED_REMOVE_ITEM(notificationId: int) -> None:
    _iv(0xBE4390CB40B3E627, notificationId)

def SET_TEXT_COLOUR(red: int, green: int, blue: int, alpha: int) -> None:
    _iv(0xBE6B23FFA53FB442, red, green, blue, alpha)

def SET_BLIP_AS_SHORT_RANGE(blip: int, toggle: bool) -> None:
    _iv(0xBE8BE4FE60E27B72, blip, toggle)

def GET_BLIP_INFO_ID_TYPE(blip: int) -> int:
    return _ii(0xBE9B0959FFD0779B, blip)

def DRAW_HUD_OVER_FADE_THIS_FRAME() -> None:
    _iv(0xBF4F34A85CA2970C)

def CREATE_FAKE_MP_GAMER_TAG(ped: int, username: str, pointedClanTag: bool, isRockstarClan: bool, clanTag: str, clanFlag: int) -> int:
    return _ii(0xBFEFE3321A3F5015, ped, username, pointedClanTag, isRockstarClan, clanTag, clanFlag)

def SET_TEXT_CENTRE(align: bool) -> None:
    _iv(0xC02F4DBFB51D988B, align)

def SET_MULTIPLAYER_WALLET_CASH() -> None:
    _iv(0xC2D15BEF167E27BC)

def GET_FAKE_SPECTATOR_MODE() -> bool:
    return _ib(0xC2D2AD9EAAE265B8)

def SET_WIDESCREEN_FORMAT(p0: int) -> None:
    _iv(0xC3B07BA00A83B0F1, p0)

def IS_SOCIAL_CLUB_ACTIVE() -> bool:
    return _ib(0xC406BE343FC4B9AF)

def SET_BLIP_EXTENDED_HEIGHT_THRESHOLD(blip: int, toggle: bool) -> None:
    _iv(0xC4278F70131BAA6D, blip, toggle)

def REMOVE_COP_BLIP_FROM_PED(ped: int) -> None:
    _iv(0xC594B315EDF2D4AF, ped)

def ADD_TEXT_COMPONENT_SUBSTRING_TEXT_LABEL(labelName: str) -> None:
    _iv(0xC63CD5D2920ACBE7, labelName)

def PRELOAD_BUSYSPINNER() -> None:
    _iv(0xC65AB383CD91DF98)

def END_TEXT_COMMAND_THEFEED_POST_MESSAGETEXT_SUBTITLE_LABEL(txdName: str, textureName: str, flash: bool, iconType: int, sender: str, subject: str) -> int:
    return _ii(0xC6F580E4C94926AC, txdName, textureName, flash, iconType, sender, subject)

def SHOW_CONTACT_INSTRUCTIONAL_BUTTON(toggle: bool) -> None:
    _iv(0xC772A904CDE1186F, toggle)

def PAUSE_MENU_SET_BUSY_SPINNER(p0: bool, position: int, spinnerIndex: int) -> None:
    _iv(0xC78E239AC5B2DDB9, p0, position, spinnerIndex)

def REMOVE_MULTIPLAYER_BANK_CASH() -> None:
    _iv(0xC7C6789AA1CFEDD0)

def PAUSE_MENU_GET_MOUSE_CLICK_EVENT(p0: int, p1: int, p2: int) -> bool:
    return _ib(0xC8E1071177A23BE5, p0, p1, p2)

def END_TEXT_COMMAND_THEFEED_POST_UNLOCK_TU(gxtLabel1: str, p1: int, gxtLabel2: str, p3: int) -> int:
    return _ii(0xC8F3AAF93D0600BF, gxtLabel1, p1, gxtLabel2, p3)

def GET_CHARACTER_MENU_PED_INT_STAT(p0: int, p1: int, p2: int) -> bool:
    return _ib(0xCA6B2F7CE32AB653, p0, p1, p2)

def SHOW_GOLD_TICK_ON_BLIP(blip: int, toggle: bool) -> None:
    _iv(0xCAC2031EBF79B1A8, blip, toggle)

def SET_RADAR_ZOOM_TO_DISTANCE(zoom: float) -> None:
    _iv(0xCB7CC0D58405AD41, zoom)

def CLEAR_PRINTS() -> None:
    _iv(0xCC33FA791322B9D9)

def ALLOW_PAUSE_WHEN_NOT_IN_STATE_OF_PLAY_THIS_FRAME() -> None:
    _iv(0xCC3FDDED67BCFC63)

def END_TEXT_COMMAND_DISPLAY_TEXT(x: float, y: float, p2: int) -> None:
    _iv(0xCD015E5BB0D96A57, x, y, p2)

def SET_BLIP_SCALE_2D(blip: int, xScale: float, yScale: float) -> None:
    _iv(0xCD6524439909C979, blip, xScale, yScale)

def SET_FAKE_SPECTATOR_MODE(toggle: bool) -> None:
    _iv(0xCD74233600C4EA6B, toggle)

def PAUSE_MENUCEPTION_THE_KICK() -> None:
    _iv(0xCDCA26E80FAECB8F)

def ADD_BLIP_FOR_AREA(x: float, y: float, z: float, width: float, height: float) -> int:
    return _ii(0xCE5D0E5E315DB238, x, y, z, width, height)

def GET_CHARACTER_FROM_AUDIO_CONVERSATION_FILENAME_BYTES(text: str, startPosition: int, endPosition: int) -> str:
    return _is(0xCE94AEBA5D82908A, text, startPosition, endPosition)

def FLAG_PLAYER_CONTEXT_IN_TOURNAMENT(toggle: bool) -> None:
    _iv(0xCEF214315D276FD1, toggle)

def SET_MP_GAMER_TAG_WANTED_LEVEL(gamerTagId: int, wantedlvl: int) -> None:
    _iv(0xCF228E2AA03099C3, gamerTagId, wantedlvl)

def CLEAR_THIS_PRINT(p0: str) -> None:
    _iv(0xCF708001E1E536DD, p0)

def END_TEXT_COMMAND_ADD_DIRECTLY_TO_PREVIOUS_BRIEFS(p0: bool) -> None:
    _iv(0xCFDBDF5AE59BA0F4, p0)

def GET_STREET_NAME_FROM_HASH_KEY(hash: int) -> str:
    return _is(0xD0EF8A959B8A4CB9, hash)

def CLEAR_ALL_BLIP_ROUTES() -> None:
    _iv(0xD12882D3FF82BF11)

def SET_BLOCK_WANTED_FLASH(disabled: bool) -> None:
    _iv(0xD1942374085C8469, disabled)

def SET_FAKE_MINIMAP_MAX_ALTIMETER_HEIGHT(altitude: float, p1: bool, p2: int) -> None:
    _iv(0xD201F3FF917A506D, altitude, p1, p2)

def END_TEXT_COMMAND_THEFEED_POST_REPLAY(type: int, image: int, text: str) -> int:
    return _ii(0xD202B92CBF1D816F, type, image, text)

def UPDATE_RADAR_ZOOM_TO_BLIP() -> None:
    _iv(0xD2049635DEB9C375)

def SET_MP_GAMER_TAGS_SHOULD_USE_POINTS_HEALTH(gamerTagId: int, toggle: bool) -> None:
    _iv(0xD29EC58C2F6B5014, gamerTagId, toggle)

def CLOSE_SOCIAL_CLUB_MENU() -> None:
    _iv(0xD2B32BE3FC1626C6)

def SET_PED_HAS_AI_BLIP(ped: int, hasCone: bool) -> None:
    _iv(0xD30C50DF888D58B5, ped, hasCone)

def SET_BLIP_SCALE(blip: int, scale: float) -> None:
    _iv(0xD38744167B2FA257, blip, scale)

def SET_BLIP_FLASH_TIMER(blip: int, duration: int) -> None:
    _iv(0xD3CD6FD297AE87CC, blip, duration)

def BUSYSPINNER_IS_ON() -> bool:
    return _ib(0xD422FCC5F239A915)

def THEFEED_REPORT_LOGO_ON() -> None:
    _iv(0xD4438C0564490E63)

def HIDE_HELP_TEXT_THIS_FRAME() -> None:
    _iv(0xD46923FC481CA285)

def GET_CLOSEST_BLIP_INFO_ID(blipSprite: int) -> int:
    return _ii(0xD484BF71050CA1EE, blipSprite)

def SET_MP_GAMER_TAG_ALPHA(gamerTagId: int, component: int, alpha: int) -> None:
    _iv(0xD48FE545CD46F857, gamerTagId, component, alpha)

def SET_SCRIPT_VARIABLE_HUD_COLOUR(r: int, g: int, b: int, a: int) -> None:
    _iv(0xD68A5FF8A3A89874, r, g, b, a)

def DELETE_WAYPOINTS_FROM_THIS_PLAYER() -> None:
    _iv(0xD8E694757BCEA8E9)

def IS_BLIP_SHORT_RANGE(blip: int) -> bool:
    return _ib(0xDA5F8727EB75B926, blip)

def IS_HELP_MESSAGE_ON_SCREEN() -> bool:
    return _ib(0xDAD37F45428801AE)

def SET_WARNING_MESSAGE_OPTION_HIGHLIGHT(p0: int) -> bool:
    return _ib(0xDAF87174BE7454FF, p0)

def START_GPS_CUSTOM_ROUTE(hudColor: int, displayOnFoot: bool, followPlayer: bool) -> None:
    _iv(0xDB34E8D56FC13B08, hudColor, displayOnFoot, followPlayer)

def GET_RENDERED_CHARACTER_HEIGHT(size: float, font: int) -> float:
    return _if(0xDB88A37483346780, size, font)

def SET_WARNING_MESSAGE_WITH_HEADER(entryHeader: str, entryLine1: str, instructionalKey: int, entryLine2: str, p4: bool, p5: int, showBackground: int, p7: int, p8: bool, p9: int) -> None:
    _iv(0xDC38CC1E35B6A5D7, entryHeader, entryLine1, instructionalKey, entryLine2, p4, p5, showBackground, p7, p8, p9)

def GET_MAIN_PLAYER_BLIP_ID() -> int:
    return _ii(0xDCD4EC3F419D02FA)

def SHOW_CREW_INDICATOR_ON_BLIP(blip: int, toggle: bool) -> None:
    _iv(0xDCFB5D4DB8BF367E, blip, toggle)

def IS_SCRIPTED_HUD_COMPONENT_ACTIVE(id: int) -> bool:
    return _ib(0xDD100EB17A94FF65, id)

def SET_MULTIPLAYER_BANK_CASH() -> None:
    _iv(0xDD21B55DF695CD0A)

def DOES_BLIP_HAVE_GPS_ROUTE(blip: int) -> bool:
    return _ib(0xDD2238F57B977751, blip)

def PAUSE_MENU_ACTIVATE_CONTEXT(contextHash: int) -> None:
    _iv(0xDD564BDD0472C936, contextHash)

def END_TEXT_COMMAND_THEFEED_POST_REPLAY_INPUT(type: int, button: str, text: str) -> int:
    return _ii(0xDD6CB2CCE7C2735C, type, button, text)

def PAUSE_MENU_GET_HAIR_COLOUR_INDEX() -> int:
    return _ii(0xDE03620F8703A9DF)

def SET_MP_GAMER_TAG_NAME(gamerTagId: int, string: str) -> None:
    _iv(0xDEA2B8283BAA3944, gamerTagId, string)

def SET_PAUSE_MENU_ACTIVE(toggle: bool) -> None:
    _iv(0xDF47FC56C71569CF, toggle)

def GET_BLIP_COLOUR(blip: int) -> int:
    return _ii(0xDF729E8D20CF7327, blip)

def SET_BLIP_SPRITE(blip: int, spriteId: int) -> None:
    _iv(0xDF735600A4696DAF, blip, spriteId)

def GET_MINIMAP_FOW_DISCOVERY_RATIO() -> float:
    return _if(0xE0130B41D3CF4574)

def BEGIN_TEXT_COMMAND_CLEAR_PRINT(text: str) -> None:
    _iv(0xE124FA80A759019C, text)

def IS_WARNING_MESSAGE_ACTIVE() -> bool:
    return _ib(0xE18B138FABC53103)

def THEFEED_RESUME() -> None:
    _iv(0xE1CD1E48E025E661)

def SET_BLIP_HIGH_DETAIL(blip: int, toggle: bool) -> None:
    _iv(0xE2590BC29220CEBB, blip, toggle)

def HIDE_SCRIPTED_HUD_COMPONENT_THIS_FRAME(id: int) -> None:
    _iv(0xE374C498D8BADC14, id)

def GET_GLOBAL_ACTIONSCRIPT_FLAG(flagIndex: int) -> int:
    return _ii(0xE3B05614DCE1D014, flagIndex)

def IS_BLIP_ON_MINIMAP(blip: int) -> bool:
    return _ib(0xE41CA53051197A27, blip)

def SET_MISSION_NAME_FOR_UGC_MISSION(p0: bool, name: str) -> None:
    _iv(0xE45087D85F468BC2, p0, name)

def ADD_VALID_VEHICLE_HIT_HASH(p0: int) -> None:
    _iv(0xE4C3B169876D33D7, p0)

def SET_PED_AI_BLIP_GANG_ID(ped: int, gangId: int) -> None:
    _iv(0xE52B8E7F85D39A08, ped, gangId)

def ALLOW_DISPLAY_OF_MULTIPLAYER_CASH_TEXT(allow: bool) -> None:
    _iv(0xE67C6DFD386EA5E7, allow)

def CLEAR_GPS_CUSTOM_ROUTE() -> None:
    _iv(0xE6DE0561D9232A64)

def ADD_TEXT_COMPONENT_FLOAT(value: float, decimalPlaces: int) -> None:
    _iv(0xE7DCB5B874BCD96E, value, decimalPlaces)

def SET_RADAR_AS_EXTERIOR_THIS_FRAME() -> None:
    _iv(0xE81B7D2A3DAB2D81)

def RELEASE_NAMED_RENDERTARGET(name: str) -> bool:
    return _ib(0xE9F6FFE837354DD4, name)

def SET_BLIP_NAME_FROM_TEXT_FILE(blip: int, gxtEntry: str) -> None:
    _iv(0xEAA0FFE120D92784, blip, gxtEntry)

def HUD_FORCE_WEAPON_WHEEL(show: bool) -> None:
    _iv(0xEB354E5376BC81A7, show)

def IS_UPDATING_MP_GAMER_TAG_NAME_AND_CREW_DETAILS(gamerTagId: int) -> bool:
    return _ib(0xEB709A36958ABE0D, gamerTagId)

def CLEAR_VALID_VEHICLE_HIT_HASHES() -> None:
    _iv(0xEB81A3DADD503187)

def TAKE_CONTROL_OF_FRONTEND() -> None:
    _iv(0xEC9264727EEC0F28)

def SET_PAUSE_MENU_PED_SLEEP_STATE(state: bool) -> None:
    _iv(0xECF128344E9FF9F1, state)

def FORCE_CLOSE_REPORTUGC_MENU() -> None:
    _iv(0xEE4C0E6DBC6F2C6F)

def SET_ALL_MP_GAMER_TAGS_VISIBILITY(gamerTagId: int, toggle: bool) -> None:
    _iv(0xEE76FF7E6A0166B0, gamerTagId, toggle)

def ACTIVATE_FRONTEND_MENU(menuhash: int, togglePause: bool, component: int) -> None:
    _iv(0xEF01D36B9C9D0C7B, menuhash, togglePause, component)

def GET_MENU_PED_INT_STAT(p0: int, p1: int) -> bool:
    return _ib(0xEF4CED81CEBEDC6D, p0, p1)

def END_TEXT_COMMAND_THEFEED_POST_MPTICKER(blink: bool, p1: bool) -> int:
    return _ii(0xF020C96915705B3A, blink, p1)

def GET_LENGTH_OF_LITERAL_STRING(string: str) -> int:
    return _ii(0xF030907CCBB8A9FD, string)

def PAUSE_MENU_SET_WARN_ON_TAB_CHANGE(p0: bool) -> None:
    _iv(0xF06EBB91A81E09E3, p0)

def ARE_ONLINE_POLICIES_UP_TO_DATE() -> bool:
    return _ib(0xF13FE2A80C05C561)

def SHOW_START_MISSION_INSTRUCTIONAL_BUTTON(toggle: bool) -> None:
    _iv(0xF1A6C18B35BCADE6, toggle)

def HAS_MENU_TRIGGER_EVENT_OCCURRED() -> bool:
    return _ib(0xF284AC67940C6812)

def FLASH_MINIMAP_DISPLAY() -> None:
    _iv(0xF2DD778C22B15BDA)

def REPLACE_HUD_COLOUR_WITH_RGBA(hudColorIndex: int, r: int, g: int, b: int, a: int) -> None:
    _iv(0xF314CF4F0211894E, hudColorIndex, r, g, b, a)

def OVERRIDE_MP_TEXT_CHAT_COLOR(p0: int, hudColor: int) -> None:
    _iv(0xF47E567B3630DD12, p0, hudColor)

def _SHOW_PURCHASE_INSTRUCTIONAL_BUTTON(toggle: bool) -> None:
    _iv(0xF6865E26067B708C, toggle)

def LINK_NAMED_RENDERTARGET(modelHash: int) -> None:
    _iv(0xF6C09E276AEB3F2D, modelHash)

def SETUP_FAKE_CONE_DATA(blip: int, p1: float, p2: float, p3: float, p4: float, p5: float, p6: float, p7: int, p8: int) -> None:
    _iv(0xF83D0FEBE75E62C9, blip, p1, p2, p3, p4, p5, p6, p7, p8)

def SET_BLIP_ROTATION(blip: int, rotation: int) -> None:
    _iv(0xF87683CDF73C3F6E, blip, rotation)

def SET_MINIMAP_HIDE_FOW(toggle: bool) -> None:
    _iv(0xF8DEE0A5600CBB93, toggle)

def BEGIN_TEXT_COMMAND_SET_BLIP_NAME(textLabel: str) -> None:
    _iv(0xF9113A30DE5C6670, textLabel)

def SET_RADAR_ZOOM_TO_BLIP(blip: int, zoom: float) -> None:
    _iv(0xF98E4B3E56AFC7B1, blip, zoom)

def GET_HUD_SCREEN_POSITION_FROM_WORLD_POSITION(worldX: float, worldY: float, worldZ: float, screenX: int, screenY: int) -> int:
    return _ii(0xF9904D11F1ACBEC3, worldX, worldY, worldZ, screenX, screenY)

def GET_BLIP_INFO_ID_COORD(blip: int) -> 'gta.Vector3':
    return _ivec(0xFA7C7F0AADF25D09, blip)

def END_TEXT_COMMAND_CLEAR_PRINT() -> None:
    _iv(0xFCC75460ABA29378)

def SET_PED_AI_BLIP_SPRITE(ped: int, spriteId: int) -> None:
    _iv(0xFCFACD0DB9D7A57D, ped, spriteId)

def SET_MULTIPLAYER_HUD_CASH(p0: int, p1: bool) -> None:
    _iv(0xFD1D220394BCB824, p0, p1)

def THEFEED_PAUSE() -> None:
    _iv(0xFDB423997FA30340)

def THEFEED_RESET_ALL_PARAMETERS() -> None:
    _iv(0xFDD85225B2DEA55E)

def THEFEED_FREEZE_NEXT_POST() -> None:
    _iv(0xFDEC055AB549E328)

def SET_NEW_WAYPOINT(x: float, y: float) -> None:
    _iv(0xFE43368D2AA4F2FC, x, y)

def CLEAR_GPS_PLAYER_WAYPOINT() -> None:
    _iv(0xFF4FB7C8CDFA3DA7)
