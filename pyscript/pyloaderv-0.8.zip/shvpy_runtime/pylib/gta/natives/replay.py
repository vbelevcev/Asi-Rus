"""Auto-generated raw native bindings for namespace REPLAY.

Generated from natives.json — do not edit by hand. Re-run gen_natives.py
to refresh. Idiomatic wrappers live in gta.world, gta.ui, etc.

Each native calls a typed gta._invoke_* fast-path (vectorcall, no kwargs).
"""

import gta
from gta import _invoke_void as _iv, _invoke_bool as _ib


def REPLAY_CONTROL_SHUTDOWN() -> None:
    _iv(0x3353D13F09307691)

def ACTIVATE_ROCKSTAR_EDITOR(p0: int) -> None:
    _iv(0x49DA8145672B2725, p0)

def SET_SCRIPTS_HAVE_CLEANED_UP_FOR_REPLAY_SYSTEM() -> None:
    _iv(0x5AD3932DAEB1E5D3)

def REGISTER_EFFECT_FOR_REPLAY_EDITOR(p0: str, p1: bool) -> None:
    _iv(0x7E2BD3EF6C205F09, p0, p1)

def REPLAY_SYSTEM_HAS_REQUESTED_A_SCRIPT_CLEANUP() -> bool:
    return _ib(0x95AB8B5C992C7B58)

def SET_REPLAY_SYSTEM_PAUSED_FOR_SAVE(p0: bool) -> None:
    _iv(0xE058175F8EAFE79A, p0)
