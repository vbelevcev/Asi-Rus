"""On-screen UI helpers: notifications, subtitles, help text."""

from __future__ import annotations

import gta
from gta.natives.hud import (
    ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME,
    BEGIN_TEXT_COMMAND_DISPLAY_HELP,
    BEGIN_TEXT_COMMAND_PRINT,
    END_TEXT_COMMAND_DISPLAY_HELP,
    END_TEXT_COMMAND_PRINT,
)


def notify(message: str) -> None:
    """Top-left ticker feed. Supports ~r~/~g~/~b~/~y~/~w~/~p~/~o~/~n~ codes."""
    gta.notify(message)


def show_subtitle(message: str, duration_ms: int = 2500) -> None:
    """Subtitle at the bottom of the screen."""
    BEGIN_TEXT_COMMAND_PRINT("STRING")
    ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(message)
    END_TEXT_COMMAND_PRINT(duration_ms, True)


def show_help_text(message: str, beep: bool = False) -> None:
    """Help prompt (e.g. 'Press ~INPUT_PICKUP~ to pick up')."""
    BEGIN_TEXT_COMMAND_DISPLAY_HELP("STRING")
    ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(message)
    END_TEXT_COMMAND_DISPLAY_HELP(0, False, beep, -1)
