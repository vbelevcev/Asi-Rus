"""Player wrapper."""

from __future__ import annotations

from gta.natives.player import (
    GET_PLAYER_WANTED_LEVEL,
    IS_PLAYER_DEAD,
    PLAYER_ID,
    PLAYER_PED_ID,
    SET_PLAYER_WANTED_LEVEL,
    SET_PLAYER_WANTED_LEVEL_NOW,
    SET_POLICE_IGNORE_PLAYER,
)
from gta.ped import Ped


class Player:
    __slots__ = ("id",)

    def __init__(self, player_id: int) -> None:
        self.id = player_id

    def __repr__(self) -> str:
        return f"Player(id={self.id})"

    @property
    def ped(self) -> Ped:
        return Ped(PLAYER_PED_ID())

    @property
    def wanted_level(self) -> int:
        return GET_PLAYER_WANTED_LEVEL(self.id)

    @wanted_level.setter
    def wanted_level(self, level: int) -> None:
        SET_PLAYER_WANTED_LEVEL(self.id, level, False)
        SET_PLAYER_WANTED_LEVEL_NOW(self.id, False)

    @property
    def is_dead(self) -> bool:
        return IS_PLAYER_DEAD(self.id)

    def set_police_ignore(self, ignore: bool) -> None:
        SET_POLICE_IGNORE_PLAYER(self.id, ignore)


def current() -> Player:
    """Return the local Player (the one you're controlling)."""
    return Player(PLAYER_ID())
