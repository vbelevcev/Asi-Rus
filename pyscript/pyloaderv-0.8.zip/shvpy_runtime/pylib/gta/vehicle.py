"""Vehicle wrapper."""

from __future__ import annotations

from gta.entity import Entity
from gta.natives.vehicle import (
    DELETE_VEHICLE,
    GET_PED_IN_VEHICLE_SEAT,
    GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS,
    GET_VEHICLE_NUMBER_OF_PASSENGERS,
    IS_VEHICLE_DRIVEABLE,
    SET_VEHICLE_ENGINE_ON,
    SET_VEHICLE_ON_GROUND_PROPERLY,
)


class Vehicle(Entity):

    @property
    def is_driveable(self) -> bool:
        return IS_VEHICLE_DRIVEABLE(self.handle, False)

    @property
    def passenger_count(self) -> int:
        return GET_VEHICLE_NUMBER_OF_PASSENGERS(self.handle, False, False)

    @property
    def max_passengers(self) -> int:
        return GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS(self.handle)

    def set_engine(self, on: bool, instantly: bool = True) -> None:
        SET_VEHICLE_ENGINE_ON(self.handle, on, instantly, False)

    def place_on_ground(self) -> bool:
        return SET_VEHICLE_ON_GROUND_PROPERLY(self.handle, 5.0)

    def ped_in_seat(self, seat: int):
        """Return Ped in `seat` (-1=driver, 0+=passenger), or None if empty."""
        h = GET_PED_IN_VEHICLE_SEAT(self.handle, seat, False)
        if h == 0:
            return None
        from gta.ped import Ped
        return Ped(h)

    def delete(self) -> None:
        DELETE_VEHICLE(self.handle)
