"""Vector3 math helpers for GTA V scripting."""

from __future__ import annotations

import math as _math

import gta


def distance(a: "gta.Vector3", b: "gta.Vector3") -> float:
    dx, dy, dz = a[0] - b[0], a[1] - b[1], a[2] - b[2]
    return _math.sqrt(dx * dx + dy * dy + dz * dz)


def distance_2d(a: "gta.Vector3", b: "gta.Vector3") -> float:
    dx, dy = a[0] - b[0], a[1] - b[1]
    return _math.sqrt(dx * dx + dy * dy)


def length(v: "gta.Vector3") -> float:
    return _math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])


def add(a: "gta.Vector3", b: "gta.Vector3") -> tuple[float, float, float]:
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def sub(a: "gta.Vector3", b: "gta.Vector3") -> tuple[float, float, float]:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def scale(v: "gta.Vector3", s: float) -> tuple[float, float, float]:
    return (v[0] * s, v[1] * s, v[2] * s)


def offset_around(origin: "gta.Vector3", radius: float, angle_rad: float) -> tuple[float, float, float]:
    """Return `origin` offset by `radius` at `angle_rad` (XY plane, z unchanged)."""
    return (origin[0] + radius * _math.cos(angle_rad),
            origin[1] + radius * _math.sin(angle_rad),
            origin[2])
