"""Ped (non-player character) wrapper."""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from gta.entity import Entity
from gta.natives.ped import (
    IS_PED_IN_ANY_VEHICLE,
    IS_PED_IN_VEHICLE,
    IS_PED_JACKING,
    IS_PED_SHOOTING,
    SET_PED_AS_COP,
    SET_PED_INTO_VEHICLE,
    SET_PED_RELATIONSHIP_GROUP_HASH,
    DELETE_PED,
)
from gta.natives.task import CLEAR_PED_TASKS, TASK_COMBAT_PED
from gta.natives.weapon import GIVE_WEAPON_TO_PED

if TYPE_CHECKING:
    from gta.vehicle import Vehicle


class Ped(Entity):

    def give_weapon(self, weapon_hash: int, ammo: int = 999,
                    hidden: bool = False, equip_now: bool = True) -> None:
        GIVE_WEAPON_TO_PED(self.handle, weapon_hash, ammo, hidden, equip_now)

    def set_as_cop(self, is_cop: bool = True) -> None:
        SET_PED_AS_COP(self.handle, is_cop)

    def set_relationship_group(self, group_hash: int) -> None:
        SET_PED_RELATIONSHIP_GROUP_HASH(self.handle, group_hash)

    def task_combat(self, target: "Ped", combat_flags: int = 0,
                    threat_flags: int = 16) -> None:
        TASK_COMBAT_PED(self.handle, target.handle, combat_flags, threat_flags)

    def clear_tasks(self) -> None:
        CLEAR_PED_TASKS(self.handle)

    def set_into(self, vehicle: "Vehicle", seat: int = -1) -> None:
        """Seat -1 = driver, 0 = front passenger, 1+ = rear seats."""
        SET_PED_INTO_VEHICLE(self.handle, vehicle.handle, seat)

    @property
    def is_shooting(self) -> bool:
        return IS_PED_SHOOTING(self.handle)

    @property
    def is_jacking(self) -> bool:
        return IS_PED_JACKING(self.handle)

    def is_in_vehicle(self, vehicle: Optional["Vehicle"] = None) -> bool:
        if vehicle is None:
            return IS_PED_IN_ANY_VEHICLE(self.handle, False)
        return IS_PED_IN_VEHICLE(self.handle, vehicle.handle, False)

    def delete(self) -> None:
        """Use DELETE_PED to also release model refs."""
        DELETE_PED(self.handle)
