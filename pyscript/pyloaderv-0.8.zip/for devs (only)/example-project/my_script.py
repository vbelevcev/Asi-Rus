#
# Example PyloaderV script (0.8 style).
#
# Drop this file into your GTA V install's pyscript/ folder (next to
# PyloaderV.asi) and launch the game. Press F7 in-game to count peds.
#
# Open THIS folder in VS Code with the Python extension installed and you
# get full autocomplete + type checking for the `gta` module and all its
# submodules (gta.player, gta.world, gta.ped, gta.ui, gta.math, ...).
#

import gta
from gta import player, world, ui


INTERVAL_MS = 500  # on_tick cadence in ms (0 = every frame)


def on_start() -> None:
    """Called once when the script is loaded (or reloaded with F9)."""
    ui.notify("~g~hello ~w~from python")
    gta.log("info", "my_script: started")


def on_tick() -> None:
    """Called every INTERVAL_MS. You can gta.wait(ms) inside here."""
    me = player.current()
    if me.wanted_level >= 4:
        ui.notify("~r~watch out")


def on_key_down(vk: int, down: bool, shift: bool, ctrl: bool, alt: bool) -> None:
    """Runs on SHV's keyboard thread. Do NOT call gta.wait() here."""
    if down and vk == 0x76:  # F7
        peds = world.get_all_peds()
        ui.notify(f"peds in world: {len(peds)}")


def on_aborted() -> None:
    """Called before the script is unloaded (F9 reload, or game shutdown)."""
    gta.log("info", "my_script: stopping")
