# PyloaderV 0.8 — For script developers

This folder does **NOT** need to be copied into your GTA V install. It is only
useful for authoring scripts with autocomplete and type checking in an editor
like VS Code.

---

## Contents

- **`stubs/`** — Type stubs (`.pyi`) for the `gta` module and all its
  submodules: `entity`, `ped`, `vehicle`, `player`, `world`, `ui`, `math`,
  `natives.<namespace>`. Copy these into your own project if you already have
  a scripts folder set up.

- **`example-project/`** — A pre-configured Python project ready to open in
  VS Code. Contains `pyrightconfig.json` + `stubs/` + a starter script
  (`my_script.py`).

---

## How to get autocomplete

1. Install [VS Code](https://code.visualstudio.com).

2. Install Microsoft's **Python** extension (ships with Pylance, which powers
   autocomplete).

3. Open the `example-project/` folder in VS Code:
   `File → Open Folder…` → select this folder.

4. Open `my_script.py`. Type `gta.` — a popup should show every available
   function. Also try `from gta import ` to see the submodules (`player`,
   `world`, `ped`…).

5. Write your script. When ready, copy the `.py` into your GTA V install's
   `pyscript/` folder (next to `PyloaderV.asi`) and launch the game.

> **Tip:** you can work directly inside your `pyscript/` folder by copying
> `pyrightconfig.json` + `stubs/` into it and opening `pyscript/` in VS Code.
> That way editing = testing.

---

## Other editors

The same stubs work with PyCharm, Vim + LSP, Neovim + Pyright, Sublime + LSP,
etc. Point your editor's type-checker at the `stubs/` folder (or add it to
your dev `PYTHONPATH`) and autocomplete will work.

---

## API overview (module `gta`)

### Low-level (module `gta`)

```python
invoke(hash, *args, return_type='int'|'float'|'bool'|'str'|'vector3'|'void')
                                    # call a native
wait(ms=0)                          # yield the script fiber for ms milliseconds
log(level, message)                 # level = 'debug'|'info'|'warn'|'error'
notify(message)                     # in-game ticker (supports ~r~ ~g~ ~b~ etc.)
get_all_vehicles/peds/objects/pickups()  # list[int] — raw handles
game_version()                      # int — eGameVersion enum value
get_global_ptr(id)                  # int — raw pointer to a script global
entity_address(handle)              # int — base address of a native entity
read_float(addr) / read_int(addr)   # raw memory reads (advanced)
```

### High-level (new in 0.6)

```python
gta.player.current() -> Player
    .ped, .wanted_level, .is_dead, .set_police_ignore(bool)

gta.world
    create_ped(model, pos, heading=.., ped_type=..) -> Ped | None
    create_vehicle(model, pos, heading=..) -> Vehicle | None
    load_model(model) / release_model(model)
    get_all_peds() -> list[Ped]
    get_all_vehicles() -> list[Vehicle]

gta.entity.Entity        # position, heading, health, exists,
                         # dismiss(), delete()
gta.ped.Ped(Entity)      # give_weapon, set_as_cop, task_combat,
                         # clear_tasks, set_into, is_shooting, is_jacking,
                         # is_in_vehicle
gta.vehicle.Vehicle(Entity)   # is_driveable, passenger_count,
                              # set_engine, place_on_ground, ped_in_seat

gta.ui
    notify(msg)          # in-game ticker (same as gta.notify)
    show_subtitle(msg, duration_ms=..)
    show_help_text(msg, beep=..)

gta.math
    distance(a, b) / distance_2d(a, b) / length(v)
    add(a, b) / sub(a, b) / scale(v, s)
    offset_around(origin, radius, angle_rad) -> (x, y, z)

gta.natives.<namespace>   # direct access to 6649 auto-generated natives.
                          # Namespaces: PLAYER, PED, VEHICLE, ENTITY,
                          # WEAPON, AI, AUDIO, HUD, CAM, CUTSCENE,
                          # GRAPHICS, STREAMING, WORLDPROBE, ... (45 total)
```

---

## Troubleshooting

**"`gta.invoke()` does not exist" in Pylance:**
Make sure `pyrightconfig.json` is in the root folder you opened in VS Code,
and `stubPath` points to `"stubs"`. Restart Pylance:
`Ctrl+Shift+P` → **Python: Restart Language Server**.