================================================================================
PyloaderV 0.8
Python host for GTA V via ScriptHookV
================================================================================


Requirements:

- GTA V (Legacy or Enhanced)

- ScriptHookV: http://www.dev-c.com/gtav/scripthookv/

- Python: NO install needed — the embedded Python 3.12 runtime is
  already bundled in this zip (shvpy_runtime/ folder).


Installation:

Copy into your GTA V root (the folder containing GTA5.exe) ONLY these:

- PyloaderV.asi
- PyloaderV.ini
- pyscript/            (drop your Python scripts here)
- shvpy_runtime/       (embedded Python 3.12, do not rename)

Do NOT copy the "for devs (only)/" folder into GTA V. It contains
tooling to write scripts with autocomplete in an editor (VS Code
recommended). See "for devs (only)/readme.md" for details.


Description:

PyloaderV lets you write GTA V mods in pure Python.
Drop a .py file into pyscript/, launch the game, done.

If you modify a script, press F9 in-game to reload everything
(key is configurable in the .ini), or enable AutoReload=true to
pick up changes automatically whenever you save a file.

The pyscript/ folder ships with two examples (hello.py, vehicle_demo.py) —
feel free to delete them.


Writing a script (0.8 style, recommended):

    import gta
    from gta import player, world, ui

    INTERVAL_MS = 500

    def on_start():
        ui.notify("~g~hello ~w~from python")

    def on_tick():
        me = player.current()
        gta.log("info", f"wanted={me.wanted_level}")

    def on_key_down(vk, down, shift, ctrl, alt):
        if down and vk == 0x74:  # F5
            ui.notify(f"peds: {len(world.get_all_peds())}")

    def on_aborted():
        pass


Available API:

Module `gta` (low-level):
    invoke(hash, *args, return_type='int')  — call a GTA native
    wait(ms=0)                               — yield for ms ms
    log(level, message)                      — 'debug'|'info'|'warn'|'error'
    notify(message)                          — in-game ticker
    get_all_vehicles/peds/objects/pickups()  — list of handles
    game_version()                           — game version (int)
    get_global_ptr(id)                       — pointer to global
    entity_address(handle)                   — pointer to entity
    read_float(addr) / read_int(addr)        — memory reads

High-level modules:
    gta.player                — current(), Player, wanted_level, ped, ...
    gta.world                 — create_ped, create_vehicle, load_model, ...
    gta.ped                   — Ped: give_weapon, task_combat, set_into, ...
    gta.vehicle               — Vehicle: place_on_ground, set_engine, ...
    gta.entity                — Entity (base): position, heading, health, ...
    gta.ui                    — notify, show_subtitle, show_help_text
    gta.math                  — distance, offset_around, add, sub, scale
    gta.natives.<namespace>   — direct access to all 6649 natives (PLAYER,
                                PED, VEHICLE, ENTITY, AUDIO, HUD, ...)


Installing pip packages:

To use numpy, requests, etc., install them from an external Python:
    py -3.12 -m pip install --target "<GTAV>/shvpy_runtime/Lib/site-packages" numpy
(site-packages is already on the embedded sys.path.)


Logs:
    PyloaderV.log (next to the .asi) — load errors, print() output,
    gta.log() output.


Uninstall:
Delete PyloaderV.asi, PyloaderV.ini, PyloaderV.log,
pyscript/ and shvpy_runtime/ from your GTA V root.